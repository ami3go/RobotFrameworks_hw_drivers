#!/usr/bin/env bash
# Run the Robot Framework examples against the mock instrument.
# Pass --host <ip> to target a real instrument instead.
set -euo pipefail
cd "$(dirname "$0")/.."
exec python3 scripts/run_examples.py "$@"
