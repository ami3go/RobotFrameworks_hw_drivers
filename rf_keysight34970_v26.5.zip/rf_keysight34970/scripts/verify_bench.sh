#!/usr/bin/env bash
# Hardware verification against a real instrument.
#
#   ./scripts/verify_bench.sh 10.0.0.12
#
# Read-only. Output-driving tests are skipped unless you additionally
# pass --allow-output-writes, which should only be done with nothing
# consequential wired to the 34907A.
set -euo pipefail
if [ $# -lt 1 ]; then
  echo "usage: $0 <instrument-ip> [--allow-output-writes]" >&2
  exit 2
fi
HOST="$1"; shift
cd "$(dirname "$0")/.."
exec python3 scripts/run_examples.py --host "$HOST" --hardware "$@"
