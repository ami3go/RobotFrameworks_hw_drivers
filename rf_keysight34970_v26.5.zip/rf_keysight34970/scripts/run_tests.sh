#!/usr/bin/env bash
# Unit and integration tests. Hardware-marked tests are deselected.
set -euo pipefail
cd "$(dirname "$0")/.."
exec python3 -m pytest "$@"
