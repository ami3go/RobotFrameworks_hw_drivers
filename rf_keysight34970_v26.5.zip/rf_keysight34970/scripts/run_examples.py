#!/usr/bin/env python3
"""
Run the Robot Framework example suites.

Against the in-repo mock instrument by default, so the examples work
with no hardware attached. Pass --host to reach a real instrument.

    python scripts/run_examples.py
    python scripts/run_examples.py --host 10.0.0.12
    python scripts/run_examples.py --suite measurement_example.robot
    python scripts/run_examples.py --host 10.0.0.12 --hardware
"""

from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "tests"))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", help="instrument IP; omit to use the mock")
    parser.add_argument("--port", type=int, default=5025)
    parser.add_argument("--suite", help="single suite filename to run")
    parser.add_argument(
        "--hardware",
        action="store_true",
        help="run the hardware verification suites instead of the examples",
    )
    parser.add_argument(
        "--allow-output-writes",
        action="store_true",
        help="permit tests that drive physical output lines (34907A)",
    )
    parser.add_argument("--outputdir", default=str(ROOT / "results"))
    args = parser.parse_args()

    import robot

    target = ROOT / "examples" / "robot"
    if args.hardware:
        target = target / "hardware"
    if args.suite:
        target = target / args.suite
        if not target.exists():
            print(f"no such suite: {target}", file=sys.stderr)
            return 2

    server = None
    host, port = args.host, args.port

    if host is None:
        from mock_instrument import MockScpiServer

        server = MockScpiServer()
        server.start()
        time.sleep(0.2)
        host, port = server.host, server.port
        print(f"No --host given: using the mock instrument on {host}:{port}")
        print("Results are exercise of the driver, NOT of any real hardware.\n")
    else:
        print(f"Running against {host}:{port}\n")

    variables = [f"HOST:{host}", f"PORT:{port}"]
    if args.allow_output_writes:
        if host is not None and server is None:
            print("WARNING: output writes enabled against real hardware.")
            print("Physical lines on the 34907A will be driven.\n")
        variables.append("ALLOW_OUTPUT_WRITES:yes")

    try:
        rc = robot.run(str(target), variable=variables, outputdir=args.outputdir)
    finally:
        if server is not None:
            server.stop()

    print(f"\nReport: {Path(args.outputdir) / 'report.html'}")
    return rc


if __name__ == "__main__":
    raise SystemExit(main())
