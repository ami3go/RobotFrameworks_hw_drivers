"""
Temperature subpackage (Phase 4).

Gate 1 provides the data models and the ``TemperatureEngine``
interface. The concrete engine and its Robot Framework keywords arrive
in Gate 2.
"""

from .base import TemperatureEngine
from .models import (
    PLAUSIBLE_RANGE_C,
    RTD_ALPHA_OPTIONS,
    RTD_NOMINAL_PT100,
    RTD_NOMINAL_PT1000,
    THERMISTOR_NOMINALS,
    ReferenceJunction,
    TemperatureConfig,
    TemperatureUnit,
    ThermocoupleType,
    TransducerType,
    is_plausible,
    to_celsius,
)

__all__ = [
    "TemperatureEngine",
    "TemperatureConfig",
    "TransducerType",
    "ThermocoupleType",
    "ReferenceJunction",
    "TemperatureUnit",
    "PLAUSIBLE_RANGE_C",
    "RTD_ALPHA_OPTIONS",
    "RTD_NOMINAL_PT100",
    "RTD_NOMINAL_PT1000",
    "THERMISTOR_NOMINALS",
    "is_plausible",
    "to_celsius",
]
