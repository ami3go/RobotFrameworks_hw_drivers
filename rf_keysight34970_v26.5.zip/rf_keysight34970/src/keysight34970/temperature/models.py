"""
Temperature data models (Phase 4).

Transducer types, their subtypes, temperature units, and the
configuration that binds them. Pure data with no I/O.

WHY THIS IS ITS OWN SUBSYSTEM: temperature is not just another
measurement function. A thermocouple reading depends on a reference
junction the instrument must be told about; an RTD depends on a
nominal resistance and may need 4-wire connection; a thermistor depends
on its nominal value. Getting any of these wrong yields a number in
degrees that is confidently, silently wrong -- the misattribution class
this driver has produced three times already. The types here exist to
make each of those choices explicit and checkable.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Optional

from ..exceptions import ConfigurationError
from ..measurement.models import Unit


class TransducerType(str, Enum):
    """How temperature is sensed. Values are SCPI mnemonics."""

    THERMOCOUPLE = "TC"
    RTD = "RTD"           # 2-wire RTD
    RTD_4WIRE = "FRTD"    # 4-wire RTD
    THERMISTOR = "THER"

    @property
    def requires_four_wire_pair(self) -> bool:
        """4-wire RTDs consume the paired channel N+10, exactly as
        4-wire resistance does."""

        return self is TransducerType.RTD_4WIRE

    @property
    def is_rtd(self) -> bool:
        return self in {TransducerType.RTD, TransducerType.RTD_4WIRE}


class ThermocoupleType(str, Enum):
    """Thermocouple alloy types supported by the 34970A/34972A.

    The type determines the voltage-to-temperature conversion. Selecting
    the wrong one produces a plausible temperature that is wrong by tens
    of degrees, which is why this has no default.
    """

    B = "B"
    E = "E"
    J = "J"
    K = "K"
    N = "N"
    R = "R"
    S = "S"
    T = "T"


class ReferenceJunction(str, Enum):
    """Where the thermocouple's cold-junction compensation comes from.

    INTERNAL uses the module's own temperature sensor. EXTERNAL assumes
    a known fixed reference temperature the caller supplies. FIXED is
    the instrument's term for a user-specified constant.

    This is the single most common source of a wrong thermocouple
    reading: an uncompensated junction is off by roughly room
    temperature.
    """

    INTERNAL = "INT"
    EXTERNAL = "EXT"
    FIXED = "FIX"


class TemperatureUnit(str, Enum):
    """Units the instrument can report temperature in.

    Values are SCPI mnemonics (``UNIT:TEMP``).
    """

    CELSIUS = "C"
    FAHRENHEIT = "F"
    KELVIN = "K"

    @property
    def measurement_unit(self) -> Unit:
        """The corresponding Phase 2 ``Unit``, so a temperature reading
        carries the unit actually configured rather than an assumed
        Celsius."""

        return {
            TemperatureUnit.CELSIUS: Unit.CELSIUS,
            TemperatureUnit.FAHRENHEIT: Unit.FAHRENHEIT,
            TemperatureUnit.KELVIN: Unit.KELVIN,
        }[self]

    @classmethod
    def parse(cls, value: "TemperatureUnit | str") -> "TemperatureUnit":
        """Accept 'C', 'CELSIUS', 'degC', 'F', 'K', etc."""

        if isinstance(value, TemperatureUnit):
            return value
        text = str(value).strip().upper().removeprefix("DEG")
        aliases = {
            "C": cls.CELSIUS, "CELSIUS": cls.CELSIUS,
            "F": cls.FAHRENHEIT, "FAHRENHEIT": cls.FAHRENHEIT,
            "K": cls.KELVIN, "KELVIN": cls.KELVIN,
        }
        if text in aliases:
            return aliases[text]
        raise ConfigurationError(
            f"Unknown temperature unit {value!r}; expected C, F or K",
            context={"value": str(value)},
        )


# Standard nominal resistances at 0 degrees C.
RTD_NOMINAL_PT100 = 100.0
RTD_NOMINAL_PT1000 = 1000.0

# Standard thermistor nominal resistances at 25 degrees C.
THERMISTOR_NOMINALS = frozenset({2252.0, 5000.0, 10000.0})

# The instrument's RTD alpha (temperature coefficient) options.
RTD_ALPHA_OPTIONS = frozenset({0.00385, 0.00391})


@dataclass(frozen=True)
class TemperatureConfig:
    """A complete temperature measurement configuration.

    Validation is deliberately strict about combinations that are
    silently wrong rather than obviously wrong: a thermocouple with no
    type, an RTD nominal that no standard sensor uses, a fixed reference
    junction with no temperature. Each of those produces a reading, and
    the reading is a lie.
    """

    transducer: TransducerType
    unit: TemperatureUnit = TemperatureUnit.CELSIUS

    # Thermocouple-specific
    thermocouple_type: Optional[ThermocoupleType] = None
    reference_junction: Optional[ReferenceJunction] = None
    fixed_reference_c: Optional[float] = None

    # RTD-specific
    rtd_nominal_ohms: Optional[float] = None
    rtd_alpha: Optional[float] = None
    rtd_reference_ohms: Optional[float] = None
    """Measured 0 C resistance of this specific RTD.

    An RTD's actual R0 differs from its nominal value by enough to shift
    readings by tenths of a degree. Supplying the calibrated figure is
    the difference between a nominally-correct reading and an accurate
    one; leaving it None uses the nominal value.
    """

    # Thermocouple integrity
    open_detect: Optional[bool] = None
    """Enable the instrument's open-junction check.

    A broken thermocouple does not read obviously wrong -- it reads
    something. Open-detect injects a small current to test continuity
    before each reading, and is the instrument's own defence against the
    exact failure this transducer is most prone to. Costs a little
    speed, which is why it is opt-in rather than forced.
    """

    # Thermistor-specific
    thermistor_nominal_ohms: Optional[float] = None

    def __post_init__(self) -> None:
        if self.transducer is TransducerType.THERMOCOUPLE:
            self._validate_thermocouple()
        else:
            if self.thermocouple_type is not None:
                raise ConfigurationError(
                    f"thermocouple_type applies only to thermocouples, not "
                    f"{self.transducer.value}",
                    context={"transducer": self.transducer.value},
                )
            if self.reference_junction is not None:
                raise ConfigurationError(
                    f"reference_junction applies only to thermocouples, not "
                    f"{self.transducer.value}",
                    context={"transducer": self.transducer.value},
                )

        if self.transducer.is_rtd:
            self._validate_rtd()
        elif self.rtd_nominal_ohms is not None or self.rtd_alpha is not None:
            raise ConfigurationError(
                f"RTD settings apply only to RTD transducers, not "
                f"{self.transducer.value}",
                context={"transducer": self.transducer.value},
            )

        if self.transducer is TransducerType.THERMISTOR:
            self._validate_thermistor()
        elif self.thermistor_nominal_ohms is not None:
            raise ConfigurationError(
                f"thermistor_nominal_ohms applies only to thermistors, not "
                f"{self.transducer.value}",
                context={"transducer": self.transducer.value},
            )

        if self.open_detect is not None and (
            self.transducer is not TransducerType.THERMOCOUPLE
        ):
            raise ConfigurationError(
                f"open_detect applies only to thermocouples, not "
                f"{self.transducer.value}. Only a thermocouple has a "
                "junction that can go open.",
                context={"transducer": self.transducer.value},
            )

        if self.rtd_reference_ohms is not None:
            if not self.transducer.is_rtd:
                raise ConfigurationError(
                    f"rtd_reference_ohms applies only to RTDs, not "
                    f"{self.transducer.value}",
                    context={"transducer": self.transducer.value},
                )
            if self.rtd_reference_ohms <= 0:
                raise ConfigurationError(
                    f"rtd_reference_ohms must be > 0, got "
                    f"{self.rtd_reference_ohms}"
                )

    def _validate_thermocouple(self) -> None:
        if self.thermocouple_type is None:
            # No default: the alloy determines the voltage-to-temperature
            # curve, and guessing K would give a confident wrong answer
            # for any other type.
            raise ConfigurationError(
                "thermocouple_type is required for a thermocouple; the alloy "
                "determines the conversion and there is no safe default"
            )

        junction = self.reference_junction
        if junction is ReferenceJunction.FIXED:
            if self.fixed_reference_c is None:
                raise ConfigurationError(
                    "reference_junction=FIXED requires fixed_reference_c; "
                    "an uncompensated junction is wrong by roughly room "
                    "temperature"
                )
            if not (-273.15 <= self.fixed_reference_c <= 1000.0):
                raise ConfigurationError(
                    f"fixed_reference_c of {self.fixed_reference_c} is "
                    "outside a physically plausible range"
                )
        elif self.fixed_reference_c is not None:
            raise ConfigurationError(
                "fixed_reference_c applies only to "
                "reference_junction=FIXED; setting it otherwise would have "
                "no effect and the reading would be compensated differently "
                "than intended"
            )

    def _validate_rtd(self) -> None:
        if self.rtd_nominal_ohms is not None and self.rtd_nominal_ohms <= 0:
            raise ConfigurationError(
                f"rtd_nominal_ohms must be positive, got "
                f"{self.rtd_nominal_ohms}"
            )
        if self.rtd_alpha is not None and self.rtd_alpha not in RTD_ALPHA_OPTIONS:
            raise ConfigurationError(
                f"rtd_alpha must be one of "
                f"{sorted(RTD_ALPHA_OPTIONS)}, got {self.rtd_alpha}",
                context={"rtd_alpha": self.rtd_alpha},
            )

    def _validate_thermistor(self) -> None:
        if self.thermistor_nominal_ohms is None:
            raise ConfigurationError(
                "thermistor_nominal_ohms is required for a thermistor; "
                f"standard values are {sorted(THERMISTOR_NOMINALS)}"
            )
        if self.thermistor_nominal_ohms not in THERMISTOR_NOMINALS:
            raise ConfigurationError(
                f"thermistor_nominal_ohms of {self.thermistor_nominal_ohms} "
                f"is not a standard value {sorted(THERMISTOR_NOMINALS)}; the "
                "instrument's conversion assumes one of these curves",
                context={"nominal": self.thermistor_nominal_ohms},
            )

    @property
    def measurement_unit(self) -> Unit:
        return self.unit.measurement_unit

    def describe(self) -> str:
        """Human-readable summary for logs and failure messages."""

        if self.transducer is TransducerType.THERMOCOUPLE:
            detail = f"type {self.thermocouple_type.value} thermocouple"
            if self.reference_junction is not None:
                detail += f", {self.reference_junction.value} reference"
        elif self.transducer.is_rtd:
            wires = 4 if self.transducer.requires_four_wire_pair else 2
            nominal = self.rtd_nominal_ohms or RTD_NOMINAL_PT100
            detail = f"{wires}-wire RTD, {nominal:g} ohm nominal"
        else:
            detail = f"{self.thermistor_nominal_ohms:g} ohm thermistor"
        return f"{detail}, reading in {self.unit.value}"


# Rough validity envelopes per transducer, in degrees Celsius. Used to
# flag a reading that is physically implausible for the configured
# sensor -- a common symptom of a wrong thermocouple type or an open
# junction, both of which otherwise return believable numbers.
PLAUSIBLE_RANGE_C: dict[TransducerType, tuple[float, float]] = {
    # Union across all alloys; only used when the alloy is unknown.
    TransducerType.THERMOCOUPLE: (-270.0, 1820.0),
    TransducerType.RTD: (-200.0, 850.0),
    TransducerType.RTD_4WIRE: (-200.0, 850.0),
    TransducerType.THERMISTOR: (-80.0, 150.0),
}

# Per-alloy envelopes, in degrees Celsius. The union range above spans
# every alloy, so a type-T thermocouple reading 1500 C -- far beyond
# what type T can physically measure -- passed as plausible. Narrowing
# per alloy is what makes the check able to catch a wrong-type
# configuration rather than only a fully open junction.
#
# Values follow published thermocouple ranges. NOT hardware-verified.
THERMOCOUPLE_RANGE_C: dict["ThermocoupleType", tuple[float, float]] = {
    ThermocoupleType.B: (250.0, 1820.0),
    ThermocoupleType.E: (-270.0, 1000.0),
    ThermocoupleType.J: (-210.0, 1200.0),
    ThermocoupleType.K: (-270.0, 1372.0),
    ThermocoupleType.N: (-270.0, 1300.0),
    ThermocoupleType.R: (-50.0, 1768.0),
    ThermocoupleType.S: (-50.0, 1768.0),
    ThermocoupleType.T: (-270.0, 400.0),
}


def plausible_range_for(config: "TemperatureConfig") -> tuple[float, float]:
    """The validity envelope for a specific configuration.

    Uses the per-alloy range when the transducer is a thermocouple whose
    alloy is known, falling back to the transducer-wide union otherwise.
    """

    # Direct attribute access, deliberately. A getattr() with a default
    # would silently fall back to the wider union range if the field
    # were ever renamed -- turning a precise check into a permissive one
    # with no error. Failing loudly is the safer degradation for a check
    # whose whole job is catching a misconfigured sensor.
    if (
        config.transducer is TransducerType.THERMOCOUPLE
        and config.thermocouple_type is not None
    ):
        return THERMOCOUPLE_RANGE_C[config.thermocouple_type]
    return PLAUSIBLE_RANGE_C[config.transducer]


def to_celsius(value: float, unit: TemperatureUnit) -> float:
    """Convert a reading to Celsius for range checking."""

    if unit is TemperatureUnit.CELSIUS:
        return value
    if unit is TemperatureUnit.FAHRENHEIT:
        return (value - 32.0) * 5.0 / 9.0
    return value - 273.15


def is_plausible(value: float, config: TemperatureConfig) -> bool:
    """Whether a reading falls within the configured sensor's range.

    Not a correctness guarantee -- a wrong thermocouple type usually
    still gives an in-range number. It catches the grosser failures:
    open junctions, disconnected sensors, and unit confusion.
    """

    low, high = plausible_range_for(config)
    return low <= to_celsius(value, config.unit) <= high
