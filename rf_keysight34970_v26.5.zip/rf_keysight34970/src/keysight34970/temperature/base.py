"""
Temperature engine interface (Phase 4, Gate 1).

Defines the contract Gate 2 implements.

The split mirrors the instrument: configuring a transducer is separate
from reading it, because transducer configuration is expensive to
repeat and persists on the channel, while a reading is cheap. It also
mirrors the Phase 2 measurement engine deliberately, so a user who
knows one knows the other.
"""

from __future__ import annotations

import abc
from typing import Optional, Sequence

from ..measurement.channels import ChannelList
from ..measurement.models import Measurement
from .models import TemperatureConfig, TemperatureUnit


class TemperatureEngine(abc.ABC):
    """Contract for configuring and reading temperature channels."""

    @abc.abstractmethod
    def configure(self, channels: ChannelList, config: TemperatureConfig) -> None:
        """Configure a temperature transducer on the given channels.

        Raises:
            ConfigurationError: if the transducer cannot be used on
                those channels (no DMM path, missing 4-wire pair).
            StateError: if no connection is active.
            CommandError: if the instrument rejects the configuration.
        """

    @abc.abstractmethod
    def read(self, channels: ChannelList | None = None) -> Sequence[Measurement]:
        """Read configured temperature channels.

        Readings carry the unit that was actually configured, not an
        assumed Celsius.
        """

    @abc.abstractmethod
    def measure(
        self, channels: ChannelList, config: TemperatureConfig
    ) -> Sequence[Measurement]:
        """Configure and read in one operation."""

    @abc.abstractmethod
    def set_unit(self, unit: TemperatureUnit, channels: ChannelList | None = None) -> None:
        """Change the reported temperature unit.

        Applies to channels rather than globally, because the instrument
        stores the unit per channel and a bench may legitimately mix
        them.
        """

    @abc.abstractmethod
    def get_configuration(
        self, channel: "ChannelList | str | int"
    ) -> Optional[TemperatureConfig]:
        """Return the temperature configuration the driver applied to a
        channel, or None. Driver-side state; no instrument round trip."""

    @abc.abstractmethod
    def read_reference_junction(self) -> Measurement:
        """Read the internal reference junction temperature.

        Worth exposing directly: when thermocouple readings look wrong,
        this distinguishes a bad junction reference from a wrong
        thermocouple type, and the two have completely different fixes.
        """
