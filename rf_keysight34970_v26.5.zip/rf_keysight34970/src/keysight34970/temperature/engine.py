"""
SCPI implementation of the TemperatureEngine interface (Phase 4, Gate 2).

Owns no I/O: every interaction goes through the Phase 1 ``Connection``,
inheriting its error-queue policy.

SCPI model used here::

    CONF:TEMP <transducer>,<type>,(@ch)   configure a temperature channel
    UNIT:TEMP C|F|K,(@ch)                 reported unit, per channel
    SENS:TEMP:TRAN:TC:RJUN:TYPE INT|EXT|FIX,(@ch)
    SENS:TEMP:TRAN:TC:RJUN <celsius>,(@ch)
    SENS:TEMP:TRAN:RTD:RES <ohms>,(@ch)   nominal R0
    SENS:TEMP:TRAN:RTD:ALPH <alpha>,(@ch)
    SENS:TEMP:TRAN:THER:TYPE <ohms>,(@ch)
    SYST:TEMP?                            internal reference junction
    READ? / MEAS:TEMP?                    readings

Ordering matters: ``CONF:TEMP`` establishes the transducer, and the
``SENS:TEMP:TRAN:*`` subsystems are keyed by it. Sending a
junction-reference command before the channel is a thermocouple is
rejected by the instrument, so configuration is always applied in this
order.

VERIFICATION STATUS: sequencing follows the published programmer's
reference and is exercised against the in-repo mock. NOT verified
against physical hardware or a real sensor.
"""

from __future__ import annotations

from typing import Optional, Sequence

from ..connection import Connection
from ..exceptions import ConfigurationError
from ..logging_config import get_logger
from ..measurement.channels import CARD_SPECS, CardType, ChannelId, ChannelList
from ..measurement.engine import ScpiMeasurementEngine
from ..measurement.models import Measurement, MeasurementFunction, Unit
from ..measurement.parsing import parse_readings
from .base import TemperatureEngine
from .models import (
    ReferenceJunction,
    TemperatureConfig,
    TemperatureUnit,
    TransducerType,
    is_plausible,
)


def _ascending(channels: ChannelList) -> ChannelList:
    """Sort channels ascending before submission.

    Same reasoning as the Phase 2 measurement engine: readings are
    matched to channels positionally and the mainframe scans ascending
    regardless of list order, so a non-ascending list would misattribute
    every reading while keeping the count correct.
    """

    return ChannelList(sorted(channels, key=lambda c: c.address))


class ScpiTemperatureEngine(TemperatureEngine):
    """Temperature engine driving a 34970A/34972A over SCPI."""

    def __init__(
        self,
        connection: Connection,
        *,
        measurement_engine: Optional[ScpiMeasurementEngine] = None,
    ) -> None:
        """
        Args:
            measurement_engine: optional. Supplies installed-card
                knowledge for channel validation and shares the
                per-channel configuration record, so a channel
                configured for temperature is visible to scanning.
        """

        self._connection = connection
        self._measurement = measurement_engine
        self._configured: dict[int, TemperatureConfig] = {}
        # Unit applied to channels configured from now on, when set
        # before any channel exists.
        self._default_unit: Optional[TemperatureUnit] = None
        self._log = get_logger(connection.config.display_name())

    # -- TemperatureEngine -----------------------------------------

    def configure(self, channels: ChannelList, config: TemperatureConfig) -> None:
        channels = ChannelList.parse(channels)
        self._validate(channels, config)
        target = _ascending(channels)
        scpi = target.to_scpi()

        # CONF:TEMP first: the SENS:TEMP:TRAN:* subsystems are keyed by
        # the transducer, and the instrument rejects them otherwise.
        probe = self._probe_argument(config)
        self._connection.write(f"CONF:TEMP {config.transducer.value},{probe},{scpi}")

        self._apply_transducer_settings(target, config)
        self._connection.write(f"UNIT:TEMP {config.unit.value},{scpi}")

        for channel in target:
            self._configured[channel.address] = config
            # Mirror into the measurement engine so scanning tags these
            # channels as TEMPERATURE rather than treating them as
            # unconfigured.
            if self._measurement is not None:
                self._measurement.record_external_configuration(
                    channel.address, self._temperature_measurement_config()
                )

        self._log.info("Configured %s on %s", config.describe(), scpi)

    def read(self, channels: ChannelList | None = None) -> Sequence[Measurement]:
        target = _ascending(self._resolve_target(channels))

        self._connection.write(f"ROUT:SCAN {target.to_scpi()}")
        response = self._connection.query("READ?")
        return self._parse(response, target)

    def measure(
        self, channels: ChannelList, config: TemperatureConfig
    ) -> Sequence[Measurement]:
        self.configure(channels, config)
        return self.read(channels)

    def set_unit(
        self, unit: TemperatureUnit, channels: ChannelList | None = None
    ) -> None:
        resolved = TemperatureUnit.parse(unit)

        # Setting the unit before configuring any channel is legitimate:
        # it is a session preference, and a suite that sets it in setup
        # or restores it in teardown should not have to know whether a
        # channel happens to be configured at that moment.
        #
        # Previously this went through _resolve_target(), which raised
        # "No temperature channels have been configured; call configure()
        # before read()" -- an error about reading, raised by a write,
        # naming a precondition this operation does not have. Found by
        # the hardware verification suite, where a teardown restoring the
        # unit failed on a skipped test.
        if channels is None and not self._configured:
            self._default_unit = resolved
            self._log.info(
                "Temperature unit set to %s; will apply to channels "
                "configured from now on",
                resolved.value,
            )
            return

        target = _ascending(self._resolve_target(channels))
        self._connection.write(f"UNIT:TEMP {resolved.value},{target.to_scpi()}")
        self._default_unit = resolved

        # Keep the driver's record truthful: a reading fetched after this
        # must not still claim the old unit.
        from dataclasses import replace

        for channel in target:
            existing = self._configured.get(channel.address)
            if existing is not None:
                self._configured[channel.address] = replace(existing, unit=resolved)

    def get_configuration(
        self, channel: "ChannelList | str | int"
    ) -> Optional[TemperatureConfig]:
        resolved = ChannelId.parse(
            channel if not isinstance(channel, ChannelList) else next(iter(channel))
        )
        return self._configured.get(resolved.address)

    def read_reference_junction(self) -> Measurement:
        """Read the internal reference junction temperature.

        Always reported in Celsius by the instrument regardless of the
        configured display unit, so the unit is fixed here rather than
        taken from a channel configuration.
        """

        response = self._connection.query("SYST:TEMP?")
        readings = parse_readings(
            response, MeasurementFunction.TEMPERATURE, unit=Unit.CELSIUS
        )
        return readings[0]

    # -- helpers ---------------------------------------------------

    def implausible_readings(
        self, measurements: Sequence[Measurement]
    ) -> list[Measurement]:
        """Readings outside the configured transducer's physical range.

        A wrong thermocouple type usually still reads in range, so this
        does not verify correctness. It catches open junctions,
        disconnected sensors and unit confusion, which produce wild
        values that would otherwise be recorded as data.
        """

        flagged: list[Measurement] = []
        for measurement in measurements:
            if measurement.channel is None:
                continue
            config = self._configured.get(measurement.channel.address)
            if config is None:
                continue
            if measurement.is_overrange or not is_plausible(measurement.value, config):
                flagged.append(measurement)
        return flagged

    def _temperature_measurement_config(self):
        from ..measurement.models import MeasurementConfig

        return MeasurementConfig(function=MeasurementFunction.TEMPERATURE)

    def _probe_argument(self, config: TemperatureConfig) -> str:
        """The probe-type argument of ``CONF:TEMP <transducer>,<type>``."""

        if config.transducer is TransducerType.THERMOCOUPLE:
            return config.thermocouple_type.value
        if config.transducer.is_rtd:
            return f"{config.rtd_nominal_ohms:g}" if config.rtd_nominal_ohms else "85"
        return f"{config.thermistor_nominal_ohms:g}"

    def _apply_transducer_settings(
        self, channels: ChannelList, config: TemperatureConfig
    ) -> None:
        scpi = channels.to_scpi()
        transducer = config.transducer.value

        if config.transducer is TransducerType.THERMOCOUPLE:
            if config.reference_junction is not None:
                self._connection.write(
                    f"SENS:TEMP:TRAN:TC:RJUN:TYPE "
                    f"{config.reference_junction.value},{scpi}"
                )
                if config.reference_junction is ReferenceJunction.FIXED:
                    self._connection.write(
                        f"SENS:TEMP:TRAN:TC:RJUN "
                        f"{config.fixed_reference_c:g},{scpi}"
                    )
            if config.open_detect is not None:
                # The instrument's own defence against an open junction,
                # which otherwise returns a believable number rather
                # than an error.
                self._connection.write(
                    f"SENS:TEMP:TRAN:TC:CHEC "
                    f"{'ON' if config.open_detect else 'OFF'},{scpi}"
                )
        elif config.transducer.is_rtd:
            if config.rtd_nominal_ohms is not None:
                self._connection.write(
                    f"SENS:TEMP:TRAN:{transducer}:RES "
                    f"{config.rtd_nominal_ohms:g},{scpi}"
                )
            if config.rtd_alpha is not None:
                self._connection.write(
                    f"SENS:TEMP:TRAN:{transducer}:ALPH "
                    f"{config.rtd_alpha:g},{scpi}"
                )
            if config.rtd_reference_ohms is not None:
                # This sensor's calibrated 0 C resistance. Distinct from
                # the nominal R0 above: nominal says "this is a PT100",
                # this says "this particular PT100 is 100.02 ohms".
                self._connection.write(
                    f"SENS:TEMP:TRAN:{transducer}:RES:REF "
                    f"{config.rtd_reference_ohms:g},{scpi}"
                )

    def _resolve_target(self, channels: ChannelList | None) -> ChannelList:
        if channels is not None:
            target = ChannelList.parse(channels)
            if not len(target):
                raise ConfigurationError("Cannot read from an empty channel list")
            unconfigured = [
                c.address for c in target if c.address not in self._configured
            ]
            if unconfigured:
                raise ConfigurationError(
                    f"Channel(s) {unconfigured} are not configured for "
                    "temperature; call configure() first",
                    context={"unconfigured": unconfigured},
                )
            return target

        if not self._configured:
            raise ConfigurationError(
                "No temperature channels have been configured; call "
                "configure() before read()"
            )
        return ChannelList(list(self._configured.keys()))

    def _parse(self, response: str, target: ChannelList) -> Sequence[Measurement]:
        """Parse readings, tagging each with its own channel's unit.

        Channels may legitimately be configured in different units, so a
        single unit for the whole response would mislabel some of them.
        """

        channel_list = list(target)
        units = {
            self._configured[c.address].measurement_unit
            for c in channel_list
            if c.address in self._configured
        }

        if len(units) == 1:
            return parse_readings(
                response,
                MeasurementFunction.TEMPERATURE,
                target,
                unit=units.pop(),
            )

        parsed = parse_readings(response, MeasurementFunction.TEMPERATURE, target)
        retagged: list[Measurement] = []
        for measurement, channel in zip(parsed, channel_list):
            config = self._configured[channel.address]
            retagged.append(
                Measurement(
                    value=measurement.value,
                    unit=config.measurement_unit,
                    function=MeasurementFunction.TEMPERATURE,
                    channel=channel,
                    timestamp=measurement.timestamp,
                    raw=measurement.raw,
                )
            )
        return retagged

    def _validate(self, channels: ChannelList, config: TemperatureConfig) -> None:
        if not len(channels):
            raise ConfigurationError("Cannot configure an empty channel list")

        cards = self._measurement.cards if self._measurement is not None else {}
        channels.validate_against(cards)

        for channel in channels:
            if channel.slot not in cards:
                continue
            card = cards[channel.slot]
            spec = CARD_SPECS[card]
            if not spec.supports_measurement(channel.channel):
                raise ConfigurationError(
                    f"Channel {channel} on the {card.value} in slot "
                    f"{channel.slot} cannot be routed to the internal DMM, so "
                    "it cannot measure temperature",
                    context={"channel": channel.address, "card": card.value},
                )

        if config.transducer.requires_four_wire_pair:
            self._validate_four_wire(channels, cards)

    def _validate_four_wire(
        self, channels: ChannelList, cards: dict[int, CardType]
    ) -> None:
        """A 4-wire RTD consumes channel N+10, exactly as 4-wire
        resistance does. Reuses the Phase 2 rule rather than restating
        it, so the two cannot drift apart."""

        for channel in channels:
            try:
                paired = ChannelId(slot=channel.slot, channel=channel.channel + 10)
            except ConfigurationError as exc:
                raise ConfigurationError(
                    f"4-wire RTD on {channel} requires paired channel "
                    f"{channel.channel + 10}, which is out of range",
                    context={"channel": channel.address},
                ) from exc

            if channel.slot in cards:
                spec = CARD_SPECS[cards[channel.slot]]
                if paired.channel not in spec.valid_channels:
                    raise ConfigurationError(
                        f"4-wire RTD on {channel} requires paired channel "
                        f"{paired}, which does not exist on the "
                        f"{cards[channel.slot].value}",
                        context={"channel": channel.address},
                    )

            if paired.address in self._configured:
                raise ConfigurationError(
                    f"4-wire RTD on {channel} needs paired channel {paired}, "
                    f"but {paired} is already configured for temperature. "
                    "Choose another channel.",
                    context={"channel": channel.address, "paired": paired.address},
                )
