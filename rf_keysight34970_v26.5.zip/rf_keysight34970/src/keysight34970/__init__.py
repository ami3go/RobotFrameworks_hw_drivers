"""
keysight34970 - Robot Framework driver for the Keysight/Agilent 34970A
and 34972A Data Acquisition / Switch Unit mainframes.

This package follows the RFDS Driver Implementation Lifecycle v1.1.
See docs/architecture.md for the current phase/gate status.
"""

__version__ = "26.05.05"

from .exceptions import (
    Keysight34970Error,
    ConnectionError34970,
    TransportError,
    CommandError,
    TimeoutError34970,
    ConfigurationError,
    StateError,
)
from .config import (
    TransportKind,
    ConnectionConfig,
    InstrumentModel,
)
from .connection import Connection, ConnectionState
from .library import Keysight34970

__all__ = [
    "Keysight34970",
    "__version__",
    "Keysight34970Error",
    "ConnectionError34970",
    "TransportError",
    "CommandError",
    "TimeoutError34970",
    "ConfigurationError",
    "StateError",
    "TransportKind",
    "ConnectionConfig",
    "InstrumentModel",
    "Connection",
    "ConnectionState",
]
