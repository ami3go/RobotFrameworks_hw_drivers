"""
Core data models shared across the driver.

Phase 1 defines only ``InstrumentIdentity`` and ``ScpiError``, which the
connection framework needs. Measurement, ScanChannel, AlarmEvent, and
other domain models are introduced in Phases 2, 3, and 6 respectively,
as dataclasses in their own modules so this file does not become a
dumping ground.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class InstrumentIdentity:
    """Parsed result of a SCPI ``*IDN?`` query."""

    manufacturer: str
    model: str
    serial_number: str
    firmware_version: str
    raw: str

    @classmethod
    def parse(cls, raw_idn: str) -> "InstrumentIdentity":
        """Parse a standard SCPI IDN response of the form
        ``<manufacturer>,<model>,<serial>,<firmware>``.

        Falls back to storing best-effort fields (rather than raising)
        if the instrument returns a non-conformant response, since
        *IDN? formatting is not perfectly standardized across firmware
        revisions.
        """

        parts = [p.strip() for p in raw_idn.split(",")]
        parts += [""] * (4 - len(parts))  # pad so indexing never fails
        return cls(
            manufacturer=parts[0],
            model=parts[1],
            serial_number=parts[2],
            firmware_version=parts[3],
            raw=raw_idn,
        )


@dataclass(frozen=True)
class ScpiError:
    """A single entry from the instrument's SCPI error queue
    (``SYST:ERR?``)."""

    code: int
    message: str

    @classmethod
    def parse(cls, raw_error: str) -> "ScpiError":
        """Parse a SYST:ERR? response of the form ``<code>,"<message>"``."""

        code_str, _, message = raw_error.partition(",")
        message = message.strip().strip('"')
        try:
            code = int(code_str.strip())
        except ValueError:
            code = 0
        return cls(code=code, message=message)

    @property
    def is_no_error(self) -> bool:
        """SCPI convention: error code 0 means the queue is empty."""
        return self.code == 0
