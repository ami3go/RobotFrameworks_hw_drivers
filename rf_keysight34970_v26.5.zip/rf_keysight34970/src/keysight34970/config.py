"""
Configuration data models for the keysight34970 driver.

Phase 1 scope: enough configuration surface to establish and manage a
connection. Measurement/scan/alarm configuration is added in later
phases (2, 3, 6) and will extend, not replace, these models.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from .exceptions import ConfigurationError


class TransportKind(str, Enum):
    """Supported physical transports to reach the instrument."""

    VISA = "VISA"          # GPIB, USB-TMC, or LAN via a VISA resource string
    TCP_SOCKET = "TCP"     # Raw SCPI-over-LAN socket (instrument's SCPI port)


class InstrumentModel(str, Enum):
    """Supported mainframe models. Distinguishes slot/card capabilities
    that later phases (Scanner Engine, Digital I/O) depend on."""

    DAQ_34970A = "34970A"
    DAQ_34972A = "34972A"


DEFAULT_SCPI_PORT = 5025
DEFAULT_TIMEOUT_S = 5.0
DEFAULT_STABILIZATION_DELAY_S = 0.0


@dataclass
class ConnectionConfig:
    """Describes how to reach and manage a single instrument connection.

    Exactly one addressing scheme must be provided depending on
    ``transport``:

    - VISA:       ``visa_resource`` (e.g. "TCPIP0::10.0.0.5::inst0::INSTR",
                  "GPIB0::9::INSTR", "USB0::0x0957::0x2007::MY12345678::INSTR")
    - TCP_SOCKET: ``host`` and ``port``
    """

    transport: TransportKind
    model: InstrumentModel

    visa_resource: Optional[str] = None
    host: Optional[str] = None
    port: int = DEFAULT_SCPI_PORT

    timeout_s: float = DEFAULT_TIMEOUT_S
    stabilization_delay_s: float = DEFAULT_STABILIZATION_DELAY_S

    identify_on_connect: bool = True
    clear_on_connect: bool = True
    reset_on_connect: bool = False
    verify_model: bool = True
    """If True (default), connect() compares the model reported by
    *IDN? against the configured `model` and raises ConfigurationError
    on mismatch. Guards against a bench misconfiguration where e.g. a
    34970A is addressed with 34972A-specific slot assumptions from
    later phases. Requires identify_on_connect=True to take effect."""

    terminator: str = "\n"
    """Line terminator appended to outgoing SCPI commands and expected
    at the end of responses (TCP_SOCKET transport only; VISA transports
    manage termination via the VISA resource's own read/write
    termination settings)."""

    alias: Optional[str] = None
    """Human-readable name used in logs and Robot Framework reports so
    multi-instrument benches (see RFDS-018) can distinguish units."""

    extra: dict = field(default_factory=dict)
    """Escape hatch for transport-specific options that don't yet have a
    first-class field, without breaking API compatibility."""

    def validate(self) -> None:
        """Raise ConfigurationError if this configuration is internally
        inconsistent. Called by Connection before opening a transport."""

        if self.transport == TransportKind.VISA:
            if not self.visa_resource or not self.visa_resource.strip():
                raise ConfigurationError(
                    "visa_resource is required when transport is VISA",
                    context={"transport": self.transport.value},
                )
        elif self.transport == TransportKind.TCP_SOCKET:
            if not self.host or not self.host.strip():
                raise ConfigurationError(
                    "host is required when transport is TCP_SOCKET",
                    context={"transport": self.transport.value},
                )
            if not (0 < self.port < 65536):
                raise ConfigurationError(
                    f"port {self.port} is out of valid range 1-65535",
                    context={"transport": self.transport.value, "port": self.port},
                )
            if not self.terminator:
                raise ConfigurationError(
                    "terminator must be a non-empty string for TCP_SOCKET transport"
                )
        else:  # pragma: no cover - defensive, Enum restricts values
            raise ConfigurationError(
                f"Unsupported transport kind: {self.transport!r}"
            )

        if self.timeout_s <= 0:
            raise ConfigurationError(
                f"timeout_s must be > 0, got {self.timeout_s}"
            )
        if self.stabilization_delay_s < 0:
            raise ConfigurationError(
                f"stabilization_delay_s must be >= 0, got "
                f"{self.stabilization_delay_s}"
            )

    def display_name(self) -> str:
        """Best-effort human-readable identifier for logs, independent of
        whether an alias was configured."""

        if self.alias:
            return self.alias
        if self.transport == TransportKind.VISA:
            return self.visa_resource or "VISA:<unset>"
        return f"{self.host}:{self.port}"
