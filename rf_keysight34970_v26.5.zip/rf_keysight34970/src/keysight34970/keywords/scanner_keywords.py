"""
Scanner keyword mixin (Phase 3, Gate 2).

Keywords for configuring, running and retrieving scans. The engine is
built lazily from the active connection, and is handed the measurement
engine so scan readings inherit each channel's configured function.
"""

from __future__ import annotations

from typing import Optional

from robot.api.deco import keyword

from ..measurement.channels import ChannelList
from ..scanner.engine import ScpiScannerEngine
from ..scanner.models import ScanConfig, ScanResult, TriggerCount, TriggerSource

CAPABILITY_METADATA: dict[str, dict] = {
    "Configure Scan": {
        "risk_level": "low",
        "blocking": False,
        "notes": "Defines the scan list and trigger behaviour; does not start it.",
        "exclusive_resources": ["instrument_session"],
    },
    "Start Scan": {
        "risk_level": "medium",
        "blocking": False,
        "notes": "Arms the scan and returns immediately; the instrument keeps scanning.",
        "exclusive_resources": ["instrument_session", "internal_dmm"],
    },
    "Abort Scan": {
        "risk_level": "low",
        "blocking": False,
        "notes": "Safe when no scan is running.",
        "exclusive_resources": ["instrument_session"],
    },
    "Wait For Scan": {
        "risk_level": "low",
        "blocking": True,
        "notes": "Refuses to wait on scans that cannot self-complete.",
        "exclusive_resources": [],
    },
    "Run Scan": {
        "risk_level": "medium",
        "blocking": True,
        "notes": "Configure, arm, wait and fetch in one call.",
        "exclusive_resources": ["instrument_session", "internal_dmm"],
    },
    "Fetch Scan Readings": {
        "risk_level": "low",
        "blocking": True,
        "notes": "Retrieves whatever is in memory; may be a partial scan.",
        "exclusive_resources": ["instrument_session"],
    },
    "Get Scan Reading Count": {
        "risk_level": "low",
        "blocking": False,
        "notes": "Readings currently held in instrument memory.",
        "exclusive_resources": ["instrument_session"],
    },
    "Get Scan Readings For Channel": {
        "risk_level": "low",
        "blocking": True,
        "notes": "Slices the last fetched scan by channel.",
        "exclusive_resources": [],
    },
    "Start Monitoring Channel": {
        "risk_level": "low",
        "blocking": False,
        "notes": "Continuous single-channel monitoring; readings do NOT accumulate in memory.",
        "exclusive_resources": ["instrument_session", "internal_dmm"],
    },
    "Stop Monitoring": {
        "risk_level": "low",
        "blocking": False,
        "notes": "Safe whether or not monitoring is active.",
        "exclusive_resources": ["instrument_session"],
    },
    "Read Monitored Channel": {
        "risk_level": "low",
        "blocking": True,
        "notes": "Returns the most recent monitored reading only.",
        "exclusive_resources": ["instrument_session", "internal_dmm"],
    },
    "Get Channel Statistics": {
        "risk_level": "low",
        "blocking": True,
        "notes": "Instrument-computed statistics for one channel.",
        "exclusive_resources": ["instrument_session"],
    },
    "Clear Instrument Statistics": {
        "risk_level": "low",
        "blocking": False,
        "notes": "Statistics accumulate across scans unless cleared.",
        "exclusive_resources": ["instrument_session"],
    },
    "Get Instrument Statistics": {
        "risk_level": "low",
        "blocking": True,
        "notes": "Reads the instrument's own CALC registers, not driver-computed.",
        "exclusive_resources": ["instrument_session"],
    },
}


def _parse_trigger_source(value: str) -> TriggerSource:
    text = str(value).strip().upper()
    aliases = {
        "IMMEDIATE": TriggerSource.IMMEDIATE,
        "IMM": TriggerSource.IMMEDIATE,
        "EXTERNAL": TriggerSource.EXTERNAL,
        "EXT": TriggerSource.EXTERNAL,
        "TIMER": TriggerSource.TIMER,
        "INTERVAL": TriggerSource.TIMER,
        "BUS": TriggerSource.BUS,
        "ALARM": TriggerSource.ALARM,
        "ALAR": TriggerSource.ALARM,
    }
    if text in aliases:
        return aliases[text]
    raise AssertionError(
        f"Unknown trigger source {value!r}. Valid options: "
        + ", ".join(sorted(aliases))
    )


def _optional_float(value, label: str) -> Optional[float]:
    if value is None:
        return None
    text = str(value).strip()
    if not text or text.upper() in {"NONE", "DEFAULT"}:
        return None
    try:
        return float(text)
    except ValueError as exc:
        raise AssertionError(f"{label} must be a number, got {value!r}") from exc


def _result_to_rows(result: ScanResult) -> list:
    return [
        {
            "value": r.value,
            "channel": str(r.channel) if r.channel else "",
            "unit": r.measurement.unit.value,
            "function": r.measurement.function.value,
            "sweep": r.sweep,
            "overrange": r.is_overrange,
            "instrument_timestamp": r.instrument_timestamp or "",
        }
        for r in result.readings
    ]


class ScannerKeywords:
    """Scanner keywords. Composed into Keysight34970."""

    SESSION_RESET_HOOKS = ("_reset_scanner_state",)

    def __init__(self) -> None:
        self._scanner_engine: Optional[ScpiScannerEngine] = None
        self._last_scan_result: Optional[ScanResult] = None

    # -- keywords ---------------------------------------------------

    @keyword("Configure Scan")
    def configure_scan(
        self,
        channels: str,
        trigger_source: str = "IMMEDIATE",
        sweeps: str = "1",
        interval: str = None,
        channel_delay: str = None,
        include_timestamp: bool = True,
        include_channel: bool = True,
    ) -> None:
        """Defines a scan without starting it.

        - ``channels``: e.g. ``(@101:110)``
        - ``trigger_source``: IMMEDIATE, TIMER, EXTERNAL, BUS or ALARM
        - ``sweeps``: how many times to scan the list, or ``INF``
        - ``interval``: seconds between sweeps; **required** for TIMER,
          rejected for any other source
        - ``channel_delay``: settling delay per channel, in seconds

        Warns if the scan will produce more readings than the
        instrument's 50,000-reading memory holds.

        Example:
        | Configure Scan | (@101:110) | trigger_source=TIMER | interval=5 | sweeps=12 |
        """

        engine = self._require_scanner_engine()
        engine.configure_scan(
            ScanConfig(
                channels=ChannelList.parse(channels),
                trigger_source=_parse_trigger_source(trigger_source),
                trigger_count=TriggerCount(sweeps),
                trigger_timer_s=_optional_float(interval, "interval"),
                channel_delay_s=_optional_float(channel_delay, "channel_delay"),
                include_timestamp=bool(include_timestamp),
                include_channel=bool(include_channel),
            )
        )

    @keyword("Start Scan")
    def start_scan(self) -> None:
        """Arms the configured scan and returns immediately.

        The instrument keeps scanning after this returns. Pair with
        `Wait For Scan` or poll `Get Scan Reading Count`, and remember
        `Abort Scan` in teardown for a scan that does not self-complete.
        """

        self._require_scanner_engine().start_scan()

    @keyword("Abort Scan")
    def abort_scan(self) -> None:
        """Stops a running scan. Safe to call when none is running, so
        it is suitable for unconditional teardown."""

        self._require_scanner_engine().abort_scan()

    @keyword("Wait For Scan")
    def wait_for_scan(self, timeout: str = None) -> bool:
        """Blocks until the scan completes. Returns True, or False on
        timeout.

        Fails immediately rather than blocking if the scan cannot
        complete on its own — an infinite sweep count, or a trigger
        source waiting on an external stimulus. Blocking forever on a
        misconfigured scan is indistinguishable from broken hardware.
        """

        engine = self._require_scanner_engine()
        return engine.wait_for_scan(_optional_float(timeout, "timeout"))

    @keyword("Run Scan")
    def run_scan(
        self,
        channels: str,
        trigger_source: str = "IMMEDIATE",
        sweeps: str = "1",
        interval: str = None,
        channel_delay: str = None,
        timeout: str = None,
    ) -> list:
        """Configures, arms, waits and fetches in one call. Returns a
        list of reading records.

        Each record carries ``value``, ``channel``, ``unit``,
        ``function``, ``sweep``, ``overrange`` and
        ``instrument_timestamp``.

        If the wait times out, the readings taken so far are still
        returned — a partial result is more useful than an exception
        that discards them. Check the count against what you expected.

        Example:
        | ${rows}= | Run Scan | (@101:105) | sweeps=10 |
        """

        engine = self._require_scanner_engine()
        result = engine.run_scan(
            ScanConfig(
                channels=ChannelList.parse(channels),
                trigger_source=_parse_trigger_source(trigger_source),
                trigger_count=TriggerCount(sweeps),
                trigger_timer_s=_optional_float(interval, "interval"),
                channel_delay_s=_optional_float(channel_delay, "channel_delay"),
            ),
            timeout_s=_optional_float(timeout, "timeout"),
        )
        self._last_scan_result = result
        return _result_to_rows(result)

    @keyword("Fetch Scan Readings")
    def fetch_scan_readings(self, clear: bool = False) -> list:
        """Retrieves readings from instrument memory as records.

        Does not wait for the scan to finish, so this may return a
        partial scan. With ``clear=True`` the readings are erased from
        instrument memory as they are read.

        Example:
        | ${rows}= | Fetch Scan Readings | clear=True |
        """

        engine = self._require_scanner_engine()
        result = engine.fetch_readings(clear=bool(clear))
        self._last_scan_result = result
        return _result_to_rows(result)

    @keyword("Get Scan Reading Count")
    def get_scan_reading_count(self) -> int:
        """Returns how many readings the instrument currently holds.

        The way to monitor a scan that cannot be waited on.
        """

        return self._require_scanner_engine().reading_count()

    @keyword("Get Scan Readings For Channel")
    def get_scan_readings_for_channel(self, channel: str) -> list:
        """Returns the values one channel produced in the last fetched
        scan, in scan order.

        Use this rather than indexing the flat reading list: a
        multi-sweep scan interleaves channels, and reproducing that
        arithmetic at the call site is where off-by-one misattribution
        comes from.

        Example:
        | ${values}= | Get Scan Readings For Channel | 101 |
        """

        if self._last_scan_result is None:
            raise AssertionError(
                "No scan readings available - run 'Run Scan' or "
                "'Fetch Scan Readings' first"
            )
        return [r.value for r in self._last_scan_result.for_channel(channel)]

    @keyword("Get Instrument Statistics")
    def get_instrument_statistics(self) -> dict:
        """Returns min/max/average/count/span from the instrument's own
        CALC registers.

        Distinct from `Get Measurement Statistics`, which the driver
        computes over values it has fetched. These remain available for
        a scan too large to retrieve, but are accumulated over whatever
        the instrument considers the current set — the two can
        legitimately disagree.
        """

        stats = self._require_scanner_engine().get_instrument_statistics()
        return {
            "minimum": stats.minimum,
            "maximum": stats.maximum,
            "average": stats.average,
            "count": stats.count,
            "span": stats.span,
        }

    @keyword("Start Monitoring Channel")
    def start_monitoring_channel(self, channel: str) -> None:
        """Continuously monitors one channel.

        Monitoring is **not** scanning. The instrument reads the channel
        as fast as it can and keeps only the newest value; nothing
        accumulates in reading memory. `Fetch Scan Readings` will not
        return monitored values — use `Read Monitored Channel`.

        Example:
        | Start Monitoring Channel | 101 |
        """

        self._require_scanner_engine().start_monitor(channel)

    @keyword("Stop Monitoring")
    def stop_monitoring(self) -> None:
        """Stops monitoring. Safe whether or not monitoring is active,
        so it can be used unconditionally in teardown."""

        self._require_scanner_engine().stop_monitor()

    @keyword("Read Monitored Channel")
    def read_monitored_channel(self) -> float:
        """Returns the most recent value from the monitored channel.

        Fails if monitoring was never started, rather than returning a
        stale or unrelated reading.
        """

        return self._require_scanner_engine().read_monitor().value

    @keyword("Get Channel Statistics")
    def get_channel_statistics(self, channel: str) -> dict:
        """Returns instrument-computed statistics for one channel:
        ``count``, ``minimum``, ``maximum``, ``average``, ``span``,
        ``unit``.

        These cover every reading the instrument took, including any
        lost to reading-memory overflow — unlike statistics computed
        from fetched readings.

        Example:
        | ${stats}= | Get Channel Statistics | 101 |
        """

        stats = self._require_scanner_engine().get_channel_statistics(channel)
        return {
            "count": stats.count,
            "minimum": stats.minimum,
            "maximum": stats.maximum,
            "average": stats.average,
            "span": stats.span,
            "unit": stats.unit.value,
        }

    @keyword("Clear Instrument Statistics")
    def clear_instrument_statistics(self) -> None:
        """Resets the instrument's statistics registers.

        Whether the registers survive the start of a new scan is
        firmware-dependent and unverified by this driver's tests. Clear
        before a scan whose statistics you intend to read, and the
        result is well-defined either way.
        """

        self._require_scanner_engine().clear_statistics()

    # -- internals ---------------------------------------------------

    def _reset_scanner_state(self) -> None:
        """Drop scanner state bound to a closed session. A scan
        configuration is instrument state and does not survive one."""

        self._scanner_engine = None
        self._last_scan_result = None

    def _require_scanner_engine(self) -> ScpiScannerEngine:
        if self._scanner_engine is None:
            connection = getattr(self, "_connection", None)
            if connection is None or not connection.is_connected:
                raise AssertionError(
                    "No instrument connection is open - call "
                    "'Connect To Instrument' first"
                )
            measurement = None
            require = getattr(self, "_require_measurement_engine", None)
            if callable(require):
                try:
                    measurement = require()
                except AssertionError:
                    measurement = None
            self._scanner_engine = ScpiScannerEngine(
                connection, measurement_engine=measurement
            )
        return self._scanner_engine
