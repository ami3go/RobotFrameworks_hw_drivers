"""
Measurement keyword mixin (Phase 2, Gate 2).

Keywords for configuring and reading measurements. The engine is
created lazily on first use from the active connection, so
`Connect To Instrument` needs no measurement-specific arguments and
existing Phase 1 suites keep working unchanged.

Each mixin owns its own capability metadata (``CAPABILITY_METADATA``
here, alongside the connection mixin's own). ``library.py`` merges
them, so adding a phase means adding one module rather than editing a
central registry every phase contends over.
"""

from __future__ import annotations

from typing import Optional

from robot.api.deco import keyword

from ..measurement.channels import CardType, ChannelList
from ..measurement.engine import ScpiMeasurementEngine
from ..measurement.models import (
    AcquisitionSettings,
    AutoRange,
    AutoZero,
    InputImpedance,
    Measurement,
    MeasurementConfig,
    MeasurementFunction,
    MeasurementStatistics,
    Nplc,
)

CAPABILITY_METADATA: dict[str, dict] = {
    "Configure Measurement": {
        "risk_level": "low",
        "blocking": False,
        "notes": "Persists until changed; does not read.",
        "exclusive_resources": ["instrument_session"],
    },
    "Read Measurement": {
        "risk_level": "low",
        "blocking": True,
        "notes": "Triggers a scan of the given or configured channels.",
        "exclusive_resources": ["instrument_session", "internal_dmm"],
    },
    "Measure": {
        "risk_level": "medium",
        "blocking": True,
        "notes": "One-shot; resets unspecified measurement parameters to defaults.",
        "exclusive_resources": ["instrument_session", "internal_dmm"],
    },
    "Measure Value": {
        "risk_level": "medium",
        "blocking": True,
        "notes": "Convenience wrapper over Measure for a single channel.",
        "exclusive_resources": ["instrument_session", "internal_dmm"],
    },
    "Get Configured Function": {
        "risk_level": "low",
        "blocking": False,
        "notes": "Driver-side state; does not query the instrument.",
        "exclusive_resources": [],
    },
    "Set Installed Card": {
        "risk_level": "low",
        "blocking": False,
        "notes": "Declares slot contents to enable channel validation.",
        "exclusive_resources": [],
    },
    "Read Measurement Details": {
        "risk_level": "low",
        "blocking": True,
        "notes": "As Read Measurement, but returns dicts carrying channel, unit, function and over-range flag.",
        "exclusive_resources": ["instrument_session", "internal_dmm"],
    },
    "Get Measurement Statistics": {
        "risk_level": "low",
        "blocking": True,
        "notes": "Reads configured channels and returns min/max/average/span.",
        "exclusive_resources": ["instrument_session", "internal_dmm"],
    },
    "Measurement Should Be Within": {
        # medium, not low: this calls Measure internally, so it inherits
        # MEAS:'s reset of unspecified measurement parameters. Caught by
        # test_risk_levels_agree_with_capability_metadata.
        "risk_level": "medium",
        "blocking": True,
        "notes": "Assertion keyword; fails on over-range rather than comparing the sentinel numerically. Inherits Measure's parameter reset.",
        "exclusive_resources": ["instrument_session", "internal_dmm"],
    },
    "Clear Measurement Configuration": {
        "risk_level": "low",
        "blocking": False,
        "notes": "Driver-side only; does not change instrument configuration.",
        "exclusive_resources": [],
    },
    "Get Four Wire Pair": {
        "risk_level": "low",
        "blocking": False,
        "notes": "Driver-side calculation; sends nothing to the instrument.",
        "exclusive_resources": [],
    },
}

_FUNCTION_ALIASES = {
    "DCV": MeasurementFunction.DC_VOLTAGE,
    "DC VOLTAGE": MeasurementFunction.DC_VOLTAGE,
    "ACV": MeasurementFunction.AC_VOLTAGE,
    "AC VOLTAGE": MeasurementFunction.AC_VOLTAGE,
    "DCI": MeasurementFunction.DC_CURRENT,
    "DC CURRENT": MeasurementFunction.DC_CURRENT,
    "ACI": MeasurementFunction.AC_CURRENT,
    "AC CURRENT": MeasurementFunction.AC_CURRENT,
    "RESISTANCE": MeasurementFunction.RESISTANCE_2W,
    "2W RESISTANCE": MeasurementFunction.RESISTANCE_2W,
    "4W RESISTANCE": MeasurementFunction.RESISTANCE_4W,
    "FREQUENCY": MeasurementFunction.FREQUENCY,
    "PERIOD": MeasurementFunction.PERIOD,
    "CONTINUITY": MeasurementFunction.CONTINUITY,
    "DIODE": MeasurementFunction.DIODE,
    "TEMPERATURE": MeasurementFunction.TEMPERATURE,
}


def parse_function(value: str) -> MeasurementFunction:
    """Resolve a Robot-friendly function name to a MeasurementFunction.

    Accepts the SCPI mnemonic ("VOLT:DC"), the enum name
    ("DC_VOLTAGE"), or a human alias ("DCV", "DC Voltage").
    """

    text = str(value).strip()
    for candidate in (text.upper(), text.upper().replace("_", " ")):
        if candidate in _FUNCTION_ALIASES:
            return _FUNCTION_ALIASES[candidate]
    try:
        return MeasurementFunction(text.upper())
    except ValueError:
        pass
    try:
        return MeasurementFunction[text.upper().replace(" ", "_").replace(":", "_")]
    except KeyError:
        pass
    raise AssertionError(
        f"Unknown measurement function {value!r}. Valid options: "
        + ", ".join(sorted(f.name for f in MeasurementFunction))
    )


def _parse_range(value) -> float | AutoRange:
    if value is None:
        return AutoRange.AUTO
    if isinstance(value, AutoRange):
        return value
    text = str(value).strip()
    if not text or text.upper() in {"AUTO", "NONE", "DEF"}:
        return AutoRange.AUTO
    try:
        return float(text)
    except ValueError as exc:
        raise AssertionError(
            f"range/resolution must be a number or AUTO, got {value!r}"
        ) from exc


def _measurement_to_dict(measurement: Measurement) -> dict:
    """Render a Measurement for Robot Framework consumption.

    Returns a plain dict rather than the dataclass because Robot
    suites handle dicts natively (``&{m}[value]``) while a frozen
    dataclass forces users into Python evaluation.
    """

    return {
        "value": measurement.value,
        "unit": measurement.unit.value,
        "function": measurement.function.value,
        "channel": str(measurement.channel) if measurement.channel else "",
        "overrange": measurement.is_overrange,
        "timestamp": measurement.timestamp.isoformat(),
    }


def _build_acquisition(nplc, autozero, input_impedance) -> AcquisitionSettings:
    """Translate Robot string arguments into AcquisitionSettings."""

    def _opt(value, enum_cls, label):
        if value is None:
            return None
        text = str(value).strip()
        if not text or text.upper() in {"NONE", "DEFAULT"}:
            return None
        try:
            return enum_cls(text.upper())
        except ValueError as exc:
            raise AssertionError(
                f"Invalid {label} {value!r}. Valid options: "
                + ", ".join(e.value for e in enum_cls)
            ) from exc

    return AcquisitionSettings(
        nplc=_opt(nplc, Nplc, "nplc"),
        autozero=_opt(autozero, AutoZero, "autozero"),
        input_impedance=_opt(input_impedance, InputImpedance, "input impedance"),
    )


class MeasurementKeywords:
    """Measurement keywords. Composed into Keysight34970."""

    SESSION_RESET_HOOKS = ("_reset_measurement_state",)

    def __init__(self) -> None:
        self._measurement_engine: Optional[ScpiMeasurementEngine] = None
        self._declared_cards: dict[int, CardType] = {}

    # -- keywords ---------------------------------------------------

    @keyword("Set Installed Card")
    def set_installed_card(self, slot: int, card: str) -> None:
        """Declares which plug-in module occupies a slot, enabling
        channel validation for that slot.

        Without this, channels in that slot are validated loosely --
        the driver cannot yet discover installed cards itself.

        Valid cards: 34901A, 34902A, 34903A, 34904A, 34905A, 34906A,
        34907A, 34908A, UNKNOWN.

        Example:
        | Set Installed Card | 1 | 34901A |
        """

        try:
            card_type = CardType(str(card).strip().upper())
        except ValueError as exc:
            raise AssertionError(
                f"Unknown card {card!r}. Valid options: "
                + ", ".join(c.value for c in CardType)
            ) from exc

        slot_number = int(slot)
        if not (1 <= slot_number <= 3):
            raise AssertionError(f"slot must be 1-3, got {slot_number}")

        self._declared_cards[slot_number] = card_type
        if self._measurement_engine is not None:
            self._measurement_engine.set_card(slot_number, card_type)

    @keyword("Configure Measurement")
    def configure_measurement(
        self,
        function: str,
        channels: str,
        range: str = "AUTO",  # noqa: A002 - Robot-facing argument name
        resolution: str = "AUTO",
        nplc: str = None,
        autozero: str = None,
        input_impedance: str = None,
    ) -> None:
        """Configures a measurement function on the given channels
        without taking a reading. Configuration persists on the
        instrument until changed.

        - ``function``: e.g. DCV, ACV, DCI, 4W Resistance, Frequency
        - ``channels``: e.g. ``101``, ``(@101,103)``, ``101:110``
        - ``range`` / ``resolution``: numeric, or AUTO

        A resolution cannot be given without an explicit range.

        Optional acquisition tuning:
        - ``nplc``: integration time in power line cycles (0.02, 0.2, 1,
          2, 10, 20, 100, 200, MIN, MAX). **1 or above rejects mains
          hum; below 1 does not.** Higher values are slower and quieter.
        - ``autozero``: ON, OFF, or ONCE. OFF is faster but lets offset
          drift accumulate.
        - ``input_impedance``: AUTO or HIGH. HIGH forces >10 Gohm on all
          ranges — use it when the source impedance is high enough that
          a 10 Mohm input would load the signal down.

        Example:
        | Configure Measurement | DCV | (@101:105) | range=10 | nplc=10 |
        """

        engine = self._require_measurement_engine()
        engine.configure(
            ChannelList.parse(channels),
            MeasurementConfig(
                function=parse_function(function),
                range=_parse_range(range),
                resolution=_parse_range(resolution),
                acquisition=_build_acquisition(nplc, autozero, input_impedance),
            ),
        )

    @keyword("Read Measurement")
    def read_measurement(self, channels: str = "") -> list:
        """Triggers a scan and returns readings as a list of floats.

        With no argument, reads every channel configured so far via
        `Configure Measurement` — note this accumulates across the whole
        suite, so use `Clear Measurement Configuration` in ``Test Setup``
        if each test should read only its own channels. Fails if a
        requested channel was never configured, rather than silently
        reading something else.


        Readings are returned in **ascending channel order**, which may
        differ from the order you listed channels in. The instrument
        scans ascending, and readings are matched to channels by
        position, so the driver normalises the order to keep that
        matching correct.

        Example:
        | ${values}= | Read Measurement | (@101,102) |
        """

        engine = self._require_measurement_engine()
        target = ChannelList.parse(channels) if str(channels).strip() else None
        return [m.value for m in engine.read(target)]

    @keyword("Measure")
    def measure(
        self,
        function: str,
        channels: str,
        range: str = "AUTO",  # noqa: A002
        resolution: str = "AUTO",
    ) -> list:
        """Configures and reads in one operation, returning a list of
        floats.

        Note this resets measurement parameters you did not specify to
        their defaults. Use `Configure Measurement` + `Read Measurement`
        when other settings must persist.

        Unlike `Configure Measurement`, this keyword takes no ``nplc``,
        ``autozero`` or ``input_impedance`` arguments. That asymmetry is
        deliberate: MEAS: reads immediately and resets unspecified
        parameters, so there is no point at which those settings could
        be applied and still affect the reading. Accepting them would
        mean returning a value the caller believes was taken at, say,
        10 NPLC when it was not. To tune acquisition, use
        `Configure Measurement` then `Read Measurement`.


        Readings are returned in **ascending channel order**, which may
        differ from the order you listed channels in. The instrument
        scans ascending, and readings are matched to channels by
        position, so the driver normalises the order to keep that
        matching correct.

        Example:
        | ${values}= | Measure | DCV | (@101:104) |
        """

        engine = self._require_measurement_engine()
        measurements = engine.measure(
            ChannelList.parse(channels),
            MeasurementConfig(
                function=parse_function(function),
                range=_parse_range(range),
                resolution=_parse_range(resolution),
            ),
        )
        return [m.value for m in measurements]

    @keyword("Measure Value")
    def measure_value(
        self,
        function: str,
        channel: str,
        range: str = "AUTO",  # noqa: A002
        resolution: str = "AUTO",
    ) -> float:
        """Measures a single channel and returns one float.

        Fails if the channel argument resolves to more than one channel,
        rather than silently returning only the first reading.

        Example:
        | ${volts}= | Measure Value | DCV | 101 |
        """

        channel_list = ChannelList.parse(channel)
        if len(channel_list) != 1:
            raise AssertionError(
                f"'Measure Value' expects exactly one channel, got "
                f"{len(channel_list)}. Use 'Measure' for multiple channels."
            )
        return self.measure(function, channel, range, resolution)[0]

    @keyword("Get Configured Function")
    def get_configured_function(self, channel: str) -> str:
        """Returns the function configured on a channel as its SCPI
        mnemonic (e.g. ``VOLT:DC``), or an empty string if the driver
        has not configured it.

        Reflects driver-side state; it does not query the instrument.
        """

        engine = self._require_measurement_engine()
        config = engine.get_configured_function(channel)
        return config.function.value if config is not None else ""

    @keyword("Read Measurement Details")
    def read_measurement_details(self, channels: str = "") -> list:
        """As `Read Measurement`, but returns a list of dictionaries
        carrying the full result rather than bare floats.

        Each entry has: ``value``, ``unit``, ``function``, ``channel``,
        ``overrange``, ``timestamp``.

        Prefer this when a reading might be over-range: `Read
        Measurement` returns the raw sentinel 9.9e37, which compares as
        a perfectly ordinary large float and will pass a naive
        assertion.

        Example:
        | ${rows}= | Read Measurement Details |
        | Should Not Be True | ${rows}[0][overrange] |
        """

        engine = self._require_measurement_engine()
        target = ChannelList.parse(channels) if str(channels).strip() else None
        return [_measurement_to_dict(m) for m in engine.read(target)]

    @keyword("Get Measurement Statistics")
    def get_measurement_statistics(self, channels: str = "") -> dict:
        """Reads the given (or all configured) channels and returns
        ``count``, ``minimum``, ``maximum``, ``average``, ``span`` and
        ``unit``.

        Fails rather than returning a number if any reading is
        over-range, or if the channels span different units — averaging
        volts with ohms, or averaging in 9.9e37, produces a
        plausible-looking lie.

        Example:
        | ${stats}= | Get Measurement Statistics | (@101:110) |
        """

        engine = self._require_measurement_engine()
        target = ChannelList.parse(channels) if str(channels).strip() else None
        measurements = list(engine.read(target))
        stats: MeasurementStatistics = MeasurementStatistics.from_measurements(
            measurements
        )
        return {
            "count": stats.count,
            "minimum": stats.minimum,
            "maximum": stats.maximum,
            "average": stats.average,
            "span": stats.span,
            "unit": stats.unit.value,
        }

    @keyword("Measurement Should Be Within")
    def measurement_should_be_within(
        self,
        function: str,
        channel: str,
        minimum: float,
        maximum: float,
        range: str = "AUTO",  # noqa: A002
    ) -> float:
        """Measures one channel and fails unless the reading falls
        within [minimum, maximum] inclusive. Returns the reading.

        An over-range reading fails explicitly rather than being
        compared numerically against the bounds.

        Example:
        | Measurement Should Be Within | DCV | 101 | 4.9 | 5.1 |
        """

        engine = self._require_measurement_engine()
        channel_list = ChannelList.parse(channel)
        if len(channel_list) != 1:
            raise AssertionError(
                f"'Measurement Should Be Within' expects exactly one channel, "
                f"got {len(channel_list)}"
            )

        measurement = engine.measure(
            channel_list,
            MeasurementConfig(
                function=parse_function(function), range=_parse_range(range)
            ),
        )[0]

        if measurement.is_overrange:
            raise AssertionError(
                f"Reading on channel {channel} is over-range; the instrument "
                "could not measure it on the selected range"
            )

        low, high = float(minimum), float(maximum)
        if not (low <= measurement.value <= high):
            raise AssertionError(
                f"Reading {measurement.value:.6g} {measurement.unit.value} on "
                f"channel {channel} is outside [{low:.6g}, {high:.6g}]"
            )
        return measurement.value

    @keyword("Clear Measurement Configuration")
    def clear_measurement_configuration(self, channels: str = "") -> None:
        """Forgets which channels this driver has configured, so a
        subsequent bare `Read Measurement` scans only what you configure
        afterwards.

        This does **not** change the instrument — the function stays
        configured there until overwritten.

        Why you need it: configuration accumulates. The library holds
        one session per suite, so every `Configure Measurement` across
        every test case adds to the set that a bare `Read Measurement`
        covers. A test that configures 5 channels can end up reading 20.
        Calling this in ``Test Setup`` keeps each test independent.

        Example:
        | Clear Measurement Configuration |
        | Clear Measurement Configuration | (@101,102) |
        """

        engine = self._require_measurement_engine()
        target = ChannelList.parse(channels) if str(channels).strip() else None
        engine.clear_configuration(target)

    @keyword("Get Four Wire Pair")
    def get_four_wire_pair(self, channel: str) -> str:
        """Returns the channel that a 4-wire measurement on ``channel``
        will also occupy (N+10 on the same slot).

        That paired channel is consumed by the measurement and must not
        be used for anything else.

        Example:
        | ${paired}= | Get Four Wire Pair | 101 |   # -> 111
        """

        from ..measurement.channels import ChannelId

        engine = self._require_measurement_engine()
        return str(engine.four_wire_pair(ChannelId.parse(channel)))

    # -- internals ---------------------------------------------------

    def _require_measurement_engine(self) -> ScpiMeasurementEngine:
        """Return the engine, creating it from the active connection on
        first use."""

        if self._measurement_engine is None:
            connection = getattr(self, "_connection", None)
            if connection is None or not connection.is_connected:
                raise AssertionError(
                    "No instrument connection is open - call "
                    "'Connect To Instrument' first"
                )
            self._measurement_engine = ScpiMeasurementEngine(
                connection, cards=self._declared_cards
            )
        return self._measurement_engine

    def _reset_measurement_state(self) -> None:
        """Drop the engine so a later connection builds a fresh one.

        Called by the connection mixin on disconnect/reconnect: an
        engine bound to a closed connection would otherwise raise a
        confusing StateError from deep in the SCPI layer rather than the
        connection layer's clear message, and would carry stale
        per-channel configuration across sessions.
        """

        self._measurement_engine = None
