"""
Robot Framework keywords for connection lifecycle management.

This module is a *mixin* (see library.py), not a standalone Robot
Framework library, so that later phases can add Measurement, Scanner,
Temperature, etc. keywords to the same instrument object without
multiple inheritance surprises or duplicated connection state.
"""

from __future__ import annotations

from typing import Optional

from robot.api.deco import keyword

from ..config import ConnectionConfig, InstrumentModel, TransportKind
from ..connection import Connection, ConnectionState

# Lightweight planning-hint metadata per keyword, staged ahead of the full
# RFDS-017 AI Driver Contract generation in Phase 10. Deliberately NOT a
# complete contract (no error catalogue references, no verification
# oracles yet) - just the fields an AI planner most needs early: risk
# level, whether the call blocks for a stabilization delay, and whether
# it holds any exclusive bench resource. Phase 10 will read this registry
# (or its successor) when generating ai/ai_contract.yaml.
CAPABILITY_METADATA: dict[str, dict] = {
    "Connect To Instrument": {
        "risk_level": "low",
        "blocking": True,
        "exclusive_resources": ["instrument_session"],
    },
    "Disconnect From Instrument": {
        "risk_level": "low",
        "blocking": False,
        "exclusive_resources": [],
    },
    "Reconnect To Instrument": {
        "risk_level": "medium",
        "blocking": True,
        "exclusive_resources": ["instrument_session"],
    },
    "Get Instrument Identity": {
        "risk_level": "low",
        "blocking": False,
        "exclusive_resources": [],
    },
    "Get Connection State": {
        "risk_level": "low",
        "blocking": False,
        "exclusive_resources": [],
    },
    "Instrument Should Be Connected": {
        "risk_level": "low",
        "blocking": False,
        "exclusive_resources": [],
    },
    "Reset Instrument": {
        "risk_level": "medium",
        "blocking": True,
        "notes": "Clears any scan/channel configuration on the instrument.",
        "exclusive_resources": ["instrument_session"],
    },
    "Clear Instrument Status": {
        "risk_level": "low",
        "blocking": False,
        "exclusive_resources": [],
    },
    "Set Instrument Timeout": {
        "risk_level": "low",
        "blocking": False,
        "exclusive_resources": [],
    },
    "Send Scpi Command": {
        "risk_level": "high",
        "blocking": False,
        "notes": "Escape hatch - bypasses dedicated-keyword risk analysis.",
        "exclusive_resources": ["instrument_session"],
    },
    "Query Scpi Command": {
        "risk_level": "high",
        "blocking": False,
        "notes": "Escape hatch - bypasses dedicated-keyword risk analysis.",
        "exclusive_resources": ["instrument_session"],
    },
    "Drain Instrument Error Queue": {
        "risk_level": "low",
        "blocking": False,
        "exclusive_resources": [],
    },
}


class ConnectionKeywords:
    """Provides: Connect To Instrument, Disconnect From Instrument,
    Get Instrument Identity, Send Scpi Command, Query Scpi Command."""

    SESSION_RESET_HOOKS: tuple[str, ...] = ()
    """Method names to call when a session ends. Mixins override this."""

    def __init__(self) -> None:
        self._connection: Optional[Connection] = None

    # -- keywords ---------------------------------------------------

    @keyword("Connect To Instrument")
    def connect_to_instrument(
        self,
        model: str,
        transport: str,
        resource: str,
        port: int = 5025,
        timeout: float = 5.0,
        alias: Optional[str] = None,
        reset: bool = False,
        verify_model: bool = True,
        terminator: str = "\n",
    ) -> None:
        """Opens a connection to a 34970A/34972A mainframe.

        Arguments:
        - ``model``: "34970A" or "34972A"
        - ``transport``: "VISA" or "TCP"
        - ``resource``: VISA resource string (transport=VISA) or
          hostname/IP (transport=TCP)
        - ``port``: SCPI socket port, only used when transport=TCP
          (default 5025)
        - ``timeout``: command/query timeout in seconds
        - ``alias``: optional friendly name used in logs; useful when a
          bench (RFDS-018) has multiple instruments of this type
        - ``reset``: send *RST before use (default False, since reset
          clears any existing scan/channel configuration)
        - ``verify_model``: fail the connection if the instrument's
          reported *IDN? model doesn't match ``model`` (default True).
          Set to False only when deliberately connecting to a
          compatible-but-differently-reported unit.
        - ``terminator``: line terminator for TCP transport (default
          "\\n"); ignored for VISA, which manages termination itself.

        Example:
        | Connect To Instrument | 34972A | TCP | 10.0.0.12 | alias=daq1 |
        """

        transport_kind = TransportKind(transport.upper())
        instrument_model = InstrumentModel(model.upper())

        config = ConnectionConfig(
            transport=transport_kind,
            model=instrument_model,
            visa_resource=resource if transport_kind == TransportKind.VISA else None,
            host=resource if transport_kind == TransportKind.TCP_SOCKET else None,
            port=port,
            timeout_s=timeout,
            reset_on_connect=reset,
            verify_model=verify_model,
            terminator=terminator,
            alias=alias,
        )

        self._connection = Connection(config)
        self._connection.connect()

    @keyword("Disconnect From Instrument")
    def disconnect_from_instrument(self) -> None:
        """Closes the current instrument connection, if any. Safe to call
        even if no connection is open."""

        if self._connection is not None:
            self._connection.close()
            self._connection = None
        self._notify_disconnected()

    @keyword("Get Instrument Identity")
    def get_instrument_identity(self) -> str:
        """Returns the raw ``*IDN?`` string captured at connect time.

        Fails if not connected, or if the connection was made with
        identify_on_connect disabled (always True via this keyword).
        """

        connection = self._require_connection()
        if connection.identity is None:
            raise AssertionError(
                "No identity available - instrument was not identified on connect"
            )
        return connection.identity.raw

    @keyword("Send Scpi Command")
    def send_scpi_command(self, command: str) -> None:
        """Sends a raw SCPI command with no response expected, then checks
        the instrument's error queue and fails the keyword if an error
        was reported.

        Intended as an escape hatch for capabilities not yet exposed as
        dedicated keywords; prefer dedicated keywords once available so
        that AI-planner risk/precondition metadata (RFDS-017) applies.
        """

        connection = self._require_connection()
        connection.write(command)

    @keyword("Query Scpi Command")
    def query_scpi_command(self, command: str) -> str:
        """Sends a raw SCPI query and returns the response string, with
        the same error-queue check as `Send Scpi Command`."""

        connection = self._require_connection()
        return connection.query(command)

    @keyword("Instrument Should Be Connected")
    def instrument_should_be_connected(self) -> None:
        """Fails unless there is currently an active connection."""

        if self._connection is None or self._connection.state != ConnectionState.CONNECTED:
            raise AssertionError("Instrument is not connected")

    @keyword("Get Connection State")
    def get_connection_state(self) -> str:
        """Returns the current connection state name: IDLE, CONNECTING,
        CONNECTED, ERROR, or CLOSED. Returns "IDLE" if `Connect To
        Instrument` has never been called."""

        if self._connection is None:
            return ConnectionState.IDLE.name
        return self._connection.state.name

    @keyword("Reset Instrument")
    def reset_instrument(self) -> None:
        """Sends `*RST` and waits out the configured stabilization
        delay. Note this clears any scan/channel configuration on the
        instrument (added in later phases) - use deliberately, not as a
        matter of course between every test case."""

        connection = self._require_connection()
        connection.reset()

    @keyword("Clear Instrument Status")
    def clear_instrument_status(self) -> None:
        """Sends `*CLS`, clearing the instrument's status/error queue."""

        connection = self._require_connection()
        connection.clear_status()

    @keyword("Set Instrument Timeout")
    def set_instrument_timeout(self, timeout: float) -> None:
        """Updates the command/query timeout, in seconds, for the
        current connection. Useful before a keyword expected to take
        longer than the default (e.g. a long scan in later phases)."""

        connection = self._require_connection()
        connection.set_timeout(timeout)

    @keyword("Reconnect To Instrument")
    def reconnect_to_instrument(self) -> None:
        """Disconnects and reconnects using the same configuration as
        the last `Connect To Instrument` call. Useful for recovering
        from a suspected bad instrument/communication state without
        re-specifying connection parameters."""

        connection = self._require_connection()
        connection.reconnect()
        # Per-channel measurement configuration does not survive a
        # reconnect on the instrument side, so the driver must not keep
        # claiming it does.
        self._notify_disconnected()

    @keyword("Drain Instrument Error Queue")
    def drain_instrument_error_queue(self) -> list:
        """Pops and returns every pending SCPI error as a list of
        strings formatted "<code>: <message>", up to an internal safety
        bound. Does not fail the test - use for diagnostics/logging, or
        to clear a known-noisy queue before an assertion-sensitive
        section of a test."""

        connection = self._require_connection()
        errors = connection.drain_error_queue()
        return [f"{err.code}: {err.message}" for err in errors]

    # -- internals --------------------------------------------------

    def _notify_disconnected(self) -> None:
        """Let sibling mixins drop state bound to the old session.

        Mixins declare a reset hook by listing its method name in their
        class-level ``SESSION_RESET_HOOKS``. This replaces the earlier
        ``getattr(self, "_reset_measurement_state")`` lookup, which was
        flagged in three consecutive reviews: a mixin that misspelled
        the method, or simply forgot one, would silently never be reset
        and would carry stale state across sessions.

        Declared names are validated on construction (see
        ``_validate_session_reset_hooks``), so a typo fails immediately
        at library import rather than surfacing later as a stale-state
        bug.
        """

        for owner in type(self).__mro__:
            for name in owner.__dict__.get("SESSION_RESET_HOOKS", ()):
                hook = getattr(self, name, None)
                if callable(hook):
                    hook()

    def _validate_session_reset_hooks(self) -> None:
        """Fail loudly if hooks are declared wrongly or not at all.

        Two distinct mistakes, both silent without this:

        1. A declared hook that does not exist (a typo). The original
           check.
        2. A hook method that exists but was never declared. Found in
           Phase 5 Gate 2: ``DigitalKeywords`` defined
           ``_reset_digital_state`` and omitted the declaration, so the
           engine -- and the record of every output driven -- survived a
           disconnect. The first check could not see this, because
           nothing was declared to be wrong.
        """

        for owner in type(self).__mro__:
            declared = owner.__dict__.get("SESSION_RESET_HOOKS", ())

            for name in declared:
                if not callable(getattr(self, name, None)):
                    raise AttributeError(
                        f"{owner.__name__} declares session reset hook "
                        f"{name!r}, which is not a callable attribute. "
                        "Fix the name in SESSION_RESET_HOOKS."
                    )

            # A method shaped like a reset hook but not declared is
            # almost certainly an omission rather than a private helper
            # that happens to match the naming convention.
            for name, value in owner.__dict__.items():
                if (
                    name.startswith("_reset_")
                    and name.endswith("_state")
                    and callable(value)
                    and name not in declared
                ):
                    raise AttributeError(
                        f"{owner.__name__} defines {name!r} but does not "
                        "list it in SESSION_RESET_HOOKS, so it would never "
                        "run and state would leak across sessions."
                    )

    def _require_connection(self) -> Connection:
        if self._connection is None:
            raise AssertionError(
                "No instrument connection is open - call "
                "'Connect To Instrument' first"
            )
        return self._connection
