"""
Temperature keyword mixin (Phase 4, Gate 2).

Keywords for configuring and reading temperature transducers. The
engine is created lazily from the active connection, matching the
pattern established by the measurement and scanner mixins.
"""

from __future__ import annotations

from typing import Optional

from robot.api.deco import keyword

from ..measurement.channels import ChannelList
from ..temperature.engine import ScpiTemperatureEngine
from ..temperature.models import (
    ReferenceJunction,
    TemperatureConfig,
    TemperatureUnit,
    ThermocoupleType,
    TransducerType,
)

CAPABILITY_METADATA: dict[str, dict] = {
    "Configure Thermocouple": {
        "risk_level": "low",
        "blocking": False,
        "notes": "Requires an explicit alloy type; there is no safe default.",
        "exclusive_resources": ["instrument_session"],
    },
    "Configure RTD": {
        "risk_level": "low",
        "blocking": False,
        "notes": "4-wire RTDs also consume channel N+10.",
        "exclusive_resources": ["instrument_session"],
    },
    "Configure Thermistor": {
        "risk_level": "low",
        "blocking": False,
        "notes": "Nominal resistance must be a standard 2252/5000/10000 ohm curve.",
        "exclusive_resources": ["instrument_session"],
    },
    "Read Temperature": {
        "risk_level": "low",
        "blocking": True,
        "notes": "Readings carry the configured unit, not an assumed Celsius.",
        "exclusive_resources": ["instrument_session", "internal_dmm"],
    },
    "Read Temperature Details": {
        "risk_level": "low",
        "blocking": True,
        "notes": "Includes a plausibility flag for open junctions and unit confusion.",
        "exclusive_resources": ["instrument_session", "internal_dmm"],
    },
    "Set Temperature Unit": {
        "risk_level": "low",
        "blocking": False,
        "notes": "Per channel, not global.",
        "exclusive_resources": ["instrument_session"],
    },
    "Get Temperature Configuration": {
        "risk_level": "low",
        "blocking": False,
        "notes": "Driver-side state; does not query the instrument.",
        "exclusive_resources": [],
    },
    "Read Reference Junction Temperature": {
        "risk_level": "low",
        "blocking": True,
        "notes": "Always Celsius. Diagnoses bad cold-junction compensation.",
        "exclusive_resources": ["instrument_session"],
    },
    "Temperature Should Be Within": {
        "risk_level": "low",
        "blocking": True,
        "notes": "Fails explicitly on implausible or over-range readings.",
        "exclusive_resources": ["instrument_session", "internal_dmm"],
    },
}


def _parse_optional(value, parser, label):
    if value is None:
        return None
    text = str(value).strip()
    if not text or text.upper() in {"NONE", "DEFAULT"}:
        return None
    try:
        return parser(text)
    except (ValueError, KeyError) as exc:
        raise AssertionError(f"Invalid {label}: {value!r}") from exc


def _parse_switch(value, label: str):
    """Parse an ON/OFF style Robot argument into an Optional[bool]."""

    if value is None:
        return None
    text = str(value).strip().upper()
    if not text or text in {"NONE", "DEFAULT"}:
        return None
    if text in {"ON", "TRUE", "YES", "1", "ENABLE", "ENABLED"}:
        return True
    if text in {"OFF", "FALSE", "NO", "0", "DISABLE", "DISABLED"}:
        return False
    raise AssertionError(f"{label} must be ON or OFF, got {value!r}")


def _parse_optional_float(value, label: str):
    if value is None:
        return None
    text = str(value).strip()
    if not text or text.upper() in {"NONE", "DEFAULT"}:
        return None
    try:
        return float(text)
    except ValueError as exc:
        raise AssertionError(
            f"{label} must be a number, got {value!r}"
        ) from exc


class TemperatureKeywords:
    """Temperature keywords. Composed into Keysight34970."""

    # Declared so the connection mixin resets this engine on
    # disconnect/reconnect. Validated at import, so a typo here fails
    # immediately rather than surfacing as stale state across sessions.
    SESSION_RESET_HOOKS = ("_reset_temperature_state",)

    def __init__(self) -> None:
        self._temperature_engine: Optional[ScpiTemperatureEngine] = None

    # -- configuration ---------------------------------------------

    @keyword("Configure Thermocouple")
    def configure_thermocouple(
        self,
        channels: str,
        type: str,  # noqa: A002 - Robot-facing name
        unit: str = "C",
        reference: str = "INTERNAL",
        reference_temperature: str = None,
        open_detect: str = None,
    ) -> None:
        """Configures a thermocouple on the given channels.

        - ``type``: alloy letter — B, E, J, K, N, R, S or T. **Required
          with no default**: the alloy determines the voltage-to-
          temperature conversion, and assuming K would be wrong by tens
          of degrees for any other type.
        - ``open_detect``: ON/OFF. Enables the instrument's
          open-junction check. **Worth enabling on anything that
          matters**: a broken thermocouple does not report an error, it
          reports a plausible temperature. Costs a little speed.
        - ``unit``: C, F or K.
        - ``reference``: INTERNAL, EXTERNAL or FIXED cold-junction
          compensation. An uncompensated junction is wrong by roughly
          room temperature.
        - ``reference_temperature``: required when ``reference=FIXED``,
          in degrees Celsius.

        Example:
        | Configure Thermocouple | (@101:104) | K | unit=C |
        """

        alloy = _parse_optional(
            type, lambda t: ThermocoupleType[t.upper()], "thermocouple type"
        )
        if alloy is None:
            raise AssertionError(
                "A thermocouple type is required (B, E, J, K, N, R, S, T); "
                "there is no safe default"
            )
        junction = _parse_optional(
            reference,
            lambda t: ReferenceJunction[t.upper()]
            if t.upper() in ReferenceJunction.__members__
            else ReferenceJunction(t.upper()),
            "reference junction",
        )
        fixed = (
            float(reference_temperature)
            if reference_temperature not in (None, "")
            else None
        )

        self._require_temperature_engine().configure(
            ChannelList.parse(channels),
            TemperatureConfig(
                transducer=TransducerType.THERMOCOUPLE,
                thermocouple_type=alloy,
                reference_junction=junction,
                fixed_reference_c=fixed,
                open_detect=_parse_switch(open_detect, "open_detect"),
                unit=TemperatureUnit.parse(unit),
            ),
        )

    @keyword("Configure RTD")
    def configure_rtd(
        self,
        channels: str,
        nominal: str = "100",
        unit: str = "C",
        four_wire: bool = False,
        alpha: str = None,
        reference_ohms: str = None,
    ) -> None:
        """Configures an RTD on the given channels.

        - ``nominal``: resistance at 0 C, typically 100 (Pt100) or 1000.
        - ``four_wire``: use a 4-wire connection. **This also consumes
          channel N+10**, which cannot then be used for anything else.
        - ``alpha``: temperature coefficient, 0.00385 or 0.00391.

        Example:
        | Configure RTD | (@101) | nominal=100 | four_wire=True |
        """

        transducer = (
            TransducerType.RTD_4WIRE
            if str(four_wire).strip().lower() in {"true", "yes", "1"}
            else TransducerType.RTD
        )
        self._require_temperature_engine().configure(
            ChannelList.parse(channels),
            TemperatureConfig(
                transducer=transducer,
                rtd_nominal_ohms=float(nominal) if nominal else None,
                rtd_alpha=float(alpha) if alpha not in (None, "") else None,
                rtd_reference_ohms=_parse_optional_float(
                    reference_ohms, "reference_ohms"
                ),
                unit=TemperatureUnit.parse(unit),
            ),
        )

    @keyword("Configure Thermistor")
    def configure_thermistor(
        self, channels: str, nominal: str = "5000", unit: str = "C"
    ) -> None:
        """Configures a thermistor on the given channels.

        ``nominal`` must be 2252, 5000 or 10000 ohms — the instrument
        implements those three conversion curves, and any other value
        would produce believable but wrong temperatures.

        Example:
        | Configure Thermistor | (@105) | nominal=5000 |
        """

        self._require_temperature_engine().configure(
            ChannelList.parse(channels),
            TemperatureConfig(
                transducer=TransducerType.THERMISTOR,
                thermistor_nominal_ohms=float(nominal),
                unit=TemperatureUnit.parse(unit),
            ),
        )

    # -- reading ---------------------------------------------------

    @keyword("Read Temperature")
    def read_temperature(self, channels: str = "") -> list:
        """Reads configured temperature channels, returning floats in
        each channel's configured unit.

        Readings come back in ascending channel order. With no argument,
        reads every channel configured for temperature so far.
        """

        engine = self._require_temperature_engine()
        target = ChannelList.parse(channels) if str(channels).strip() else None
        return [m.value for m in engine.read(target)]

    @keyword("Read Temperature Details")
    def read_temperature_details(self, channels: str = "") -> list:
        """As `Read Temperature`, but returns dicts with ``value``,
        ``unit``, ``channel``, ``overrange`` and ``plausible``.

        ``plausible`` is False when a reading falls outside the
        configured transducer's physical range — the signature of an
        open junction, a disconnected sensor, or unit confusion. It will
        *not* catch a wrong thermocouple type, which usually reads in
        range.
        """

        engine = self._require_temperature_engine()
        target = ChannelList.parse(channels) if str(channels).strip() else None
        readings = list(engine.read(target))
        implausible = {id(m) for m in engine.implausible_readings(readings)}
        return [
            {
                "value": m.value,
                "unit": m.unit.value,
                "channel": str(m.channel) if m.channel else "",
                "overrange": m.is_overrange,
                "plausible": id(m) not in implausible,
            }
            for m in readings
        ]

    @keyword("Set Temperature Unit")
    def set_temperature_unit(self, unit: str, channels: str = "") -> None:
        """Changes the reported temperature unit (C, F or K).

        Applies per channel, not globally — the instrument stores the
        unit per channel and a bench may legitimately mix them.
        """

        engine = self._require_temperature_engine()
        target = ChannelList.parse(channels) if str(channels).strip() else None
        engine.set_unit(TemperatureUnit.parse(unit), target)

    @keyword("Get Temperature Configuration")
    def get_temperature_configuration(self, channel: str) -> str:
        """Returns a human-readable description of the transducer
        configured on a channel, or an empty string if none.

        Driver-side state; does not query the instrument.
        """

        config = self._require_temperature_engine().get_configuration(channel)
        return config.describe() if config is not None else ""

    @keyword("Read Reference Junction Temperature")
    def read_reference_junction_temperature(self) -> float:
        """Returns the internal reference junction temperature, always
        in Celsius.

        When thermocouple readings look wrong, this separates a bad
        cold-junction reference from a wrong alloy type — two problems
        with completely different fixes.
        """

        return self._require_temperature_engine().read_reference_junction().value

    @keyword("Temperature Should Be Within")
    def temperature_should_be_within(
        self, channel: str, minimum: float, maximum: float
    ) -> float:
        """Reads one configured channel and fails unless the temperature
        falls within [minimum, maximum] inclusive, in that channel's
        configured unit.

        Over-range and physically implausible readings fail explicitly
        rather than being compared numerically against the bounds.
        """

        engine = self._require_temperature_engine()
        target = ChannelList.parse(channel)
        if len(target) != 1:
            raise AssertionError(
                f"'Temperature Should Be Within' expects exactly one channel, "
                f"got {len(target)}"
            )

        measurement = list(engine.read(target))[0]
        if measurement.is_overrange:
            raise AssertionError(
                f"Temperature on channel {channel} is over-range"
            )
        if engine.implausible_readings([measurement]):
            raise AssertionError(
                f"Temperature {measurement.value:.4g} "
                f"{measurement.unit.value} on channel {channel} is outside "
                "the configured transducer's physical range - check for an "
                "open junction, a disconnected sensor, or a unit mismatch"
            )

        low, high = float(minimum), float(maximum)
        if not (low <= measurement.value <= high):
            raise AssertionError(
                f"Temperature {measurement.value:.4g} "
                f"{measurement.unit.value} on channel {channel} is outside "
                f"[{low:g}, {high:g}]"
            )
        return measurement.value

    # -- internals -------------------------------------------------

    def _require_temperature_engine(self) -> ScpiTemperatureEngine:
        if self._temperature_engine is None:
            connection = getattr(self, "_connection", None)
            if connection is None or not connection.is_connected:
                raise AssertionError(
                    "No instrument connection is open - call "
                    "'Connect To Instrument' first"
                )
            measurement = None
            require = getattr(self, "_require_measurement_engine", None)
            if callable(require):
                measurement = require()
            self._temperature_engine = ScpiTemperatureEngine(
                connection, measurement_engine=measurement
            )
        return self._temperature_engine

    def _reset_temperature_state(self) -> None:
        """Drop the engine so a later connection builds a fresh one."""

        self._temperature_engine = None
