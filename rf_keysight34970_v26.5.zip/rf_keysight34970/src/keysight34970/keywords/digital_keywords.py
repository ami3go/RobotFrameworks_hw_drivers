"""
Digital I/O keyword mixin (Phase 5, Gate 2) — 34907A multifunction module.

The engine is created lazily from the active connection, so
`Connect To Instrument` needs no digital-specific arguments and existing
suites keep working unchanged.

These are the first keywords in this driver that drive signals **out**
of the instrument. Their documentation leads with that.
"""

from __future__ import annotations

from typing import Optional

from robot.api.deco import keyword

from ..digital.engine import ScpiDigitalEngine
from ..digital.models import (
    EdgeSlope,
    InputThreshold,
    TotalizerConfig,
    TotalizerMode,
)

CAPABILITY_METADATA: dict[str, dict] = {
    "Read Digital Port": {
        "risk_level": "low",
        "blocking": False,
        "notes": "Reads an 8-bit port; drives nothing.",
        "exclusive_resources": ["instrument_session"],
    },
    "Read Digital Port Bits": {
        "risk_level": "low",
        "blocking": False,
        "notes": "Reads an 8-bit port as a binary string, MSB first.",
        "exclusive_resources": ["instrument_session"],
    },
    "Read Totalizer Details": {
        "risk_level": "medium",
        "blocking": False,
        "notes": (
            "As Read Totalizer, but reports whether the read destroyed "
            "the count and whether the counter is near its 26-bit wrap."
        ),
        "exclusive_resources": ["instrument_session"],
    },
    "Write Digital Port": {
        "risk_level": "high",
        "blocking": False,
        "notes": (
            "DRIVES PHYSICAL OUTPUT LINES. Not undone by reading; the "
            "previous value is not recoverable from the instrument."
        ),
        "exclusive_resources": ["instrument_session", "digital_output"],
    },
    "Write Digital Port Bit": {
        "risk_level": "high",
        "blocking": False,
        "notes": (
            "DRIVES PHYSICAL OUTPUT LINES. Read-modify-write, not "
            "atomic: a concurrent change to the same port is overwritten."
        ),
        "exclusive_resources": ["instrument_session", "digital_output"],
    },
    "Configure Totalizer": {
        "risk_level": "medium",
        "blocking": False,
        "notes": (
            "READ_RESET mode makes every subsequent read destructive."
        ),
        "exclusive_resources": ["instrument_session"],
    },
    "Read Totalizer": {
        "risk_level": "medium",
        "blocking": False,
        "notes": (
            "In READ_RESET mode this CONSUMES the count: the instrument "
            "zeroes it and a second read returns 0, which is a plausible "
            "count rather than an error."
        ),
        "exclusive_resources": ["instrument_session"],
    },
    "Clear Totalizer": {
        "risk_level": "medium",
        "blocking": False,
        "notes": "Discards the current count irrecoverably.",
        "exclusive_resources": ["instrument_session"],
    },
    "Write Analog Output": {
        "risk_level": "high",
        "blocking": False,
        "notes": (
            "DRIVES A PHYSICAL VOLTAGE, -12 V to +12 V. Out-of-range "
            "values are rejected, not clamped."
        ),
        "exclusive_resources": ["instrument_session", "analog_output"],
    },
    "Read Analog Output Setting": {
        "risk_level": "low",
        "blocking": False,
        "notes": (
            "Reports the COMMANDED setting, not a measurement of the "
            "output. A shorted output reads back the same as a working one."
        ),
        "exclusive_resources": ["instrument_session"],
    },
    "Read Output State": {
        "risk_level": "low",
        "blocking": True,
        "notes": "Queries the instrument for actual output state, unlike Get Driven Outputs.",
        "exclusive_resources": ["instrument_session"],
    },
    "Return Outputs To Safe State": {
        "risk_level": "high",
        "blocking": True,
        "notes": "DRIVES PHYSICAL OUTPUT LINES to zero. Zero is not safe for active-low hardware.",
        "exclusive_resources": ["instrument_session"],
    },
    "Get Driven Outputs": {
        "risk_level": "low",
        "blocking": False,
        "notes": "Driver-side record of what THIS DRIVER drove; not a survey of what is energised.",
        "exclusive_resources": [],
    },
}


def _parse_bool(value, label: str) -> bool:
    text = str(value).strip().upper()
    if text in {"ON", "TRUE", "YES", "1", "HIGH", "SET"}:
        return True
    if text in {"OFF", "FALSE", "NO", "0", "LOW", "CLEAR"}:
        return False
    raise AssertionError(f"{label} must be ON or OFF, got {value!r}")


def _parse_port_value(value) -> int:
    """Parse a port value, accepting decimal, 0b binary and 0x hex.

    Binary is the natural notation for a bit pattern and hex for a
    register value; requiring decimal would mean the caller converting
    by hand, which is where transcription errors enter.
    """

    if isinstance(value, int):
        return value
    text = str(value).strip()
    if not text:
        raise AssertionError("Digital port value is required")
    try:
        return int(text, 0) if text.lower().startswith(("0b", "0x")) else int(text)
    except ValueError as exc:
        raise AssertionError(
            f"Digital port value must be an integer, or 0b/0x prefixed, "
            f"got {value!r}"
        ) from exc


class DigitalKeywords:
    """Digital I/O keywords. Composed into Keysight34970."""

    # Declares this mixin's session-reset hook. Omitting it means the
    # engine -- and with it the record of every output driven this
    # session -- would survive a disconnect and be reported against the
    # next connection.
    SESSION_RESET_HOOKS = ("_reset_digital_state",)

    def __init__(self) -> None:
        self._digital_engine: Optional[ScpiDigitalEngine] = None

    # -- digital ports ---------------------------------------------

    @keyword("Read Digital Port")
    def read_digital_port(self, channel: str) -> int:
        """Reads an 8-bit digital port and returns its value, 0-255.

        Channels 01 and 02 of a 34907A are digital ports; addressing any
        other channel fails naming the role it actually has.

        Example:
        | ${value}= | Read Digital Port | 101 |
        """

        return self._require_digital_engine().read_port(channel).value

    @keyword("Read Digital Port Bits")
    def read_digital_port_bits(self, channel: str) -> str:
        """Reads a digital port and returns it as an 8-character binary
        string, most significant bit first — the order a wiring diagram
        is usually read in.

        Example:
        | ${bits}= | Read Digital Port Bits | 101 |    # -> "10100101"
        """

        return self._require_digital_engine().read_port(channel).to_binary()

    @keyword("Write Digital Port")
    def write_digital_port(self, channel: str, value: str) -> None:
        """**Drives an 8-bit digital port.** This changes physical output
        lines and is not undone by reading; the previous value is not
        recoverable from the instrument.

        ``value`` accepts decimal, ``0b`` binary or ``0x`` hex. Values
        outside 0-255 are rejected rather than truncated.

        Example:
        | Write Digital Port | 101 | 0b10100101 |
        """

        self._require_digital_engine().write_port(
            channel, _parse_port_value(value)
        )

    @keyword("Write Digital Port Bit")
    def write_digital_port_bit(self, channel: str, bit: int, value: str) -> None:
        """**Drives one bit of a digital port**, preserving the others.

        Not atomic: the driver reads the port, changes one bit and
        writes the byte back, because the instrument offers no
        bit-scoped write. If something else drives the same port in
        between, that change is overwritten.

        Example:
        | Write Digital Port Bit | 101 | 3 | ON |
        """

        self._require_digital_engine().write_port_bit(
            channel, int(bit), _parse_bool(value, "value")
        )

    # -- totalizer -------------------------------------------------

    @keyword("Configure Totalizer")
    def configure_totalizer(
        self,
        channel: str,
        mode: str = "READ",
        slope: str = "POSITIVE",
        threshold: str = None,
    ) -> None:
        """Configures the counter on channel 03 of a 34907A.

        - ``mode``: READ or READ_RESET. **READ_RESET makes every
          subsequent read destructive** — the instrument zeroes the
          count as part of the read, so a second read returns 0. Zero is
          a plausible count, not an error, so anything that reads twice,
          retries after a timeout, or logs before asserting will lose
          data silently. READ is the default for that reason.
        - ``slope``: POSITIVE or NEGATIVE counting edge.
        - ``threshold``: TTL or AC. The wrong choice gives a plausible
          and wrong count — usually zero, or double.

        Example:
        | Configure Totalizer | 103 | mode=READ | slope=NEGATIVE |
        """

        self._require_digital_engine().configure_totalizer(
            channel,
            TotalizerConfig(
                mode=_parse_enum(mode, TotalizerMode, "mode", {
                    "READ_RESET": TotalizerMode.READ_RESET,
                    "RESET": TotalizerMode.READ_RESET,
                    "RRES": TotalizerMode.READ_RESET,
                    "READ": TotalizerMode.READ,
                }),
                slope=_parse_enum(slope, EdgeSlope, "slope", {
                    "POSITIVE": EdgeSlope.POSITIVE, "POS": EdgeSlope.POSITIVE,
                    "RISING": EdgeSlope.POSITIVE,
                    "NEGATIVE": EdgeSlope.NEGATIVE, "NEG": EdgeSlope.NEGATIVE,
                    "FALLING": EdgeSlope.NEGATIVE,
                }),
                threshold=(
                    None
                    if threshold is None or not str(threshold).strip()
                    else _parse_enum(threshold, InputThreshold, "threshold", {
                        "TTL": InputThreshold.TTL, "AC": InputThreshold.AC,
                    })
                ),
            ),
        )

    @keyword("Read Totalizer")
    def read_totalizer(self, channel: str) -> int:
        """Reads the counter and returns the count.

        **If the totalizer is in READ_RESET mode this consumes the
        count** — the instrument zeroes it, and the value returned here
        is the only remaining copy. Use `Read Totalizer Details` if you
        need to know whether that happened.

        Example:
        | ${count}= | Read Totalizer | 103 |
        """

        return self._require_digital_engine().read_totalizer(channel).count

    @keyword("Read Totalizer Details")
    def read_totalizer_details(self, channel: str) -> dict:
        """Reads the counter and returns ``count``, ``channel``,
        ``reset_by_read`` and ``near_wrap``.

        ``reset_by_read`` tells you whether this read destroyed the
        count. ``near_wrap`` warns that the 26-bit counter is close to
        wrapping to zero — a wrapped count is indistinguishable from a
        low one.

        Example:
        | ${r}= | Read Totalizer Details | 103 |
        | Should Not Be True | ${r}[near_wrap] |
        """

        reading = self._require_digital_engine().read_totalizer(channel)
        return {
            "count": reading.count,
            "channel": str(reading.channel),
            "reset_by_read": reading.was_reset_by_read,
            "near_wrap": reading.is_near_wrap,
        }

    @keyword("Clear Totalizer")
    def clear_totalizer(self, channel: str) -> None:
        """Zeroes the counter immediately. The current count is
        discarded and is not recoverable."""

        self._require_digital_engine().clear_totalizer(channel)

    # -- analogue outputs ------------------------------------------

    @keyword("Write Analog Output")
    def write_analog_output(self, channel: str, volts: float) -> None:
        """**Drives an analogue output to a voltage**, -12 V to +12 V.

        Channels 04 and 05 of a 34907A. Out-of-range values are
        **rejected, not clamped**: clamping would drive a different
        voltage than you asked for, which on an output is a hardware
        event rather than a rounding error.

        Example:
        | Write Analog Output | 104 | 5.0 |
        """

        self._require_digital_engine().write_dac(channel, float(volts))

    @keyword("Read Analog Output Setting")
    def read_analog_output_setting(self, channel: str) -> float:
        """Returns the voltage an analogue output is **set to**.

        This is the commanded setting, not a measurement. A shorted or
        heavily loaded output reads back exactly the same as a working
        one — to verify the actual voltage, measure it on a DMM channel.
        """

        return self._require_digital_engine().read_dac_setting(channel).volts

    # -- introspection ---------------------------------------------

    @keyword("Get Driven Outputs")
    def get_driven_outputs(self) -> list:
        """Returns every output **this driver** drove in the current
        session, in order, as ``"<value> @<channel>"`` strings.

        Intended for teardown: an output left energised after a test is
        a hazard that no amount of instrument state inspection will
        attribute back to the test that caused it.

        **This is not a list of what is currently energised.** An output
        set from the front panel, by a previous session, or via
        `Send Scpi Command` never appears here, and one this driver set
        that something else later changed still appears with the
        driver's value. Use `Read Output State` to ask the hardware.

        The distinction matters most in precisely the situation where
        this keyword matters at all: deciding whether it is safe to
        disconnect.
        """

        return [str(o) for o in self._require_digital_engine().written_outputs()]

    @keyword("Read Output State")
    def read_output_state(self, channels: str = "") -> dict:
        """Asks the **instrument** for the present state of output
        channels, returning ``{channel: value}``.

        Unlike `Get Driven Outputs`, this reflects the hardware
        regardless of who set it — front panel, a previous session, or a
        raw SCPI command.

        With no argument it queries the outputs this driver has driven,
        which is the useful default for a teardown check. **That is not
        a survey of the whole card**: pass channels explicitly to check
        outputs the driver never touched.

        Example:
        | ${state}= | Read Output State | (@301,304) |
        """

        engine = self._require_digital_engine()
        target = channels if str(channels).strip() else None
        return {str(k): v for k, v in engine.read_output_state(target).items()}

    @keyword("Return Outputs To Safe State")
    def return_outputs_to_safe_state(self) -> dict:
        """Sets every output this driver has driven to zero, and returns
        what was reset as ``{channel: value}``.

        Intended for teardown. Zero means 0 V on a DAC and all-low on a
        digital port.

        **Zero is not universally safe.** An active-low relay driver
        energises on zero, and a valve held closed by a high line opens
        when it drops. This is why the driver offers this as an explicit
        keyword rather than doing it automatically on disconnect —
        de-energising hardware at teardown can be exactly the wrong
        move, and only you know which.

        Only outputs this driver drove are reset; see `Read Output
        State` for what is actually energised.

        Example:
        | [Teardown] | Return Outputs To Safe State |
        """

        engine = self._require_digital_engine()
        return {str(k): v for k, v in engine.safe_output_state().items()}

    # -- internals -------------------------------------------------

    def _require_digital_engine(self) -> ScpiDigitalEngine:
        if self._digital_engine is None:
            connection = getattr(self, "_connection", None)
            if connection is None or not connection.is_connected:
                raise AssertionError(
                    "No instrument connection is open - call "
                    "'Connect To Instrument' first"
                )
            self._digital_engine = ScpiDigitalEngine(
                connection, cards=getattr(self, "_declared_cards", None)
            )
        return self._digital_engine

    def _reset_digital_state(self) -> None:
        """Drop the engine so a later connection builds a fresh one.

        The record of driven outputs goes with it: the driver must not
        claim knowledge of outputs it set in a session that has ended.
        """

        self._digital_engine = None


def _parse_enum(value, enum_cls, label: str, aliases: dict):
    text = str(value).strip().upper().replace(" ", "_")
    if text in aliases:
        return aliases[text]
    try:
        return enum_cls(text)
    except ValueError:
        pass
    raise AssertionError(
        f"{label} must be one of {sorted(set(aliases))}, got {value!r}"
    )
