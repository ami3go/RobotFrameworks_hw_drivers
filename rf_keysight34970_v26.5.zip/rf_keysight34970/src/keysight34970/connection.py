"""
Connection framework.

Connection owns the instrument's SCPI session lifecycle: opening the
configured Transport, identifying/resetting/clearing the instrument on
connect, checking the SCPI error queue after operations, and exposing a
small state machine so higher layers (Robot keywords, Phase 2+ engines)
can guard operations that require a live connection.

State machine (Phase 1):

    IDLE --connect()--> CONNECTING --success--> CONNECTED
      ^                      |
      |                   failure
      |                      v
      +<---close()------- ERROR
    CONNECTED --close()--> CLOSED

CONNECTED --disconnect()--> IDLE (clean, reusable)
Any state --fatal transport error--> ERROR (must close() before reuse)
"""

from __future__ import annotations

import time
from enum import Enum, auto

from .config import ConnectionConfig, TransportKind
from .exceptions import CommandError, ConfigurationError, StateError, TransportError
from .logging_config import get_logger
from .models import InstrumentIdentity, ScpiError
from .transport import Transport, TcpSocketTransport, VisaTransport


class ConnectionState(Enum):
    IDLE = auto()
    CONNECTING = auto()
    CONNECTED = auto()
    ERROR = auto()
    CLOSED = auto()


_VALID_OPERATING_STATES = frozenset({ConnectionState.CONNECTED})


class Connection:
    """Manages one instrument's SCPI session over a configured Transport."""

    def __init__(self, config: ConnectionConfig, *, transport: Transport | None = None) -> None:
        """
        Args:
            config: connection configuration (transport kind, address,
                timeouts, connect-time behavior).
            transport: **testing only.** Injects a pre-built Transport
                (e.g. a fake) instead of constructing one from
                ``config``. Not part of the supported public API for
                production use — production code should configure the
                transport via ``config`` instead.
        """

        self._config = config
        self._state = ConnectionState.IDLE
        self._transport: Transport | None = None
        self._injected_transport = transport
        self._identity: InstrumentIdentity | None = None
        self._log = get_logger(config.display_name())

    # -- properties ---------------------------------------------------

    @property
    def state(self) -> ConnectionState:
        return self._state

    @property
    def config(self) -> ConnectionConfig:
        return self._config

    @property
    def identity(self) -> InstrumentIdentity | None:
        """Populated after connect() if identify_on_connect was True."""
        return self._identity

    @property
    def is_connected(self) -> bool:
        return self._state == ConnectionState.CONNECTED

    # -- lifecycle ------------------------------------------------------

    def connect(self) -> None:
        """Validate configuration, open the transport, and bring the
        instrument to a known state per the configured connect options.

        Raises:
            ConfigurationError: if the configuration is invalid.
            ConnectionError34970: if a connection attempt is made from a
                state that doesn't permit it.
            TransportError: if the transport cannot be opened.
        """

        if self._state not in (ConnectionState.IDLE, ConnectionState.CLOSED):
            raise StateError(
                f"connect() not permitted from state {self._state.name}",
                context={"state": self._state.name},
            )

        self._config.validate()
        self._state = ConnectionState.CONNECTING
        self._log.info("Connecting via %s", self._config.transport.value)

        try:
            self._transport = self._build_transport()
            self._transport.open()

            if self._config.clear_on_connect:
                self._transport.write("*CLS")
            if self._config.reset_on_connect:
                self._transport.write("*RST")
                time.sleep(self._config.stabilization_delay_s)
            if self._config.identify_on_connect:
                raw_idn = self._transport.query("*IDN?")
                self._identity = InstrumentIdentity.parse(raw_idn)
                self._log.info("Identified instrument: %s", self._identity.raw)

                if self._config.verify_model:
                    self._verify_model(self._identity)

        except Exception:
            self._state = ConnectionState.ERROR
            self._log.error("Connect failed; transitioning to ERROR state")
            raise

        self._state = ConnectionState.CONNECTED
        self._log.info("Connected")

    def disconnect(self) -> None:
        """Close the transport and return to IDLE so the Connection
        object can be reused with connect() again. Safe to call from
        any state."""

        if self._transport is not None:
            self._transport.close()
        self._transport = None
        self._identity = None
        self._state = ConnectionState.IDLE
        self._log.info("Disconnected")

    def close(self) -> None:
        """Terminally close this Connection. Unlike disconnect(), the
        object is not intended to be reused afterwards."""

        if self._transport is not None:
            self._transport.close()
        self._transport = None
        self._state = ConnectionState.CLOSED
        self._log.info("Closed")

    def reconnect(self) -> None:
        """Convenience for disconnect() followed by connect(). Useful
        after a CommandError/TransportError has left the caller unsure
        of instrument state, or as a keyword for Robot suites that want
        a clean slate between test cases without re-instantiating the
        library."""

        self.disconnect()
        self.connect()

    def __enter__(self) -> "Connection":
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()

    def __repr__(self) -> str:  # pragma: no cover - trivial
        return (
            f"Connection(model={self._config.model.value!r}, "
            f"target={self._config.display_name()!r}, "
            f"state={self._state.name})"
        )

    # -- SCPI primitives ------------------------------------------------

    def write(self, command: str, *, check_errors: bool = True) -> None:
        """Send a SCPI command with no response expected.

        Args:
            check_errors: if True (default), queries the instrument's
                error queue afterwards and raises CommandError if the
                instrument reported a fault.
        """

        self._require_connected()
        self._transport.write(command)  # type: ignore[union-attr]
        if check_errors:
            self._check_error_queue(command)

    def query(self, command: str, *, check_errors: bool = True) -> str:
        """Send a SCPI query and return the raw response string."""

        self._require_connected()
        response = self._transport.query(command)  # type: ignore[union-attr]
        if check_errors:
            self._check_error_queue(command)
        return response

    def query_error_queue_once(self) -> ScpiError:
        """Pop and return a single entry from the instrument's SCPI
        error queue without raising. Useful for diagnostics keywords
        that want to drain/inspect the queue explicitly."""

        self._require_connected()
        raw = self._transport.query("SYST:ERR?")  # type: ignore[union-attr]
        return ScpiError.parse(raw)

    def drain_error_queue(self, *, max_entries: int = 20) -> list[ScpiError]:
        """Pop and return every entry currently in the instrument's SCPI
        error queue (up to ``max_entries``, as a safety bound against a
        misbehaving instrument that never reports "No error").

        Does not raise on non-empty queue entries; this is a diagnostic
        read, not an assertion. Use `write`/`query` (check_errors=True,
        the default) for the assert-on-error behavior."""

        self._require_connected()
        errors: list[ScpiError] = []
        for _ in range(max_entries):
            error = self.query_error_queue_once()
            if error.is_no_error:
                break
            errors.append(error)
        return errors

    def reset(self) -> None:
        """Send `*RST` and wait out the configured stabilization delay.
        Does not touch the error queue itself (a `*RST` in progress can
        legitimately leave stale entries from *before* the reset)."""

        self._require_connected()
        self._transport.write("*RST")  # type: ignore[union-attr]
        if self._config.stabilization_delay_s:
            time.sleep(self._config.stabilization_delay_s)
        self._log.info("Instrument reset (*RST)")

    def clear_status(self) -> None:
        """Send `*CLS` to clear the instrument's status/error queue."""

        self._require_connected()
        self._transport.write("*CLS")  # type: ignore[union-attr]
        self._log.info("Instrument status cleared (*CLS)")

    def set_timeout(self, timeout_s: float) -> None:
        """Update the transport timeout used for subsequent commands.
        Also updates ``self.config.timeout_s`` so a later reconnect()
        keeps using the new value.

        Raises:
            ConfigurationError: if timeout_s is not positive.
        """

        if timeout_s <= 0:
            raise ConfigurationError(f"timeout_s must be > 0, got {timeout_s}")
        self._config.timeout_s = timeout_s
        if self._transport is not None:
            self._transport.set_timeout(timeout_s)
        self._log.info("Timeout set to %.3fs", timeout_s)

    # -- internals --------------------------------------------------

    def _build_transport(self) -> Transport:
        if self._injected_transport is not None:
            return self._injected_transport

        alias = self._config.display_name()
        if self._config.transport == TransportKind.VISA:
            return VisaTransport(
                self._config.visa_resource,  # type: ignore[arg-type]
                self._config.timeout_s,
                alias=alias,
            )
        return TcpSocketTransport(
            self._config.host,  # type: ignore[arg-type]
            self._config.port,
            self._config.timeout_s,
            alias=alias,
            terminator=self._config.terminator,
        )

    def _require_connected(self) -> None:
        if self._state not in _VALID_OPERATING_STATES:
            raise StateError(
                "Operation requires an active connection "
                f"(current state: {self._state.name})",
                context={"state": self._state.name},
            )

    def _verify_model(self, identity: InstrumentIdentity) -> None:
        expected = self._config.model.value
        reported = identity.model.strip().upper()
        if expected.upper() not in reported and reported not in expected.upper():
            raise ConfigurationError(
                f"Configured model {expected!r} does not match instrument-"
                f"reported model {identity.model!r}. Set verify_model=False "
                "to bypass this check if intentional.",
                context={"configured_model": expected, "reported_model": identity.model},
            )

    def _check_error_queue(self, command: str) -> None:
        try:
            error = self.query_error_queue_once()
        except TransportError as exc:
            # The command itself may have succeeded; we just couldn't
            # confirm it via SYST:ERR?. Surface this distinctly from a
            # CommandError (which means the instrument *did* respond
            # and reported a fault) so callers don't misdiagnose a
            # transport hiccup as a bad SCPI command.
            raise TransportError(
                f"Could not verify error queue after command {command!r} "
                "(transport failure during error check)",
                context={"command": command, "underlying_error": str(exc)},
            ) from exc

        if not error.is_no_error:
            raise CommandError(
                f"Instrument reported error {error.code}: {error.message}",
                scpi_code=error.code,
                scpi_message=error.message,
                command=command,
            )
