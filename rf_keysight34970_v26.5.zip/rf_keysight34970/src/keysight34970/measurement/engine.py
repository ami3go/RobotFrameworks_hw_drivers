"""
SCPI implementation of the MeasurementEngine interface.

Owns no I/O of its own: every instrument interaction goes through the
Phase 1 ``Connection``, which keeps transport concerns and error-queue
policy in one place and lets this engine be tested against a fake
connection.

SCPI MODEL (per the 34970A/34972A programmer's reference):

- ``CONF:<function> <range>,<resolution>,(@<channels>)`` configures
  channels without reading. Configuration persists.
- ``ROUT:SCAN (@<channels>)`` defines the scan list.
- ``READ?`` initiates a scan of the scan list and returns readings.
- ``MEAS:<function>? <range>,<resolution>,(@<channels>)`` configures
  and reads in one shot, resetting unspecified parameters to defaults.

VERIFICATION STATUS: this command sequencing follows the published
programmer's reference and is exercised against the in-repo mock
instrument. It has NOT been verified against physical hardware.
"""

from __future__ import annotations

from typing import Optional, Sequence

from ..connection import Connection
from ..exceptions import ConfigurationError
from ..logging_config import get_logger
from .base import MeasurementEngine
from .channels import CardType, ChannelId, ChannelList
from .models import (
    AcquisitionSettings,
    Measurement,
    MeasurementConfig,
    MeasurementFunction,
    Unit,
)
from .parsing import parse_readings


def _ascending(channels: ChannelList) -> ChannelList:
    """Return the channels sorted by address, ascending.

    WHY THIS EXISTS -- correctness, not cosmetics.

    Readings are attached to channels *positionally*: the Nth value in
    the response is taken to belong to the Nth channel. The mainframe
    scans a channel list in ascending channel order regardless of the
    order the list was written in. So if a caller asks for
    ``(@105,101)`` and the instrument returns ``ascending`` results,
    positional attribution would report channel 105's reading as
    channel 101's and vice versa -- a silent, plausible-looking wrong
    answer.

    The Gate 1 count-mismatch guard cannot catch this: the counts match
    perfectly, only the mapping is wrong. Normalising to ascending
    order here makes the driver's assumption match the instrument's
    documented behaviour.

    Consequence for callers: readings are returned in ascending channel
    order, which may differ from the order channels were requested in.
    Each Measurement carries its own ``channel``, so map by channel
    rather than by position.

    HARDWARE VERIFICATION REQUIRED: the ascending-scan behaviour is
    taken from the programmer's reference and has not been confirmed on
    a physical mainframe. If a real instrument ever returns readings in
    written order instead, this normalisation must be revisited --
    see tests/unit/test_measurement_engine.py::
    test_read_normalises_channel_order_ascending.
    """

    return ChannelList(sorted(channels, key=lambda c: c.address))


class ScpiMeasurementEngine(MeasurementEngine):
    """Measurement engine driving a 34970A/34972A over SCPI."""

    def __init__(
        self,
        connection: Connection,
        *,
        cards: Optional[dict[int, CardType]] = None,
    ) -> None:
        """
        Args:
            connection: an active Phase 1 Connection.
            cards: optional slot -> CardType map enabling channel
                validation. Slots absent from the map are treated as
                UNKNOWN (relaxed validation) rather than rejected, so a
                partially-described bench still works. The driver
                cannot yet discover installed cards itself; see Phase 7.
        """

        self._connection = connection
        self._cards: dict[int, CardType] = dict(cards or {})
        self._configured: dict[int, MeasurementConfig] = {}
        self._scan_list: Optional[ChannelList] = None
        self._log = get_logger(connection.config.display_name())

    # -- properties -----------------------------------------------

    @property
    def cards(self) -> dict[int, CardType]:
        return dict(self._cards)

    def set_card(self, slot: int, card: CardType) -> None:
        """Declare which card occupies a slot, enabling validation."""

        if not (1 <= slot <= 3):
            raise ConfigurationError(
                f"slot must be 1-3, got {slot}", context={"slot": slot}
            )
        self._cards[slot] = card

    # -- MeasurementEngine ----------------------------------------

    def configure(self, channels: ChannelList, config: MeasurementConfig) -> None:
        channels = ChannelList.parse(channels)
        self._validate(channels, config)

        command = (
            f"CONF:{config.function.value} {config.scpi_arguments()},"
            f"{channels.to_scpi()}"
        )
        self._connection.write(command)
        self._apply_acquisition(channels, config)

        for channel in channels:
            self._configured[channel.address] = config
        self._log.info(
            "Configured %s on %s", config.function.value, channels.to_scpi()
        )

    def read(self, channels: ChannelList | None = None) -> Sequence[Measurement]:
        target = _ascending(self._resolve_read_target(channels))

        self._connection.write(f"ROUT:SCAN {target.to_scpi()}")
        response = self._connection.query("READ?")

        return self._parse_for(target, response)

    def measure(
        self, channels: ChannelList, config: MeasurementConfig
    ) -> Sequence[Measurement]:
        channels = ChannelList.parse(channels)

        # MEAS: configures, triggers and returns in a single operation,
        # and resets parameters the caller did not specify. There is no
        # point at which SENS: acquisition settings could be applied and
        # still affect the reading. Silently dropping them would hand
        # back a reading the caller believes was taken at 10 NPLC when
        # it was taken at the default -- so refuse instead.
        if not config.acquisition.is_empty:
            raise ConfigurationError(
                "measure() cannot apply NPLC / autozero / input impedance: "
                "MEAS: reads immediately and resets unspecified parameters, "
                "so these settings would be silently ignored. Use "
                "configure() with the acquisition settings, then read().",
                context={"function": config.function.value},
            )

        self._validate(channels, config)
        channels = _ascending(channels)

        command = (
            f"MEAS:{config.function.value}? {config.scpi_arguments()},"
            f"{channels.to_scpi()}"
        )
        response = self._connection.query(command)

        # MEAS: resets parameters the caller did not specify, so the
        # driver's record of per-channel configuration must reflect the
        # configuration MEAS actually applied, not whatever was set
        # before.
        for channel in channels:
            self._configured[channel.address] = config

        return parse_readings(
            response, config.function, channels, unit=self._unit_for(config.function)
        )

    def record_external_configuration(
        self, channels: "ChannelList | str | int", config: MeasurementConfig
    ) -> None:
        """Record that another engine configured these channels.

        The temperature engine issues its own ``CONF:TEMP`` commands but
        still needs scanning to tag those channels as TEMPERATURE rather
        than unconfigured. This is the supported way for it to say so.

        It deliberately does NOT send anything to the instrument -- the
        caller has already done that. Recording configuration the driver
        did not apply would be worse than not recording it, so this is
        named for what it is rather than reusing ``configure()``.

        (Closes a Phase 4 Gate 2 finding: the temperature engine
        previously wrote into this class's private ``_configured`` dict.)
        """

        # Accept a scalar channel as well as a list. Normalising here
        # rather than loosening ChannelList.parse keeps the shared
        # parser's contract unchanged.
        if isinstance(channels, (int, ChannelId)) or (
            isinstance(channels, str) and "," not in channels and ":" not in channels
        ):
            targets = ChannelList([channels])
        else:
            targets = ChannelList.parse(channels)

        for channel in targets:
            self._configured[channel.address] = config

    def clear_configuration(self, channels: ChannelList | None = None) -> None:
        """Forget the driver's record of configured channels.

        Does not change the instrument -- the function stays configured
        there until overwritten. This only resets what a bare ``read()``
        will scan.

        Exists because configuration accumulates: within a Robot suite
        (SUITE scope, one session across all test cases) every
        ``configure()`` adds to the set a bare ``read()`` covers. Without
        a way to reset, a test that configures 5 channels can silently
        read 20 because earlier tests configured the rest.
        """

        if channels is None:
            self._configured.clear()
            return
        for channel in ChannelList.parse(channels):
            self._configured.pop(channel.address, None)

    def get_configured_function(
        self, channel: "ChannelList | str | int"
    ) -> Optional[MeasurementConfig]:
        resolved = ChannelId.parse(
            channel if not isinstance(channel, ChannelList) else next(iter(channel))
        )
        return self._configured.get(resolved.address)

    # -- helpers ---------------------------------------------------

    def _resolve_read_target(self, channels: ChannelList | None) -> ChannelList:
        """Decide which channels a read() applies to, failing clearly
        rather than reading something the caller didn't ask for."""

        if channels is not None:
            target = ChannelList.parse(channels)
            if not len(target):
                raise ConfigurationError("Cannot read from an empty channel list")
            unconfigured = [
                c.address for c in target if c.address not in self._configured
            ]
            if unconfigured:
                raise ConfigurationError(
                    f"Channel(s) {unconfigured} have not been configured; "
                    "call configure() first or use measure()",
                    context={"unconfigured": unconfigured},
                )
            return target

        if not self._configured:
            raise ConfigurationError(
                "No channels have been configured; call configure() before read()"
            )
        return ChannelList(list(self._configured.keys()))

    def _parse_for(
        self, target: ChannelList, response: str
    ) -> Sequence[Measurement]:
        """Parse a multi-channel response.

        Channels may carry different functions, so readings are attached
        per channel using that channel's own recorded configuration
        rather than assuming one function across the whole scan.
        """

        channel_list = list(target)
        functions = {
            self._configured[c.address].function
            for c in channel_list
            if c.address in self._configured
        }

        if len(functions) == 1:
            function = functions.pop()
            return parse_readings(
                response, function, target, unit=self._unit_for(function)
            )

        # Mixed functions: parse positionally, then re-tag each reading
        # with its own channel's function and unit.
        placeholder = MeasurementFunction.DC_VOLTAGE
        parsed = parse_readings(response, placeholder, target)
        retagged: list[Measurement] = []
        for measurement, channel in zip(parsed, channel_list):
            config = self._configured[channel.address]
            retagged.append(
                Measurement(
                    value=measurement.value,
                    unit=self._unit_for(config.function),
                    function=config.function,
                    channel=channel,
                    timestamp=measurement.timestamp,
                    raw=measurement.raw,
                )
            )
        return retagged

    def _unit_for(self, function: MeasurementFunction) -> Unit:
        return function.unit

    def _apply_acquisition(
        self, channels: ChannelList, config: MeasurementConfig
    ) -> None:
        """Apply NPLC / autozero / input impedance after the function is
        set.

        Order matters: these live in SENS: subsystems keyed by function,
        so CONF: must have established the function first. Each setting
        is a separate command, and each costs an error-queue round trip
        (the Phase 1 performance finding) -- so they are only sent when
        explicitly requested, never as defaults.
        """

        acquisition = config.acquisition
        if acquisition.is_empty:
            return

        target = channels.to_scpi()
        function = config.function.value

        if acquisition.nplc is not None:
            self._connection.write(
                f"SENS:{function}:NPLC {acquisition.nplc.value},{target}"
            )
        if acquisition.input_impedance is not None:
            # AUTO ON means "auto-select impedance"; HIGH forces >10 Gohm.
            state = "ON" if acquisition.input_impedance.value == "AUTO" else "OFF"
            self._connection.write(f"SENS:VOLT:DC:IMP:AUTO {state},{target}")
        if acquisition.autozero is not None:
            self._connection.write(
                f"SENS:{function}:ZERO:AUTO {acquisition.autozero.value},{target}"
            )

    def four_wire_pair(self, channel: ChannelId) -> ChannelId:
        """Return the paired channel a 4-wire measurement occupies.

        The mainframe pairs channel N with N+10 on the same slot for
        4-wire measurements; the paired channel is consumed by the
        measurement and cannot be used independently.
        """

        return ChannelId(slot=channel.slot, channel=channel.channel + 10)

    def _validate_four_wire(self, channels: ChannelList) -> None:
        """Reject 4-wire configurations whose paired channel does not
        exist or is already in use for something else.

        Without this the instrument silently consumes the paired
        channel, and a later measurement configured on it appears to
        work while actually fighting the 4-wire pairing.
        """

        from .channels import CARD_SPECS

        for channel in channels:
            try:
                paired = self.four_wire_pair(channel)
            except ConfigurationError as exc:
                raise ConfigurationError(
                    f"4-wire resistance on {channel} requires paired channel "
                    f"{channel.channel + 10}, which is out of range",
                    context={"channel": channel.address},
                ) from exc

            card = self._cards.get(channel.slot, CardType.UNKNOWN)
            if channel.slot in self._cards:
                spec = CARD_SPECS[card]
                if paired.channel not in spec.valid_channels:
                    raise ConfigurationError(
                        f"4-wire resistance on {channel} requires paired "
                        f"channel {paired}, which does not exist on the "
                        f"{card.value} in slot {channel.slot}",
                        context={
                            "channel": channel.address,
                            "paired": paired.address,
                            "card": card.value,
                        },
                    )

            existing = self._configured.get(paired.address)
            if existing is not None and existing.function is not (
                MeasurementFunction.RESISTANCE_4W
            ):
                raise ConfigurationError(
                    f"4-wire resistance on {channel} needs paired channel "
                    f"{paired}, but {paired} is already configured for "
                    f"{existing.function.value}. Reconfigure or choose "
                    "another channel.",
                    context={"channel": channel.address, "paired": paired.address},
                )

    def _validate(self, channels: ChannelList, config: MeasurementConfig) -> None:
        """Reject configurations the instrument cannot honour, before
        sending them, so the failure names the actual problem rather
        than surfacing as a generic SCPI error."""

        if not len(channels):
            raise ConfigurationError("Cannot configure an empty channel list")

        # Renders range/resolution, raising if resolution was set
        # without a range. Called here so the error arrives before any
        # instrument interaction.
        config.scpi_arguments()

        channels.validate_against(self._cards)

        if config.function.requires_four_wire:
            self._validate_four_wire(channels)

        for channel in channels:
            card = self._cards.get(channel.slot, CardType.UNKNOWN)
            spec_known = channel.slot in self._cards

            if spec_known:
                from .channels import CARD_SPECS

                spec = CARD_SPECS[card]

                if not spec.supports_measurement(channel.channel):
                    raise ConfigurationError(
                        f"Channel {channel} on the {card.value} in slot "
                        f"{channel.slot} cannot be routed to the internal DMM "
                        f"({spec.description})",
                        context={"channel": channel.address, "card": card.value},
                    )

                if config.function.requires_current_channel and not spec.supports_current(
                    channel.channel
                ):
                    raise ConfigurationError(
                        f"{config.function.value} requires a dedicated current "
                        f"channel; {channel} on the {card.value} is not one "
                        f"(current channels: "
                        f"{sorted(spec.current_channels) or 'none on this card'})",
                        context={
                            "channel": channel.address,
                            "function": config.function.value,
                        },
                    )
