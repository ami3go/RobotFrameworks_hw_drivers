"""
Parsing of instrument reading responses.

The 34970A/34972A returns readings as comma-separated ASCII floats in
scientific notation, e.g. ``+1.04250000E+00,+9.90000000E+37``. This
module turns those strings into ``Measurement`` objects.

Implemented in Gate 1 alongside the data models because it is pure
string handling with no I/O, and because the over-range sentinel
(``9.9E+37``) is a correctness trap: parsed naively it becomes a
plausible-looking float that will silently pass numeric assertions.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Sequence

from ..exceptions import CommandError
from .channels import ChannelId, ChannelList
from .models import Measurement, MeasurementFunction, Unit


def parse_reading(text: str) -> float:
    """Parse a single reading into a float.

    Raises:
        CommandError: if the response is not a parseable number. This is
            a CommandError rather than a ValueError because an
            unparseable reading means the instrument returned something
            unexpected -- an instrument-level fault, not a caller error.
    """

    cleaned = text.strip()
    if not cleaned:
        raise CommandError("Instrument returned an empty reading")
    try:
        return float(cleaned)
    except ValueError as exc:
        raise CommandError(
            f"Could not parse instrument reading: {cleaned!r}",
            scpi_message=cleaned,
        ) from exc


def parse_readings(
    response: str,
    function: MeasurementFunction,
    channels: ChannelList | Sequence[ChannelId] | None = None,
    *,
    unit: Unit | None = None,
) -> list[Measurement]:
    """Parse a comma-separated reading response into Measurements.

    Args:
        response: raw instrument response.
        function: the function that produced these readings, used to
            tag each Measurement and derive its unit.
        channels: channels the readings correspond to, in order. If
            supplied, the count must match the number of readings --
            a mismatch means readings would be attributed to the wrong
            channel, which is worse than failing.
        unit: override the unit derived from ``function`` (used for
            temperature, where the instrument's configured unit may be
            Celsius, Fahrenheit, or Kelvin).

    Raises:
        CommandError: on an empty response, an unparseable reading, or
            a channel/reading count mismatch.
    """

    if not response or not response.strip():
        raise CommandError("Instrument returned an empty reading response")

    values = [parse_reading(part) for part in response.split(",")]

    channel_list: list[ChannelId] | None = None
    if channels is not None:
        channel_list = list(channels)
        if len(channel_list) != len(values):
            raise CommandError(
                f"Reading count mismatch: instrument returned {len(values)} "
                f"reading(s) for {len(channel_list)} channel(s); refusing to "
                "guess the mapping",
                context={
                    "reading_count": len(values),
                    "channel_count": len(channel_list),
                },
            )

    timestamp = datetime.now(timezone.utc)
    resolved_unit = unit if unit is not None else function.unit

    return [
        Measurement(
            value=value,
            unit=resolved_unit,
            function=function,
            channel=channel_list[index] if channel_list else None,
            timestamp=timestamp,
            raw=response.strip(),
        )
        for index, value in enumerate(values)
    ]
