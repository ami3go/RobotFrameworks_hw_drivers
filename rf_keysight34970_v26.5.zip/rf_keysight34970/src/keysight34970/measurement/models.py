"""
Measurement data models.

Gate 1 scope: the vocabulary the Measurement Engine will speak --
functions, units, range/resolution settings, and the structured
``Measurement`` result object required by the Phase 2 summary. The
engine that *produces* these arrives in Gate 2.

These are pure data types with no I/O, so they are fully specified and
tested here rather than being sketched and finished later.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Optional

from ..exceptions import ConfigurationError
from .channels import ChannelId


class MeasurementFunction(str, Enum):
    """Measurement functions available via the internal DMM.

    Values are the SCPI function mnemonics, so a function maps directly
    onto ``CONF:<value>`` / ``MEAS:<value>?`` without a lookup table.
    """

    DC_VOLTAGE = "VOLT:DC"
    AC_VOLTAGE = "VOLT:AC"
    DC_CURRENT = "CURR:DC"
    AC_CURRENT = "CURR:AC"
    RESISTANCE_2W = "RES"
    RESISTANCE_4W = "FRES"
    FREQUENCY = "FREQ"
    PERIOD = "PER"
    CONTINUITY = "CONT"
    DIODE = "DIOD"
    TEMPERATURE = "TEMP"

    @property
    def unit(self) -> "Unit":
        return _FUNCTION_UNITS[self]

    @property
    def requires_current_channel(self) -> bool:
        """Current measurement requires a dedicated current channel
        (e.g. 21/22 on a 34901A), not a general-purpose one."""

        return self in {
            MeasurementFunction.DC_CURRENT,
            MeasurementFunction.AC_CURRENT,
        }

    @property
    def supports_nplc(self) -> bool:
        """Frequency and period are gated by an aperture time, not an
        integration time in power line cycles; continuity and diode run
        at a fixed configuration."""

        return self not in {
            MeasurementFunction.FREQUENCY,
            MeasurementFunction.PERIOD,
            MeasurementFunction.CONTINUITY,
            MeasurementFunction.DIODE,
        }

    @property
    def requires_four_wire(self) -> bool:
        """4-wire functions pair channel N with channel N+10, which
        makes the paired channel unavailable for other use."""

        return self is MeasurementFunction.RESISTANCE_4W


class Unit(str, Enum):
    VOLT = "V"
    AMPERE = "A"
    OHM = "Ohm"
    HERTZ = "Hz"
    SECOND = "s"
    CELSIUS = "degC"
    FAHRENHEIT = "degF"
    KELVIN = "K"
    BOOLEAN = ""      # continuity: pass/fail rather than a physical unit
    UNKNOWN = "?"


_FUNCTION_UNITS: dict[MeasurementFunction, Unit] = {
    MeasurementFunction.DC_VOLTAGE: Unit.VOLT,
    MeasurementFunction.AC_VOLTAGE: Unit.VOLT,
    MeasurementFunction.DC_CURRENT: Unit.AMPERE,
    MeasurementFunction.AC_CURRENT: Unit.AMPERE,
    MeasurementFunction.RESISTANCE_2W: Unit.OHM,
    MeasurementFunction.RESISTANCE_4W: Unit.OHM,
    MeasurementFunction.FREQUENCY: Unit.HERTZ,
    MeasurementFunction.PERIOD: Unit.SECOND,
    MeasurementFunction.CONTINUITY: Unit.OHM,
    MeasurementFunction.DIODE: Unit.VOLT,
    MeasurementFunction.TEMPERATURE: Unit.CELSIUS,
}


# The instrument returns this sentinel for an over-range reading. It is
# not a real value and must never be compared numerically as though it
# were; ``Measurement.is_overrange`` exists so callers don't hand-roll
# a float comparison against it.
OVERRANGE_SENTINEL = 9.9e37
_OVERRANGE_THRESHOLD = 9.0e37


class AutoRange(str, Enum):
    """Sentinel for range/resolution fields meaning "let the instrument
    decide", distinct from any numeric value."""

    AUTO = "AUTO"


# A range is either an explicit numeric value in the function's unit, or
# AUTO. Using a dedicated sentinel rather than None keeps "unset" and
# "explicitly autoranging" distinguishable.
RangeSetting = float | AutoRange
ResolutionSetting = float | AutoRange


class Nplc(str, Enum):
    """Integration time in Number of Power Line Cycles.

    Longer integration means lower noise and better normal-mode
    rejection of mains hum, at the cost of speed. 1 NPLC and above
    reject line noise; below 1 they do not, which is the trade-off
    worth being explicit about rather than burying in a float.
    """

    N_0_02 = "0.02"
    N_0_2 = "0.2"
    N_1 = "1"
    N_2 = "2"
    N_10 = "10"
    N_20 = "20"
    N_100 = "100"
    N_200 = "200"
    MIN = "MIN"
    MAX = "MAX"

    @property
    def rejects_line_noise(self) -> bool:
        """True if this integration time provides normal-mode rejection
        of mains frequency."""

        if self is Nplc.MAX:
            return True
        if self is Nplc.MIN:
            return False
        return float(self.value) >= 1.0


class AutoZero(str, Enum):
    """Autozero mode. OFF is faster but lets offset drift accumulate;
    ONCE takes a single zero reading then behaves like OFF."""

    ON = "ON"
    OFF = "OFF"
    ONCE = "ONCE"


class InputImpedance(str, Enum):
    """DC voltage input impedance.

    AUTO selects high impedance (>10 Gohm) on the lower ranges and
    10 Mohm above them. HIGH forces >10 Gohm on all ranges, which
    matters when measuring a high-source-impedance signal that a
    10 Mohm input would load down.
    """

    AUTO = "AUTO"
    HIGH = "HIGH"


@dataclass(frozen=True)
class AcquisitionSettings:
    """Per-channel acquisition tuning, separate from the function and
    range in ``MeasurementConfig``.

    Kept as its own type because these settings are applied by distinct
    SCPI subsystems (``SENS:<function>:NPLC``, ``SENS:ZERO:AUTO``,
    ``SENS:VOLT:DC:IMP:AUTO``) and because not every setting applies to
    every function -- NPLC is meaningless for frequency, which uses an
    aperture instead.
    """

    nplc: Optional[Nplc] = None
    autozero: Optional[AutoZero] = None
    input_impedance: Optional[InputImpedance] = None

    @property
    def is_empty(self) -> bool:
        return (
            self.nplc is None
            and self.autozero is None
            and self.input_impedance is None
        )

    def validate_for(self, function: "MeasurementFunction") -> None:
        """Reject settings the instrument cannot apply to this function,
        rather than letting them fail as an opaque SCPI error."""

        if self.nplc is not None and not function.supports_nplc:
            raise ConfigurationError(
                f"NPLC does not apply to {function.value}; that function "
                "uses an aperture/gate time rather than an integration "
                "time in power line cycles",
                context={"function": function.value},
            )
        if self.input_impedance is not None and function is not MeasurementFunction.DC_VOLTAGE:
            raise ConfigurationError(
                f"Input impedance applies only to DC voltage, not "
                f"{function.value}",
                context={"function": function.value},
            )


@dataclass(frozen=True)
class MeasurementConfig:
    """Configuration for one measurement function on one or more
    channels. Immutable so a configuration can be reused across
    channels without aliasing surprises."""

    function: MeasurementFunction
    range: RangeSetting = AutoRange.AUTO
    resolution: ResolutionSetting = AutoRange.AUTO
    acquisition: "AcquisitionSettings" = field(
        default_factory=lambda: AcquisitionSettings()
    )

    def __post_init__(self) -> None:
        if isinstance(self.range, (int, float)) and self.range <= 0:
            raise ConfigurationError(
                f"range must be positive or AUTO, got {self.range}",
                context={"function": self.function.value},
            )
        if isinstance(self.resolution, (int, float)) and self.resolution <= 0:
            raise ConfigurationError(
                f"resolution must be positive or AUTO, got {self.resolution}",
                context={"function": self.function.value},
            )
        self.acquisition.validate_for(self.function)

    @property
    def unit(self) -> Unit:
        return self.function.unit

    def scpi_arguments(self) -> str:
        """Render the ``<range>,<resolution>`` argument pair used by
        CONF/MEAS commands, e.g. ``"10,0.001"`` or ``"AUTO,AUTO"``.

        Resolution cannot be specified without a range, so a numeric
        resolution with an AUTO range is rejected rather than silently
        reordered or dropped.
        """

        if isinstance(self.resolution, (int, float)) and isinstance(
            self.range, AutoRange
        ):
            raise ConfigurationError(
                "resolution cannot be set while range is AUTO; "
                "specify an explicit range or leave both AUTO",
                context={"function": self.function.value},
            )

        range_text = "AUTO" if isinstance(self.range, AutoRange) else _format(self.range)
        resolution_text = (
            "DEF" if isinstance(self.resolution, AutoRange) else _format(self.resolution)
        )
        return f"{range_text},{resolution_text}"


def _format(value: float) -> str:
    """Render a float for SCPI without Python's scientific-notation
    quirks (e.g. ``1e-05`` rather than ``0.00001``)."""

    text = f"{value:.10g}"
    return text


@dataclass(frozen=True)
class Measurement:
    """A single structured measurement result.

    Carrying the function, unit, and channel alongside the value means a
    reading can be interpreted without knowing what was configured when
    it was taken -- which matters when results are logged, compared, or
    handed to an AI planner.
    """

    value: float
    unit: Unit
    function: MeasurementFunction
    channel: Optional[ChannelId] = None
    timestamp: datetime = field(
        default_factory=lambda: datetime.now(timezone.utc)
    )
    raw: Optional[str] = None
    """The unparsed instrument response, retained for diagnostics."""

    @property
    def is_overrange(self) -> bool:
        """True if the instrument reported an over-range reading rather
        than a real value."""

        return abs(self.value) >= _OVERRANGE_THRESHOLD

    def __str__(self) -> str:
        if self.is_overrange:
            body = "OVERRANGE"
        else:
            body = f"{self.value:.6g} {self.unit.value}".strip()
        if self.channel is not None:
            return f"{body} @{self.channel}"
        return body


@dataclass(frozen=True)
class MeasurementStatistics:
    """Summary statistics over a set of measurements.

    Populated by the Scanner Engine in Phase 3; defined here so the
    measurement vocabulary is complete in one place rather than split
    across phases.
    """

    count: int
    minimum: float
    maximum: float
    average: float
    unit: Unit
    function: Optional[MeasurementFunction] = None

    @property
    def span(self) -> float:
        return self.maximum - self.minimum

    @classmethod
    def from_measurements(
        cls, measurements: "list[Measurement]"
    ) -> "MeasurementStatistics":
        """Compute statistics, rejecting empty input and mixed units
        rather than producing a meaningless aggregate."""

        if not measurements:
            raise ConfigurationError(
                "Cannot compute statistics from an empty measurement set"
            )

        units = {m.unit for m in measurements}
        if len(units) > 1:
            raise ConfigurationError(
                f"Cannot aggregate measurements with mixed units: "
                f"{sorted(u.value for u in units)}",
                context={"units": sorted(u.value for u in units)},
            )

        overrange = [m for m in measurements if m.is_overrange]
        if overrange:
            raise ConfigurationError(
                f"Cannot compute statistics: {len(overrange)} of "
                f"{len(measurements)} readings are over-range",
                context={"overrange_count": len(overrange)},
            )

        values = [m.value for m in measurements]
        functions = {m.function for m in measurements}
        return cls(
            count=len(values),
            minimum=min(values),
            maximum=max(values),
            average=sum(values) / len(values),
            unit=measurements[0].unit,
            function=functions.pop() if len(functions) == 1 else None,
        )
