"""
Measurement subpackage (Phase 2).

Gate 1 (this release) provides the data models, channel addressing, the
response parser, and the ``MeasurementEngine`` interface. The concrete
engine and its Robot Framework keywords arrive in Gate 2.
"""

from .base import MeasurementEngine
from .channels import CARD_SPECS, CardSpec, CardType, ChannelId, ChannelList
from .models import (
    OVERRANGE_SENTINEL,
    AutoRange,
    Measurement,
    MeasurementConfig,
    MeasurementFunction,
    MeasurementStatistics,
    Unit,
)
from .parsing import parse_reading, parse_readings

__all__ = [
    "MeasurementEngine",
    "CARD_SPECS",
    "CardSpec",
    "CardType",
    "ChannelId",
    "ChannelList",
    "AutoRange",
    "Measurement",
    "MeasurementConfig",
    "MeasurementFunction",
    "MeasurementStatistics",
    "OVERRANGE_SENTINEL",
    "Unit",
    "parse_reading",
    "parse_readings",
]
