"""
Channel addressing for the 34970A/34972A.

The mainframe has three slots (1, 2, 3). A channel is addressed as a
three-digit number ``sNN`` where ``s`` is the slot digit and ``NN`` is
the channel number on the card in that slot -- e.g. ``101`` is channel
1 of the card in slot 1, ``215`` is channel 15 of the card in slot 2.

SCPI takes these as a *channel list* in the form ``(@101,103,105:110)``,
where ``:`` denotes an inclusive range.

This module is pure logic with no I/O, so it is fully testable without
an instrument. It is deliberately implemented in Gate 1 (rather than
alongside the measurement commands in Gate 2) because every later
capability -- scanning, temperature, alarms, digital I/O -- addresses
channels, and getting the addressing model wrong would propagate.

CARD DATA CAVEAT: the per-card channel ranges in ``CARD_SPECS`` are
taken from published module specifications. They have NOT been verified
against physical cards. ``CardType.UNKNOWN`` exists so a bench with an
unrecognised or unverified card can still be addressed, with range
validation relaxed rather than guessed.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from enum import Enum
from typing import Iterable, Iterator, Sequence

from ..exceptions import ConfigurationError

MIN_SLOT = 1
MAX_SLOT = 3


class CardType(str, Enum):
    """Plug-in modules supported by the 34970A/34972A mainframe."""

    MUX_34901A = "34901A"   # 20ch armature mux + 2 current channels
    MUX_34902A = "34902A"   # 16ch reed mux
    ACT_34903A = "34903A"   # 20ch actuator / general purpose switch
    MTX_34904A = "34904A"   # 4x8 two-wire matrix
    RF_34905A = "34905A"    # dual 4ch RF mux, 50 ohm
    RF_34906A = "34906A"    # dual 4ch RF mux, 75 ohm
    MFM_34907A = "34907A"   # multifunction: DIO, totalizer, DAC
    MUX_34908A = "34908A"   # 40ch single-ended mux
    UNKNOWN = "UNKNOWN"     # present but unidentified; validation relaxed


@dataclass(frozen=True)
class CardSpec:
    """Channel numbering rules for one card type.

    ``valid_channels`` is the authoritative set. ``measurable_channels``
    is the subset that can be routed to the internal DMM -- actuator,
    matrix, and multifunction cards can be *addressed* but cannot be
    *measured* through, which is exactly the kind of mistake an AI
    planner or a hurried engineer makes.
    """

    card_type: CardType
    description: str
    valid_channels: frozenset[int]
    measurable_channels: frozenset[int]
    current_channels: frozenset[int] = frozenset()

    def supports_measurement(self, channel: int) -> bool:
        return channel in self.measurable_channels

    def supports_current(self, channel: int) -> bool:
        return channel in self.current_channels


def _spec(
    card_type: CardType,
    description: str,
    valid: Iterable[int],
    measurable: Iterable[int] | None = None,
    current: Iterable[int] = (),
) -> CardSpec:
    valid_set = frozenset(valid)
    return CardSpec(
        card_type=card_type,
        description=description,
        valid_channels=valid_set,
        measurable_channels=frozenset(valid_set if measurable is None else measurable),
        current_channels=frozenset(current),
    )


CARD_SPECS: dict[CardType, CardSpec] = {
    CardType.MUX_34901A: _spec(
        CardType.MUX_34901A,
        "20-channel armature multiplexer with 2 current channels",
        valid=range(1, 23),          # 1-20 general, 21-22 current
        current=(21, 22),
    ),
    CardType.MUX_34902A: _spec(
        CardType.MUX_34902A,
        "16-channel reed multiplexer",
        valid=range(1, 17),
    ),
    CardType.ACT_34903A: _spec(
        CardType.ACT_34903A,
        "20-channel actuator / general-purpose switch",
        valid=range(1, 21),
        measurable=(),               # switching only; no DMM path
    ),
    CardType.MTX_34904A: _spec(
        CardType.MTX_34904A,
        "4x8 two-wire matrix switch",
        # Matrix channels are addressed as <row><column>: rows 1-4,
        # columns 1-8, giving 11-18, 21-28, 31-38, 41-48.
        valid=[row * 10 + col for row in range(1, 5) for col in range(1, 9)],
        measurable=(),               # switching only
    ),
    CardType.RF_34905A: _spec(
        CardType.RF_34905A,
        "Dual 4-channel RF multiplexer, 50 ohm",
        valid=[11, 12, 13, 14, 21, 22, 23, 24],
        measurable=(),
    ),
    CardType.RF_34906A: _spec(
        CardType.RF_34906A,
        "Dual 4-channel RF multiplexer, 75 ohm",
        valid=[11, 12, 13, 14, 21, 22, 23, 24],
        measurable=(),
    ),
    CardType.MFM_34907A: _spec(
        CardType.MFM_34907A,
        "Multifunction module: 2 digital I/O ports, totalizer, 2 DAC outputs",
        # 01/02 digital ports, 03 totalizer, 04/05 DAC outputs.
        valid=[1, 2, 3, 4, 5],
        measurable=(),               # not routed through the DMM
    ),
    CardType.MUX_34908A: _spec(
        CardType.MUX_34908A,
        "40-channel single-ended multiplexer",
        valid=range(1, 41),
    ),
    CardType.UNKNOWN: _spec(
        CardType.UNKNOWN,
        "Unidentified card; channel validation relaxed",
        # Widest plausible range, so an unrecognised card is usable
        # rather than blocked. Slot validity is still enforced.
        valid=range(1, 100),
    ),
}


_CHANNEL_RE = re.compile(r"^\s*(\d{3})\s*$")
_RANGE_RE = re.compile(r"^\s*(\d{3})\s*:\s*(\d{3})\s*$")


@dataclass(frozen=True, order=True)
class ChannelId:
    """A single addressable channel, e.g. slot 1 channel 3 -> ``103``."""

    slot: int
    channel: int

    def __post_init__(self) -> None:
        if not (MIN_SLOT <= self.slot <= MAX_SLOT):
            raise ConfigurationError(
                f"slot must be {MIN_SLOT}-{MAX_SLOT}, got {self.slot}",
                context={"slot": self.slot},
            )
        if not (1 <= self.channel <= 99):
            raise ConfigurationError(
                f"channel must be 1-99, got {self.channel}",
                context={"channel": self.channel},
            )

    @property
    def address(self) -> int:
        """The three-digit SCPI address, e.g. 103."""
        return self.slot * 100 + self.channel

    @classmethod
    def parse(cls, value: "ChannelId | int | str") -> "ChannelId":
        """Accept ``ChannelId``, ``103``, ``"103"``, or ``"@103"``."""

        if isinstance(value, ChannelId):
            return value

        if isinstance(value, int):
            text = str(value)
        else:
            text = str(value).strip().lstrip("@").strip()

        match = _CHANNEL_RE.match(text)
        if not match:
            raise ConfigurationError(
                f"Invalid channel address {value!r}: expected three digits "
                "such as 101, optionally prefixed with '@'",
                context={"value": str(value)},
            )

        address = int(match.group(1))
        return cls(slot=address // 100, channel=address % 100)

    def validate_against(self, card: CardType) -> None:
        """Raise ConfigurationError if this channel doesn't exist on the
        given card type."""

        spec = CARD_SPECS[card]
        if self.channel not in spec.valid_channels:
            raise ConfigurationError(
                f"Channel {self.channel} is not valid on a {card.value} "
                f"({spec.description})",
                context={
                    "address": self.address,
                    "card": card.value,
                    "channel": self.channel,
                },
            )

    def __str__(self) -> str:
        return str(self.address)


class ChannelList:
    """An ordered, de-duplicated collection of channels that renders to
    SCPI channel-list syntax.

    Order is preserved as supplied (not sorted), because scan order is
    significant on this instrument and silently reordering a user's scan
    list would change measurement sequencing.
    """

    def __init__(self, channels: Sequence[ChannelId | int | str] = ()) -> None:
        seen: dict[int, ChannelId] = {}
        for item in channels:
            channel = ChannelId.parse(item)
            seen.setdefault(channel.address, channel)
        self._channels: tuple[ChannelId, ...] = tuple(seen.values())

    @classmethod
    def parse(cls, value: "ChannelList | str | Sequence") -> "ChannelList":
        """Parse a channel list from SCPI syntax or a Python sequence.

        Accepts ``"(@101,103,105:110)"``, ``"101,103"``, ``"105:110"``,
        ``[101, 103]``, or an existing ChannelList.
        """

        if isinstance(value, ChannelList):
            return value
        if not isinstance(value, str):
            return cls(list(value))

        text = value.strip()
        if text.startswith("(") and text.endswith(")"):
            text = text[1:-1].strip()
        text = text.lstrip("@").strip()

        if not text:
            return cls()

        channels: list[ChannelId] = []
        for part in text.split(","):
            part = part.strip()
            range_match = _RANGE_RE.match(part)
            if range_match:
                start = ChannelId.parse(range_match.group(1))
                end = ChannelId.parse(range_match.group(2))
                channels.extend(cls._expand_range(start, end))
            else:
                channels.append(ChannelId.parse(part))
        return cls(channels)

    @staticmethod
    def _expand_range(start: ChannelId, end: ChannelId) -> list[ChannelId]:
        if start.slot != end.slot:
            raise ConfigurationError(
                f"Channel range {start}:{end} spans slots {start.slot} and "
                f"{end.slot}; ranges must stay within one slot",
                context={"start": start.address, "end": end.address},
            )
        if end.channel < start.channel:
            raise ConfigurationError(
                f"Channel range {start}:{end} is reversed; "
                "start must not exceed end",
                context={"start": start.address, "end": end.address},
            )
        return [
            ChannelId(slot=start.slot, channel=ch)
            for ch in range(start.channel, end.channel + 1)
        ]

    def to_scpi(self) -> str:
        """Render as a SCPI channel list, e.g. ``(@101,103,105)``.

        Emits an explicit list rather than collapsing consecutive
        channels into ranges: the instrument accepts both, and an
        explicit list is far easier to read in a failing test log.
        """

        if not self._channels:
            raise ConfigurationError("Cannot build a SCPI channel list from no channels")
        return "(@" + ",".join(str(c.address) for c in self._channels) + ")"

    def validate_against(self, cards: dict[int, CardType]) -> None:
        """Validate every channel against the card installed in its slot.

        ``cards`` maps slot number -> CardType. Slots absent from the
        mapping are treated as UNKNOWN (relaxed validation) rather than
        as an error, so a partially-described bench still works.
        """

        for channel in self._channels:
            card = cards.get(channel.slot, CardType.UNKNOWN)
            channel.validate_against(card)

    def slots(self) -> set[int]:
        return {c.slot for c in self._channels}

    def __iter__(self) -> Iterator[ChannelId]:
        return iter(self._channels)

    def __len__(self) -> int:
        return len(self._channels)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, ChannelList):
            return NotImplemented
        return self._channels == other._channels

    def __repr__(self) -> str:
        return f"ChannelList({[c.address for c in self._channels]!r})"
