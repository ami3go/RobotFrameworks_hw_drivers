"""
Measurement engine interface.

Defines the contract Gate 2 implements. Declaring it as an ABC now,
before the implementation exists, keeps the Robot keyword layer (Gate 2)
and the Scanner Engine (Phase 3) coding against an interface rather than
a concrete class -- the same separation that let Phase 1 swap transports
without touching Connection.

The split of responsibility mirrors the instrument's own model:

- ``configure()`` sets a function on channels without reading (SCPI
  ``CONF:``). Configuration persists until changed.
- ``read()`` triggers and returns readings from already-configured
  channels (SCPI ``READ?``).
- ``measure()`` is the one-shot combination (SCPI ``MEAS:...?``), which
  resets other settings to defaults -- a distinction that matters and
  is easy to lose if the two are collapsed into one method.
"""

from __future__ import annotations

import abc
from typing import Sequence

from .channels import ChannelList
from .models import Measurement, MeasurementConfig


class MeasurementEngine(abc.ABC):
    """Contract for configuring and reading measurements.

    Implementations are expected to require an active connection and to
    raise ``StateError`` if used without one, consistent with the
    Phase 1 state machine.
    """

    @abc.abstractmethod
    def configure(self, channels: ChannelList, config: MeasurementConfig) -> None:
        """Configure a measurement function on the given channels
        without taking a reading.

        Raises:
            ConfigurationError: if the function is unsupported on those
                channels (e.g. current on a non-current channel).
            StateError: if no connection is active.
            CommandError: if the instrument rejects the configuration.
        """

    @abc.abstractmethod
    def read(self, channels: ChannelList | None = None) -> Sequence[Measurement]:
        """Trigger and return readings from already-configured channels.

        Args:
            channels: restrict the read to these channels; None reads
                the full configured scan list.

        Raises:
            StateError: if no connection is active.
            CommandError: if channels were never configured.
            TimeoutError34970: if the reading exceeds the timeout.
        """

    @abc.abstractmethod
    def measure(
        self, channels: ChannelList, config: MeasurementConfig
    ) -> Sequence[Measurement]:
        """Configure and read in one operation.

        Note this resets measurement parameters not explicitly given to
        their defaults, per the instrument's MEAS: behavior. Prefer
        ``configure()`` + ``read()`` when other settings must persist.
        """

    @abc.abstractmethod
    def get_configured_function(
        self, channel: "ChannelList | str | int"
    ) -> MeasurementConfig | None:
        """Return the configuration currently applied to a channel, or
        None if the driver has not configured it.

        Reflects driver-side state; it does not re-query the instrument
        unless an implementation documents otherwise.
        """
