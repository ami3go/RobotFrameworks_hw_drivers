"""
Exception hierarchy for the keysight34970 driver.

All exceptions raised by this package derive from Keysight34970Error so
that Robot Framework test suites and AI planners can catch driver
failures with a single except clause, while still being able to branch
on more specific error types when needed.
"""

from __future__ import annotations

from typing import Optional


class Keysight34970Error(Exception):
    """Base class for all errors raised by the keysight34970 driver."""

    def __init__(self, message: str, *, context: Optional[dict] = None) -> None:
        super().__init__(message)
        self.message = message
        self.context = context or {}

    def __str__(self) -> str:  # pragma: no cover - trivial
        if self.context:
            return f"{self.message} | context={self.context}"
        return self.message


class ConfigurationError(Keysight34970Error):
    """Raised when driver or connection configuration is invalid."""


class TransportError(Keysight34970Error):
    """Raised for low-level transport failures (socket, VISA session, etc.)."""


class ConnectionError34970(Keysight34970Error):
    """Raised when a connection cannot be established, is lost, or is
    used while in an invalid state."""


class TimeoutError34970(TransportError):
    """Raised when a command or query exceeds its configured timeout."""


class CommandError(Keysight34970Error):
    """Raised when the instrument reports a SCPI error via the error
    queue (SYST:ERR?) in response to a command or query."""

    def __init__(
        self,
        message: str,
        *,
        scpi_code: Optional[int] = None,
        scpi_message: Optional[str] = None,
        command: Optional[str] = None,
        context: Optional[dict] = None,
    ) -> None:
        # Merge caller-supplied context with the SCPI-specific fields so
        # CommandError accepts `context=` like every other exception in
        # this hierarchy. Explicit SCPI fields win on key collision.
        merged = dict(context or {})
        merged.update(
            {
                "scpi_code": scpi_code,
                "scpi_message": scpi_message,
                "command": command,
            }
        )
        super().__init__(message, context=merged)
        self.scpi_code = scpi_code
        self.scpi_message = scpi_message
        self.command = command


class StateError(Keysight34970Error):
    """Raised when an operation is attempted while the driver's internal
    state machine is not in a state that permits it (e.g. issuing a
    measurement command before CONNECTED)."""
