"""
VISA-backed transport (GPIB, USB-TMC, or VISA-managed LAN).

PyVISA is an optional dependency: it is only imported when a
VisaTransport is actually constructed, so environments that only use
TCP_SOCKET transport (or that only import the package for its data
models, e.g. an AI planner) don't need PyVISA / a VISA runtime
installed.
"""

from __future__ import annotations

from typing import Any

from ..exceptions import (
    ConfigurationError,
    ConnectionError34970,
    TimeoutError34970,
    TransportError,
)
from ..logging_config import get_logger
from .base import Transport


class VisaTransport(Transport):
    """Transport implementation backed by PyVISA."""

    def __init__(self, resource_name: str, timeout_s: float, *, alias: str = "-") -> None:
        self._resource_name = resource_name
        self._timeout_s = timeout_s
        self._resource: Any = None
        self._log = get_logger(alias)

    @property
    def is_open(self) -> bool:
        return self._resource is not None

    def open(self) -> None:
        if self._resource is not None:
            return

        try:
            import pyvisa
        except ImportError as exc:
            raise ConfigurationError(
                "pyvisa is required for VISA transport but is not installed. "
                "Install it with: pip install pyvisa pyvisa-py"
            ) from exc

        try:
            rm = pyvisa.ResourceManager()
            resource = rm.open_resource(self._resource_name)
            resource.timeout = self._timeout_s * 1000.0  # PyVISA uses ms
        except pyvisa.errors.VisaIOError as exc:
            # Match on the StatusCode enum's *name* by substring rather
            # than by enum identity. Rationale: PyVISA has renamed and
            # aliased status codes across releases, and pinning to
            # specific enum members would break silently (falling back
            # to a generic TransportError) on a version bump. Substring
            # matching degrades gracefully instead, and
            # tests/unit/test_visa_transport.py asserts the translation
            # against real pyvisa StatusCode values, so a rename that
            # broke this would fail CI rather than pass unnoticed.
            # (Closes Gate 3 Minor finding.)
            status_name = getattr(exc.error_code, "name", "").lower() if hasattr(
                exc, "error_code"
            ) else ""
            if any(
                fragment in status_name
                for fragment in ("resource_not_found", "resource_busy", "resource_locked")
            ):
                raise ConnectionError34970(
                    f"Cannot open VISA resource {self._resource_name!r}: "
                    f"{exc}. It may not exist, or may already be held open "
                    "by another session (another Robot process, NI MAX, "
                    "Keysight Connection Expert, etc).",
                    context={"resource": self._resource_name, "error": str(exc)},
                ) from exc
            raise TransportError(
                f"Failed to open VISA resource {self._resource_name!r}",
                context={"resource": self._resource_name, "error": str(exc)},
            ) from exc
        except Exception as exc:  # noqa: BLE001 - pyvisa raises its own errors
            raise TransportError(
                f"Failed to open VISA resource {self._resource_name!r}",
                context={"resource": self._resource_name, "error": str(exc)},
            ) from exc

        self._resource = resource
        self._log.debug("VISA transport opened to %s", self._resource_name)

    def close(self) -> None:
        if self._resource is None:
            return
        try:
            self._resource.close()
        except Exception:  # noqa: BLE001 - best-effort close
            pass
        finally:
            self._resource = None
            self._log.debug("VISA transport closed")

    def write(self, command: str) -> None:
        self._ensure_open()
        try:
            self._resource.write(command)
        except Exception as exc:  # noqa: BLE001
            self._raise_translated(exc, command)

    def query(self, command: str) -> str:
        self._ensure_open()
        try:
            return self._resource.query(command).strip()
        except Exception as exc:  # noqa: BLE001
            self._raise_translated(exc, command)

    def _raise_translated(self, exc: Exception, command: str) -> None:
        # PyVISA raises pyvisa.errors.VisaIOError; import lazily to avoid
        # a hard dependency and to keep this module importable without
        # pyvisa installed (see open() above).
        try:
            import pyvisa

            if isinstance(exc, pyvisa.errors.VisaIOError):
                if exc.error_code == pyvisa.constants.StatusCode.error_timeout:
                    raise TimeoutError34970(
                        f"Timed out on command: {command!r}",
                        context={"command": command},
                    ) from exc
        except ImportError:  # pragma: no cover - pyvisa was already loaded in open()
            pass
        raise TransportError(
            f"VISA I/O error on command: {command!r}",
            context={"command": command, "error": str(exc)},
        ) from exc

    def _ensure_open(self) -> None:
        if self._resource is None:
            raise TransportError("VISA transport is not open")

    def set_timeout(self, timeout_s: float) -> None:
        if timeout_s <= 0:
            raise TransportError(f"timeout_s must be > 0, got {timeout_s}")
        self._timeout_s = timeout_s
        if self._resource is not None:
            self._resource.timeout = timeout_s * 1000.0  # PyVISA uses ms
        self._log.debug("VISA transport timeout set to %.3fs", timeout_s)
