"""
Raw TCP socket transport for SCPI-over-LAN.

The 34970A/34972A LAN interface accepts newline-terminated SCPI strings
on a fixed socket port (default 5025). This transport is a thin,
dependency-free alternative to VISA for LAN-only deployments.
"""

from __future__ import annotations

import socket

from ..exceptions import TimeoutError34970, TransportError
from ..logging_config import get_logger
from .base import Transport

_RECV_CHUNK_SIZE = 4096


class TcpSocketTransport(Transport):
    """Transport implementation using a plain TCP socket."""

    def __init__(
        self,
        host: str,
        port: int,
        timeout_s: float,
        *,
        alias: str = "-",
        terminator: str = "\n",
    ) -> None:
        self._host = host
        self._port = port
        self._timeout_s = timeout_s
        self._sock: socket.socket | None = None
        self._log = get_logger(alias)
        if not terminator:
            raise TransportError("terminator must be a non-empty string")
        self._terminator = terminator.encode("ascii")

    @property
    def is_open(self) -> bool:
        return self._sock is not None

    def open(self) -> None:
        if self._sock is not None:
            return
        try:
            sock = socket.create_connection(
                (self._host, self._port), timeout=self._timeout_s
            )
            sock.settimeout(self._timeout_s)

            # Disable Nagle's algorithm. SCPI is a request/response
            # protocol of very small messages, and the driver frequently
            # issues two writes back to back (a command, then the
            # SYST:ERR? check). Nagle holds the second small write until
            # the first is acknowledged, and the peer's delayed-ACK
            # timer does not fire for ~40 ms -- so every
            # command-then-check pair paid a fixed ~40 ms penalty.
            # Measured at Phase 2 Gate 5: 44 ms per configure/read,
            # falling to ~0.1 ms with this enabled.
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        except OSError as exc:
            raise TransportError(
                f"Failed to open TCP connection to {self._host}:{self._port}",
                context={"host": self._host, "port": self._port, "os_error": str(exc)},
            ) from exc
        self._sock = sock
        self._log.debug("TCP transport opened to %s:%s", self._host, self._port)

    def close(self) -> None:
        if self._sock is None:
            return
        try:
            self._sock.close()
        except OSError:
            pass  # best-effort close; nothing useful to do if this fails
        finally:
            self._sock = None
            self._log.debug("TCP transport closed")

    def write(self, command: str) -> None:
        self._ensure_open()
        if self._terminator.decode("ascii") in command:
            raise TransportError(
                f"Command contains an embedded terminator and would desync "
                f"the protocol stream: {command!r}",
                context={"command": command},
            )
        payload = command.encode("ascii") + self._terminator
        try:
            self._sock.sendall(payload)  # type: ignore[union-attr]
        except socket.timeout as exc:
            raise TimeoutError34970(
                f"Timed out writing command: {command!r}",
                context={"command": command},
            ) from exc
        except OSError as exc:
            raise TransportError(
                f"Failed to write command: {command!r}",
                context={"command": command, "os_error": str(exc)},
            ) from exc

    def query(self, command: str) -> str:
        self.write(command)
        return self._read_line()

    def _read_line(self) -> str:
        self._ensure_open()
        buf = bytearray()
        try:
            while True:
                chunk = self._sock.recv(_RECV_CHUNK_SIZE)  # type: ignore[union-attr]
                if not chunk:
                    raise TransportError(
                        "Connection closed by instrument while reading response"
                    )
                buf.extend(chunk)
                if buf.endswith(self._terminator):
                    break
        except socket.timeout as exc:
            raise TimeoutError34970(
                "Timed out waiting for instrument response"
            ) from exc
        except OSError as exc:
            raise TransportError(
                "Failed to read response", context={"os_error": str(exc)}
            ) from exc
        return buf.decode("ascii", errors="replace").strip()

    def _ensure_open(self) -> None:
        if self._sock is None:
            raise TransportError("TCP transport is not open")

    def set_timeout(self, timeout_s: float) -> None:
        if timeout_s <= 0:
            raise TransportError(f"timeout_s must be > 0, got {timeout_s}")
        self._timeout_s = timeout_s
        if self._sock is not None:
            self._sock.settimeout(timeout_s)
        self._log.debug("TCP transport timeout set to %.3fs", timeout_s)
