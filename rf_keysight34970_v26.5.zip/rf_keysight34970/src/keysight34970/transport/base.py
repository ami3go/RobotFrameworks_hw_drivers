"""
Transport abstraction.

A Transport is responsible ONLY for moving bytes/SCPI strings to and
from the instrument. It knows nothing about SCPI semantics, the
instrument's state machine, or measurement data models -- that is the
Connection layer's job (see connection.py). This separation lets Phase
1 support both VISA and raw-socket transports behind one interface, and
lets later phases add e.g. a mock/simulated transport for unit testing
without touching Connection code.
"""

from __future__ import annotations

import abc


class Transport(abc.ABC):
    """Abstract base class for all instrument transports."""

    @abc.abstractmethod
    def open(self) -> None:
        """Establish the underlying physical/virtual connection.

        Raises:
            TransportError: if the connection cannot be established.
        """

    @abc.abstractmethod
    def close(self) -> None:
        """Release the underlying connection. Must be safe to call
        multiple times and safe to call even if open() was never
        called or failed."""

    @abc.abstractmethod
    def write(self, command: str) -> None:
        """Send a SCPI command with no response expected.

        Raises:
            TransportError: on I/O failure.
            TimeoutError34970: if the write does not complete in time.
        """

    @abc.abstractmethod
    def query(self, command: str) -> str:
        """Send a SCPI query and return the raw response string, with
        trailing terminators stripped.

        Raises:
            TransportError: on I/O failure.
            TimeoutError34970: if no response arrives in time.
        """

    @property
    @abc.abstractmethod
    def is_open(self) -> bool:
        """Whether the transport currently believes it has a live
        connection. This is a local state check only -- it does not
        probe the instrument."""

    @abc.abstractmethod
    def set_timeout(self, timeout_s: float) -> None:
        """Update the read/write timeout on an already-open transport.

        Implementations must accept this call before open() as well,
        in which case it should just update the value used the next
        time the transport is opened.

        Raises:
            TransportError: if timeout_s is not positive.
        """

    def __enter__(self) -> "Transport":
        self.open()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()
