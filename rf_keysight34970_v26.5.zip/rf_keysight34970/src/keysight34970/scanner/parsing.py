"""
Parsing of scan responses.

With ``FORM:READ:CHAN ON`` and ``FORM:READ:TIME ON`` the instrument
returns each reading as a comma-separated group rather than a bare
number, e.g.::

    +1.04E+00,2026,07,22,14,30,15.250,101

The field count per reading therefore depends on what formatting was
enabled, which makes naive comma-splitting wrong in a way that produces
plausible numbers: without accounting for the extra fields, a timestamp
component gets read as the next channel's measurement value.
"""

from __future__ import annotations

from typing import Optional, Sequence

from ..exceptions import CommandError
from ..measurement.channels import ChannelId
from ..measurement.models import Measurement, MeasurementFunction, Unit
from .models import ScanReading

_TIMESTAMP_FIELDS = 6   # year, month, day, hour, minute, seconds
_CHANNEL_FIELDS = 1


def fields_per_reading(*, include_timestamp: bool, include_channel: bool) -> int:
    """How many comma-separated fields one reading occupies."""

    return (
        1
        + (_TIMESTAMP_FIELDS if include_timestamp else 0)
        + (_CHANNEL_FIELDS if include_channel else 0)
    )


def parse_scan_response(
    response: str,
    function: MeasurementFunction,
    *,
    include_timestamp: bool = True,
    include_channel: bool = True,
    unit: Optional[Unit] = None,
    channel_functions: Optional[dict[int, MeasurementFunction]] = None,
    readings_per_sweep: Optional[int] = None,
) -> list[ScanReading]:
    """Parse a scan response into ScanReadings.

    Args:
        function: fallback function when a reading's channel is unknown.
        channel_functions: per-channel functions, so a scan spanning
            functions tags each reading correctly instead of assuming
            one function throughout.
        readings_per_sweep: enables sweep numbering.

    Raises:
        CommandError: on an empty response, an unparseable field, or a
            field count that is not a whole number of readings -- the
            latter means the formatting assumed here does not match what
            the instrument actually sent, and continuing would silently
            misalign every reading.
    """

    if not response or not response.strip():
        raise CommandError("Instrument returned an empty scan response")

    fields = [f.strip() for f in response.strip().split(",")]
    stride = fields_per_reading(
        include_timestamp=include_timestamp, include_channel=include_channel
    )

    if len(fields) % stride != 0:
        raise CommandError(
            f"Scan response has {len(fields)} fields, which is not a whole "
            f"number of {stride}-field readings. The reading format enabled "
            "on the instrument does not match what the driver expects; "
            "readings would be misaligned.",
            context={"field_count": len(fields), "expected_stride": stride},
        )

    readings: list[ScanReading] = []
    for index in range(0, len(fields), stride):
        group = fields[index : index + stride]
        cursor = 0

        try:
            value = float(group[cursor])
        except ValueError as exc:
            raise CommandError(
                f"Could not parse scan reading value {group[cursor]!r}",
                scpi_message=group[cursor],
            ) from exc
        cursor += 1

        timestamp_text: Optional[str] = None
        if include_timestamp:
            parts = group[cursor : cursor + _TIMESTAMP_FIELDS]
            timestamp_text = _format_timestamp(parts)
            cursor += _TIMESTAMP_FIELDS

        channel: Optional[ChannelId] = None
        if include_channel:
            raw_channel = group[cursor]
            try:
                channel = ChannelId.parse(raw_channel)
            except Exception:
                # An unparseable channel field is diagnostic noise, not
                # a reason to discard a valid measurement.
                channel = None

        resolved_function = function
        if channel is not None and channel_functions:
            resolved_function = channel_functions.get(channel.address, function)

        readings.append(
            ScanReading(
                measurement=Measurement(
                    value=value,
                    unit=unit if unit is not None else resolved_function.unit,
                    function=resolved_function,
                    channel=channel,
                    raw=",".join(group),
                ),
                sweep=(
                    len(readings) // readings_per_sweep + 1
                    if readings_per_sweep
                    else None
                ),
                instrument_timestamp=timestamp_text,
            )
        )

    return readings


def _format_timestamp(parts: Sequence[str]) -> Optional[str]:
    """Render the instrument's six timestamp fields as ISO-8601-ish text.

    Kept as a string rather than a datetime: the instrument's clock is
    independent of the host's and may be unset or wrong, so presenting
    it as a real datetime would invite it being compared against host
    time as though the two were commensurate.
    """

    if len(parts) != _TIMESTAMP_FIELDS:
        return None
    try:
        year, month, day, hour, minute = (int(float(p)) for p in parts[:5])
        seconds = float(parts[5])
    except ValueError:
        return None
    return (
        f"{year:04d}-{month:02d}-{day:02d}T{hour:02d}:{minute:02d}:{seconds:06.3f}"
    )
