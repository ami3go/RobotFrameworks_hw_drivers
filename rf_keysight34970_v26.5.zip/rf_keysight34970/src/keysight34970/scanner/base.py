"""
Scanner engine interface (Phase 3, Gate 1).

Defines the contract Gate 2 implements. The split of operations mirrors
the instrument's own model and, more importantly, keeps *arming* a scan
distinct from *waiting* for it:

- ``configure_scan()`` defines the scan without starting it.
- ``start_scan()`` arms it (``INIT``) and returns immediately.
- ``fetch_readings()`` retrieves whatever is in memory so far.
- ``run_scan()`` is the blocking convenience: arm, wait, fetch.

Collapsing arm and wait into one call would make an infinite or
externally-triggered scan indistinguishable from a hung instrument, and
would make it impossible to inspect a long scan while it runs.
"""

from __future__ import annotations

import abc
from typing import Optional

from .models import InstrumentStatistics, ScanConfig, ScanResult


class ScannerEngine(abc.ABC):
    """Contract for configuring, running and retrieving scans."""

    @abc.abstractmethod
    def configure_scan(self, config: ScanConfig) -> None:
        """Define the scan list and trigger behaviour without starting.

        Raises:
            ConfigurationError: if the scan is invalid or its channels
                cannot be measured.
            StateError: if no connection is active.
        """

    @abc.abstractmethod
    def start_scan(self) -> None:
        """Arm the configured scan and return immediately.

        Raises:
            ConfigurationError: if no scan has been configured.
        """

    @abc.abstractmethod
    def abort_scan(self) -> None:
        """Stop a running scan. Must be safe to call when none is
        running, since the caller often cannot know."""

    @abc.abstractmethod
    def reading_count(self) -> int:
        """Readings currently held in instrument memory."""

    @abc.abstractmethod
    def fetch_readings(self, *, clear: bool = False) -> ScanResult:
        """Retrieve readings from instrument memory.

        Args:
            clear: retrieve *and erase* the readings from instrument
                memory, using ``R?`` rather than ``FETC?``. Done as one
                command rather than fetch-then-clear, which would race a
                running scan and lose readings arriving between the two.

        Does not wait for the scan to finish; a partial scan yields a
        partial result, with ``ScanResult.is_complete`` reporting which.
        """

    @abc.abstractmethod
    def wait_for_scan(self, timeout_s: Optional[float] = None) -> bool:
        """Block until the configured scan completes.

        Returns True if it completed, False on timeout. Returning a
        bool rather than raising lets a caller poll a long scan without
        exception handling in the loop.

        Raises:
            ConfigurationError: if the scan cannot complete on its own
                (infinite count, or a trigger source awaiting an
                external stimulus), since waiting would block forever.
        """

    @abc.abstractmethod
    def run_scan(
        self, config: ScanConfig, timeout_s: Optional[float] = None
    ) -> ScanResult:
        """Configure, arm, wait and fetch in one blocking call."""

    @abc.abstractmethod
    def get_instrument_statistics(self) -> InstrumentStatistics:
        """Read the instrument's own CALC statistics registers."""
