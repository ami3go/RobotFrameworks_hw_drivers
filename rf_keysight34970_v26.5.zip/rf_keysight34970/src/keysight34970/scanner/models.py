"""
Scanner data models (Phase 3).

Vocabulary for scan configuration and results: trigger control, scan
configuration with capacity and duration estimation, per-reading
records carrying sweep and instrument-timestamp context, and statistics.

Pure data with no I/O, so fully specified and tested at Gate 1.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Optional, Sequence

from ..exceptions import ConfigurationError
from ..measurement.channels import ChannelId, ChannelList
from ..measurement.models import Measurement, MeasurementFunction, Unit

# Documented reading-memory depth. Once full, the oldest readings are
# overwritten, so a scan that exceeds it loses data unless fetched as it
# runs. Named rather than inlined because the consequence of exceeding
# it is silent data loss, not an error.
READING_MEMORY_CAPACITY = 50_000

# Instrument limits.
MAX_TRIGGER_TIMER_S = 359_999.0
MAX_CHANNEL_DELAY_S = 60.0

# Rough per-channel cost of closing a relay and taking a reading, used
# only for duration estimation. Deliberately approximate: it exists to
# tell a caller "seconds" from "hours", not to predict a scan time.
_NOMINAL_CHANNEL_TIME_S = 0.01


class TriggerSource(str, Enum):
    """What starts each sweep of a scan.

    Values are the SCPI mnemonics, so they map straight onto
    ``TRIG:SOUR``.
    """

    IMMEDIATE = "IMM"   # sweep again as soon as the previous one ends
    BUS = "BUS"         # software trigger (*TRG)
    EXTERNAL = "EXT"    # rear-panel Ext Trig input
    TIMER = "TIMER"     # internal interval timer
    ALARM = "ALAR"      # an alarm condition

    @property
    def requires_timer_interval(self) -> bool:
        """Only TIMER takes an interval. Supplying one for any other
        source means the caller expects paced sweeps and will not get
        them."""

        return self is TriggerSource.TIMER

    @property
    def is_self_starting(self) -> bool:
        """Whether the scan proceeds without an external stimulus.

        This matters for waiting: a scan on a non-self-starting source
        that never receives its trigger is indistinguishable from a hung
        instrument, so the driver must not silently block on one.
        """

        return self in {TriggerSource.IMMEDIATE, TriggerSource.TIMER}


class TriggerCount:
    """How many sweeps a scan performs, or unbounded.

    A value type rather than a bare int because "run forever" is a real
    instrument setting that has to travel alongside a count, and
    encoding it as a sentinel integer invites arithmetic on a value that
    is not a number.
    """

    __slots__ = ("_sweeps",)

    _INFINITE_TOKENS = {"INF", "INFINITE"}

    def __init__(self, value: "int | str | TriggerCount") -> None:
        if isinstance(value, TriggerCount):
            self._sweeps: Optional[int] = value._sweeps
            return

        if isinstance(value, bool):  # bool is an int subclass; reject early
            raise ConfigurationError(
                f"trigger count must be a positive integer or INF, got {value!r}"
            )

        if isinstance(value, int):
            self._sweeps = self._validated(value, value)
            return

        if isinstance(value, str):
            text = value.strip().upper()
            if text in self._INFINITE_TOKENS:
                self._sweeps = None
                return
            try:
                parsed = int(text)
            except ValueError:
                raise ConfigurationError(
                    f"trigger count must be a positive integer or INF, "
                    f"got {value!r}"
                ) from None
            self._sweeps = self._validated(parsed, value)
            return

        raise ConfigurationError(
            f"trigger count must be a positive integer or INF, got {value!r}"
        )

    @staticmethod
    def _validated(parsed: int, original) -> int:
        if parsed < 1:
            raise ConfigurationError(
                f"trigger count must be a positive integer or INF, "
                f"got {original!r}"
            )
        return parsed

    @property
    def sweeps(self) -> Optional[int]:
        """Number of sweeps, or None if unbounded."""
        return self._sweeps

    @property
    def is_infinite(self) -> bool:
        return self._sweeps is None

    def to_scpi(self) -> str:
        return "INF" if self._sweeps is None else str(self._sweeps)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, TriggerCount):
            return NotImplemented
        return self._sweeps == other._sweeps

    def __hash__(self) -> int:
        return hash(self._sweeps)

    def __repr__(self) -> str:
        return f"TriggerCount({self.to_scpi()})"


@dataclass(frozen=True)
class ScanConfig:
    """Configuration for a scan.

    ``function`` is the fallback used when a reading cannot be
    attributed to a channel whose function the driver knows; channels
    are configured individually through the Phase 2 measurement engine,
    and a scan may legitimately span functions.
    """

    channels: ChannelList
    function: MeasurementFunction = MeasurementFunction.DC_VOLTAGE
    trigger_source: TriggerSource = TriggerSource.IMMEDIATE
    trigger_count: TriggerCount = field(default_factory=lambda: TriggerCount(1))
    trigger_timer_s: Optional[float] = None
    channel_delay_s: Optional[float] = None
    include_channel: bool = True
    include_timestamp: bool = True

    def __post_init__(self) -> None:
        if not len(self.channels):
            raise ConfigurationError("A scan requires at least one channel")

        if self.trigger_source.requires_timer_interval:
            if self.trigger_timer_s is None:
                raise ConfigurationError(
                    "trigger_source=TIMER requires trigger_timer_s",
                    context={"trigger_source": self.trigger_source.value},
                )
        elif self.trigger_timer_s is not None:
            raise ConfigurationError(
                f"trigger_timer_s applies only to trigger_source=TIMER, "
                f"not {self.trigger_source.value}. Setting it here would "
                "have no effect and the scan would run unpaced.",
                context={"trigger_source": self.trigger_source.value},
            )

        if self.trigger_timer_s is not None and not (
            0 < self.trigger_timer_s <= MAX_TRIGGER_TIMER_S
        ):
            raise ConfigurationError(
                f"trigger_timer_s must be > 0 and <= {MAX_TRIGGER_TIMER_S:g}, "
                f"got {self.trigger_timer_s}"
            )

        if self.channel_delay_s is not None and not (
            0 <= self.channel_delay_s <= MAX_CHANNEL_DELAY_S
        ):
            raise ConfigurationError(
                f"channel_delay_s must be between 0 and "
                f"{MAX_CHANNEL_DELAY_S:g} seconds, got {self.channel_delay_s}"
            )

    @property
    def readings_per_sweep(self) -> int:
        return len(self.channels)

    @property
    def total_readings(self) -> Optional[int]:
        """Readings a completed scan produces, or None if unbounded."""

        sweeps = self.trigger_count.sweeps
        if sweeps is None:
            return None
        return self.readings_per_sweep * sweeps

    def exceeds_reading_memory(self) -> bool:
        """Whether the scan can outgrow reading memory.

        An unbounded scan always can. Returning a bool rather than
        raising keeps the scan legal: draining memory during the scan is
        a valid strategy, and refusing outright would block it.
        """

        total = self.total_readings
        if total is None:
            return True
        return total > READING_MEMORY_CAPACITY

    def estimated_duration_s(self) -> Optional[float]:
        """Rough scan duration, or None when it cannot be known.

        Returns None for unbounded scans and for externally paced
        sources, where the duration depends on something outside the
        instrument. A number would be a guess presented as a fact.
        """

        sweeps = self.trigger_count.sweeps
        if sweeps is None or not self.trigger_source.is_self_starting:
            return None

        per_channel = max(self.channel_delay_s or 0.0, _NOMINAL_CHANNEL_TIME_S)
        sweep_time = per_channel * self.readings_per_sweep

        if self.trigger_source is TriggerSource.TIMER and self.trigger_timer_s:
            # The timer paces sweep starts, so a sweep that finishes
            # early still waits out the interval.
            sweep_time = max(sweep_time, self.trigger_timer_s)

        return sweep_time * sweeps


@dataclass(frozen=True)
class ScanReading:
    """One reading from a scan, with its scan context.

    Wraps rather than extends ``Measurement`` so the Phase 2 type stays
    free of scan-specific concepts, and so a scan reading can carry the
    instrument's own timestamp separately from the host timestamp the
    Measurement already has.
    """

    measurement: Measurement
    sweep: Optional[int] = None
    instrument_timestamp: Optional[str] = None
    """The instrument's own clock reading, as text.

    Deliberately not a datetime: the instrument's clock is independent
    of the host's and may be unset or wrong, so presenting it as a real
    datetime would invite comparison with host time as though the two
    were commensurate.
    """

    @property
    def value(self) -> float:
        return self.measurement.value

    @property
    def channel(self) -> Optional[ChannelId]:
        return self.measurement.channel

    @property
    def unit(self) -> Unit:
        return self.measurement.unit

    @property
    def is_overrange(self) -> bool:
        return self.measurement.is_overrange


@dataclass(frozen=True)
class InstrumentStatistics:
    """Statistics computed by the instrument over its own readings.

    Distinct from the driver-side statistics of Phase 2: these cover
    every reading the instrument took, including any never transferred
    to the host. The unit is not recoverable from the statistics
    registers alone, hence the UNKNOWN default.
    """

    minimum: float
    maximum: float
    average: float
    count: int
    unit: Unit = Unit.UNKNOWN

    @property
    def span(self) -> float:
        return self.maximum - self.minimum


@dataclass(frozen=True)
class ScanResult:
    """Readings from a scan, with the configuration that produced them.

    Keeping the config alongside the readings is what makes
    ``is_complete`` answerable: a short scan is not an error the
    instrument reports, it simply returns fewer readings.
    """

    readings: Sequence[ScanReading]
    config: ScanConfig
    fetched_at: datetime = field(
        default_factory=lambda: datetime.now(timezone.utc)
    )
    """When these readings were retrieved from the instrument.

    Named for what it actually is. It was previously ``completed_at``,
    which was a lie for a partial fetch of a running scan: the scan had
    not completed, and the timestamp described the fetch. For when each
    reading was taken, use ``ScanReading.instrument_timestamp``.
    """

    @property
    def reading_count(self) -> int:
        return len(self.readings)

    @property
    def sweep_count(self) -> int:
        """Number of sweeps represented, derived from the readings."""

        sweeps = [r.sweep for r in self.readings if r.sweep is not None]
        if sweeps:
            return max(sweeps)
        per_sweep = self.config.readings_per_sweep
        if not per_sweep:
            return 0
        return -(-self.reading_count // per_sweep)  # ceiling division

    @property
    def is_complete(self) -> bool:
        """Whether every expected reading arrived.

        An unbounded scan is never 'complete'; a truncated one silently
        skews any analysis, so this is worth asserting explicitly.
        """

        expected = self.config.total_readings
        if expected is None:
            return False
        return self.reading_count == expected

    def values(self) -> list[float]:
        return [r.value for r in self.readings]

    def for_channel(self, channel: "ChannelId | int | str") -> list[ScanReading]:
        """Every reading for one channel, across all sweeps, in order."""

        target = ChannelId.parse(channel).address
        return [
            r
            for r in self.readings
            if r.channel is not None and r.channel.address == target
        ]

    def overrange_readings(self) -> list[ScanReading]:
        return [r for r in self.readings if r.is_overrange]

    def statistics_for_channel(
        self, channel: "ChannelId | int | str"
    ) -> InstrumentStatistics:
        """Driver-side statistics for one channel of this scan.

        Raises rather than returning an empty result for a channel with
        no readings: an empty statistic is indistinguishable from a
        channel that read zero.
        """

        readings = self.for_channel(channel)
        if not readings:
            raise ConfigurationError(
                f"No readings for channel {ChannelId.parse(channel)} in this "
                "scan result",
                context={"channel": ChannelId.parse(channel).address},
            )

        overrange = [r for r in readings if r.is_overrange]
        if overrange:
            raise ConfigurationError(
                f"Cannot compute statistics for channel "
                f"{ChannelId.parse(channel)}: {len(overrange)} of "
                f"{len(readings)} readings are over-range",
                context={"overrange_count": len(overrange)},
            )

        values = [r.value for r in readings]
        return InstrumentStatistics(
            minimum=min(values),
            maximum=max(values),
            average=sum(values) / len(values),
            count=len(values),
            unit=readings[0].unit,
        )
