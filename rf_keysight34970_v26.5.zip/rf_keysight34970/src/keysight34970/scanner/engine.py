"""
SCPI implementation of the ScannerEngine interface (Phase 3, Gate 2).

Owns no I/O: every interaction goes through the Phase 1 ``Connection``,
inheriting its error-queue policy.

SCPI model used here:

    ROUT:SCAN (@101:110)        define the scan list
    TRIG:SOUR IMM|EXT|TIMER|BUS what starts each sweep
    TRIG:COUN <n>|INF           how many sweeps
    TRIG:TIM <seconds>          interval, TIMER source only
    ROUT:CHAN:DELAY <s>,(@..)   settling delay per channel
    FORM:READ:CHAN ON|OFF       include channel in each reading
    FORM:READ:TIME ON|OFF       include timestamp in each reading
    INIT                        arm the scan (returns immediately)
    DATA:POIN?                  readings currently in memory
    FETC?                       retrieve readings from memory
    ABOR                        stop a running scan

VERIFICATION STATUS: sequencing follows the published programmer's
reference and is exercised against the in-repo mock. Not verified
against physical hardware.
"""

from __future__ import annotations

import time
from datetime import datetime, timezone
from typing import Optional

from ..connection import Connection
from ..exceptions import ConfigurationError
from ..logging_config import get_logger
from ..measurement.channels import ChannelId
from ..measurement.engine import ScpiMeasurementEngine
from ..measurement.models import Measurement, MeasurementFunction, Unit
from ..measurement.parsing import parse_readings
from .base import ScannerEngine
from .models import (
    READING_MEMORY_CAPACITY,
    InstrumentStatistics,
    ScanConfig,
    ScanResult,
    TriggerSource,
)
from .parsing import parse_scan_response

_POLL_INITIAL_S = 0.001
_POLL_MAX_S = 0.05
_POLL_BACKOFF = 1.6


class ScpiScannerEngine(ScannerEngine):
    """Scanner engine driving a 34970A/34972A over SCPI."""

    def __init__(
        self,
        connection: Connection,
        *,
        measurement_engine: Optional[ScpiMeasurementEngine] = None,
    ) -> None:
        """
        Args:
            measurement_engine: optional. When supplied, per-channel
                measurement functions are read from it so scan readings
                are tagged with the correct function and unit instead of
                a single assumed function.
        """

        self._connection = connection
        self._measurement = measurement_engine
        self._config: Optional[ScanConfig] = None
        self._monitored: Optional[ChannelId] = None
        self._started_at: Optional[float] = None
        self._log = get_logger(connection.config.display_name())

    @property
    def config(self) -> Optional[ScanConfig]:
        return self._config

    # -- ScannerEngine ---------------------------------------------

    def configure_scan(self, config: ScanConfig) -> None:
        if config.exceeds_reading_memory():
            # Warn, do not refuse. The capacity constant is documented
            # rather than verified, and a driver that blocked a valid
            # scan because its constant was wrong would be worse than
            # one that lets the caller decide.
            total = config.total_readings
            self._log.warning(
                "Scan will produce %s readings, exceeding the documented "
                "reading memory capacity of %d. Fetch periodically or the "
                "oldest readings will be lost.",
                "unbounded" if total is None else total,
                READING_MEMORY_CAPACITY,
            )

        self._connection.write(f"ROUT:SCAN {config.channels.to_scpi()}")

        if config.channel_delay_s is not None:
            self._connection.write(
                f"ROUT:CHAN:DELAY {config.channel_delay_s:g},"
                f"{config.channels.to_scpi()}"
            )

        self._connection.write(f"TRIG:SOUR {config.trigger_source.value}")
        self._connection.write(f"TRIG:COUN {config.trigger_count.to_scpi()}")

        if config.trigger_source is TriggerSource.TIMER:
            self._connection.write(f"TRIG:TIM {config.trigger_timer_s:g}")

        self._connection.write(
            f"FORM:READ:CHAN {'ON' if config.include_channel else 'OFF'}"
        )
        self._connection.write(
            f"FORM:READ:TIME {'ON' if config.include_timestamp else 'OFF'}"
        )

        self._config = config
        self._started_at = None
        self._log.info(
            "Scan configured: %d channel(s), %s sweep(s), trigger %s",
            config.readings_per_sweep,
            config.trigger_count.to_scpi(),
            config.trigger_source.value,
        )

    def start_scan(self) -> None:
        config = self._require_config()

        # Symmetric to the guard in start_monitor(): both claim the DMM.
        # Here the driver stops monitoring rather than refusing, because
        # a scan is the more specific request -- the caller has just
        # configured one -- and leaving a monitor running would corrupt
        # it silently.
        if self._monitored is not None:
            self._log.info("Stopping monitor before starting scan")
            self.stop_monitor()

        self._connection.write("INIT")
        self._started_at = time.monotonic()
        self._log.info("Scan armed (%s)", config.trigger_source.value)

    def abort_scan(self) -> None:
        """Safe to call when no scan is running; the caller usually
        cannot know, and making them find out first would mean an extra
        round trip to answer a question the instrument tolerates."""

        self._connection.write("ABOR")
        self._started_at = None
        self._log.info("Scan aborted")

    def reading_count(self) -> int:
        response = self._connection.query("DATA:POIN?")
        try:
            return int(float(response.strip()))
        except ValueError as exc:
            raise ConfigurationError(
                f"Could not parse reading count from {response!r}"
            ) from exc

    def fetch_readings(self, *, clear: bool = False) -> ScanResult:
        config = self._require_config()

        if self.reading_count() == 0:
            # FETC? on empty memory raises an instrument error. Returning
            # an empty, explicitly-incomplete result is more useful than
            # surfacing a SCPI fault for the ordinary case of polling a
            # scan that has not produced anything yet.
            return ScanResult(readings=[], config=config)

        # FETC? leaves readings in memory; R? reads and erases them.
        # Using R? for clear=True is not an optimisation -- fetching
        # then separately clearing would race a running scan, losing any
        # readings that arrived between the two commands.
        response = self._connection.query("R?" if clear else "FETC?")
        readings = parse_scan_response(
            response,
            self._fallback_function(),
            include_timestamp=config.include_timestamp,
            include_channel=config.include_channel,
            unit=self._fallback_unit(),
            channel_functions=self._channel_functions(),
            readings_per_sweep=config.readings_per_sweep,
        )

        return ScanResult(
            readings=readings,
            config=config,
            fetched_at=datetime.now(timezone.utc),
        )

    def wait_for_scan(self, timeout_s: Optional[float] = None) -> bool:
        config = self._require_config()

        if config.trigger_count.is_infinite:
            raise ConfigurationError(
                "Cannot wait for a scan with an infinite trigger count: it "
                "never completes. Use start_scan() with fetch_readings(), "
                "and abort_scan() when finished.",
                context={"trigger_count": "INF"},
            )
        if not config.trigger_source.is_self_starting:
            raise ConfigurationError(
                f"Cannot wait for a scan triggered by "
                f"{config.trigger_source.value}: sweeps only occur when an "
                "external stimulus arrives, so waiting could block "
                "indefinitely. Poll reading_count() instead.",
                context={"trigger_source": config.trigger_source.value},
            )

        expected = config.total_readings
        assert expected is not None  # guaranteed by the infinite check above

        deadline = None if timeout_s is None else time.monotonic() + timeout_s
        interval = _POLL_INITIAL_S

        # Poll rather than *OPC?: the scan must remain observable while
        # it runs. *OPC? blocks the session until completion, which
        # would make reading_count() unavailable during a long scan and
        # would turn a timeout into a transport-level failure with the
        # instrument still busy. Polling costs one short query per
        # interval and keeps the session usable -- the Gate 2 finding
        # asked this be reconsidered, and this is the reconsidered
        # answer with the reasoning recorded.
        while True:
            if self.reading_count() >= expected:
                return True
            if deadline is not None and time.monotonic() >= deadline:
                self._log.warning(
                    "Scan did not complete within %.3fs (%d of %d readings)",
                    timeout_s,
                    self.reading_count(),
                    expected,
                )
                return False
            time.sleep(interval)
            # Adaptive backoff. A fixed 50 ms interval added up to a
            # full interval of latency *after* the scan finished, which
            # for a ~100 ms scan is 50% overhead on the measured
            # duration. Starting fast and backing off keeps short scans
            # responsive without spamming a long one with queries: a
            # 10-minute scan settles at 20 polls/second's worth of
            # nothing, i.e. one query per 50 ms as before.
            interval = min(interval * _POLL_BACKOFF, _POLL_MAX_S)

    def run_scan(
        self, config: ScanConfig, timeout_s: Optional[float] = None
    ) -> ScanResult:
        self.configure_scan(config)
        self.start_scan()
        self.wait_for_scan(timeout_s)
        # Fetch regardless of whether the wait timed out: a partial
        # result with is_complete=False tells the caller more than an
        # exception that discards the readings already taken.
        return self.fetch_readings()

    def get_instrument_statistics(self) -> InstrumentStatistics:
        minimum = float(self._connection.query("CALC:AVER:MIN?"))
        maximum = float(self._connection.query("CALC:AVER:MAX?"))
        average = float(self._connection.query("CALC:AVER:AVER?"))
        count = int(float(self._connection.query("CALC:AVER:COUN?")))
        return InstrumentStatistics(
            minimum=minimum, maximum=maximum, average=average, count=count
        )

    # -- extended features (Gate 3) --------------------------------

    def start_monitor(self, channel: "ChannelId | int | str") -> None:
        """Continuously monitor a single channel (``ROUT:MON``).

        Monitoring is not scanning: the instrument takes readings from
        one channel as fast as it can and keeps only the most recent.
        Nothing accumulates in reading memory, so a monitored value must
        be read with ``read_monitor()`` -- fetching scan readings will
        not return it.
        """

        target = ChannelId.parse(channel)
        self._require_measurable(target)

        # Monitoring and scanning both take over the internal DMM. The
        # instrument does not arbitrate between them: starting a monitor
        # mid-scan produces readings from whichever won, with no error.
        # Refuse rather than let the caller collect data whose source is
        # ambiguous. (Closes a Gate 3 finding: the contract warned a
        # planner off this, but the driver allowed it.)
        if self._scan_is_running():
            raise ConfigurationError(
                "Cannot start monitoring while a scan is running: both use "
                "the internal DMM and the instrument does not arbitrate "
                "between them. Call abort_scan() first, or wait for the "
                "scan to finish.",
                context={"channel": target.address},
            )

        self._connection.write(f"ROUT:MON (@{target.address})")
        self._connection.write("ROUT:MON:STAT ON")
        self._monitored = target
        self._log.info("Monitoring channel %s", target)

    def stop_monitor(self) -> None:
        """Stop monitoring. Safe whether or not monitoring is active."""

        self._connection.write("ROUT:MON:STAT OFF")
        self._monitored = None

    def read_monitor(self) -> Measurement:
        """Return the most recent monitored reading (``ROUT:MON:DATA?``).

        Raises:
            ConfigurationError: if monitoring was never started, rather
                than returning a stale or unrelated value.
        """

        if self._monitored is None:
            raise ConfigurationError(
                "No channel is being monitored; call start_monitor() first"
            )

        response = self._connection.query("ROUT:MON:DATA?")
        function = (self._channel_functions() or {}).get(
            self._monitored.address, self._fallback_function()
        )
        readings = parse_readings(
            response,
            function,
            [self._monitored],
            unit=self._fallback_unit(),
        )
        return readings[0]

    @property
    def monitored_channel(self) -> Optional["ChannelId"]:
        return self._monitored

    def get_channel_statistics(
        self, channel: "ChannelId | int | str"
    ) -> InstrumentStatistics:
        """Instrument-computed statistics for one channel.

        The instrument's statistics registers are per-channel, so this
        selects the channel first. Distinct from
        ``ScanResult.statistics_for_channel``, which computes from the
        readings actually transferred: these cover every reading the
        instrument took, including any lost to memory overflow.
        """

        target = ChannelId.parse(channel)
        suffix = f",(@{target.address})"
        minimum = float(self._connection.query(f"CALC:AVER:MIN?{suffix}"))
        maximum = float(self._connection.query(f"CALC:AVER:MAX?{suffix}"))
        average = float(self._connection.query(f"CALC:AVER:AVER?{suffix}"))
        count = int(float(self._connection.query(f"CALC:AVER:COUN?{suffix}")))

        # Look the function up directly rather than through
        # _channel_functions(), which is scoped to the configured scan:
        # statistics can legitimately be requested for a channel that
        # was measured but never scanned.
        function = None
        if self._measurement is not None:
            configured = self._measurement.get_configured_function(target.address)
            if configured is not None:
                function = configured.function

        return InstrumentStatistics(
            minimum=minimum,
            maximum=maximum,
            average=average,
            count=count,
            unit=function.unit if function is not None else Unit.UNKNOWN,
        )

    def clear_statistics(self) -> None:
        """Reset the instrument's statistics registers (``CALC:AVER:CLE``).

        Without this, statistics accumulate across scans and a second
        scan reports a min/max spanning the first one too.
        """

        self._connection.write("CALC:AVER:CLE")

    def _scan_is_running(self) -> bool:
        """Whether a scan is still in progress.

        ``_started_at`` alone is a poor proxy: it stays set after a
        bounded scan finishes naturally, which would refuse monitoring
        with a message claiming a scan was running when none was.

        A scan is running if it was armed and either is unbounded, or
        has not yet produced all its expected readings. This costs one
        short query, which is the right trade against refusing a valid
        operation with a misleading reason.
        """

        if self._started_at is None:
            return False
        config = self._config
        if config is None:
            return False
        if config.trigger_count.is_infinite:
            return True
        expected = config.total_readings
        if expected is None:
            return True
        return self.reading_count() < expected

    def _require_measurable(self, channel: "ChannelId") -> None:
        """Reject monitoring a channel that cannot reach the DMM."""

        if self._measurement is None:
            return
        from ..measurement.channels import CARD_SPECS, CardType

        cards = self._measurement.cards
        if channel.slot not in cards:
            return
        card = cards[channel.slot]
        spec = CARD_SPECS[card]
        if not spec.supports_measurement(channel.channel):
            raise ConfigurationError(
                f"Channel {channel} on the {card.value} in slot "
                f"{channel.slot} cannot be routed to the internal DMM, so it "
                "cannot be monitored",
                context={"channel": channel.address, "card": card.value},
            )

    # -- helpers ---------------------------------------------------

    def _require_config(self) -> ScanConfig:
        if self._config is None:
            raise ConfigurationError(
                "No scan has been configured; call configure_scan() first"
            )
        return self._config

    def _channel_functions(self) -> Optional[dict[int, MeasurementFunction]]:
        """Per-channel functions from the measurement engine, so a scan
        spanning functions tags each reading correctly."""

        if self._measurement is None:
            return None

        # Scoped to the scan's channels when a scan is configured, but
        # must not *require* one: monitoring and per-channel statistics
        # are independent of any scan, and demanding a scan config there
        # would fail with an error naming the wrong problem.
        if self._config is not None:
            channels = list(self._config.channels)
        elif self._monitored is not None:
            channels = [self._monitored]
        else:
            return None

        functions: dict[int, MeasurementFunction] = {}
        for channel in channels:
            config = self._measurement.get_configured_function(channel.address)
            if config is not None:
                functions[channel.address] = config.function
        return functions or None

    def _fallback_function(self) -> MeasurementFunction:
        """Function assumed for readings whose channel is unknown.

        Only meaningful when every configured channel shares one
        function; otherwise the caller gets DC_VOLTAGE as a structural
        placeholder and ``_fallback_unit()`` reports UNKNOWN so the
        value is not labelled with a unit nobody verified.
        """

        functions = self._channel_functions()
        if functions:
            distinct = set(functions.values())
            if len(distinct) == 1:
                return distinct.pop()
        return MeasurementFunction.DC_VOLTAGE

    def _fallback_unit(self) -> Optional[Unit]:
        """Unit for readings whose channel could not be identified.

        Returns None (meaning "derive from the function") when the
        function is genuinely known, and Unit.UNKNOWN when it is not.

        Closes a Gate 2 finding: previously an unattributable reading
        was silently tagged DC volts. Labelling a resistance reading
        "V" is precisely the misattribution class this driver has been
        bitten by twice already -- a plausible, confidently-wrong
        answer. UNKNOWN is less convenient and honest.
        """

        functions = self._channel_functions()
        if functions and len(set(functions.values())) == 1:
            return None
        return Unit.UNKNOWN
