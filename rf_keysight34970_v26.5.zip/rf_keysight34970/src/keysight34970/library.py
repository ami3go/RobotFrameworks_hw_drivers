"""
Public Robot Framework library entry point.

This is the class users import in their .robot files:

    *** Settings ***
    Library    keysight34970.Keysight34970

Phase 1 only mixes in ConnectionKeywords. Phases 2-9 will add further
mixins here (MeasurementKeywords, ScannerKeywords, TemperatureKeywords,
DigitalIOKeywords, AlarmKeywords, ConfigManagerKeywords, ...) without
changing this class's public shape or breaking existing test suites,
per the backward-compatibility requirement in the lifecycle contract.
"""

from __future__ import annotations

from robot.api.deco import not_keyword

from .keywords.connection_keywords import (
    CAPABILITY_METADATA as CONNECTION_CAPABILITY_METADATA,
)
from .keywords.connection_keywords import ConnectionKeywords
from .keywords.measurement_keywords import (
    CAPABILITY_METADATA as MEASUREMENT_CAPABILITY_METADATA,
)
from .keywords.measurement_keywords import MeasurementKeywords
from .keywords.scanner_keywords import (
    CAPABILITY_METADATA as SCANNER_CAPABILITY_METADATA,
)
from .keywords.scanner_keywords import ScannerKeywords
from .keywords.temperature_keywords import (
    CAPABILITY_METADATA as TEMPERATURE_CAPABILITY_METADATA,
)
from .keywords.temperature_keywords import TemperatureKeywords
from .keywords.digital_keywords import (
    CAPABILITY_METADATA as DIGITAL_CAPABILITY_METADATA,
)
from .keywords.digital_keywords import DigitalKeywords

# Merged from each mixin's own registry. Adding a phase means adding a
# module, not editing a central registry every phase contends over.
CAPABILITY_METADATA: dict[str, dict] = {
    **CONNECTION_CAPABILITY_METADATA,
    **MEASUREMENT_CAPABILITY_METADATA,
    **SCANNER_CAPABILITY_METADATA,
    **TEMPERATURE_CAPABILITY_METADATA,
    **DIGITAL_CAPABILITY_METADATA,
}

# SUITE scope: one library instance (and therefore one instrument
# session) per Robot Framework suite. TEST scope was used through Gate
# 3 and was wrong - it constructs a fresh instance per test case, which
# silently discards any connection opened in `Suite Setup`. GLOBAL would
# be worse still on a shared bench (RFDS-018), since separate suites
# would contend for one session without an explicit handoff.
ROBOT_LIBRARY_SCOPE = "SUITE"
ROBOT_LIBRARY_VERSION = "26.05.05"


class Keysight34970(
    ConnectionKeywords,
    MeasurementKeywords,
    ScannerKeywords,
    TemperatureKeywords,
    DigitalKeywords,
):
    """Robot Framework library for the Keysight/Agilent 34970A / 34972A
    Data Acquisition / Switch Unit.

    Provides connection lifecycle keywords: connect/disconnect/reconnect,
    reset/clear, timeout control, raw SCPI escape hatches, and
    error-queue diagnostics.

    ``MeasurementKeywords`` (Phase 2) adds configure/read/measure
    keywords driving the internal DMM. See CHANGELOG.md.
    """

    ROBOT_LIBRARY_SCOPE = ROBOT_LIBRARY_SCOPE
    ROBOT_LIBRARY_VERSION = ROBOT_LIBRARY_VERSION

    def __init__(self) -> None:
        # Each mixin initialises its own disjoint state explicitly.
        # Cooperative super() chaining is avoided deliberately: mixins
        # here are independent, and explicit calls keep the wiring
        # obvious as further phases add more of them.
        ConnectionKeywords.__init__(self)
        MeasurementKeywords.__init__(self)
        ScannerKeywords.__init__(self)
        TemperatureKeywords.__init__(self)
        DigitalKeywords.__init__(self)
        # Fail at construction if any mixin declares a reset hook that
        # does not exist, rather than silently skipping it later.
        self._validate_session_reset_hooks()

    @staticmethod
    @not_keyword
    def get_capability_metadata() -> dict:
        """Returns planning-hint metadata (risk level, blocking
        behavior, exclusive resources) for every keyword currently
        implemented. Staged ahead of the full RFDS-017 AI Driver
        Contract, which Phase 10 will generate from this and successor
        registries. Not itself a conformant ai_contract.yaml.

        Marked @not_keyword: this is a Python-only introspection API.
        Without it, Robot Framework auto-exposes it as a keyword named
        "Get Capability Metadata", putting an undeclared capability in
        the public surface that appears in neither CAPABILITY_METADATA
        nor the RFDS-017 contract.
        """

        import copy

        return copy.deepcopy(CAPABILITY_METADATA)
