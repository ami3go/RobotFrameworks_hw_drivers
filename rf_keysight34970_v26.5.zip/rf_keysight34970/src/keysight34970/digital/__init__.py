"""
Digital I/O subpackage (Phase 5) — 34907A multifunction module.

Gate 1 provides the data models, channel-role validation and the
``DigitalEngine`` interface. The concrete engine and its Robot
Framework keywords arrive in Gate 2.
"""

from .base import DigitalEngine
from .models import (
    DAC_MAX_V,
    DAC_MIN_V,
    PORT_BITS,
    PORT_MAX_VALUE,
    TOTALIZER_MAX_COUNT,
    ChannelRole,
    DacOutput,
    DigitalPortState,
    EdgeSlope,
    InputThreshold,
    TotalizerConfig,
    TotalizerMode,
    TotalizerReading,
    require_role,
    role_of,
)

__all__ = [
    "DigitalEngine",
    "ChannelRole",
    "DacOutput",
    "DigitalPortState",
    "EdgeSlope",
    "InputThreshold",
    "TotalizerConfig",
    "TotalizerMode",
    "TotalizerReading",
    "role_of",
    "require_role",
    "DAC_MIN_V",
    "DAC_MAX_V",
    "PORT_BITS",
    "PORT_MAX_VALUE",
    "TOTALIZER_MAX_COUNT",
]
