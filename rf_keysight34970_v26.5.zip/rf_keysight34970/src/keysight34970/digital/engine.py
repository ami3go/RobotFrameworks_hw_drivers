"""
SCPI implementation of the DigitalEngine interface (Phase 5, Gate 2).

Owns no I/O: every interaction goes through the Phase 1 ``Connection``,
inheriting its error-queue policy.

SCPI model used here:

    SOUR:DIG:DATA:BYTE <value>,(@ch)   drive a digital port
    SENS:DIG:DATA:BYTE? (@ch)          read a digital port
    SENS:TOT:TYPE READ|RRES,(@ch)      whether reading clears the count
    SENS:TOT:SLOP POS|NEG,(@ch)        counting edge
    SENS:TOT:DATA? (@ch)               read the count
    SENS:TOT:CLE:IMM (@ch)             zero the count now
    SOUR:VOLT <volts>,(@ch)            drive an analogue output
    SOUR:VOLT? (@ch)                   read back the commanded setting

VERIFICATION STATUS: command spellings follow the published
programmer's reference and are exercised against the in-repo mock. NOT
verified against physical hardware. That caveat carries more weight in
this phase than in earlier ones: an incorrect command here does not
merely fail to read something, it may drive an output.
"""

from __future__ import annotations

from collections import deque
from typing import Optional, Sequence

from ..connection import Connection
from ..exceptions import CommandError, ConfigurationError
from ..logging_config import get_logger
from ..measurement.channels import CardType, ChannelId, ChannelList
from .base import DigitalEngine
from .models import (
    DAC_CHANNELS,
    WRITE_HISTORY_LIMIT,
    ChannelRole,
    role_of,
    DacOutput,
    DigitalPortState,
    TotalizerConfig,
    TotalizerReading,
    require_role,
)


class ScpiDigitalEngine(DigitalEngine):
    """Digital I/O engine driving a 34907A over SCPI."""

    def __init__(
        self,
        connection: Connection,
        *,
        cards: Optional[dict[int, CardType]] = None,
    ) -> None:
        """
        Args:
            cards: optional slot -> CardType map. When a slot is
                declared and holds something other than a 34907A, this
                engine refuses to address it. Slots absent from the map
                are not blocked -- the driver cannot discover installed
                cards, and refusing everything undeclared would make the
                module unusable on a partially-described bench.
        """

        self._connection = connection
        self._cards: dict[int, CardType] = dict(cards or {})
        self._totalizer_configs: dict[int, TotalizerConfig] = {}
        # Bounded history of drives, most recent last. A soak test that
        # writes an output in a loop would otherwise grow this without
        # limit -- measured at Phase 5 Gate 5: 5000 recorded drives made
        # get_driven_outputs() cost 3 ms, on a call that performs no
        # instrument I/O at all.
        #
        # The bound is on the HISTORY only. `_latest` keeps one entry per
        # channel and is never trimmed, so the safety-critical question
        # -- which outputs has this driver energised, and to what -- stays
        # exactly answerable however long the session runs.
        self._written: deque[DacOutput | DigitalPortState] = deque(
            maxlen=WRITE_HISTORY_LIMIT
        )
        self._latest: dict[int, DacOutput | DigitalPortState] = {}
        self._log = get_logger(connection.config.display_name())

    # -- digital ports ---------------------------------------------

    def read_port(self, channel: "str | int") -> DigitalPortState:
        target = self._resolve(channel, ChannelRole.DIGITAL_PORT)
        response = self._connection.query(
            f"SENS:DIG:DATA:BYTE? (@{target.address})"
        )
        return DigitalPortState(channel=target, value=self._parse_int(response, target))

    def write_port(self, channel: "str | int", value: int) -> None:
        target = self._resolve(channel, ChannelRole.DIGITAL_PORT)

        # Construct the state first: it validates the 8-bit range, so an
        # out-of-range value is rejected before any line is driven.
        state = DigitalPortState(channel=target, value=int(value))

        self._connection.write(
            f"SOUR:DIG:DATA:BYTE {state.value},(@{target.address})"
        )
        self._written.append(state)
        self._latest[state.channel.address] = state
        self._log.info("Drove digital port %s to %s", target, state.to_binary())

    def write_port_bit(self, channel: "str | int", bit: int, value: bool) -> None:
        """Set one bit, preserving the others.

        NOT ATOMIC. This reads the port, changes one bit and writes the
        whole byte back. If anything else drives the same port between
        the two operations, that change is overwritten. The instrument
        offers no bit-scoped write, so the race is inherent rather than
        an implementation shortcut -- which is why it is stated here
        instead of being hidden behind a convenient signature.
        """

        target = self._resolve(channel, ChannelRole.DIGITAL_PORT)
        current = self.read_port(target)
        updated = current.with_bit(int(bit), bool(value))

        if updated.value == current.value:
            self._log.debug(
                "Bit %d of %s already %s; no write issued",
                bit,
                target,
                bool(value),
            )
            return

        self.write_port(target, updated.value)

    # -- totalizer -------------------------------------------------

    def configure_totalizer(
        self, channel: "str | int", config: TotalizerConfig
    ) -> None:
        target = self._resolve(channel, ChannelRole.TOTALIZER)

        self._connection.write(
            f"SENS:TOT:TYPE {config.mode.value},(@{target.address})"
        )
        self._connection.write(
            f"SENS:TOT:SLOP {config.slope.value},(@{target.address})"
        )
        if config.threshold is not None:
            self._connection.write(
                f"SENS:TOT:THR {config.threshold.value},(@{target.address})"
            )

        self._totalizer_configs[target.address] = config

        if config.reading_is_destructive:
            self._log.warning(
                "Totalizer %s configured READ_RESET: reading the count "
                "zeroes it, so a second read returns 0",
                target,
            )

    def read_totalizer(self, channel: "str | int") -> TotalizerReading:
        target = self._resolve(channel, ChannelRole.TOTALIZER)
        response = self._connection.query(f"SENS:TOT:DATA? (@{target.address})")

        config = self._totalizer_configs.get(target.address)
        destructive = config.reading_is_destructive if config else False

        reading = TotalizerReading(
            channel=target,
            count=self._parse_int(response, target),
            was_reset_by_read=destructive,
        )

        if destructive:
            self._log.info(
                "Read and cleared totalizer %s: count %d is now the only "
                "copy",
                target,
                reading.count,
            )
        if reading.is_near_wrap:
            self._log.warning(
                "Totalizer %s at %d is near the 26-bit wrap point; the "
                "counter wraps to zero rather than saturating, and a "
                "wrapped count is indistinguishable from a low one",
                target,
                reading.count,
            )
        return reading

    def clear_totalizer(self, channel: "str | int") -> None:
        target = self._resolve(channel, ChannelRole.TOTALIZER)
        self._connection.write(f"SENS:TOT:CLE:IMM (@{target.address})")
        self._log.info("Cleared totalizer %s", target)

    # -- analogue outputs ------------------------------------------

    def write_dac(self, channel: "str | int", volts: float) -> None:
        target = self._resolve(channel, ChannelRole.DAC)

        # Validates the range before anything is driven. Out of range
        # raises rather than clamping.
        output = DacOutput(channel=target, volts=float(volts))

        self._connection.write(f"SOUR:VOLT {output.volts:g},(@{target.address})")
        self._written.append(output)
        self._latest[output.channel.address] = output
        self._log.info("Drove analogue output %s", output)

    def read_dac_setting(self, channel: "str | int") -> DacOutput:
        """Return the commanded setting, not a measurement.

        The instrument reports what it was told to output. Nothing here
        verifies that the output is actually at that voltage -- a
        shorted or loaded output reads back the same as a working one.
        """

        target = self._resolve(channel, ChannelRole.DAC)
        response = self._connection.query(f"SOUR:VOLT? (@{target.address})")
        try:
            volts = float(response.strip())
        except ValueError as exc:
            raise CommandError(
                f"Could not parse analogue output setting from {response!r}",
                scpi_message=response,
            ) from exc
        return DacOutput(channel=target, volts=volts)

    # -- introspection ---------------------------------------------

    def get_totalizer_config(
        self, channel: "str | int"
    ) -> Optional[TotalizerConfig]:
        target = ChannelId.parse(channel)
        return self._totalizer_configs.get(target.address)

    def written_outputs(self) -> Sequence[DacOutput | DigitalPortState]:
        """Every output **this driver** drove in this session, in order.

        Exists so a teardown can report or restore what a test drove.
        An output left energised after a test is a hazard that no amount
        of instrument state inspection will attribute back to the test
        that caused it.

        WHAT THIS IS NOT: a record of what is currently energised. An
        output set from the front panel, by a previous session, or via
        ``Send Scpi Command`` never appears here, and an output this
        driver set and something else later changed still appears with
        the driver's value. For "what is the hardware actually doing",
        use ``read_output_state()``, which asks the instrument.

        The distinction matters most in exactly the situation where
        these methods matter at all: deciding whether it is safe to
        disconnect.
        """

        return tuple(self._written)

    def latest_outputs(self) -> dict[int, DacOutput | DigitalPortState]:
        """The most recent drive per channel, as this driver saw it.

        Unlike ``written_outputs()``, this is never trimmed: it answers
        "which outputs has this driver energised, and to what", which is
        the question a teardown actually needs and which must stay
        correct however long a session runs.

        Still a driver-side record -- see ``read_output_state()`` for
        what the hardware reports.
        """

        return dict(self._latest)

    def read_output_state(
        self, channels: "ChannelList | str | int | None" = None
    ) -> dict[int, float]:
        """Query the instrument for the present state of output channels.

        Unlike ``written_outputs()``, this reflects the hardware
        regardless of who set it -- front panel, another session, or a
        raw SCPI command.

        Args:
            channels: which outputs to query. Defaults to every output
                this driver has driven, which is the useful default for
                a teardown check but is NOT a survey of the whole card.
                Pass channels explicitly to check outputs the driver
                never touched.

        Returns a mapping of channel address to present value. DAC
        channels report volts; digital ports report their byte value.
        """

        if channels is None:
            targets = sorted(self._latest)
            if not targets:
                return {}
        else:
            targets = [c.address for c in ChannelList.parse(channels)]

        state: dict[int, float] = {}
        for address in targets:
            channel = ChannelId.parse(address)
            if self._is_dac_channel(channel):
                response = self._connection.query(f"SOUR:VOLT? (@{address})")
            else:
                response = self._connection.query(f"SENS:DIG:DATA:BYTE? (@{address})")
            try:
                state[address] = float(response.strip())
            except ValueError as exc:
                raise CommandError(
                    f"Could not parse output state for channel {address} "
                    f"from {response!r}",
                    context={"channel": address},
                ) from exc
        return state

    def safe_output_state(self) -> dict[int, float]:
        """Return every driven output to zero, and report what was reset.

        Zero is the safe default for both subsystems this touches: 0 V
        on a DAC and all-low on a digital port. It is NOT universally
        safe -- an active-low relay driver energises on zero -- so this
        is offered as an explicit operation rather than run
        automatically on disconnect. Silently de-energising hardware at
        teardown could be exactly the wrong move.
        """

        reset: dict[int, float] = {}
        for address in sorted(self._latest):
            channel = ChannelId.parse(address)
            if self._is_dac_channel(channel):
                self.write_dac(channel, 0.0)
            else:
                self.write_port(channel, 0)
            reset[address] = 0.0
        return reset

    def _is_dac_channel(self, channel: ChannelId) -> bool:
        """Whether a channel is a DAC output rather than a digital port.

        Resolved through the shared ``role_of()`` map rather than an
        inline channel-number test, so this and the write paths cannot
        disagree about what a channel is. Misrouting here would mean
        sending a DAC voltage to a digital port -- a write to physical
        hardware. (Closes a Gate 3 finding.)
        """

        try:
            return role_of(channel) is ChannelRole.DAC
        except ConfigurationError:
            # Role not resolvable for this channel; fall back to the
            # layout default rather than guessing.
            return channel.channel in DAC_CHANNELS

    def set_card(self, slot: int, card: CardType) -> None:
        if not (1 <= int(slot) <= 3):
            raise ConfigurationError(
                f"slot must be 1-3, got {slot}", context={"slot": slot}
            )
        self._cards[int(slot)] = card

    # -- helpers ---------------------------------------------------

    def _resolve(self, channel: "str | int", role: ChannelRole) -> ChannelId:
        """Validate the channel's role and the card in its slot."""

        target = require_role(channel, role)

        declared = self._cards.get(target.slot)
        if declared is not None and declared is not CardType.MFM_34907A:
            raise ConfigurationError(
                f"Channel {target} is in slot {target.slot}, which holds a "
                f"{declared.value}. Digital I/O, the totalizer and the "
                "analogue outputs are provided by the 34907A "
                "multifunction module only.",
                context={"channel": target.address, "card": declared.value},
            )
        return target

    @staticmethod
    def _parse_int(response: str, channel: ChannelId) -> int:
        """Parse an integer response.

        Accepts the scientific-notation form some firmware returns for
        integer queries (``+1.02400000E+03``), because silently failing
        to parse a count would be worse than accepting both spellings.
        """

        text = response.strip()
        if not text:
            raise CommandError(
                f"Instrument returned an empty response for channel {channel}"
            )
        try:
            return int(text)
        except ValueError:
            pass
        try:
            as_float = float(text)
        except ValueError as exc:
            raise CommandError(
                f"Could not parse an integer for channel {channel} from "
                f"{response!r}",
                scpi_message=text,
            ) from exc
        if as_float != int(as_float):
            raise CommandError(
                f"Expected an integer for channel {channel} but got "
                f"{as_float!r}",
                scpi_message=text,
            )
        return int(as_float)
