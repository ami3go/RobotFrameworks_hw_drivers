"""
Digital I/O engine interface (Phase 5, Gate 1).

Defines the contract Gate 2 implements.

The operation split follows the hardware's three distinct roles rather
than presenting one uniform "channel" abstraction. A digital port, a
counter and an analogue output share nothing but an address, and
flattening them would let a caller write a voltage to a port by
supplying the wrong channel number.

READS AND WRITES ARE SEPARATED DELIBERATELY. This is the first phase
whose capabilities drive signals out of the instrument, and an output
operation is not undone by a subsequent read. Every write-shaped method
is named for the fact that it writes.
"""

from __future__ import annotations

import abc
from typing import Optional, Sequence

from .models import (
    DacOutput,
    DigitalPortState,
    TotalizerConfig,
    TotalizerReading,
)


class DigitalEngine(abc.ABC):
    """Contract for 34907A digital I/O, totalizer and analogue output."""

    # -- digital ports ---------------------------------------------

    @abc.abstractmethod
    def read_port(self, channel: "str | int") -> DigitalPortState:
        """Read the current byte value of a digital port.

        Raises:
            ConfigurationError: if the channel is not a digital port.
            StateError: if no connection is active.
        """

    @abc.abstractmethod
    def write_port(self, channel: "str | int", value: int) -> None:
        """Drive a digital port to a byte value.

        This changes the state of physical output lines. It is not
        undone by reading, and the previous value is not recoverable
        from the instrument.

        Raises:
            ConfigurationError: if the channel is not a digital port, or
                the value does not fit in 8 bits.
        """

    @abc.abstractmethod
    def write_port_bit(self, channel: "str | int", bit: int, value: bool) -> None:
        """Set one bit of a digital port, preserving the others.

        Implemented as read-modify-write, which is not atomic. If
        anything else drives the same port between the read and the
        write, that change is overwritten. Implementations should say so
        rather than implying the operation is bit-scoped at the hardware
        level.
        """

    # -- totalizer -------------------------------------------------

    @abc.abstractmethod
    def configure_totalizer(
        self, channel: "str | int", config: TotalizerConfig
    ) -> None:
        """Configure the counter's read mode, count edge and threshold."""

    @abc.abstractmethod
    def read_totalizer(self, channel: "str | int") -> TotalizerReading:
        """Read the counter.

        In READ_RESET mode this **consumes** the count: the instrument
        zeroes it as part of the read, and the returned object is the
        only remaining copy. Implementations must record that on the
        reading rather than leaving the caller to infer it from
        configuration set elsewhere.
        """

    @abc.abstractmethod
    def clear_totalizer(self, channel: "str | int") -> None:
        """Zero the counter immediately, discarding the current count."""

    # -- analogue outputs ------------------------------------------

    @abc.abstractmethod
    def write_dac(self, channel: "str | int", volts: float) -> None:
        """Drive an analogue output to a voltage.

        Raises:
            ConfigurationError: if the channel is not a DAC, or the
                voltage is outside the module's range. Out-of-range
                values are rejected rather than clamped: clamping would
                drive a different voltage than the caller asked for,
                which on an output is a hardware event rather than a
                rounding error.
        """

    @abc.abstractmethod
    def read_dac_setting(self, channel: "str | int") -> DacOutput:
        """Return the voltage a DAC channel is currently set to.

        This reports the commanded setting, not a measurement of the
        output. Implementations must not present it as verification that
        the output is actually at that voltage.
        """

    # -- introspection ---------------------------------------------

    @abc.abstractmethod
    def get_totalizer_config(
        self, channel: "str | int"
    ) -> Optional[TotalizerConfig]:
        """Return the configuration this driver applied to a counter, or
        None if it has not configured one.

        Reflects driver-side state; it does not re-query the instrument.
        """

    @abc.abstractmethod
    def written_outputs(self) -> Sequence[DacOutput | DigitalPortState]:
        """Every output this driver has driven in the current session.

        Exists so a teardown can restore or report outputs it set. An
        output left driven after a test is a hazard that no amount of
        instrument state inspection will attribute back to the test that
        caused it.
        """
