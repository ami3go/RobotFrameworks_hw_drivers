"""
Structured logging setup for the keysight34970 driver.

Robot Framework already captures stdout/log messages per keyword, but
this driver also supports being used outside Robot (plain Python, or
by an AI test planner), so it configures its own logger namespace
rather than assuming a Robot Framework context.
"""

from __future__ import annotations

import logging

LOGGER_NAME = "keysight34970"

_DEFAULT_FORMAT = (
    "%(asctime)s | %(levelname)-8s | %(name)s | %(instrument)s | %(message)s"
)


class _InstrumentContextFilter(logging.Filter):
    """Ensures every record has an ``instrument`` field, defaulting to
    "-" for log statements not tied to a specific connection (e.g.
    module import, configuration parsing)."""

    def filter(self, record: logging.LogRecord) -> bool:
        if not hasattr(record, "instrument"):
            record.instrument = "-"
        return True


def get_logger(instrument_alias: str = "-") -> logging.LoggerAdapter:
    """Return a LoggerAdapter that automatically tags every message with
    the given instrument alias, so multi-instrument bench logs (see
    RFDS-018 Shared Resources / Signal Graph) remain attributable."""

    logger = logging.getLogger(LOGGER_NAME)
    return logging.LoggerAdapter(logger, {"instrument": instrument_alias})


def configure_logging(level: int = logging.INFO, *, propagate: bool = False) -> None:
    """Idempotently configure the package logger. Safe to call multiple
    times (e.g. once per Robot Framework suite) without duplicating
    handlers."""

    logger = logging.getLogger(LOGGER_NAME)
    logger.setLevel(level)
    logger.propagate = propagate

    has_filter = any(isinstance(f, _InstrumentContextFilter) for f in logger.filters)
    if not has_filter:
        logger.addFilter(_InstrumentContextFilter())

    if not logger.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(logging.Formatter(_DEFAULT_FORMAT))
        logger.addHandler(handler)
