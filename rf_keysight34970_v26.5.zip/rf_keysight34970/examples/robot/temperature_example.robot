*** Settings ***
Documentation     Phase 4 example: temperature measurement. Replace
...               ${HOST} and the channels to match your bench.
Library           keysight34970.Keysight34970
Suite Setup       Open Bench
Suite Teardown    Disconnect From Instrument
Test Setup        Clear Instrument Status

*** Variables ***
${HOST}           10.0.0.12
${PORT}           5025

*** Keywords ***
Open Bench
    Connect To Instrument    34972A    TCP    ${HOST}    port=${PORT}    alias=daq1
    Set Installed Card    1    34901A

*** Test Cases ***
Thermocouple Requires An Explicit Type
    [Documentation]    The alloy sets the voltage-to-temperature curve.
    ...                Assuming K would be wrong by tens of degrees for
    ...                any other type, so there is no default.
    Run Keyword And Expect Error    *thermocouple type is required*
    ...    Configure Thermocouple    (@101)    ${EMPTY}

Read A Type K Thermocouple
    Configure Thermocouple    (@101,102)    K
    ${temps}=    Read Temperature
    Length Should Be    ${temps}    2

Readings Carry The Configured Unit
    [Documentation]    Not an assumed Celsius.
    Configure Thermocouple    (@101)    K    unit=F
    ${rows}=    Read Temperature Details
    Should Be Equal    ${rows}[0][unit]    degF

Channels May Use Different Units
    Configure Thermocouple    (@101)    K    unit=C
    Configure Thermocouple    (@102)    K    unit=F
    ${rows}=    Read Temperature Details
    Should Be Equal    ${rows}[0][unit]    degC
    Should Be Equal    ${rows}[1][unit]    degF

Change Unit After Configuring
    Configure Thermocouple    (@101)    K    unit=C
    Set Temperature Unit    K
    ${rows}=    Read Temperature Details
    Should Be Equal    ${rows}[0][unit]    K

Read An RTD
    Configure RTD    (@103)    nominal=100
    ${temp}=    Read Temperature    (@103)
    Length Should Be    ${temp}    1

Four Wire RTD Consumes The Paired Channel
    [Documentation]    A 4-wire RTD on 101 also occupies 111.
    Configure Thermocouple    (@111)    K
    Run Keyword And Expect Error    *already configured*
    ...    Configure RTD    (@101)    four_wire=True

Thermistor Must Use A Standard Curve
    [Documentation]    The instrument implements 2252/5000/10000 ohm
    ...                curves; another value gives believable but wrong
    ...                temperatures.
    Run Keyword And Expect Error    *not a standard value*
    ...    Configure Thermistor    (@104)    nominal=3000

Read The Reference Junction
    [Documentation]    When thermocouple readings look wrong, this
    ...                separates a bad cold junction from a wrong alloy.
    ${ref}=    Read Reference Junction Temperature
    Should Be True    ${ref} > -50 and ${ref} < 100

Assert A Temperature Is In Range
    Configure Thermocouple    (@101)    K
    ${temp}=    Temperature Should Be Within    101    0    100
    Should Be True    ${temp} >= 0

Temperature Channels Are Visible To Scanning
    Configure Thermocouple    (@101,102)    K
    ${function}=    Get Configured Function    101
    Should Be Equal    ${function}    TEMP

Open Detect Guards A Broken Junction
    [Documentation]    A thermocouple with a broken junction reports a
    ...                plausible temperature, not an error. Open-detect
    ...                is the instrument's own check for it.
    Configure Thermocouple    (@101)    K    open_detect=ON
    ${temps}=    Read Temperature    (@101)
    Length Should Be    ${temps}    1

Calibrated RTD Reference Resistance
    [Documentation]    nominal says "this is a PT100"; reference_ohms
    ...                says "this one is 100.02 ohms at 0 C".
    Configure RTD    (@106)    nominal=100    reference_ohms=100.02
    ${temps}=    Read Temperature    (@106)
    Length Should Be    ${temps}    1

Wrong Alloy Is Caught Only When Grossly Wrong
    [Documentation]    Type B cannot measure near ambient, so an
    ...                ambient reading from one is implausible and
    ...                fails even with wide bounds. A *moderately*
    ...                wrong alloy would NOT be caught -- see the user
    ...                guide.
    Configure Thermocouple    (@101)    B
    Run Keyword And Expect Error    *
    ...    Temperature Should Be Within    101    -1000000    1000000

Open Detect Is Not Even Expressible For An RTD
    [Documentation]    Only a thermocouple has a junction that can open,
    ...                so Configure RTD does not accept the argument at
    ...                all. Robot rejects it before the driver is
    ...                reached, which is stronger than a runtime error.
    ...                The Python API enforces the same rule with a
    ...                ConfigurationError.
    Run Keyword And Expect Error    *unexpected named argument*
    ...    Configure RTD    (@106)    nominal=100    open_detect=ON
