*** Settings ***
Documentation     Phase 1 example: recommended suite structure using
...               suite-level connection setup/teardown, plus error
...               handling and diagnostics patterns. Replace ${HOST}
...               with your instrument's IP before running.
Library           keysight34970.Keysight34970
Suite Setup       Open Bench Connection
Suite Teardown    Disconnect From Instrument
Test Setup        Clear Instrument Status

*** Variables ***
${HOST}           10.0.0.12
${PORT}           5025
${MODEL}          34972A

*** Keywords ***
Open Bench Connection
    [Documentation]    Connecting once per suite rather than per test is
    ...                usually preferable: it avoids repeated session
    ...                setup cost, and on a shared bench (RFDS-018) it
    ...                holds the instrument for a predictable window.
    Connect To Instrument    ${MODEL}    TCP    ${HOST}
    ...    port=${PORT}    alias=daq1    timeout=10
    Instrument Should Be Connected

*** Test Cases ***
Identity Is Reported Correctly
    ${idn}=    Get Instrument Identity
    Should Contain    ${idn}    ${MODEL}

Error Queue Is Clean At Test Start
    ${errors}=    Drain Instrument Error Queue
    Should Be Empty    ${errors}

Invalid Command Fails The Keyword
    [Documentation]    Errors reported by the instrument surface as
    ...                keyword failures, so tests fail loudly rather
    ...                than continuing against a faulted instrument.
    Run Keyword And Expect Error    *Instrument reported error*
    ...    Send Scpi Command    BOGUS:COMMAND

Connection Survives An Instrument Error
    Run Keyword And Expect Error    *    Send Scpi Command    BOGUS:COMMAND
    Instrument Should Be Connected
    ${idn}=    Query Scpi Command    *IDN?
    Should Not Be Empty    ${idn}

Timeout Can Be Raised For Slow Operations
    [Documentation]    Later phases add long-running scans; raising the
    ...                timeout beforehand avoids spurious failures.
    Set Instrument Timeout    30
    ${idn}=    Query Scpi Command    *IDN?
    Should Not Be Empty    ${idn}
    [Teardown]    Set Instrument Timeout    10

Reconnect Restores A Working Session
    Reconnect To Instrument
    Instrument Should Be Connected
    ${state}=    Get Connection State
    Should Be Equal    ${state}    CONNECTED
