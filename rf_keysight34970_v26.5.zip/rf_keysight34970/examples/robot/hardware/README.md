# Hardware verification suites

Run these against a **real** 34970A/34972A. Everything else in this
project has only ever been validated against an in-repo mock.

Run in order:

```bash
robot --variable HOST:10.0.0.12 01_bench_survey.robot
robot --variable HOST:10.0.0.12 02_verify_commands.robot
robot --variable HOST:10.0.0.12 03_verify_assumptions.robot
```

| Suite | Purpose | Drives outputs? |
|---|---|---|
| `01_bench_survey` | Identifies mainframe and cards; declares them to the driver | No |
| `02_verify_commands` | Exercises every capability the detected bench supports | Only with opt-in |
| `03_verify_assumptions` | Tests the beliefs the driver's correctness rests on | No |

## Adapting to the bench

Card detection uses `SYST:CTYP?` on each slot. Tests requiring hardware
the bench does not have are **skipped, not failed** — a skip means "this
bench cannot answer that question", a failure means the driver is wrong.

Verified against five simulated layouts: full bench (27 pass / 2 skip),
mux-only (23/6), switch-only (6/23), empty (6/23), and an unrecognised
card (6/23, validation relaxed rather than refused).

## Driving outputs

`02_verify_commands` is read-only by default. Output tests are skipped
unless you opt in:

```bash
robot --variable HOST:10.0.0.12 --variable ALLOW_OUTPUT_WRITES:yes 02_verify_commands.robot
```

**Only do this with nothing consequential wired to the 34907A.** These
keywords drive physical lines, and zero is not a safe value for all
wiring — an active-low relay driver energises at zero. Read the digital
I/O section of the user guide first.

## Suite 03 is the important one

It targets specific beliefs encoded in the driver that would produce
plausible, confidently wrong results if false:

- **Ascending channel order** — the driver matches readings to channels
  *by position*. If the mainframe does not scan ascending, every
  multi-channel reading is misattributed and the counts still look
  right. Measurement, scanning and temperature all rest on this.
- **Card channel ranges** — from published specs, never measured.
- **Over-range sentinel** — `9.9E+37` must be recognised, or it becomes
  a real-looking reading of 1e38 that passes numeric assertions.
- **4-wire pairing** — N+10 reservation.
- **Statistics across scans** — records which way this firmware goes;
  the driver documents it as firmware-dependent and unverified.

A failure in suite 03 is not a bug in the test. Each test's
documentation says what a failure implies.

## What this already found

Running suite 02 against the mock exposed a driver defect:
`Set Temperature Unit` failed when no channels were configured, raising
an error about *reading* from an operation that writes. Fixed, with a
regression test.
