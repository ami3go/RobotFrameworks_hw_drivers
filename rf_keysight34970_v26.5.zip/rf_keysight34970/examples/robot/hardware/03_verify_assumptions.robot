*** Settings ***
Documentation     Tests the assumptions this driver's correctness rests
...               on, none of which has ever been checked against real
...               hardware.
...
...               This suite exists because five phases of development
...               were validated entirely against a mock this project
...               wrote to match its own assumptions. Every test here
...               targets a specific belief encoded in the driver that
...               would produce a plausible, confidently wrong result if
...               it turned out to be false.
...
...               A FAILURE HERE IS NOT A BUG IN THE TEST. It means the
...               driver is wrong about the instrument, and the note in
...               each test says what that implies.
...
...               Run with:
...               | robot --variable HOST:10.0.0.12 03_verify_assumptions.robot
Resource          ../resources/bench_discovery.resource
Library           Collections
Suite Setup       Prepare Bench
Suite Teardown    Release Bench
Test Setup        Clear Instrument Status

*** Variables ***
${HOST}           127.0.0.1
${PORT}           5025
${MODEL}          34972A

*** Keywords ***
Prepare Bench
    Connect To Instrument    ${MODEL}    TCP    ${HOST}    port=${PORT}    alias=bench    timeout=30
    ${bench}=    Discover Bench
    Set Suite Variable    ${BENCH}    ${bench}
    ${mslot}=    Get First Measuring Slot    ${bench}
    Set Suite Variable    ${MEAS_SLOT}    ${mslot}
    Clear Instrument Status

Release Bench
    Run Keyword And Ignore Error    Stop Monitoring
    Run Keyword And Ignore Error    Abort Scan
    Disconnect From Instrument

Require Multi Channel Card
    Skip If    '${MEAS_SLOT}' == '${EMPTY}'    No measuring card on this bench.

*** Test Cases ***
Readings Come Back In Ascending Channel Order
    [Documentation]
    ...    ASSUMPTION (Phase 2, load-bearing for everything since).
    ...
    ...    The driver normalises scan lists to ascending order and
    ...    matches readings to channels BY POSITION. It does this
    ...    because the mainframe is documented to scan ascending
    ...    regardless of the order a list is written in.
    ...
    ...    IF THIS FAILS: every multi-channel reading this driver has
    ...    ever produced is attributed to the wrong channel. The reading
    ...    counts are correct, so nothing else detects it. Measurement,
    ...    scanning and temperature all rest on this.
    [Setup]    Require Multi Channel Card
    ${a}=    Channel On Slot    ${MEAS_SLOT}    1
    ${b}=    Channel On Slot    ${MEAS_SLOT}    2
    ${c}=    Channel On Slot    ${MEAS_SLOT}    3
    Clear Measurement Configuration
    Configure Measurement    DCV    (@${a},${b},${c})
    ${rows}=    Read Measurement Details    (@${c},${a},${b})
    ${addresses}=    Create List
    FOR    ${row}    IN    @{rows}
        Append To List    ${addresses}    ${row}[channel]
    END
    ${sorted}=    Copy List    ${addresses}
    Sort List    ${sorted}
    Should Be Equal    ${addresses}    ${sorted}
    ...    msg=Readings did NOT come back ascending. The driver's positional channel matching is wrong and every multi-channel result is misattributed.

Requested Channels All Appear Exactly Once
    [Documentation]
    ...    Guards the same assumption from the other side: a reading
    ...    count that matches while the channel set does not would mean
    ...    a channel was read twice and another skipped.
    [Setup]    Require Multi Channel Card
    ${a}=    Channel On Slot    ${MEAS_SLOT}    1
    ${b}=    Channel On Slot    ${MEAS_SLOT}    2
    Clear Measurement Configuration
    Configure Measurement    DCV    (@${a},${b})
    ${rows}=    Read Measurement Details    (@${a},${b})
    Length Should Be    ${rows}    2
    ${addresses}=    Create List
    FOR    ${row}    IN    @{rows}
        Append To List    ${addresses}    ${row}[channel]
    END
    List Should Not Contain Duplicates    ${addresses}

Declared Card Channel Ranges Match The Hardware
    [Documentation]
    ...    ASSUMPTION (Phase 2 Gate 1). The per-card channel counts in
    ...    CARD_SPECS come from published module specifications and have
    ...    never been checked against a physical card.
    ...
    ...    IF THIS FAILS: the driver rejects channels the card actually
    ...    has, or accepts ones it does not. The first is an annoyance;
    ...    the second means a silent misconfiguration.
    [Setup]    Require Multi Channel Card
    ${model}=    Get From Dictionary    ${BENCH}    ${MEAS_SLOT}
    ${first}=    Channel On Slot    ${MEAS_SLOT}    1
    Configure Measurement    DCV    (@${first})
    Log    Channel 1 accepted on ${model}, as the driver's spec predicts.
    ${errors}=    Drain Instrument Error Queue
    Should Be Empty    ${errors}
    ...    msg=The instrument rejected a channel the driver believes valid for a ${model}.

Statistics Registers Behave Predictably Across Scans
    [Documentation]
    ...    UNVERIFIED (Phase 3 Gate 4). The driver documents that you
    ...    should clear statistics before a scan whose statistics you
    ...    intend to read, because whether the registers survive a new
    ...    scan is firmware-dependent and was never confirmed.
    ...
    ...    This records the actual behaviour rather than asserting one:
    ...    read the log to find out which way this firmware goes.
    [Setup]    Require Multi Channel Card
    ${ch}=    Channel On Slot    ${MEAS_SLOT}    1
    Clear Measurement Configuration
    Configure Measurement    DCV    (@${ch})
    Clear Instrument Statistics
    Run Scan    (@${ch})    sweeps=2    timeout=60
    ${first}=    Get Instrument Statistics
    Run Scan    (@${ch})    sweeps=2    timeout=60
    ${second}=    Get Instrument Statistics
    Log    After first scan: ${first}[count]. After second, without clearing: ${second}[count].
    IF    ${second}[count] > ${first}[count]
        Log    This firmware ACCUMULATES statistics across scans.    WARN
    ELSE
        Log    This firmware RESETS statistics at scan start.
    END

Over Range Returns The Documented Sentinel
    [Documentation]
    ...    ASSUMPTION. The driver treats 9.9E+37 as the over-range
    ...    marker and every plausibility and statistics guard depends on
    ...    recognising it.
    ...
    ...    IF THIS FAILS: an over-range reading is treated as a real
    ...    measurement of about 1e38 — which will pass a naive numeric
    ...    assertion.
    ...
    ...    Requires an open or over-range input on the channel below to
    ...    be meaningful; it is skipped rather than forced, since forcing
    ...    it means driving a real signal.
    [Setup]    Require Multi Channel Card
    ${ch}=    Channel On Slot    ${MEAS_SLOT}    1
    Clear Measurement Configuration
    Configure Measurement    DCV    (@${ch})    range=0.1
    ${rows}=    Read Measurement Details    (@${ch})
    ${flagged}=    Set Variable    ${rows}[0][overrange]
    ${value}=    Set Variable    ${rows}[0][value]
    Log    Reading ${value}, driver flags overrange=${flagged}
    IF    ${value} > 1e30 and not ${flagged}
        Fail    Instrument returned an over-range magnitude the driver did not recognise as the sentinel.
    END

Four Wire Consumes The Paired Channel
    [Documentation]
    ...    ASSUMPTION (Phase 3). The driver reserves channel N+10 for a
    ...    4-wire measurement on channel N and refuses to configure
    ...    anything else there.
    ...
    ...    IF THIS FAILS: the driver blocks a channel the instrument
    ...    would have allowed, or permits a conflict it should prevent.
    [Setup]    Require Multi Channel Card
    ${ch}=    Channel On Slot    ${MEAS_SLOT}    1
    ${paired}=    Get Four Wire Pair    ${ch}
    ${expected}=    Channel On Slot    ${MEAS_SLOT}    11
    Should Be Equal As Integers    ${paired}    ${expected}
    Clear Measurement Configuration
    Configure Measurement    4W Resistance    (@${ch})
    ${errors}=    Drain Instrument Error Queue
    Should Be Empty    ${errors}
    ...    msg=The instrument rejected a 4-wire configuration the driver believes valid.

Error Check Round Trip Cost Is Acceptable
    [Documentation]
    ...    Phase 2 measured that error checking costs a second round
    ...    trip, negligible over loopback but ~2 ms on a real LAN. This
    ...    records the real figure so later phases can plan against it
    ...    rather than against a mock.
    [Setup]    Require Multi Channel Card
    ${ch}=    Channel On Slot    ${MEAS_SLOT}    1
    Clear Measurement Configuration
    ${start}=    Get Time    epoch
    FOR    ${i}    IN RANGE    20
        Configure Measurement    DCV    (@${ch})
    END
    ${end}=    Get Time    epoch
    ${elapsed}=    Evaluate    (${end} - ${start}) * 1000 / 20
    Log    Mean configure round trip on this bench: ${elapsed} ms

Assumption Suite Left No Errors Behind
    ${errors}=    Drain Instrument Error Queue
    Should Be Empty    ${errors}
