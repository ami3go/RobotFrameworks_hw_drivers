*** Settings ***
Documentation     Surveys the instrument and reports what is installed.
...
...               Run this first against any new bench. It is entirely
...               read-only: it identifies the mainframe and each card,
...               and drives nothing.
...
...               Run with:
...               | robot --variable HOST:10.0.0.12 01_bench_survey.robot
Resource          ../resources/bench_discovery.resource
Library           Collections
Suite Setup       Connect To Instrument    ${MODEL}    TCP    ${HOST}    port=${PORT}    alias=bench
Suite Teardown    Disconnect From Instrument

*** Variables ***
${HOST}           127.0.0.1
${PORT}           5025
${MODEL}          34972A

*** Test Cases ***
Mainframe Responds And Identifies Itself
    [Documentation]    If this fails, nothing else in this directory is
    ...                worth running.
    Instrument Should Be Connected
    ${idn}=    Get Instrument Identity
    Log    Mainframe: ${idn}
    Should Contain Any    ${idn}    34970A    34972A

Error Queue Is Clean Before Survey
    [Documentation]    A pre-existing error would otherwise be blamed on
    ...                the first command this suite sends.
    Clear Instrument Status
    ${errors}=    Drain Instrument Error Queue
    Should Be Empty    ${errors}

Report Installed Cards
    [Documentation]    Identifies every populated slot and declares it
    ...                to the driver. An empty bench is reported, not
    ...                failed — that is a valid configuration.
    ${bench}=    Discover Bench
    Set Suite Variable    ${BENCH}    ${bench}
    ${count}=    Get Length    ${bench}
    Log    Populated slots: ${count}
    FOR    ${slot}    ${model}    IN    &{bench}
        Log    Slot ${slot}: ${model}
    END

Report Measurement Capability
    [Documentation]    Which slots can reach the internal DMM. A bench
    ...                of switch-only cards cannot measure anything, and
    ...                knowing that up front prevents a confusing failure
    ...                three suites later.
    ${slots}=    Get Slots With Card Type    ${BENCH}    @{MEASURING_CARDS}
    ${count}=    Get Length    ${slots}
    Log    Measuring slots: ${slots}
    IF    ${count} == 0
        Log    No card on this bench can route a channel to the DMM.    WARN
    END

Report Digital Capability
    [Documentation]    Whether a 34907A is present. Digital verification
    ...                is skipped without one.
    ${slots}=    Get Slots With Card Type    ${BENCH}    @{MULTIFUNCTION_CARDS}
    ${count}=    Get Length    ${slots}
    Log    Multifunction slots: ${slots}
    IF    ${count} == 0    Log    No 34907A: digital I/O verification will skip.

Survey Left No Errors Behind
    [Documentation]    Identification should not fault the instrument.
    ...                A non-empty queue here means one of the survey
    ...                commands was rejected.
    ${errors}=    Drain Instrument Error Queue
    Should Be Empty    ${errors}
