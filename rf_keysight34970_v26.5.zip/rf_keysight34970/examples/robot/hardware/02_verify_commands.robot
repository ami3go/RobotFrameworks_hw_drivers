*** Settings ***
Documentation     Verifies every driver capability the detected bench
...               can support.
...
...               Adapts to what is installed: tests requiring a card
...               the bench does not have are SKIPPED, not failed. A
...               skip means "this bench cannot answer that question";
...               a failure means the driver is wrong.
...
...               SAFETY. Read-only by default. Tests that drive
...               physical outputs are skipped unless you opt in:
...               | robot --variable ALLOW_OUTPUT_WRITES:yes ...
...               Only enable that with nothing consequential wired to
...               the 34907A. See the digital I/O section of the user
...               guide before you do.
...
...               Run with:
...               | robot --variable HOST:10.0.0.12 02_verify_commands.robot
Resource          ../resources/bench_discovery.resource
Library           Collections
Suite Setup       Prepare Bench
Suite Teardown    Release Bench
Test Setup        Clear Instrument Status

*** Variables ***
${HOST}                  127.0.0.1
${PORT}                  5025
${MODEL}                 34972A
${ALLOW_OUTPUT_WRITES}   no
${SCAN_SWEEPS}           3

*** Keywords ***
Prepare Bench
    Connect To Instrument    ${MODEL}    TCP    ${HOST}    port=${PORT}    alias=bench    timeout=30
    ${bench}=    Discover Bench
    Set Suite Variable    ${BENCH}    ${bench}
    ${mslot}=    Get First Measuring Slot    ${bench}
    Set Suite Variable    ${MEAS_SLOT}    ${mslot}
    ${dslot}=    Get First Multifunction Slot    ${bench}
    Set Suite Variable    ${DIO_SLOT}    ${dslot}
    Clear Instrument Status

Release Bench
    [Documentation]    Unconditional teardown. Both keywords are safe
    ...                when their subsystem was never used.
    Run Keyword And Ignore Error    Stop Monitoring
    Run Keyword And Ignore Error    Abort Scan
    Disconnect From Instrument

Require Measuring Card
    Skip If    '${MEAS_SLOT}' == '${EMPTY}'
    ...    No card on this bench can route a channel to the DMM.

Require Multifunction Card
    Skip If    '${DIO_SLOT}' == '${EMPTY}'    No 34907A on this bench.

Require Output Consent
    Skip If    '${ALLOW_OUTPUT_WRITES}' != 'yes'
    ...    Output writes not enabled. Re-run with --variable ALLOW_OUTPUT_WRITES:yes only if nothing consequential is wired.

First Measurable Channel
    ${channel}=    Channel On Slot    ${MEAS_SLOT}    1
    RETURN    ${channel}

*** Test Cases ***
# --- connection -----------------------------------------------------

Connection Lifecycle Commands
    Instrument Should Be Connected
    ${state}=    Get Connection State
    Should Be Equal    ${state}    CONNECTED
    ${idn}=    Get Instrument Identity
    Should Not Be Empty    ${idn}

Timeout Control
    Set Instrument Timeout    45
    ${idn}=    Query Scpi Command    *IDN?
    Should Not Be Empty    ${idn}
    [Teardown]    Set Instrument Timeout    30

Error Queue Reports A Bad Command
    [Documentation]    Confirms the instrument actually rejects bad
    ...                syntax and the driver surfaces it. If this passes
    ...                silently the error-checking path is not working.
    Run Keyword And Expect Error    *Instrument reported error*
    ...    Send Scpi Command    BOGUS:COMMAND
    ${errors}=    Drain Instrument Error Queue
    Log    Residual errors after deliberate fault: ${errors}

Session Survives An Instrument Error
    Run Keyword And Expect Error    *    Send Scpi Command    BOGUS:COMMAND
    Instrument Should Be Connected
    ${idn}=    Query Scpi Command    *IDN?
    Should Not Be Empty    ${idn}

Reconnect Restores The Session
    Reconnect To Instrument
    Instrument Should Be Connected

# --- measurement ----------------------------------------------------

Configure And Read DC Voltage
    [Setup]    Require Measuring Card
    ${ch}=    First Measurable Channel
    Configure Measurement    DCV    (@${ch})    range=10
    ${values}=    Read Measurement    (@${ch})
    Length Should Be    ${values}    1
    Log    DCV on ${ch}: ${values}[0]

One Shot Measure
    [Setup]    Require Measuring Card
    ${ch}=    First Measurable Channel
    ${value}=    Measure Value    DCV    ${ch}
    Log    One-shot DCV on ${ch}: ${value}

Measurement Details Carry Unit And Channel
    [Setup]    Require Measuring Card
    ${ch}=    First Measurable Channel
    Configure Measurement    DCV    (@${ch})
    ${rows}=    Read Measurement Details    (@${ch})
    Should Be Equal    ${rows}[0][unit]        V
    Should Be Equal As Integers    ${rows}[0][channel]    ${ch}
    Should Be Equal    ${rows}[0][function]    VOLT:DC
    Should Not Be True  ${rows}[0][overrange]

Resistance Measurement
    [Setup]    Require Measuring Card
    ${ch}=    First Measurable Channel
    Configure Measurement    Resistance    (@${ch})
    ${rows}=    Read Measurement Details    (@${ch})
    Should Be Equal    ${rows}[0][unit]    Ohm

Integration Time Control
    [Documentation]    NPLC >= 1 rejects mains hum. Verifies the SENS:
    ...                subsystem accepts the setting on real firmware.
    [Setup]    Require Measuring Card
    ${ch}=    First Measurable Channel
    Configure Measurement    DCV    (@${ch})    range=10    nplc=10
    ${values}=    Read Measurement    (@${ch})
    Length Should Be    ${values}    1

Configured Function Is Reported
    [Setup]    Require Measuring Card
    ${ch}=    First Measurable Channel
    Configure Measurement    4W Resistance    (@${ch})
    ${function}=    Get Configured Function    ${ch}
    Should Be Equal    ${function}    FRES
    [Teardown]    Clear Measurement Configuration

Measurement Statistics
    [Setup]    Require Measuring Card
    ${ch}=    First Measurable Channel
    Clear Measurement Configuration
    Configure Measurement    DCV    (@${ch})
    ${stats}=    Get Measurement Statistics
    Should Be Equal As Integers    ${stats}[count]    1
    Should Be Equal    ${stats}[unit]    V

# --- scanning -------------------------------------------------------

Scan Configured Channels
    [Setup]    Require Measuring Card
    ${ch}=    First Measurable Channel
    Clear Measurement Configuration
    Configure Measurement    DCV    (@${ch})
    Run Scan    (@${ch})    sweeps=${SCAN_SWEEPS}    timeout=60
    ${count}=    Get Scan Reading Count
    Should Be Equal As Integers    ${count}    ${SCAN_SWEEPS}

Scan Readings Carry Their Channel
    [Setup]    Require Measuring Card
    ${ch}=    First Measurable Channel
    Clear Measurement Configuration
    Configure Measurement    DCV    (@${ch})
    Run Scan    (@${ch})    sweeps=2    timeout=60
    ${rows}=    Get Scan Readings For Channel    ${ch}
    Length Should Be    ${rows}    2

Instrument Statistics After A Scan
    [Setup]    Require Measuring Card
    ${ch}=    First Measurable Channel
    Clear Measurement Configuration
    Clear Instrument Statistics
    Configure Measurement    DCV    (@${ch})
    Run Scan    (@${ch})    sweeps=${SCAN_SWEEPS}    timeout=60
    ${stats}=    Get Instrument Statistics
    Should Be Equal As Integers    ${stats}[count]    ${SCAN_SWEEPS}

Per Channel Instrument Statistics
    [Setup]    Require Measuring Card
    ${ch}=    First Measurable Channel
    Clear Measurement Configuration
    Clear Instrument Statistics
    Configure Measurement    DCV    (@${ch})
    Run Scan    (@${ch})    sweeps=${SCAN_SWEEPS}    timeout=60
    ${stats}=    Get Channel Statistics    ${ch}
    Should Be Equal As Integers    ${stats}[count]    ${SCAN_SWEEPS}

Monitor A Channel
    [Setup]    Require Measuring Card
    ${ch}=    First Measurable Channel
    Configure Measurement    DCV    (@${ch})
    Start Monitoring Channel    ${ch}
    ${live}=    Read Monitored Channel
    Log    Monitored value: ${live}
    [Teardown]    Stop Monitoring

Monitoring Is Refused During A Scan
    [Documentation]    Both claim the DMM. Verifies the driver's
    ...                interlock holds against real firmware timing.
    [Setup]    Require Measuring Card
    ${ch}=    First Measurable Channel
    Clear Measurement Configuration
    Configure Measurement    DCV    (@${ch})
    Configure Scan    (@${ch})    sweeps=INF
    Start Scan
    Run Keyword And Expect Error    *while a scan is running*
    ...    Start Monitoring Channel    ${ch}
    [Teardown]    Abort Scan

# --- temperature ----------------------------------------------------

Thermocouple Configuration Is Accepted
    [Documentation]    Verifies the SENS:TEMP:TRAN subsystem accepts the
    ...                driver's command sequencing. The reading itself
    ...                is only meaningful with a real sensor attached.
    [Setup]    Require Measuring Card
    ${ch}=    First Measurable Channel
    Configure Thermocouple    (@${ch})    K    open_detect=ON
    ${config}=    Get Temperature Configuration    ${ch}
    Should Not Be Empty    ${config}

Reference Junction Is Readable
    [Setup]    Require Measuring Card
    ${ch}=    First Measurable Channel
    Configure Thermocouple    (@${ch})    K
    ${ref}=    Read Reference Junction Temperature
    Log    Internal reference junction: ${ref} C

RTD Configuration Is Accepted
    [Setup]    Require Measuring Card
    ${ch}=    First Measurable Channel
    Configure RTD    (@${ch})    nominal=100    reference_ohms=100.02
    ${config}=    Get Temperature Configuration    ${ch}
    Should Not Be Empty    ${config}

Temperature Unit Selection
    [Setup]    Require Measuring Card
    ${ch}=    First Measurable Channel
    Configure Thermocouple    (@${ch})    K
    Set Temperature Unit    F
    ${rows}=    Read Temperature Details    (@${ch})
    # The driver reports SCPI unit mnemonics: degC / degF / K.
    Should Be Equal    ${rows}[0][unit]    degF
    [Teardown]    Run Keyword And Ignore Error    Set Temperature Unit    C

# --- digital I/O ----------------------------------------------------

Read Digital Port
    [Documentation]    Read-only; safe on any bench with a 34907A.
    [Setup]    Require Multifunction Card
    ${port}=    Channel On Slot    ${DIO_SLOT}    1
    ${value}=    Read Digital Port    ${port}
    Log    Port ${port} reads ${value}
    ${bits}=    Read Digital Port Bits    ${port}
    Length Should Be    ${bits}    8

Read Output State Without Driving
    [Setup]    Require Multifunction Card
    ${port}=    Channel On Slot    ${DIO_SLOT}    1
    ${state}=    Read Output State    (@${port})
    Log    Present output state: ${state}

Driven Record Starts Empty
    [Documentation]    The driver should claim nothing it has not done.
    [Setup]    Require Multifunction Card
    ${driven}=    Get Driven Outputs
    Log    Driver has driven: ${driven}

Totalizer Reads
    [Setup]    Require Multifunction Card
    ${tot}=    Channel On Slot    ${DIO_SLOT}    3
    Configure Totalizer    ${tot}    mode=READ
    ${count}=    Read Totalizer    ${tot}
    Log    Totalizer count: ${count}

Write Digital Port
    [Documentation]    DRIVES PHYSICAL LINES. Opt-in only.
    [Setup]    Run Keywords    Require Multifunction Card    AND    Require Output Consent
    ${port}=    Channel On Slot    ${DIO_SLOT}    1
    Write Digital Port    ${port}    0b00000000
    ${state}=    Read Output State    (@${port})
    Should Be Equal As Integers    ${state}[${port}]    0
    [Teardown]    Return Outputs To Safe State

Write Analog Output
    [Documentation]    DRIVES PHYSICAL LINES. Opt-in only. Writes 0 V,
    ...                which is the least disruptive value available —
    ...                but see the user guide: zero is not safe for all
    ...                wiring.
    [Setup]    Run Keywords    Require Multifunction Card    AND    Require Output Consent
    ${dac}=    Channel On Slot    ${DIO_SLOT}    4
    Write Analog Output    ${dac}    0
    ${setting}=    Read Analog Output Setting    ${dac}
    Should Be Equal As Numbers    ${setting}    0
    [Teardown]    Return Outputs To Safe State

# --- final -----------------------------------------------------------

Verification Left No Errors Behind
    [Documentation]    Every deliberate fault above was drained. Any
    ...                error remaining here was raised by a command the
    ...                driver believes is valid.
    ${errors}=    Drain Instrument Error Queue
    Should Be Empty    ${errors}
