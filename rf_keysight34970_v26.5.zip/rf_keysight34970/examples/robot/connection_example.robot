*** Settings ***
Documentation     Phase 1 example: connection lifecycle keywords against
...               a real 34970A/34972A on the LAN. Replace ${HOST} with
...               your instrument's IP address before running.
Library           keysight34970.Keysight34970

*** Variables ***
${HOST}           10.0.0.12
${PORT}           5025

*** Test Cases ***
Connect And Identify Instrument
    Connect To Instrument    34972A    TCP    ${HOST}    port=${PORT}    alias=daq1
    Instrument Should Be Connected
    ${idn}=    Get Instrument Identity
    Log    Connected to: ${idn}
    Disconnect From Instrument

Raw Scpi Escape Hatch
    Connect To Instrument    34972A    TCP    ${HOST}    port=${PORT}    alias=daq1
    Send Scpi Command    *CLS
    ${response}=    Query Scpi Command    *IDN?
    Should Not Be Empty    ${response}
    [Teardown]    Disconnect From Instrument

Reset And Timeout Control
    Connect To Instrument    34972A    TCP    ${HOST}    port=${PORT}    alias=daq1
    Set Instrument Timeout    2
    Reset Instrument
    Clear Instrument Status
    ${state}=    Get Connection State
    Should Be Equal    ${state}    CONNECTED
    [Teardown]    Disconnect From Instrument

Recover From A Bad Command
    Connect To Instrument    34972A    TCP    ${HOST}    port=${PORT}    alias=daq1
    Run Keyword And Expect Error    *Instrument reported error*
    ...    Send Scpi Command    BOGUS:COMMAND
    ${errors}=    Drain Instrument Error Queue
    Log    Remaining queued errors after failure: ${errors}
    Reconnect To Instrument
    Instrument Should Be Connected
    [Teardown]    Disconnect From Instrument
