*** Settings ***
Documentation     Phase 5 example: 34907A digital I/O, totalizer and
...               analogue outputs.
...
...               THIS SUITE DRIVES PHYSICAL OUTPUTS. On a real bench,
...               check what is wired to the module before running it.
...               Replace ${HOST} and the slot digit to match your bench.
Library           keysight34970.Keysight34970
Suite Setup       Open Bench
Suite Teardown    Return Outputs To Safe State
Test Setup        Clear Instrument Status

*** Variables ***
${HOST}           10.0.0.12
${PORT}           5025
${MODEL}          34972A
# 34907A channel layout within its slot: 01/02 ports, 03 totalizer,
# 04/05 analogue outputs.
${PORT_A}         101
${PORT_B}         102
${COUNTER}        103
${DAC_A}          104

*** Keywords ***
Open Bench
    Connect To Instrument    ${MODEL}    TCP    ${HOST}    port=${PORT}    alias=daq1
    Set Installed Card    1    34907A

Return Outputs To Safe State
    [Documentation]    An output left energised after a suite is a
    ...                hazard nothing downstream can attribute back to
    ...                the test that caused it. Driving to a known safe
    ...                state is the suite's responsibility, not the
    ...                instrument's.
    ${driven}=    Get Driven Outputs
    Log    Outputs driven by this suite: ${driven}
    Write Analog Output     ${DAC_A}    0
    Write Digital Port      ${PORT_A}    0
    Disconnect From Instrument

*** Test Cases ***
Read A Digital Port
    ${value}=    Read Digital Port    ${PORT_A}
    Should Be True    0 <= ${value} <= 255

Write And Read Back A Port
    Write Digital Port    ${PORT_A}    0b10100101
    ${bits}=    Read Digital Port Bits    ${PORT_A}
    Should Be Equal    ${bits}    10100101

Port Values Accept Binary Decimal And Hex
    Write Digital Port    ${PORT_A}    0xA5
    ${value}=    Read Digital Port    ${PORT_A}
    Should Be Equal As Integers    ${value}    165

Set A Single Bit Without Disturbing Others
    [Documentation]    Read-modify-write, not atomic — see the user
    ...                guide before using this on a shared port.
    Write Digital Port        ${PORT_A}    0b00000000
    Write Digital Port Bit    ${PORT_A}    3    ON
    ${bits}=    Read Digital Port Bits    ${PORT_A}
    Should Be Equal    ${bits}    00001000

Out Of Range Port Value Is Rejected
    Run Keyword And Expect Error    *8 bits*
    ...    Write Digital Port    ${PORT_A}    256

Addressing An Analogue Output As A Port Is Rejected
    [Documentation]    The failure this validation exists for: writing a
    ...                byte to channel 04 would drive an unintended
    ...                voltage.
    Run Keyword And Expect Error    *not a digital port*
    ...    Write Digital Port    ${DAC_A}    1

Non Destructive Totalizer Reads Preserve The Count
    Configure Totalizer    ${COUNTER}    mode=READ
    ${first}=     Read Totalizer    ${COUNTER}
    ${second}=    Read Totalizer    ${COUNTER}
    Should Be Equal As Integers    ${first}    ${second}

Read Reset Mode Consumes The Count
    [Documentation]    The 34907A's most dangerous setting. A second
    ...                read returns 0 — a plausible count, not an error.
    Configure Totalizer    ${COUNTER}    mode=READ_RESET
    ${details}=    Read Totalizer Details    ${COUNTER}
    Should Be True    ${details}[reset_by_read]
    ${second}=     Read Totalizer    ${COUNTER}
    Should Be Equal As Integers    ${second}    0

Clear The Totalizer
    Configure Totalizer    ${COUNTER}    mode=READ
    Clear Totalizer    ${COUNTER}
    ${count}=    Read Totalizer    ${COUNTER}
    Should Be Equal As Integers    ${count}    0

Drive And Read Back An Analogue Output
    Write Analog Output    ${DAC_A}    5.25
    ${setting}=    Read Analog Output Setting    ${DAC_A}
    Should Be Equal As Numbers    ${setting}    5.25

Out Of Range Voltage Is Rejected Not Clamped
    [Documentation]    Clamping would drive a different voltage than
    ...                asked for, which on an output is a hardware event.
    Run Keyword And Expect Error    *clamping silently*
    ...    Write Analog Output    ${DAC_A}    15

Driven Outputs Are Tracked For Teardown
    Write Analog Output    ${DAC_A}    1.5
    ${driven}=    Get Driven Outputs
    Should Not Be Empty    ${driven}
