
Driven Record And Actual State Answer Different Questions
    [Documentation]    Get Driven Outputs is a driver-side record of
    ...                what THIS driver wrote. Read Output State asks
    ...                the instrument. A raw SCPI write shows up in one
    ...                and not the other -- which is the whole reason
    ...                both exist.
    Write Digital Port    301    15
    Send Scpi Command     SOUR:DIG:DATA:BYTE 240,(@301)

    ${driven}=    Get Driven Outputs
    Should Contain    ${driven}[0]    15

    ${actual}=    Read Output State
    Should Be Equal As Integers    ${actual}[301]    240
    [Teardown]    Return Outputs To Safe State

Check Outputs This Driver Never Touched
    [Documentation]    The default covers only driven outputs. Deciding
    ...                whether it is safe to disconnect needs more.
    ${state}=    Read Output State    (@301,302)
    Length Should Be    ${state}    2

Safe State Leaves Undriven Outputs Alone
    [Documentation]    Zeroing an output the driver never set could
    ...                de-energise hardware it knows nothing about.
    Send Scpi Command     SOUR:DIG:DATA:BYTE 240,(@302)
    Write Digital Port    301    15
    Return Outputs To Safe State
    ${state}=    Read Output State    (@302)
    Should Be Equal As Integers    ${state}[302]    240

Teardown Returns Outputs To Zero
    [Documentation]    Zero is NOT universally safe -- an active-low
    ...                driver energises at zero. Use this only when you
    ...                know your wiring fails safe low.
    Write Digital Port     301    255
    Write Analog Output    304    5.0
    ${reset}=    Return Outputs To Safe State
    Length Should Be    ${reset}    2
    ${state}=    Read Output State
    Should Be Equal As Numbers    ${state}[304]    0
