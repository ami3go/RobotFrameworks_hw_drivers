*** Settings ***
Documentation     Phase 3 example: scanning. Replace ${HOST} and the
...               channel numbers to match your bench.
Library           keysight34970.Keysight34970
Suite Setup       Open Bench
Suite Teardown    Close Bench
Test Setup        Reset Test State
Test Teardown     Abort Scan

*** Variables ***
${HOST}           10.0.0.12
${PORT}           5025
${MODEL}          34972A

*** Keywords ***
Open Bench
    Connect To Instrument    ${MODEL}    TCP    ${HOST}    port=${PORT}    alias=daq1
    Set Installed Card    1    34901A

Close Bench
    Run Keyword And Ignore Error    Abort Scan
    Disconnect From Instrument

Reset Test State
    Clear Instrument Status
    Clear Measurement Configuration

*** Test Cases ***
Scan A Block Of Channels
    ${rows}=    Run Scan    (@101:105)    sweeps=3
    Length Should Be    ${rows}    15
    Should Be Equal As Integers    ${rows}[0][sweep]     1
    Should Be Equal As Integers    ${rows}[-1][sweep]    3

Slice Results By Channel Not Position
    [Documentation]    A multi-sweep scan interleaves channels.
    ...                Reproducing that arithmetic at the call site is
    ...                where off-by-one misattribution comes from.
    Run Scan    (@101,102)    sweeps=4
    ${values}=    Get Scan Readings For Channel    101
    Length Should Be    ${values}    4

Arm A Scan And Poll It
    [Documentation]    Arming and waiting are separate so a long scan
    ...                can be inspected while it runs.
    Configure Scan    (@101:104)    sweeps=2
    Start Scan
    ${count}=    Get Scan Reading Count
    Should Be True    ${count} >= 0
    Wait For Scan    timeout=10
    ${rows}=    Fetch Scan Readings
    Length Should Be    ${rows}    8

Interval Scanning With A Timer
    Configure Scan    (@101)    trigger_source=TIMER    interval=0.05    sweeps=3
    Start Scan
    Wait For Scan    timeout=10
    ${rows}=    Fetch Scan Readings
    Length Should Be    ${rows}    3

Timer Source Requires An Interval
    Run Keyword And Expect Error    *requires trigger_timer_s*
    ...    Configure Scan    (@101)    trigger_source=TIMER    sweeps=2

Waiting On An Infinite Scan Is Refused
    [Documentation]    Blocking forever on a misconfigured scan is
    ...                indistinguishable from broken hardware, so the
    ...                driver refuses rather than hanging.
    Configure Scan    (@101)    sweeps=INF
    Run Keyword And Expect Error    *never completes*    Wait For Scan    timeout=1

Waiting On An External Trigger Is Refused
    Configure Scan    (@101)    trigger_source=EXTERNAL    sweeps=5
    Run Keyword And Expect Error    *external stimulus*    Wait For Scan    timeout=1

Fetch With Clear Empties Instrument Memory
    Configure Scan    (@101,102)    sweeps=2
    Start Scan
    Wait For Scan    timeout=10
    Fetch Scan Readings    clear=True
    ${count}=    Get Scan Reading Count
    Should Be Equal As Integers    ${count}    0

Instrument Statistics Come From The Instrument
    [Documentation]    Distinct from Get Measurement Statistics, which
    ...                the driver computes over fetched values.
    Run Scan    (@101:105)    sweeps=2
    ${stats}=    Get Instrument Statistics
    Should Be Equal As Integers    ${stats}[count]    10
    Should Be True    ${stats}[minimum] <= ${stats}[average]

Monitor A Single Channel
    [Documentation]    Monitoring keeps only the newest value. Nothing
    ...                accumulates, so Fetch Scan Readings returns
    ...                nothing from a monitored channel.
    Configure Measurement       DCV    (@101)
    Start Monitoring Channel    101
    ${live}=    Read Monitored Channel
    Should Be True    ${live} > 0
    [Teardown]    Stop Monitoring

Monitoring Is Refused During A Scan
    [Documentation]    Both claim the internal DMM and the instrument
    ...                does not arbitrate between them.
    Configure Measurement    DCV    (@101,102)
    Configure Scan           (@101,102)    sweeps=INF
    Start Scan
    Run Keyword And Expect Error    *while a scan is running*
    ...    Start Monitoring Channel    101
    [Teardown]    Abort Scan

Per Channel Statistics Are Scoped
    Configure Measurement    DCV    (@101,102)
    Clear Instrument Statistics
    Run Scan    (@101,102)    sweeps=3    timeout=10
    ${ch101}=    Get Channel Statistics    101
    ${all}=      Get Instrument Statistics
    Should Be Equal As Integers    ${ch101}[count]    3
    Should Be Equal As Integers    ${all}[count]      6

Clear Statistics Before A Scan You Intend To Measure
    [Documentation]    Whether the instrument's statistics registers
    ...                survive a new scan is firmware-dependent and is
    ...                NOT verified here (the mock resets them). Clearing
    ...                explicitly makes the result well-defined either
    ...                way, which is why the keyword exists.
    Configure Measurement    DCV    (@101)
    Clear Instrument Statistics
    Run Scan    (@101)    sweeps=2    timeout=10
    ${stats}=    Get Instrument Statistics
    Should Be Equal As Integers    ${stats}[count]    2
