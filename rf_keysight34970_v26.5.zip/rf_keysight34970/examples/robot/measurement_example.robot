*** Settings ***
Documentation     Phase 2 example: measurement keywords. Replace ${HOST}
...               and the channel numbers with values matching your
...               bench before running against real hardware.
Library           keysight34970.Keysight34970
Suite Setup       Open Bench
Suite Teardown    Disconnect From Instrument
Test Setup        Reset Test State

*** Variables ***
${HOST}           10.0.0.12
${PORT}           5025
${MODEL}          34972A

*** Keywords ***
Reset Test State
    [Documentation]    Configured channels accumulate across a suite
    ...                because one session serves every test case.
    ...                Clearing keeps each test independent.
    Clear Instrument Status
    Clear Measurement Configuration

Open Bench
    Connect To Instrument    ${MODEL}    TCP    ${HOST}    port=${PORT}    alias=daq1
    # Declaring the installed card lets the driver reject invalid
    # channels and unsupported functions before they reach the
    # instrument. Without it, validation is relaxed.
    Set Installed Card    1    34901A

*** Test Cases ***
Measure A Single Channel
    ${volts}=    Measure Value    DCV    101
    Should Be True    isinstance($volts, float)

Measure Several Channels At Once
    ${values}=    Measure    DCV    (@101,102)
    Length Should Be    ${values}    2

Configure Once Then Read Repeatedly
    [Documentation]    Preferred over Measure when you read the same
    ...                channels repeatedly: configuration persists, so
    ...                each read is one round trip instead of two.
    Configure Measurement    DCV    (@101:103)    range=10
    ${first}=     Read Measurement
    ${second}=    Read Measurement
    Length Should Be    ${first}     3
    Length Should Be    ${second}    3

Read A Subset Of Configured Channels
    Configure Measurement    DCV    (@101:103)
    ${values}=    Read Measurement    (@102)
    Length Should Be    ${values}    1

Configured Function Is Reported
    Configure Measurement    4W Resistance    (@101)
    ${function}=    Get Configured Function    101
    Should Be Equal    ${function}    FRES

Reading An Unconfigured Channel Fails
    [Documentation]    The driver refuses rather than silently reading
    ...                whatever the instrument last had configured.
    Configure Measurement    DCV    (@101)
    Run Keyword And Expect Error    *have not been configured*
    ...    Read Measurement    (@105)

Current Requires A Current Channel
    [Documentation]    On a 34901A only channels 21-22 can measure
    ...                current; the driver catches this before it
    ...                reaches the instrument.
    Run Keyword And Expect Error    *requires a dedicated current channel*
    ...    Configure Measurement    DCI    (@101)

Resolution Requires An Explicit Range
    Run Keyword And Expect Error    *resolution cannot be set*
    ...    Configure Measurement    DCV    (@101)    resolution=0.001

Tune Integration Time For Accuracy
    [Documentation]    NPLC >= 1 rejects mains hum; below 1 does not.
    ...                Higher is slower and quieter.
    Configure Measurement    DCV    (@101)    range=10    nplc=10
    ${value}=    Read Measurement    (@101)
    Length Should Be    ${value}    1

Detect An Over-Range Reading
    [Documentation]    Read Measurement returns the raw 9.9e37 sentinel,
    ...                which passes naive assertions. The details form
    ...                flags it properly.
    # Slot 2 has no card declared, so validation is relaxed there.
    Configure Measurement    DCV    (@299)
    ${rows}=    Read Measurement Details
    Should Be True    ${rows}[0][overrange]

Statistics Across A Channel Block
    Configure Measurement    DCV    (@101:105)
    ${stats}=    Get Measurement Statistics
    Should Be Equal As Integers    ${stats}[count]    5
    Should Be True    ${stats}[maximum] >= ${stats}[minimum]

Assert A Reading Is In Range
    Measurement Should Be Within    DCV    101    1.0    1.1

Four Wire Consumes The Paired Channel
    ${paired}=    Get Four Wire Pair    101
    Should Be Equal    ${paired}    111

Four Wire Conflict Is Rejected
    [Documentation]    Configuring 4-wire on 101 needs 111 free.
    Configure Measurement    DCV    (@111)
    Run Keyword And Expect Error    *already configured*
    ...    Configure Measurement    4W Resistance    (@101)
