"""
Minimal mock SCPI-over-TCP instrument, used only for local integration
smoke testing of the driver's TCP transport + connection framework.
Not part of the shipped package; not a substitute for real-hardware
verification (see Gate 4 acceptance criteria: "Examples verified on
supported hardware where applicable").
"""

from __future__ import annotations

import socket
import threading

RESPONSES = {
    "*IDN?": "Keysight Technologies,34972A,MY58012345,1.13-1.09-1.03",
}


class MockScpiServer:
    """Note: `_error_queue` is only safe here because the mock is
    single-connection / single-threaded per test run; it is not a
    model for real instrument error-queue semantics under concurrent
    access."""

    def __init__(self, host: str = "127.0.0.1", port: int = 0) -> None:
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._sock.bind((host, port))
        self._sock.listen(1)
        self.host, self.port = self._sock.getsockname()
        self._thread = threading.Thread(target=self._serve, daemon=True)
        self._stop = False
        self._error_queue: list[str] = []
        self._scan_list: list[str] = []
        self._configured: dict[str, str] = {}
        # Deterministic per-channel values so tests can assert exact
        # readings. Channel 199 returns the over-range sentinel.
        self._values: dict[str, float] = {}
        # Default bench layout the discovery suite will find. Override
        # per test to exercise other configurations.
        self.slot_cards = {"1": "34901A", "2": "34908A", "3": "34907A"}
        self._monitor = None
        self._monitor_on = False
        self._dig_ports: dict[str, int] = {}
        self._totalizer: dict[str, int] = {}
        self._tot_mode: dict[str, str] = {}
        self._dac: dict[str, float] = {}
        self._temp_units: dict[str, str] = {}
        # Scan state with genuine memory semantics: a scan that ignores
        # memory cannot exercise partial-fetch or overflow paths.
        self._trigger_count: int | str = 1
        self._trigger_source = "IMM"
        self._fmt_chan = True
        self._fmt_time = True
        self._memory: list[str] = []
        self._armed = False

    def start(self) -> None:
        self._thread.start()

    def stop(self) -> None:
        self._stop = True
        try:
            self._sock.close()
        except OSError:
            pass

    def _serve(self) -> None:
        while not self._stop:
            try:
                conn, _ = self._sock.accept()
            except OSError:
                return
            with conn:
                buf = b""
                while True:
                    chunk = conn.recv(4096)
                    if not chunk:
                        break
                    buf += chunk
                    while b"\n" in buf:
                        line, buf = buf.split(b"\n", 1)
                        command = line.decode("ascii").strip()

                        if command == "*CLS":
                            self._error_queue.clear()
                            continue
                        if command.upper().startswith("SYST:TEMP?"):
                            conn.sendall(b"+2.35000000E+01\n")
                            continue
                        if command.upper().startswith("UNIT:TEMP"):
                            for ch in _channels_of(command):
                                self._temp_units[ch] = command.split()[1].split(",")[0]
                            continue
                        if command.upper().startswith("SENS:TEMP:TRAN"):
                            continue
                        if command.upper().startswith("CONF:TEMP"):
                            for ch in _channels_of(command):
                                self._configured[ch] = "TEMP"
                            continue
                        if command.upper().startswith("CONF:"):
                            self._handle_conf(command)
                            continue
                        if command.upper().startswith("ROUT:MON:STAT"):
                            self._monitor_on = command.upper().endswith("ON")
                            continue
                        if command.upper().startswith("ROUT:MON:DATA?"):
                            ch = self._monitor or "101"
                            conn.sendall(f"{_mock_value(ch):+.8E}\n".encode())
                            continue
                        if command.upper().startswith("ROUT:MON"):
                            chans = _channels_of(command)
                            self._monitor = chans[0] if chans else None
                            continue
                        if command.upper().startswith("SOUR:DIG:DATA:BYTE"):
                            self._handle_dig_write(command)
                            continue
                        if command.upper().startswith("SENS:DIG:DATA:BYTE?"):
                            chans = _channels_of(command)
                            key = chans[0] if chans else "101"
                            conn.sendall(
                                f"{self._dig_ports.get(key, 0)}\n".encode("ascii")
                            )
                            continue
                        if command.upper().startswith("SENS:TOT:CLE"):
                            for c in _channels_of(command):
                                self._totalizer[c] = 0
                            continue
                        if command.upper().startswith("SENS:TOT:TYPE"):
                            for c in _channels_of(command):
                                self._tot_mode[c] = (
                                    "RRES" if "RRES" in command.upper() else "READ"
                                )
                            continue
                        if command.upper().startswith("SENS:TOT:DATA?"):
                            chans = _channels_of(command)
                            key = chans[0] if chans else "103"
                            count = self._totalizer.get(key, 1234)
                            if self._tot_mode.get(key) == "RRES":
                                self._totalizer[key] = 0
                            conn.sendall(f"{count}\n".encode("ascii"))
                            continue
                        if command.upper().startswith("SENS:TOT:"):
                            continue
                        if command.upper().startswith("SOUR:VOLT?"):
                            chans = _channels_of(command)
                            key = chans[0] if chans else "104"
                            conn.sendall(
                                f"{self._dac.get(key, 0.0):+.6E}\n".encode("ascii")
                            )
                            continue
                        if command.upper().startswith("SOUR:VOLT"):
                            self._handle_dac_write(command)
                            continue
                        if command.upper().startswith("CALC:AVER:CLE"):
                            continue
                        if command.upper().startswith("ROUT:SCAN"):
                            self._scan_list = _channels_of(command)
                            continue
                        if command.upper().startswith("TRIG:COUN"):
                            arg = command.split(None, 1)[1].strip().upper()
                            self._trigger_count = (
                                "INF" if arg.startswith("INF") else int(float(arg))
                            )
                            continue
                        if command.upper().startswith("TRIG:SOUR"):
                            self._trigger_source = command.split(None, 1)[1].strip().upper()
                            continue
                        if command.upper().startswith("TRIG:TIM"):
                            continue
                        if command.upper().startswith("ROUT:CHAN:DELAY"):
                            continue
                        if command.upper().startswith("FORM:READ:CHAN"):
                            self._fmt_chan = "ON" in command.upper()
                            continue
                        if command.upper().startswith("FORM:READ:TIME"):
                            self._fmt_time = "ON" in command.upper()
                            continue
                        if command.upper() == "INIT":
                            self._run_scan()
                            continue
                        if command.upper() == "ABOR":
                            self._armed = False
                            continue
                        if command.upper() == "BOGUS:COMMAND":
                            self._error_queue.append('-113,"Undefined header"')
                            continue

                        if command.upper().startswith("MEAS:"):
                            self._handle_conf(command.split("?")[0])
                            reply = self._readings_for(_channels_of(command))
                            conn.sendall((reply + "\n").encode("ascii"))
                            continue
                        if command.upper().rstrip("?") == "READ":
                            if not self._scan_list:
                                self._error_queue.append(
                                    '-221,"Settings conflict; no scan list"'
                                )
                                conn.sendall(b'-221\n')
                                continue
                            reply = self._readings_for(self._scan_list)
                            conn.sendall((reply + "\n").encode("ascii"))
                            continue

                        if command.upper().rstrip("?") == "DATA:POIN":
                            conn.sendall(f"{len(self._memory)}\n".encode("ascii"))
                            continue
                        if command.upper().rstrip("?") in {"FETC", "R"}:
                            if not self._memory:
                                self._error_queue.append(
                                    '-230,"Data corrupt or stale"'
                                )
                                conn.sendall(b'\n')
                                continue
                            payload = ",".join(self._memory)
                            if command.upper().rstrip("?") == "R":
                                self._memory.clear()
                            conn.sendall((payload + "\n").encode("ascii"))
                            continue
                        if command.upper().startswith("CALC:AVER:"):
                            conn.sendall(self._calc_reply(command).encode("ascii"))
                            continue

                        if command.upper().startswith("SYST:CTYP?"):
                            # Slot contents. Configurable per test run so
                            # the discovery suite can be exercised against
                            # different bench layouts.
                            slot = command.split("?", 1)[1].strip()
                            model = self.slot_cards.get(slot)
                            if model:
                                reply = (
                                    f"Agilent Technologies,{model},"
                                    f"MY5500{slot},1.0"
                                )
                            else:
                                reply = "0,No Module,0,0"
                            conn.sendall((reply + "\n").encode("ascii"))
                            continue

                        if command == "SYST:ERR?":
                            if self._error_queue:
                                reply = self._error_queue.pop(0)
                            else:
                                reply = '0,"No error"'
                            conn.sendall((reply + "\n").encode("ascii"))
                        elif command.endswith("?"):
                            reply = RESPONSES.get(command, '0,"No error"')
                            conn.sendall((reply + "\n").encode("ascii"))
                        # other non-query commands (e.g. *RST) get no reply


def _channels_of(command: str) -> list[str]:
    """Extract channel numbers from a trailing (@...) channel list."""
    if "(@" not in command:
        return []
    inner = command.split("(@", 1)[1].split(")", 1)[0]
    return [c.strip() for c in inner.split(",") if c.strip()]


def _temp_value(channel: str, unit: str) -> float:
    """Plausible room-temperature-ish reading in the requested unit."""
    base_c = 20.0 + int(channel) % 10
    if unit.upper().startswith("F"):
        return base_c * 9.0 / 5.0 + 32.0
    if unit.upper().startswith("K"):
        return base_c + 273.15
    return base_c


def _mock_value(channel: str) -> float:
    """Deterministic pseudo-reading so tests can assert exact values."""
    if channel.endswith("99"):  # any slot: channel 99 is the over-range probe
        return 9.9e37  # over-range sentinel
    return round(int(channel) / 100.0, 4)


def _install_helpers():
    def _handle_conf(self, command: str) -> None:
        upper = command.upper()
        head = upper.split(None, 1)[0]
        function = head.split(":", 1)[1] if ":" in head else ""
        for channel in _channels_of(command):
            self._configured[channel] = function

    def _readings_for(self, channels: list[str]) -> str:
        if not channels:
            return "+0.00000000E+00"
        out = []
        for c in channels:
            if self._configured.get(c) == "TEMP":
                out.append(f"{_temp_value(c, self._temp_units.get(c, 'C')):+.8E}")
            else:
                out.append(f"{_mock_value(c):+.8E}")
        return ",".join(out)

    MockScpiServer._handle_conf = _handle_conf
    MockScpiServer._readings_for = _readings_for


_install_helpers()


def _install_scan_helpers():
    def _run_scan(self) -> None:
        """Execute the configured scan synchronously into memory.

        Synchronous is a deliberate simplification: it means a mock scan
        is always complete by the time INIT returns, so tests exercise
        the fetch/parse path deterministically. Timing-dependent
        behaviour (partial fetch mid-scan) is tested by manipulating
        memory directly rather than by racing a thread.
        """

        sweeps = 1 if self._trigger_count == "INF" else int(self._trigger_count)
        sweeps = min(sweeps, 500)  # bound the mock; not an instrument limit
        self._memory.clear()
        for sweep in range(sweeps):
            for channel in self._scan_list:
                self._memory.append(
                    self._format_reading(channel, sweep)
                )
        self._armed = True

    def _format_reading(self, channel: str, sweep: int) -> str:
        value = _mock_value(channel)
        parts = [f"{value:+.8E}"]
        if self._fmt_time:
            second = 15.0 + sweep * 0.25
            parts += ["2026", "07", "22", "14", "30", f"{second:06.3f}"]
        if self._fmt_chan:
            parts.append(channel)
        return ",".join(parts)

    def _calc_reply(self, command: str) -> str:
        # A trailing (@nnn) restricts statistics to one channel, which
        # is how the instrument's per-channel registers behave.
        wanted = _channels_of(command)
        entries = self._memory
        if wanted:
            target = wanted[0]
            entries = [e for e in self._memory if e.split(",")[-1].strip() == target]

        values = [float(entry.split(",")[0]) for entry in entries] or [0.0]
        upper = command.upper()
        if "MIN" in upper:
            result = min(values)
        elif "MAX" in upper:
            result = max(values)
        elif "COUN" in upper:
            return f"{len(values)}\n"
        else:
            result = sum(values) / len(values)
        return f"{result:+.8E}\n"

    MockScpiServer._run_scan = _run_scan
    MockScpiServer._format_reading = _format_reading
    MockScpiServer._calc_reply = _calc_reply


_install_scan_helpers()


def _install_digital_helpers():
    def _handle_dig_write(self, command: str) -> None:
        payload = command.split(None, 1)[1] if " " in command else ""
        value_text = payload.split(",")[0].strip()
        try:
            value = int(float(value_text))
        except ValueError:
            self._error_queue.append('-224,"Illegal parameter value"')
            return
        for c in _channels_of(command):
            self._dig_ports[c] = value & 0xFF

    def _handle_dac_write(self, command: str) -> None:
        payload = command.split(None, 1)[1] if " " in command else ""
        value_text = payload.split(",")[0].strip()
        try:
            volts = float(value_text)
        except ValueError:
            self._error_queue.append('-224,"Illegal parameter value"')
            return
        if abs(volts) > 12.0:
            self._error_queue.append('-222,"Data out of range"')
            return
        for c in _channels_of(command):
            self._dac[c] = volts

    MockScpiServer._handle_dig_write = _handle_dig_write
    MockScpiServer._handle_dac_write = _handle_dac_write


_install_digital_helpers()
