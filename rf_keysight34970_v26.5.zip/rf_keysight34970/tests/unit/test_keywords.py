"""
Unit tests for the Robot Framework keyword layer.

These drive the keyword methods directly (as Robot Framework would)
against the in-repo mock SCPI server, so the keyword-level argument
handling, error messages, and state guards are covered independently
of the .robot example suite.
"""

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from mock_instrument import MockScpiServer  # noqa: E402

from keysight34970.library import Keysight34970  # noqa: E402


@pytest.fixture
def instrument():
    server = MockScpiServer()
    server.start()
    lib = Keysight34970()
    yield lib, server
    try:
        lib.disconnect_from_instrument()
    except Exception:
        pass
    server.stop()


def _connect(lib, server, **kwargs):
    lib.connect_to_instrument(
        "34972A", "TCP", server.host, port=server.port, **kwargs
    )


# -- happy paths ----------------------------------------------------


def test_connect_and_identity(instrument):
    lib, server = instrument
    _connect(lib, server)

    lib.instrument_should_be_connected()
    assert "34972A" in lib.get_instrument_identity()
    assert lib.get_connection_state() == "CONNECTED"


def test_disconnect_sets_state_and_is_idempotent(instrument):
    lib, server = instrument
    _connect(lib, server)

    lib.disconnect_from_instrument()
    assert lib.get_connection_state() == "IDLE"

    # Second call must not raise.
    lib.disconnect_from_instrument()
    assert lib.get_connection_state() == "IDLE"


def test_reset_clear_and_timeout_keywords(instrument):
    lib, server = instrument
    _connect(lib, server)

    lib.reset_instrument()
    lib.clear_instrument_status()
    lib.set_instrument_timeout(2.0)

    assert lib.get_connection_state() == "CONNECTED"


def test_query_scpi_command_returns_response(instrument):
    lib, server = instrument
    _connect(lib, server)

    assert "Keysight" in lib.query_scpi_command("*IDN?")


def test_drain_error_queue_returns_formatted_strings(instrument):
    lib, server = instrument
    _connect(lib, server)

    with pytest.raises(Exception):
        lib.send_scpi_command("BOGUS:COMMAND")

    # The failing command already drained its own error via the check;
    # a subsequent drain should be clean and return a list.
    errors = lib.drain_instrument_error_queue()
    assert isinstance(errors, list)


# -- guard / failure paths ------------------------------------------


def test_keywords_fail_clearly_when_not_connected():
    lib = Keysight34970()

    for call in (
        lib.get_instrument_identity,
        lib.reset_instrument,
        lib.clear_instrument_status,
        lib.reconnect_to_instrument,
        lib.drain_instrument_error_queue,
    ):
        with pytest.raises(AssertionError, match="No instrument connection"):
            call()


def test_instrument_should_be_connected_fails_when_not_connected():
    lib = Keysight34970()
    with pytest.raises(AssertionError, match="not connected"):
        lib.instrument_should_be_connected()


def test_get_connection_state_before_any_connect_is_idle():
    lib = Keysight34970()
    assert lib.get_connection_state() == "IDLE"


def test_send_scpi_command_requires_connection():
    lib = Keysight34970()
    with pytest.raises(AssertionError, match="No instrument connection"):
        lib.send_scpi_command("*CLS")


def test_bad_scpi_command_surfaces_instrument_error(instrument):
    lib, server = instrument
    _connect(lib, server)

    with pytest.raises(Exception, match="Instrument reported error"):
        lib.send_scpi_command("BOGUS:COMMAND")


def test_model_mismatch_is_rejected_by_keyword(instrument):
    lib, server = instrument
    # Mock reports 34972A; ask for 34970A with verification on.
    with pytest.raises(Exception, match="does not match"):
        lib.connect_to_instrument(
            "34970A", "TCP", server.host, port=server.port
        )


def test_verify_model_false_allows_mismatch_via_keyword(instrument):
    lib, server = instrument
    lib.connect_to_instrument(
        "34970A", "TCP", server.host, port=server.port, verify_model=False
    )
    assert lib.get_connection_state() == "CONNECTED"


def test_reconnect_keyword_restores_connection(instrument):
    lib, server = instrument
    _connect(lib, server)

    lib.reconnect_to_instrument()

    lib.instrument_should_be_connected()
    assert "34972A" in lib.get_instrument_identity()


def test_invalid_transport_string_rejected(instrument):
    lib, server = instrument
    with pytest.raises(ValueError):
        lib.connect_to_instrument("34972A", "CARRIER_PIGEON", server.host)


def test_invalid_model_string_rejected(instrument):
    lib, server = instrument
    with pytest.raises(ValueError):
        lib.connect_to_instrument("34999X", "TCP", server.host)
