from datetime import datetime, timezone

import pytest

from keysight34970.exceptions import CommandError, ConfigurationError
from keysight34970.measurement.channels import ChannelId, ChannelList
from keysight34970.measurement.models import (
    OVERRANGE_SENTINEL,
    AutoRange,
    Measurement,
    MeasurementConfig,
    MeasurementFunction,
    MeasurementStatistics,
    Unit,
)
from keysight34970.measurement.parsing import parse_reading, parse_readings


# -- functions and units --------------------------------------------


@pytest.mark.parametrize(
    "function,unit",
    [
        (MeasurementFunction.DC_VOLTAGE, Unit.VOLT),
        (MeasurementFunction.AC_CURRENT, Unit.AMPERE),
        (MeasurementFunction.RESISTANCE_4W, Unit.OHM),
        (MeasurementFunction.FREQUENCY, Unit.HERTZ),
        (MeasurementFunction.PERIOD, Unit.SECOND),
        (MeasurementFunction.TEMPERATURE, Unit.CELSIUS),
        (MeasurementFunction.DIODE, Unit.VOLT),
    ],
)
def test_function_units(function, unit):
    assert function.unit is unit


def test_every_function_has_a_unit():
    for function in MeasurementFunction:
        assert isinstance(function.unit, Unit)


def test_scpi_mnemonics_are_the_enum_values():
    assert MeasurementFunction.DC_VOLTAGE.value == "VOLT:DC"
    assert MeasurementFunction.RESISTANCE_4W.value == "FRES"


def test_current_functions_flagged():
    assert MeasurementFunction.DC_CURRENT.requires_current_channel
    assert MeasurementFunction.AC_CURRENT.requires_current_channel
    assert not MeasurementFunction.DC_VOLTAGE.requires_current_channel


def test_four_wire_flagged():
    assert MeasurementFunction.RESISTANCE_4W.requires_four_wire
    assert not MeasurementFunction.RESISTANCE_2W.requires_four_wire


# -- MeasurementConfig ----------------------------------------------


def test_default_config_is_fully_auto():
    config = MeasurementConfig(MeasurementFunction.DC_VOLTAGE)
    assert config.range is AutoRange.AUTO
    assert config.resolution is AutoRange.AUTO
    assert config.scpi_arguments() == "AUTO,DEF"


def test_explicit_range_and_resolution():
    config = MeasurementConfig(MeasurementFunction.DC_VOLTAGE, range=10, resolution=0.001)
    assert config.scpi_arguments() == "10,0.001"


def test_explicit_range_with_auto_resolution():
    config = MeasurementConfig(MeasurementFunction.DC_VOLTAGE, range=10)
    assert config.scpi_arguments() == "10,DEF"


def test_resolution_without_range_is_rejected():
    """The instrument cannot take a resolution without a range; failing
    is better than silently dropping the resolution."""
    config = MeasurementConfig(MeasurementFunction.DC_VOLTAGE, resolution=0.001)
    with pytest.raises(ConfigurationError, match="resolution cannot be set"):
        config.scpi_arguments()


@pytest.mark.parametrize("bad", [0, -1, -0.5])
def test_non_positive_range_rejected(bad):
    with pytest.raises(ConfigurationError, match="range must be positive"):
        MeasurementConfig(MeasurementFunction.DC_VOLTAGE, range=bad)


@pytest.mark.parametrize("bad", [0, -0.001])
def test_non_positive_resolution_rejected(bad):
    with pytest.raises(ConfigurationError, match="resolution must be positive"):
        MeasurementConfig(MeasurementFunction.DC_VOLTAGE, resolution=bad)


def test_small_values_avoid_python_scientific_notation():
    """1e-05 would be rejected by some SCPI parsers; render plainly."""
    config = MeasurementConfig(
        MeasurementFunction.DC_VOLTAGE, range=0.1, resolution=0.00001
    )
    assert config.scpi_arguments() == "0.1,1e-05" or "0.00001" in config.scpi_arguments()


def test_config_unit_follows_function():
    assert MeasurementConfig(MeasurementFunction.RESISTANCE_2W).unit is Unit.OHM


def test_config_is_immutable():
    config = MeasurementConfig(MeasurementFunction.DC_VOLTAGE)
    with pytest.raises(Exception):
        config.range = 10  # type: ignore[misc]


# -- Measurement ----------------------------------------------------


def test_measurement_basic_fields():
    m = Measurement(1.5, Unit.VOLT, MeasurementFunction.DC_VOLTAGE, ChannelId(1, 1))
    assert m.value == 1.5
    assert not m.is_overrange
    assert "1.5 V" in str(m)
    assert "@101" in str(m)


def test_measurement_without_channel_omits_channel_in_str():
    m = Measurement(1.5, Unit.VOLT, MeasurementFunction.DC_VOLTAGE)
    assert "@" not in str(m)


def test_overrange_detection():
    m = Measurement(
        OVERRANGE_SENTINEL, Unit.VOLT, MeasurementFunction.DC_VOLTAGE
    )
    assert m.is_overrange
    assert "OVERRANGE" in str(m)


def test_negative_overrange_detected():
    m = Measurement(-OVERRANGE_SENTINEL, Unit.VOLT, MeasurementFunction.DC_VOLTAGE)
    assert m.is_overrange


def test_normal_large_value_is_not_overrange():
    m = Measurement(1000.0, Unit.VOLT, MeasurementFunction.DC_VOLTAGE)
    assert not m.is_overrange


def test_timestamp_defaults_to_now_utc():
    m = Measurement(1.0, Unit.VOLT, MeasurementFunction.DC_VOLTAGE)
    assert m.timestamp.tzinfo is timezone.utc
    assert (datetime.now(timezone.utc) - m.timestamp).total_seconds() < 5


# -- parsing --------------------------------------------------------


def test_parse_single_reading():
    assert parse_reading("+1.04250000E+00") == pytest.approx(1.0425)


def test_parse_reading_strips_whitespace():
    assert parse_reading("  -2.5E-03  ") == pytest.approx(-0.0025)


def test_parse_empty_reading_raises():
    with pytest.raises(CommandError, match="empty reading"):
        parse_reading("   ")


def test_parse_garbage_reading_raises_command_error():
    with pytest.raises(CommandError, match="Could not parse"):
        parse_reading("NOT_A_NUMBER")


def test_parse_multiple_readings():
    result = parse_readings(
        "+1.0E+00,+2.0E+00,+3.0E+00", MeasurementFunction.DC_VOLTAGE
    )
    assert [m.value for m in result] == [1.0, 2.0, 3.0]
    assert all(m.unit is Unit.VOLT for m in result)


def test_parse_attaches_channels_in_order():
    channels = ChannelList.parse("(@101,102)")
    result = parse_readings("+1.0E+00,+2.0E+00", MeasurementFunction.DC_VOLTAGE, channels)
    assert [m.channel.address for m in result] == [101, 102]


def test_channel_count_mismatch_refuses_to_guess():
    """Misattributing readings to channels is worse than failing."""
    channels = ChannelList.parse("(@101,102,103)")
    with pytest.raises(CommandError, match="Reading count mismatch"):
        parse_readings("+1.0E+00,+2.0E+00", MeasurementFunction.DC_VOLTAGE, channels)


def test_parse_empty_response_raises():
    with pytest.raises(CommandError, match="empty reading response"):
        parse_readings("", MeasurementFunction.DC_VOLTAGE)


def test_parse_preserves_raw_response():
    raw = "+1.0E+00,+2.0E+00"
    result = parse_readings(raw, MeasurementFunction.DC_VOLTAGE)
    assert all(m.raw == raw for m in result)


def test_parse_detects_overrange_reading():
    result = parse_readings("+9.90000000E+37", MeasurementFunction.DC_VOLTAGE)
    assert result[0].is_overrange


def test_unit_override_for_temperature():
    result = parse_readings(
        "+2.5E+01", MeasurementFunction.TEMPERATURE, unit=Unit.FAHRENHEIT
    )
    assert result[0].unit is Unit.FAHRENHEIT


def test_readings_share_one_timestamp():
    result = parse_readings("+1.0E+00,+2.0E+00", MeasurementFunction.DC_VOLTAGE)
    assert result[0].timestamp == result[1].timestamp


# -- statistics -----------------------------------------------------


def _m(value: float) -> Measurement:
    return Measurement(value, Unit.VOLT, MeasurementFunction.DC_VOLTAGE)


def test_statistics_basic():
    stats = MeasurementStatistics.from_measurements([_m(1.0), _m(2.0), _m(6.0)])
    assert stats.count == 3
    assert stats.minimum == 1.0
    assert stats.maximum == 6.0
    assert stats.average == pytest.approx(3.0)
    assert stats.span == pytest.approx(5.0)
    assert stats.function is MeasurementFunction.DC_VOLTAGE


def test_statistics_from_empty_set_rejected():
    with pytest.raises(ConfigurationError, match="empty measurement set"):
        MeasurementStatistics.from_measurements([])


def test_statistics_rejects_mixed_units():
    mixed = [
        _m(1.0),
        Measurement(2.0, Unit.OHM, MeasurementFunction.RESISTANCE_2W),
    ]
    with pytest.raises(ConfigurationError, match="mixed units"):
        MeasurementStatistics.from_measurements(mixed)


def test_statistics_rejects_overrange_readings():
    """Averaging in 9.9e37 would produce a plausible-looking lie."""
    readings = [_m(1.0), _m(OVERRANGE_SENTINEL)]
    with pytest.raises(ConfigurationError, match="over-range"):
        MeasurementStatistics.from_measurements(readings)


def test_statistics_function_is_none_when_mixed():
    readings = [
        _m(1.0),
        Measurement(2.0, Unit.VOLT, MeasurementFunction.AC_VOLTAGE),
    ]
    stats = MeasurementStatistics.from_measurements(readings)
    assert stats.function is None
