import pytest

from keysight34970.config import ConnectionConfig, InstrumentModel, TransportKind
from keysight34970.connection import Connection, ConnectionState
from keysight34970.exceptions import CommandError, StateError, TransportError

from .fakes import FakeTransport


def make_config(**overrides):
    defaults = dict(
        transport=TransportKind.TCP_SOCKET,
        model=InstrumentModel.DAQ_34972A,
        host="10.0.0.5",
        port=5025,
        identify_on_connect=True,
        clear_on_connect=True,
    )
    defaults.update(overrides)
    return ConnectionConfig(**defaults)


def test_connect_success_moves_to_connected_and_parses_identity():
    fake = FakeTransport(
        responses={
            "*IDN?": "Keysight,34972A,MY001,1.0",
            "SYST:ERR?": '0,"No error"',
        }
    )
    conn = Connection(make_config(), transport=fake)

    conn.connect()

    assert conn.state == ConnectionState.CONNECTED
    assert conn.identity is not None
    assert conn.identity.model == "34972A"
    assert "*CLS" in fake.sent
    assert "*IDN?" in fake.sent


def test_connect_failure_moves_to_error_state():
    fake = FakeTransport()
    fake.fail_open = True
    conn = Connection(make_config(), transport=fake)

    with pytest.raises(TransportError):
        conn.connect()

    assert conn.state == ConnectionState.ERROR


def test_double_connect_raises_state_error():
    fake = FakeTransport(responses={"*IDN?": "Keysight,34972A,MY001,1.0"})
    conn = Connection(make_config(), transport=fake)
    conn.connect()

    with pytest.raises(StateError):
        conn.connect()


def test_write_before_connect_raises_state_error():
    fake = FakeTransport()
    conn = Connection(make_config())
    with pytest.raises(StateError):
        conn.write("VOLT:DC?")


def test_command_error_raised_when_error_queue_nonempty():
    fake = FakeTransport(
        responses={
            "*IDN?": "Keysight,34972A,MY001,1.0",
            "SYST:ERR?": '-113,"Undefined header"',
        }
    )
    conn = Connection(make_config(), transport=fake)
    conn.connect()

    with pytest.raises(CommandError) as exc_info:
        conn.write("BOGUS:COMMAND")

    assert exc_info.value.scpi_code == -113


def test_disconnect_returns_to_idle_and_allows_reconnect():
    fake = FakeTransport(responses={"*IDN?": "Keysight,34972A,MY001,1.0"})
    conn = Connection(make_config(), transport=fake)
    conn.connect()
    conn.disconnect()

    assert conn.state == ConnectionState.IDLE
    assert conn.identity is None

    conn.connect()
    assert conn.state == ConnectionState.CONNECTED


def test_close_is_terminal():
    fake = FakeTransport(responses={"*IDN?": "Keysight,34972A,MY001,1.0"})
    conn = Connection(make_config(), transport=fake)
    conn.connect()
    conn.close()

    assert conn.state == ConnectionState.CLOSED
    with pytest.raises(StateError):
        conn.write("VOLT:DC?")


def test_reset_sends_rst_and_waits_stabilization(monkeypatch):
    fake = FakeTransport(responses={"*IDN?": "Keysight,34972A,MY001,1.0"})
    conn = Connection(make_config(stabilization_delay_s=0.01), transport=fake)
    conn.connect()

    slept = []
    monkeypatch.setattr("keysight34970.connection.time.sleep", lambda s: slept.append(s))
    conn.reset()

    assert "*RST" in fake.sent
    assert slept == [0.01]


def test_clear_status_sends_cls():
    fake = FakeTransport(responses={"*IDN?": "Keysight,34972A,MY001,1.0"})
    conn = Connection(make_config(), transport=fake)
    conn.connect()
    fake.sent.clear()

    conn.clear_status()

    assert fake.sent == ["*CLS"]


def test_set_timeout_updates_transport_and_config():
    fake = FakeTransport(responses={"*IDN?": "Keysight,34972A,MY001,1.0"})
    conn = Connection(make_config(), transport=fake)
    conn.connect()

    conn.set_timeout(2.5)

    assert fake.timeout_s == 2.5
    assert conn.config.timeout_s == 2.5


def test_set_timeout_rejects_non_positive():
    fake = FakeTransport()
    conn = Connection(make_config(), transport=fake)

    with pytest.raises(Exception):
        conn.set_timeout(0)


def test_reconnect_cycles_through_idle():
    fake = FakeTransport(responses={"*IDN?": "Keysight,34972A,MY001,1.0"})
    conn = Connection(make_config(), transport=fake)
    conn.connect()

    conn.reconnect()

    assert conn.state == ConnectionState.CONNECTED
    assert conn.identity is not None


def test_drain_error_queue_collects_multiple_errors():
    responses_sequence = iter(
        ['-113,"Undefined header"', '-222,"Data out of range"', '0,"No error"']
    )

    class SequencedFakeTransport(FakeTransport):
        def query(self, command):
            self.write(command)
            if command == "SYST:ERR?":
                return next(responses_sequence)
            return self.responses.get(command, "")

    fake = SequencedFakeTransport(responses={"*IDN?": "Keysight,34972A,MY001,1.0"})
    conn = Connection(make_config(), transport=fake)
    conn.connect()

    errors = conn.drain_error_queue()

    assert [e.code for e in errors] == [-113, -222]


def test_drain_error_queue_stops_at_no_error_immediately():
    fake = FakeTransport(
        responses={"*IDN?": "Keysight,34972A,MY001,1.0", "SYST:ERR?": '0,"No error"'}
    )
    conn = Connection(make_config(), transport=fake)
    conn.connect()

    assert conn.drain_error_queue() == []


def test_repr_includes_state_and_target():
    fake = FakeTransport(responses={"*IDN?": "Keysight,34972A,MY001,1.0"})
    conn = Connection(make_config(), transport=fake)
    conn.connect()

    text = repr(conn)
    assert "CONNECTED" in text
    assert "34972A" in text


def test_model_mismatch_raises_configuration_error_and_moves_to_error_state():
    from keysight34970.exceptions import ConfigurationError

    fake = FakeTransport(responses={"*IDN?": "Keysight,34970A,MY001,1.0"})
    # Configured for 34972A but instrument reports 34970A
    conn = Connection(make_config(model=InstrumentModel.DAQ_34972A), transport=fake)

    with pytest.raises(ConfigurationError, match="does not match"):
        conn.connect()

    assert conn.state == ConnectionState.ERROR


def test_model_match_allows_connect():
    fake = FakeTransport(responses={"*IDN?": "Keysight,34972A,MY001,1.0"})
    conn = Connection(make_config(model=InstrumentModel.DAQ_34972A), transport=fake)

    conn.connect()  # should not raise

    assert conn.state == ConnectionState.CONNECTED


def test_verify_model_false_bypasses_mismatch_check():
    fake = FakeTransport(responses={"*IDN?": "Keysight,34970A,MY001,1.0"})
    conn = Connection(
        make_config(model=InstrumentModel.DAQ_34972A, verify_model=False),
        transport=fake,
    )

    conn.connect()  # should not raise despite mismatch

    assert conn.state == ConnectionState.CONNECTED


def test_is_connected_property_tracks_state():
    fake = FakeTransport(responses={"*IDN?": "Keysight,34972A,MY001,1.0"})
    conn = Connection(make_config(), transport=fake)

    assert not conn.is_connected
    conn.connect()
    assert conn.is_connected
    conn.close()
    assert not conn.is_connected


def test_context_manager_connects_and_closes():
    fake = FakeTransport(responses={"*IDN?": "Keysight,34972A,MY001,1.0"})
    with Connection(make_config(), transport=fake) as conn:
        assert conn.state == ConnectionState.CONNECTED
    assert conn.state == ConnectionState.CLOSED


def test_check_errors_false_skips_error_queue_query():
    fake = FakeTransport(
        responses={
            "*IDN?": "Keysight,34972A,MY001,1.0",
            "SYST:ERR?": '-113,"Undefined header"',
        }
    )
    conn = Connection(make_config(), transport=fake)
    conn.connect()
    fake.sent.clear()

    # Would raise CommandError if the queue were checked.
    conn.write("SOME:COMMAND", check_errors=False)

    assert "SYST:ERR?" not in fake.sent

    result = conn.query("*IDN?", check_errors=False)
    assert result == "Keysight,34972A,MY001,1.0"


def test_transport_failure_during_error_check_is_distinct_from_command_error():
    """Regression guard for the Gate 2 fix: a transport failure while
    reading SYST:ERR? must not be reported as an instrument-side
    CommandError."""

    fake = FakeTransport(responses={"*IDN?": "Keysight,34972A,MY001,1.0"})
    conn = Connection(make_config(), transport=fake)
    conn.connect()

    def _fail_on_error_query(command):
        fake.write(command)
        if command == "SYST:ERR?":
            raise TransportError("simulated link drop")
        return fake.responses.get(command, "")

    fake.query = _fail_on_error_query

    with pytest.raises(TransportError, match="Could not verify error queue"):
        conn.write("SOME:COMMAND")


def test_config_rejects_negative_stabilization_delay():
    from keysight34970.exceptions import ConfigurationError

    with pytest.raises(ConfigurationError, match="stabilization_delay_s"):
        make_config(stabilization_delay_s=-0.5).validate()


def test_display_name_for_visa_without_alias():
    config = ConnectionConfig(
        transport=TransportKind.VISA,
        model=InstrumentModel.DAQ_34970A,
        visa_resource="GPIB0::9::INSTR",
    )
    assert config.display_name() == "GPIB0::9::INSTR"
