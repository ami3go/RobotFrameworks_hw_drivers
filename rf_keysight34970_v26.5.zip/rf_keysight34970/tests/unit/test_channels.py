import pytest

from keysight34970.exceptions import ConfigurationError
from keysight34970.measurement.channels import (
    CARD_SPECS,
    CardType,
    ChannelId,
    ChannelList,
)


# -- ChannelId ------------------------------------------------------


@pytest.mark.parametrize(
    "value,slot,channel",
    [
        (101, 1, 1),
        ("101", 1, 1),
        ("@101", 1, 1),
        (" 215 ", 2, 15),
        ("@ 322", 3, 22),
        (322, 3, 22),
    ],
)
def test_parse_accepts_supported_forms(value, slot, channel):
    parsed = ChannelId.parse(value)
    assert (parsed.slot, parsed.channel) == (slot, channel)


def test_parse_is_idempotent_on_channelid():
    original = ChannelId(1, 3)
    assert ChannelId.parse(original) is original


def test_address_property():
    assert ChannelId(2, 7).address == 207
    assert str(ChannelId(3, 12)) == "312"


@pytest.mark.parametrize("bad", ["", "1", "12", "1234", "abc", "@", "10a", "1.1"])
def test_parse_rejects_malformed(bad):
    with pytest.raises(ConfigurationError, match="Invalid channel address"):
        ChannelId.parse(bad)


@pytest.mark.parametrize("slot", [0, 4, -1, 9])
def test_slot_out_of_range_rejected(slot):
    with pytest.raises(ConfigurationError, match="slot must be"):
        ChannelId(slot=slot, channel=1)


@pytest.mark.parametrize("channel", [0, 100, -5])
def test_channel_out_of_range_rejected(channel):
    with pytest.raises(ConfigurationError, match="channel must be"):
        ChannelId(slot=1, channel=channel)


def test_parse_rejects_slot_zero_address():
    """001 would imply slot 0, which does not exist."""
    with pytest.raises(ConfigurationError, match="slot must be"):
        ChannelId.parse("001")


def test_channelid_is_hashable_and_ordered():
    assert ChannelId(1, 1) < ChannelId(1, 2) < ChannelId(2, 1)
    assert len({ChannelId(1, 1), ChannelId(1, 1)}) == 1


# -- card validation ------------------------------------------------


def test_valid_channel_on_34901a():
    ChannelId.parse("101").validate_against(CardType.MUX_34901A)
    ChannelId.parse("122").validate_against(CardType.MUX_34901A)  # current channel


def test_invalid_channel_on_34901a():
    with pytest.raises(ConfigurationError, match="not valid on a 34901A"):
        ChannelId.parse("123").validate_against(CardType.MUX_34901A)


def test_34902a_has_sixteen_channels():
    ChannelId.parse("116").validate_against(CardType.MUX_34902A)
    with pytest.raises(ConfigurationError):
        ChannelId.parse("117").validate_against(CardType.MUX_34902A)


def test_34908a_has_forty_channels():
    ChannelId.parse("140").validate_against(CardType.MUX_34908A)
    with pytest.raises(ConfigurationError):
        ChannelId.parse("141").validate_against(CardType.MUX_34908A)


def test_matrix_card_uses_row_column_addressing():
    ChannelId.parse("111").validate_against(CardType.MTX_34904A)  # row1 col1
    ChannelId.parse("148").validate_against(CardType.MTX_34904A)  # row4 col8
    with pytest.raises(ConfigurationError):
        ChannelId.parse("149").validate_against(CardType.MTX_34904A)  # col 9
    with pytest.raises(ConfigurationError):
        ChannelId.parse("101").validate_against(CardType.MTX_34904A)  # no row 0


def test_unknown_card_relaxes_channel_validation():
    """An unrecognised card must remain usable rather than blocked."""
    ChannelId.parse("199").validate_against(CardType.UNKNOWN)


def test_switch_only_cards_are_not_measurable():
    for card in (
        CardType.ACT_34903A,
        CardType.MTX_34904A,
        CardType.RF_34905A,
        CardType.MFM_34907A,
    ):
        spec = CARD_SPECS[card]
        assert spec.measurable_channels == frozenset(), card


def test_mux_cards_are_measurable():
    spec = CARD_SPECS[CardType.MUX_34901A]
    assert spec.supports_measurement(1)
    assert spec.supports_current(21)
    assert not spec.supports_current(1)


def test_every_card_type_has_a_spec():
    assert set(CARD_SPECS) == set(CardType)


# -- ChannelList ----------------------------------------------------


def test_parse_scpi_list():
    channels = ChannelList.parse("(@101,103,105)")
    assert [c.address for c in channels] == [101, 103, 105]


def test_parse_bare_list_without_parens_or_at():
    assert [c.address for c in ChannelList.parse("101,102")] == [101, 102]


def test_parse_range_expands_inclusively():
    channels = ChannelList.parse("(@105:108)")
    assert [c.address for c in channels] == [105, 106, 107, 108]


def test_parse_mixed_singles_and_ranges():
    channels = ChannelList.parse("(@101,105:107,110)")
    assert [c.address for c in channels] == [101, 105, 106, 107, 110]


def test_parse_from_python_sequence():
    assert [c.address for c in ChannelList.parse([101, "102", ChannelId(1, 3)])] == [
        101,
        102,
        103,
    ]


def test_parse_is_idempotent_on_channellist():
    original = ChannelList.parse("(@101)")
    assert ChannelList.parse(original) is original


def test_duplicates_are_removed_preserving_first_occurrence():
    channels = ChannelList.parse("(@103,101,103,101)")
    assert [c.address for c in channels] == [103, 101]


def test_order_is_preserved_not_sorted():
    """Scan order is significant; the list must not be silently sorted."""
    channels = ChannelList.parse("(@110,101,105)")
    assert [c.address for c in channels] == [110, 101, 105]


def test_range_spanning_slots_rejected():
    with pytest.raises(ConfigurationError, match="spans slots"):
        ChannelList.parse("(@108:203)")


def test_reversed_range_rejected():
    with pytest.raises(ConfigurationError, match="reversed"):
        ChannelList.parse("(@110:105)")


def test_single_channel_range_is_allowed():
    assert [c.address for c in ChannelList.parse("(@105:105)")] == [105]


def test_to_scpi_round_trip():
    assert ChannelList.parse("(@101,103)").to_scpi() == "(@101,103)"


def test_to_scpi_expands_ranges_explicitly():
    assert ChannelList.parse("(@101:103)").to_scpi() == "(@101,102,103)"


def test_empty_list_cannot_render_scpi():
    with pytest.raises(ConfigurationError, match="no channels"):
        ChannelList().to_scpi()


def test_empty_string_parses_to_empty_list():
    assert len(ChannelList.parse("")) == 0
    assert len(ChannelList.parse("(@)")) == 0


def test_slots_reports_distinct_slots():
    assert ChannelList.parse("(@101,205,301)").slots() == {1, 2, 3}


def test_validate_against_card_map():
    channels = ChannelList.parse("(@101,201)")
    channels.validate_against({1: CardType.MUX_34901A, 2: CardType.MUX_34902A})


def test_validate_against_card_map_detects_bad_channel():
    channels = ChannelList.parse("(@117)")
    with pytest.raises(ConfigurationError, match="not valid on a 34902A"):
        channels.validate_against({1: CardType.MUX_34902A})


def test_unmapped_slot_defaults_to_relaxed_validation():
    """A partially-described bench must still work."""
    ChannelList.parse("(@399)").validate_against({1: CardType.MUX_34901A})


def test_equality_and_len():
    assert ChannelList.parse("(@101,102)") == ChannelList.parse("(@101:102)")
    assert len(ChannelList.parse("(@101:110)")) == 10
    assert ChannelList.parse("(@101)") != "not a channel list"


def test_repr_is_readable():
    assert "101" in repr(ChannelList.parse("(@101)"))
