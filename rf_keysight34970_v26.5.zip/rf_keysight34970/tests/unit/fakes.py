"""In-memory fake Transport for driving Connection/keyword unit tests
without real hardware."""

from __future__ import annotations

from keysight34970.exceptions import TransportError
from keysight34970.transport.base import Transport


class FakeTransport(Transport):
    def __init__(self, responses: dict[str, str] | None = None) -> None:
        self.responses = responses or {}
        self.sent: list[str] = []
        self._open = False
        self.fail_open = False
        self.timeout_s = 5.0

    @property
    def is_open(self) -> bool:
        return self._open

    def open(self) -> None:
        if self.fail_open:
            raise TransportError("simulated open failure")
        self._open = True

    def close(self) -> None:
        self._open = False

    def write(self, command: str) -> None:
        if not self._open:
            raise TransportError("write on closed transport")
        self.sent.append(command)

    def query(self, command: str) -> str:
        self.write(command)
        return self.responses.get(command, "")

    def set_timeout(self, timeout_s: float) -> None:
        # Deliberately duplicates the validation in the real transports:
        # each Transport implementation is responsible for guarding its
        # own invariants, so a fake that silently accepted a bad value
        # would let a Connection-layer bug pass unit tests that the real
        # transports would catch at runtime. (Closes Gate 2 Minor finding.)
        if timeout_s <= 0:
            raise TransportError(f"timeout_s must be > 0, got {timeout_s}")
        self.timeout_s = timeout_s
