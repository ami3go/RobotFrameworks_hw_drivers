"""Phase 4 Gate 3 extended features: open-detect, RTD reference
resistance, and per-alloy plausibility."""

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from mock_instrument import MockScpiServer  # noqa: E402

from keysight34970.exceptions import ConfigurationError  # noqa: E402
from keysight34970.library import Keysight34970  # noqa: E402
from keysight34970.temperature.models import (  # noqa: E402
    PLAUSIBLE_RANGE_C,
    THERMOCOUPLE_RANGE_C,
    ReferenceJunction,
    TemperatureConfig,
    ThermocoupleType,
    TransducerType,
    is_plausible,
    plausible_range_for,
)


@pytest.fixture
def lib():
    server = MockScpiServer()
    server.start()
    library = Keysight34970()
    library.connect_to_instrument("34972A", "TCP", server.host, port=server.port)
    yield library
    try:
        library.disconnect_from_instrument()
    except Exception:
        pass
    server.stop()


def tc(alloy=ThermocoupleType.K, **kw):
    return TemperatureConfig(
        transducer=TransducerType.THERMOCOUPLE, thermocouple_type=alloy, **kw
    )


# -- per-alloy plausibility -----------------------------------------


def test_every_alloy_has_a_range():
    assert set(THERMOCOUPLE_RANGE_C) == set(ThermocoupleType)


def test_type_t_rejects_a_reading_only_type_k_could_reach():
    """The union range spanned every alloy, so 1500 C on a type T --
    far beyond what type T can physically measure -- passed as
    plausible. That is exactly the wrong-alloy misconfiguration the
    check is supposed to catch."""
    assert not is_plausible(1500.0, tc(ThermocoupleType.T))
    assert is_plausible(1300.0, tc(ThermocoupleType.K))


def test_type_t_accepts_its_own_range():
    assert is_plausible(350.0, tc(ThermocoupleType.T))
    assert not is_plausible(500.0, tc(ThermocoupleType.T))


def test_type_b_lower_bound_is_not_ambient():
    """Type B cannot measure near room temperature; a 20 C reading from
    one usually means the wrong type is configured."""
    assert not is_plausible(20.0, tc(ThermocoupleType.B))


def test_range_falls_back_to_union_when_alloy_unknown():
    config = TemperatureConfig(
        transducer=TransducerType.RTD, rtd_nominal_ohms=100.0
    )
    assert plausible_range_for(config) == PLAUSIBLE_RANGE_C[TransducerType.RTD]


def test_per_alloy_range_is_used_when_alloy_known():
    assert plausible_range_for(tc(ThermocoupleType.T)) == THERMOCOUPLE_RANGE_C[
        ThermocoupleType.T
    ]


# -- open detect ----------------------------------------------------


def test_open_detect_rejected_for_non_thermocouple():
    with pytest.raises(ConfigurationError, match="only to thermocouples"):
        TemperatureConfig(
            transducer=TransducerType.RTD, rtd_nominal_ohms=100.0, open_detect=True
        )


def test_open_detect_emits_check_command(lib):
    lib.configure_thermocouple("(@101)", "K", open_detect="ON")
    assert lib.get_temperature_configuration("101")


@pytest.mark.parametrize("value,expected", [("ON", "ON"), ("OFF", "OFF")])
def test_open_detect_switch_forms(lib, value, expected):
    lib.configure_thermocouple("(@101)", "K", open_detect=value)


def test_open_detect_rejects_nonsense(lib):
    with pytest.raises(AssertionError, match="must be ON or OFF"):
        lib.configure_thermocouple("(@101)", "K", open_detect="SOMETIMES")


def test_open_detect_omitted_sends_nothing(lib):
    """Not specifying it must leave the instrument's setting alone
    rather than silently forcing a default."""
    lib.configure_thermocouple("(@101)", "K")
    config = lib.get_temperature_configuration("101")
    assert config


# -- RTD reference resistance ---------------------------------------


def test_rtd_reference_rejected_for_thermocouple():
    with pytest.raises(ConfigurationError, match="only to RTDs"):
        tc(rtd_reference_ohms=100.0)


def test_rtd_reference_must_be_positive():
    with pytest.raises(ConfigurationError, match="must be > 0"):
        TemperatureConfig(
            transducer=TransducerType.RTD,
            rtd_nominal_ohms=100.0,
            rtd_reference_ohms=0,
        )


def test_rtd_reference_accepted(lib):
    lib.configure_rtd("(@102)", nominal="100", reference_ohms="100.02")
    assert lib.get_temperature_configuration("102")


def test_rtd_reference_rejects_non_numeric(lib):
    with pytest.raises(AssertionError, match="must be a number"):
        lib.configure_rtd("(@102)", nominal="100", reference_ohms="about a hundred")


def test_rtd_reference_distinct_from_nominal():
    """Nominal says 'this is a PT100'; reference says 'this particular
    PT100 measures 100.02 ohms at 0 C'."""
    config = TemperatureConfig(
        transducer=TransducerType.RTD,
        rtd_nominal_ohms=100.0,
        rtd_reference_ohms=100.02,
    )
    assert config.rtd_nominal_ohms != config.rtd_reference_ohms


# -- SCPI emission --------------------------------------------------


def _engine_with_fake():
    from keysight34970.config import ConnectionConfig, InstrumentModel, TransportKind
    from keysight34970.connection import Connection
    from keysight34970.temperature.engine import ScpiTemperatureEngine

    from .fakes import FakeTransport

    fake = FakeTransport(responses={"*IDN?": "Keysight,34972A,MY1,1.0"})
    conn = Connection(
        ConnectionConfig(
            transport=TransportKind.TCP_SOCKET,
            model=InstrumentModel.DAQ_34972A,
            host="10.0.0.5",
        ),
        transport=fake,
    )
    conn.connect()
    fake.sent.clear()
    return ScpiTemperatureEngine(conn), fake


def _sent(fake):
    return [c for c in fake.sent if c != "SYST:ERR?"]


def test_open_detect_on_emits_check_on():
    from keysight34970.measurement.channels import ChannelList

    engine, fake = _engine_with_fake()
    engine.configure(ChannelList.parse("(@101)"), tc(open_detect=True))
    assert any("SENS:TEMP:TRAN:TC:CHEC ON,(@101)" == c for c in _sent(fake))


def test_open_detect_off_emits_check_off():
    from keysight34970.measurement.channels import ChannelList

    engine, fake = _engine_with_fake()
    engine.configure(ChannelList.parse("(@101)"), tc(open_detect=False))
    assert any("SENS:TEMP:TRAN:TC:CHEC OFF,(@101)" == c for c in _sent(fake))


def test_open_detect_unset_emits_no_check_command():
    from keysight34970.measurement.channels import ChannelList

    engine, fake = _engine_with_fake()
    engine.configure(ChannelList.parse("(@101)"), tc())
    assert not any("CHEC" in c for c in _sent(fake))


def test_rtd_reference_emits_res_ref():
    from keysight34970.measurement.channels import ChannelList

    engine, fake = _engine_with_fake()
    engine.configure(
        ChannelList.parse("(@102)"),
        TemperatureConfig(
            transducer=TransducerType.RTD,
            rtd_nominal_ohms=100.0,
            rtd_reference_ohms=100.02,
        ),
    )
    commands = _sent(fake)
    assert any("RES:REF 100.02,(@102)" in c for c in commands)
    # The nominal must still be sent, and separately.
    assert any(c.endswith("RES 100,(@102)") for c in commands)


# -- coverage of remaining branches ---------------------------------


@pytest.mark.parametrize("blank", [None, "", "  ", "NONE", "default"])
def test_optional_argument_blank_forms_are_ignored(lib, blank):
    """Robot passes empty strings freely; every optional argument must
    treat them as 'not specified' rather than as a value."""
    lib.configure_thermocouple("(@101)", "K", open_detect=blank)
    lib.configure_rtd("(@102)", nominal="100", reference_ohms=blank)


def test_read_reference_junction(lib):
    lib.configure_thermocouple("(@101)", "K")
    value = lib.read_reference_junction_temperature()
    assert isinstance(value, float)


def test_read_temperature_returns_values(lib):
    lib.configure_thermocouple("(@101,102)", "K")
    values = lib.read_temperature()
    assert len(values) == 2


def test_temperature_should_be_within_passes_and_fails(lib):
    lib.configure_thermocouple("(@101)", "K")
    reading = lib.read_temperature("(@101)")[0]

    lib.temperature_should_be_within("101", reading - 1, reading + 1)

    with pytest.raises(AssertionError, match="outside"):
        lib.temperature_should_be_within("101", reading + 100, reading + 200)


def test_temperature_should_be_within_rejects_implausible(lib):
    """An implausible reading must fail even when the caller's bounds
    would accept it: type B cannot measure near ambient, so a ~1 C
    reading from one means the sensor or configuration is wrong."""
    lib.configure_thermocouple("(@101)", "B")
    with pytest.raises(AssertionError):
        lib.temperature_should_be_within("101", -1e9, 1e9)


def test_plausible_range_uses_direct_attribute_access():
    """Regression guard: a getattr() fallback would silently widen the
    range to the union if the field were renamed."""
    import inspect

    from keysight34970.temperature import models

    source = inspect.getsource(models.plausible_range_for)
    code = "\n".join(
        line for line in source.splitlines() if not line.strip().startswith("#")
    )
    assert "getattr(" not in code


def test_set_unit_before_any_channel_is_configured(lib):
    """Setting the unit is a session preference, not a read.

    Found by the hardware verification suite: a teardown restoring the
    unit failed on a skipped test, raising "No temperature channels have
    been configured; call configure() before read()" -- an error about
    reading, raised by a write, naming a precondition this operation
    does not have.
    """
    lib.set_temperature_unit("F")
    lib.set_temperature_unit("C")


def test_set_unit_still_applies_to_configured_channels(lib):
    lib.configure_thermocouple("(@101)", "K")
    lib.set_temperature_unit("F")
    assert lib.read_temperature_details("(@101)")[0]["unit"] == "degF"
