import pytest

from keysight34970.exceptions import ConfigurationError
from keysight34970.measurement.models import Unit
from keysight34970.temperature.models import (
    PLAUSIBLE_RANGE_C,
    RTD_NOMINAL_PT100,
    THERMISTOR_NOMINALS,
    ReferenceJunction,
    TemperatureConfig,
    TemperatureUnit,
    ThermocoupleType,
    TransducerType,
    is_plausible,
    to_celsius,
)


def tc(**kwargs):
    kwargs.setdefault("thermocouple_type", ThermocoupleType.K)
    return TemperatureConfig(TransducerType.THERMOCOUPLE, **kwargs)


# -- units ----------------------------------------------------------


@pytest.mark.parametrize(
    "text,expected",
    [
        ("C", TemperatureUnit.CELSIUS),
        ("c", TemperatureUnit.CELSIUS),
        ("Celsius", TemperatureUnit.CELSIUS),
        ("degC", TemperatureUnit.CELSIUS),
        ("F", TemperatureUnit.FAHRENHEIT),
        ("FAHRENHEIT", TemperatureUnit.FAHRENHEIT),
        ("K", TemperatureUnit.KELVIN),
        ("kelvin", TemperatureUnit.KELVIN),
    ],
)
def test_unit_parsing(text, expected):
    assert TemperatureUnit.parse(text) is expected


def test_unit_parse_is_idempotent():
    assert TemperatureUnit.parse(TemperatureUnit.KELVIN) is TemperatureUnit.KELVIN


@pytest.mark.parametrize("bad", ["R", "rankine", "", "degX"])
def test_unknown_unit_rejected(bad):
    with pytest.raises(ConfigurationError, match="Unknown temperature unit"):
        TemperatureUnit.parse(bad)


def test_units_map_to_measurement_units():
    """A temperature reading must carry the unit actually configured,
    not an assumed Celsius."""
    assert TemperatureUnit.CELSIUS.measurement_unit is Unit.CELSIUS
    assert TemperatureUnit.FAHRENHEIT.measurement_unit is Unit.FAHRENHEIT
    assert TemperatureUnit.KELVIN.measurement_unit is Unit.KELVIN


@pytest.mark.parametrize(
    "value,unit,celsius",
    [
        (25.0, TemperatureUnit.CELSIUS, 25.0),
        (77.0, TemperatureUnit.FAHRENHEIT, 25.0),
        (298.15, TemperatureUnit.KELVIN, 25.0),
        (-40.0, TemperatureUnit.FAHRENHEIT, -40.0),
    ],
)
def test_conversion_to_celsius(value, unit, celsius):
    assert to_celsius(value, unit) == pytest.approx(celsius, abs=1e-9)


# -- thermocouples --------------------------------------------------


def test_thermocouple_requires_a_type():
    """The alloy determines the conversion; guessing K would give a
    confident wrong answer for every other type."""
    with pytest.raises(ConfigurationError, match="thermocouple_type is required"):
        TemperatureConfig(TransducerType.THERMOCOUPLE)


def test_all_thermocouple_types_accepted():
    for alloy in ThermocoupleType:
        assert tc(thermocouple_type=alloy).thermocouple_type is alloy


def test_fixed_reference_requires_a_temperature():
    """An uncompensated junction is wrong by roughly room temperature."""
    with pytest.raises(ConfigurationError, match="requires fixed_reference_c"):
        tc(reference_junction=ReferenceJunction.FIXED)


def test_fixed_reference_temperature_must_be_physical():
    with pytest.raises(ConfigurationError, match="physically plausible"):
        tc(reference_junction=ReferenceJunction.FIXED, fixed_reference_c=-500.0)


def test_fixed_reference_without_fixed_junction_rejected():
    """Silently ignoring it would compensate differently than intended."""
    with pytest.raises(ConfigurationError, match="applies only to"):
        tc(reference_junction=ReferenceJunction.INTERNAL, fixed_reference_c=0.0)


def test_valid_fixed_reference():
    config = tc(reference_junction=ReferenceJunction.FIXED, fixed_reference_c=0.0)
    assert config.fixed_reference_c == 0.0


def test_thermocouple_settings_rejected_on_other_transducers():
    with pytest.raises(ConfigurationError, match="applies only to thermocouples"):
        TemperatureConfig(
            TransducerType.RTD, thermocouple_type=ThermocoupleType.K
        )
    with pytest.raises(ConfigurationError, match="applies only to thermocouples"):
        TemperatureConfig(
            TransducerType.THERMISTOR,
            thermistor_nominal_ohms=5000.0,
            reference_junction=ReferenceJunction.INTERNAL,
        )


# -- RTDs -----------------------------------------------------------


def test_rtd_defaults_are_permitted():
    assert TemperatureConfig(TransducerType.RTD).rtd_nominal_ohms is None


def test_rtd_nominal_must_be_positive():
    with pytest.raises(ConfigurationError, match="must be positive"):
        TemperatureConfig(TransducerType.RTD, rtd_nominal_ohms=0)


def test_rtd_alpha_restricted_to_instrument_options():
    with pytest.raises(ConfigurationError, match="rtd_alpha must be one of"):
        TemperatureConfig(TransducerType.RTD, rtd_alpha=0.004)


@pytest.mark.parametrize("alpha", [0.00385, 0.00391])
def test_valid_rtd_alphas(alpha):
    assert TemperatureConfig(TransducerType.RTD, rtd_alpha=alpha).rtd_alpha == alpha


def test_four_wire_rtd_flagged():
    assert TransducerType.RTD_4WIRE.requires_four_wire_pair
    assert not TransducerType.RTD.requires_four_wire_pair
    assert TransducerType.RTD_4WIRE.is_rtd and TransducerType.RTD.is_rtd


def test_rtd_settings_rejected_on_other_transducers():
    with pytest.raises(ConfigurationError, match="RTD settings apply only"):
        tc(rtd_nominal_ohms=RTD_NOMINAL_PT100)


# -- thermistors ----------------------------------------------------


def test_thermistor_requires_a_nominal():
    with pytest.raises(ConfigurationError, match="thermistor_nominal_ohms is required"):
        TemperatureConfig(TransducerType.THERMISTOR)


@pytest.mark.parametrize("nominal", sorted(THERMISTOR_NOMINALS))
def test_standard_thermistor_nominals(nominal):
    config = TemperatureConfig(
        TransducerType.THERMISTOR, thermistor_nominal_ohms=nominal
    )
    assert config.thermistor_nominal_ohms == nominal


def test_nonstandard_thermistor_rejected():
    """The instrument's conversion assumes one of the standard curves;
    a different nominal yields a believable wrong temperature."""
    with pytest.raises(ConfigurationError, match="not a standard value"):
        TemperatureConfig(TransducerType.THERMISTOR, thermistor_nominal_ohms=3000.0)


def test_thermistor_settings_rejected_on_other_transducers():
    with pytest.raises(ConfigurationError, match="applies only to thermistors"):
        tc(thermistor_nominal_ohms=5000.0)


# -- description and plausibility -----------------------------------


def test_describe_covers_each_transducer():
    assert "type K thermocouple" in tc().describe()
    assert "INT reference" in tc(reference_junction=ReferenceJunction.INTERNAL).describe()
    assert "4-wire RTD" in TemperatureConfig(TransducerType.RTD_4WIRE).describe()
    assert "2-wire RTD" in TemperatureConfig(TransducerType.RTD).describe()
    assert "5000 ohm thermistor" in TemperatureConfig(
        TransducerType.THERMISTOR, thermistor_nominal_ohms=5000.0
    ).describe()


def test_describe_reports_the_unit():
    assert "in F" in tc(unit=TemperatureUnit.FAHRENHEIT).describe()


def test_plausibility_ranges_exist_for_every_transducer():
    assert set(PLAUSIBLE_RANGE_C) == set(TransducerType)


def test_plausible_readings_accepted():
    assert is_plausible(25.0, tc())
    assert is_plausible(
        77.0, tc(unit=TemperatureUnit.FAHRENHEIT)
    )
    assert is_plausible(298.15, tc(unit=TemperatureUnit.KELVIN))


def test_implausible_readings_flagged():
    """Catches open junctions and disconnected sensors, which otherwise
    return believable-looking numbers."""
    assert not is_plausible(5000.0, tc())
    thermistor = TemperatureConfig(
        TransducerType.THERMISTOR, thermistor_nominal_ohms=5000.0
    )
    assert not is_plausible(500.0, thermistor)   # beyond thermistor range
    assert is_plausible(50.0, thermistor)


def test_plausibility_respects_configured_unit():
    """25 K is implausible for a thermocouple even though 25 C is fine;
    a unit mix-up must not pass unnoticed."""
    kelvin = tc(unit=TemperatureUnit.KELVIN)
    assert is_plausible(298.15, kelvin)
    assert not is_plausible(-10.0, kelvin)  # below absolute zero in C terms
