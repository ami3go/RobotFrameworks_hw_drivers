from keysight34970.library import Keysight34970


def test_capability_metadata_covers_every_keyword():
    """Metadata must cover exactly the keywords Robot exposes.

    Derived from the live library rather than a hardcoded list, so a
    keyword added in any future phase without matching metadata fails
    here instead of silently drifting.
    """

    from robot.running.testlibraries import TestLibrary as RobotTestLibrary

    metadata = Keysight34970.get_capability_metadata()
    discovered = {
        kw.name
        for kw in RobotTestLibrary.from_name("keysight34970.Keysight34970").keywords
    }

    assert set(metadata) == discovered, (
        f"metadata only: {sorted(set(metadata) - discovered)}; "
        f"keywords only: {sorted(discovered - set(metadata))}"
    )

    for name, entry in metadata.items():
        assert "risk_level" in entry, name
        assert entry["risk_level"] in {"low", "medium", "high"}, name
        assert "blocking" in entry, name
        assert "exclusive_resources" in entry, name


def test_measurement_capabilities_are_registered():
    metadata = Keysight34970.get_capability_metadata()
    for name in (
        "Configure Measurement",
        "Read Measurement",
        "Measure",
        "Measure Value",
        "Get Configured Function",
        "Set Installed Card",
    ):
        assert name in metadata, name


def test_dmm_capabilities_declare_the_dmm_as_exclusive():
    """Capabilities that operate the DMM must say so, or a planner may
    schedule two of them concurrently."""
    metadata = Keysight34970.get_capability_metadata()
    for name in ("Read Measurement", "Measure", "Measure Value"):
        assert "internal_dmm" in metadata[name]["exclusive_resources"], name


def test_capability_metadata_returns_a_copy_not_the_live_registry():
    metadata = Keysight34970.get_capability_metadata()
    metadata["Connect To Instrument"]["risk_level"] = "mutated"

    fresh = Keysight34970.get_capability_metadata()
    assert fresh["Connect To Instrument"]["risk_level"] != "mutated"
