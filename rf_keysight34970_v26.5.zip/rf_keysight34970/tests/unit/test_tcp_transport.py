import socket
import threading

import pytest

from keysight34970.exceptions import TimeoutError34970, TransportError
from keysight34970.transport.tcp_transport import TcpSocketTransport


class _EchoServer:
    """Tiny single-shot echo server for exercising real socket I/O."""

    def __init__(self, terminator: bytes = b"\n") -> None:
        self._terminator = terminator
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._sock.bind(("127.0.0.1", 0))
        self._sock.listen(1)
        self.host, self.port = self._sock.getsockname()
        self._thread = threading.Thread(target=self._serve, daemon=True)
        self._stop = False

    def start(self) -> None:
        self._thread.start()

    def stop(self) -> None:
        self._stop = True
        try:
            self._sock.close()
        except OSError:
            pass

    def _serve(self) -> None:
        try:
            conn, _ = self._sock.accept()
        except OSError:
            return
        with conn:
            buf = b""
            while not self._stop:
                chunk = conn.recv(4096)
                if not chunk:
                    return
                buf += chunk
                while self._terminator in buf:
                    line, buf = buf.split(self._terminator, 1)
                    conn.sendall(line + b"-ECHO" + self._terminator)


@pytest.fixture
def echo_server():
    server = _EchoServer()
    server.start()
    yield server
    server.stop()


def test_default_terminator_round_trip(echo_server):
    transport = TcpSocketTransport(echo_server.host, echo_server.port, timeout_s=2.0)
    transport.open()
    try:
        response = transport.query("HELLO")
        assert response == "HELLO-ECHO"
    finally:
        transport.close()


def test_custom_terminator_round_trip():
    server = _EchoServer(terminator=b"\r\n")
    server.start()
    try:
        transport = TcpSocketTransport(
            server.host, server.port, timeout_s=2.0, terminator="\r\n"
        )
        transport.open()
        try:
            response = transport.query("HELLO")
            assert response == "HELLO-ECHO"
        finally:
            transport.close()
    finally:
        server.stop()


def test_command_with_embedded_terminator_rejected(echo_server):
    transport = TcpSocketTransport(echo_server.host, echo_server.port, timeout_s=2.0)
    transport.open()
    try:
        with pytest.raises(TransportError, match="embedded terminator"):
            transport.write("VOLT:DC?\nBOGUS")
    finally:
        transport.close()


def test_empty_terminator_rejected_at_construction():
    with pytest.raises(TransportError, match="non-empty"):
        TcpSocketTransport("127.0.0.1", 5025, timeout_s=1.0, terminator="")


def test_write_before_open_raises(echo_server):
    transport = TcpSocketTransport(echo_server.host, echo_server.port, timeout_s=1.0)
    with pytest.raises(TransportError, match="not open"):
        transport.write("*CLS")


def test_open_failure_on_unreachable_port():
    # Port 1 on localhost is essentially guaranteed closed for a
    # non-root test process.
    transport = TcpSocketTransport("127.0.0.1", 1, timeout_s=1.0)
    with pytest.raises(TransportError, match="Failed to open TCP connection"):
        transport.open()


def test_close_is_idempotent_and_safe_before_open(echo_server):
    transport = TcpSocketTransport(echo_server.host, echo_server.port, timeout_s=1.0)
    transport.close()  # before open - must not raise
    transport.open()
    assert transport.is_open
    transport.close()
    transport.close()  # twice - must not raise
    assert not transport.is_open


def test_open_is_idempotent(echo_server):
    transport = TcpSocketTransport(echo_server.host, echo_server.port, timeout_s=2.0)
    transport.open()
    try:
        transport.open()  # second call is a no-op, not an error
        assert transport.is_open
    finally:
        transport.close()


def test_set_timeout_rejects_non_positive(echo_server):
    transport = TcpSocketTransport(echo_server.host, echo_server.port, timeout_s=1.0)
    with pytest.raises(TransportError, match="must be > 0"):
        transport.set_timeout(0)


def test_set_timeout_applies_before_and_after_open(echo_server):
    transport = TcpSocketTransport(echo_server.host, echo_server.port, timeout_s=1.0)
    transport.set_timeout(3.0)  # before open
    transport.open()
    try:
        transport.set_timeout(4.0)  # after open
        assert transport._sock.gettimeout() == 4.0
    finally:
        transport.close()


def test_read_timeout_raises_timeout_error():
    """A server that accepts but never replies must produce
    TimeoutError34970, not a hang or a generic TransportError."""

    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(("127.0.0.1", 0))
    server.listen(1)
    host, port = server.getsockname()

    accepted = []

    def _accept_and_stay_silent():
        try:
            conn, _ = server.accept()
            accepted.append(conn)  # hold it open, send nothing
        except OSError:
            pass

    thread = threading.Thread(target=_accept_and_stay_silent, daemon=True)
    thread.start()

    transport = TcpSocketTransport(host, port, timeout_s=0.3)
    transport.open()
    try:
        with pytest.raises(TimeoutError34970, match="Timed out waiting"):
            transport.query("*IDN?")
    finally:
        transport.close()
        for conn in accepted:
            conn.close()
        server.close()


def test_connection_closed_mid_read_raises_transport_error():
    """If the instrument drops the connection before terminating its
    response, that must surface as a TransportError, not an empty
    string that silently corrupts a measurement."""

    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(("127.0.0.1", 0))
    server.listen(1)
    host, port = server.getsockname()

    def _accept_then_hangup():
        try:
            conn, _ = server.accept()
            conn.recv(4096)
            conn.sendall(b"PARTIAL")  # no terminator
            conn.close()
        except OSError:
            pass

    thread = threading.Thread(target=_accept_then_hangup, daemon=True)
    thread.start()

    transport = TcpSocketTransport(host, port, timeout_s=2.0)
    transport.open()
    try:
        with pytest.raises(TransportError, match="closed by instrument"):
            transport.query("*IDN?")
    finally:
        transport.close()
        server.close()


def test_context_manager_opens_and_closes(echo_server):
    with TcpSocketTransport(
        echo_server.host, echo_server.port, timeout_s=2.0
    ) as transport:
        assert transport.is_open
        assert transport.query("PING") == "PING-ECHO"
    assert not transport.is_open


def test_nagle_is_disabled(echo_server):
    """Regression guard for a ~40 ms per-operation penalty.

    SCPI is a request/response protocol of tiny messages, and the driver
    routinely issues two writes back to back (a command, then the
    SYST:ERR? check). With Nagle enabled the second small write waits
    for the first to be acknowledged, and the peer's delayed-ACK timer
    does not fire for ~40 ms. Measured at Phase 2 Gate 5: every
    configure/read cost 44 ms; 0.065 ms with TCP_NODELAY set.

    This went undetected from Phase 1 Gate 1 because the Phase 1
    performance review only benchmarked connect() and single queries --
    write-then-read patterns, which Nagle does not penalise.
    """

    transport = TcpSocketTransport(echo_server.host, echo_server.port, timeout_s=2.0)
    transport.open()
    try:
        assert (
            transport._sock.getsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY) != 0
        ), "TCP_NODELAY must be set or every command pays a ~40ms Nagle penalty"
    finally:
        transport.close()


def test_back_to_back_writes_are_not_delayed(echo_server):
    """Behavioural counterpart to the socket-option check: two writes
    followed by a read must not take anywhere near the ~40 ms delayed-ACK
    interval."""

    import time

    transport = TcpSocketTransport(echo_server.host, echo_server.port, timeout_s=2.0)
    transport.open()
    try:
        transport.write("WARMUP")
        transport._read_line()

        start = time.perf_counter()
        for _ in range(5):
            transport.write("PING")
            transport._read_line()
        elapsed_ms = (time.perf_counter() - start) * 1000

        assert elapsed_ms < 50, (
            f"5 request/response round trips took {elapsed_ms:.1f} ms; "
            "a Nagle/delayed-ACK interaction would make this ~200 ms"
        )
    finally:
        transport.close()
