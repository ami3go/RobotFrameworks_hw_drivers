import pytest

from keysight34970.config import ConnectionConfig, InstrumentModel, TransportKind
from keysight34970.exceptions import ConfigurationError


def test_tcp_config_requires_host():
    config = ConnectionConfig(
        transport=TransportKind.TCP_SOCKET,
        model=InstrumentModel.DAQ_34972A,
    )
    with pytest.raises(ConfigurationError, match="host"):
        config.validate()


def test_visa_config_requires_resource():
    config = ConnectionConfig(
        transport=TransportKind.VISA,
        model=InstrumentModel.DAQ_34970A,
    )
    with pytest.raises(ConfigurationError, match="visa_resource"):
        config.validate()


def test_tcp_config_rejects_bad_port():
    config = ConnectionConfig(
        transport=TransportKind.TCP_SOCKET,
        model=InstrumentModel.DAQ_34972A,
        host="10.0.0.5",
        port=70000,
    )
    with pytest.raises(ConfigurationError, match="port"):
        config.validate()


def test_valid_tcp_config_passes():
    config = ConnectionConfig(
        transport=TransportKind.TCP_SOCKET,
        model=InstrumentModel.DAQ_34972A,
        host="10.0.0.5",
        port=5025,
    )
    config.validate()  # should not raise


def test_negative_timeout_rejected():
    config = ConnectionConfig(
        transport=TransportKind.TCP_SOCKET,
        model=InstrumentModel.DAQ_34972A,
        host="10.0.0.5",
        timeout_s=-1,
    )
    with pytest.raises(ConfigurationError, match="timeout_s"):
        config.validate()


def test_display_name_uses_alias_when_set():
    config = ConnectionConfig(
        transport=TransportKind.TCP_SOCKET,
        model=InstrumentModel.DAQ_34972A,
        host="10.0.0.5",
        alias="daq1",
    )
    assert config.display_name() == "daq1"


def test_display_name_falls_back_to_host_port():
    config = ConnectionConfig(
        transport=TransportKind.TCP_SOCKET,
        model=InstrumentModel.DAQ_34972A,
        host="10.0.0.5",
        port=5025,
    )
    assert config.display_name() == "10.0.0.5:5025"


def test_whitespace_only_host_rejected():
    config = ConnectionConfig(
        transport=TransportKind.TCP_SOCKET,
        model=InstrumentModel.DAQ_34972A,
        host="   ",
    )
    with pytest.raises(ConfigurationError, match="host"):
        config.validate()


def test_whitespace_only_visa_resource_rejected():
    config = ConnectionConfig(
        transport=TransportKind.VISA,
        model=InstrumentModel.DAQ_34970A,
        visa_resource="   ",
    )
    with pytest.raises(ConfigurationError, match="visa_resource"):
        config.validate()


def test_empty_terminator_rejected():
    config = ConnectionConfig(
        transport=TransportKind.TCP_SOCKET,
        model=InstrumentModel.DAQ_34972A,
        host="10.0.0.5",
        terminator="",
    )
    with pytest.raises(ConfigurationError, match="terminator"):
        config.validate()


def test_default_verify_model_is_enabled():
    config = ConnectionConfig(
        transport=TransportKind.TCP_SOCKET,
        model=InstrumentModel.DAQ_34972A,
        host="10.0.0.5",
    )
    assert config.verify_model is True
