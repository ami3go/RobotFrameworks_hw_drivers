"""Phase 5 Gate 1: digital I/O models and channel-role validation."""

import pytest

from keysight34970.digital.models import (
    DAC_MAX_V,
    DAC_MIN_V,
    PORT_BITS,
    PORT_MAX_VALUE,
    TOTALIZER_MAX_COUNT,
    ChannelRole,
    DacOutput,
    DigitalPortState,
    EdgeSlope,
    InputThreshold,
    TotalizerConfig,
    TotalizerMode,
    TotalizerReading,
    require_role,
    role_of,
)
from keysight34970.exceptions import ConfigurationError
from keysight34970.measurement.channels import ChannelId


def ch(address):
    return ChannelId.parse(address)


# -- channel roles --------------------------------------------------


@pytest.mark.parametrize(
    "address,role",
    [
        (101, ChannelRole.DIGITAL_PORT),
        (102, ChannelRole.DIGITAL_PORT),
        (103, ChannelRole.TOTALIZER),
        (104, ChannelRole.DAC),
        (105, ChannelRole.DAC),
        (201, ChannelRole.DIGITAL_PORT),
        (305, ChannelRole.DAC),
    ],
)
def test_role_of_known_channels(address, role):
    assert role_of(address) is role


@pytest.mark.parametrize("address", [106, 110, 120, 199])
def test_role_of_rejects_non_34907a_channels(address):
    with pytest.raises(ConfigurationError, match="not a 34907A channel"):
        role_of(address)


def test_role_error_names_the_valid_channels():
    """The 34907A's layout is not guessable from the other cards, so the
    error has to say what the module actually provides."""
    with pytest.raises(ConfigurationError) as exc:
        role_of(107)
    message = str(exc.value)
    assert "digital ports" in message
    assert "totalizer" in message
    assert "analogue outputs" in message


def test_require_role_returns_channel_on_match():
    assert require_role(101, ChannelRole.DIGITAL_PORT).address == 101


def test_require_role_names_both_roles_on_mismatch():
    with pytest.raises(ConfigurationError, match="analogue output.*not a digital port"):
        require_role(104, ChannelRole.DIGITAL_PORT)


def test_require_role_rejects_writing_dac_to_a_port():
    """The failure this validation exists for: addressing a DAC as a
    digital port would drive an unintended output."""
    with pytest.raises(ConfigurationError):
        require_role(101, ChannelRole.DAC)


# -- digital port state ---------------------------------------------


def test_port_bits_are_least_significant_first():
    state = DigitalPortState(channel=ch(101), value=0b00000101)
    assert state.bit(0) is True
    assert state.bit(1) is False
    assert state.bit(2) is True
    assert state.bits[:3] == (True, False, True)


def test_port_binary_rendering_is_most_significant_first():
    """Bit indexing counts from the LSB, but a wiring diagram is read
    MSB-first; both orders exist deliberately."""
    assert DigitalPortState(channel=ch(101), value=0b10100101).to_binary() == "10100101"


def test_port_value_bounds():
    DigitalPortState(channel=ch(101), value=0)
    DigitalPortState(channel=ch(101), value=PORT_MAX_VALUE)
    for bad in (-1, 256, 1000):
        with pytest.raises(ConfigurationError, match="8 bits"):
            DigitalPortState(channel=ch(101), value=bad)


@pytest.mark.parametrize("bad_bit", [-1, PORT_BITS, 99])
def test_bit_index_bounds(bad_bit):
    state = DigitalPortState(channel=ch(101), value=0)
    with pytest.raises(ConfigurationError, match="Bit index"):
        state.bit(bad_bit)
    with pytest.raises(ConfigurationError, match="Bit index"):
        state.with_bit(bad_bit, True)


def test_with_bit_sets_and_clears_without_touching_others():
    state = DigitalPortState(channel=ch(101), value=0b00000000)
    assert state.with_bit(3, True).value == 0b00001000
    full = DigitalPortState(channel=ch(101), value=0b11111111)
    assert full.with_bit(3, False).value == 0b11110111


def test_with_bit_returns_a_new_state():
    """Read-modify-write on a port is racy; returning a new value makes
    the write-back an explicit act."""
    state = DigitalPortState(channel=ch(101), value=0)
    updated = state.with_bit(0, True)
    assert state.value == 0
    assert updated is not state


def test_port_state_carries_its_channel():
    assert "@101" in str(DigitalPortState(channel=ch(101), value=5))


# -- totalizer ------------------------------------------------------


def test_read_reset_mode_is_flagged_destructive():
    """The 34907A's most dangerous setting: a second read returns 0,
    which is a plausible count rather than an error."""
    assert TotalizerMode.READ_RESET.is_destructive
    assert not TotalizerMode.READ.is_destructive


def test_totalizer_config_defaults_to_non_destructive():
    assert not TotalizerConfig().reading_is_destructive
    assert TotalizerConfig().slope is EdgeSlope.POSITIVE


def test_totalizer_config_destructive_flag_follows_mode():
    config = TotalizerConfig(mode=TotalizerMode.READ_RESET)
    assert config.reading_is_destructive


def test_totalizer_reading_bounds():
    TotalizerReading(channel=ch(103), count=0)
    TotalizerReading(channel=ch(103), count=TOTALIZER_MAX_COUNT)
    with pytest.raises(ConfigurationError, match="negative"):
        TotalizerReading(channel=ch(103), count=-1)
    with pytest.raises(ConfigurationError, match="26-bit"):
        TotalizerReading(channel=ch(103), count=TOTALIZER_MAX_COUNT + 1)


def test_totalizer_max_is_26_bits():
    assert TOTALIZER_MAX_COUNT == 67_108_863


def test_near_wrap_detection():
    """The counter wraps rather than saturating, and a wrapped count is
    indistinguishable from a low one."""
    assert TotalizerReading(channel=ch(103), count=TOTALIZER_MAX_COUNT).is_near_wrap
    assert not TotalizerReading(channel=ch(103), count=0).is_near_wrap
    assert not TotalizerReading(channel=ch(103), count=1000).is_near_wrap


def test_reset_by_read_recorded_on_the_reading():
    """Recorded per reading, not inferred from configuration: if it is
    True the count is gone and this object is the only copy."""
    reading = TotalizerReading(channel=ch(103), count=42, was_reset_by_read=True)
    assert reading.was_reset_by_read
    assert not TotalizerReading(channel=ch(103), count=42).was_reset_by_read


def test_edge_and_threshold_scpi_values():
    assert EdgeSlope.POSITIVE.value == "POS"
    assert EdgeSlope.NEGATIVE.value == "NEG"
    assert InputThreshold.TTL.value == "TTL"
    assert InputThreshold.AC.value == "AC"
    assert TotalizerMode.READ_RESET.value == "RRES"


# -- DAC ------------------------------------------------------------


def test_dac_accepts_full_range():
    DacOutput(channel=ch(104), volts=DAC_MIN_V)
    DacOutput(channel=ch(104), volts=DAC_MAX_V)
    DacOutput(channel=ch(104), volts=0.0)


@pytest.mark.parametrize("bad", [-12.001, 12.001, 50.0, -100.0])
def test_dac_rejects_out_of_range_rather_than_clamping(bad):
    """Clamping would drive a different voltage than requested, which on
    an output is a hardware event rather than a rounding error."""
    with pytest.raises(ConfigurationError, match="clamping silently"):
        DacOutput(channel=ch(104), volts=bad)


def test_dac_rendering_shows_sign():
    assert str(DacOutput(channel=ch(104), volts=5.0)).startswith("+5")
    assert str(DacOutput(channel=ch(104), volts=-5.0)).startswith("-5")


def test_role_labels_and_articles_agree():
    """Error messages are read by someone who has just addressed the
    wrong channel; "not a analogue output" reads as machine output."""
    assert ChannelRole.DAC.label == "analogue output"
    assert ChannelRole.DAC.article == "an"
    assert ChannelRole.DIGITAL_PORT.article == "a"
    assert ChannelRole.TOTALIZER.article == "a"


def test_mismatch_message_reads_naturally():
    with pytest.raises(ConfigurationError) as exc:
        require_role(101, ChannelRole.DAC)
    assert "is a digital port, not an analogue output" in str(exc.value)


# -- composition (Gate 1 skeleton) ----------------------------------


def test_digital_mixin_contributes_keywords_and_metadata():
    """Gate 1 asserted this mixin registered nothing; Gate 2 added the
    keywords, so the assertion now checks the pairing instead. Updated
    rather than deleted, because the property worth protecting is that
    the keyword surface and the metadata registry agree."""
    from robot.running.testlibraries import TestLibrary as RobotTestLibrary

    from keysight34970.keywords.digital_keywords import (
        CAPABILITY_METADATA,
        DigitalKeywords,
    )
    from keysight34970.library import Keysight34970

    assert issubclass(Keysight34970, DigitalKeywords)
    assert CAPABILITY_METADATA

    discovered = {
        kw.name
        for kw in RobotTestLibrary.from_name("keysight34970.Keysight34970").keywords
    }
    assert set(CAPABILITY_METADATA) <= discovered
    assert set(CAPABILITY_METADATA) <= set(
        Keysight34970.get_capability_metadata()
    )


def test_output_capabilities_are_marked_high_risk():
    """A planner must not treat driving a physical output as it would a
    read. These are the first capabilities in the driver that can damage
    connected hardware."""
    from keysight34970.keywords.digital_keywords import CAPABILITY_METADATA

    for name in ("Write Digital Port", "Write Digital Port Bit", "Write Analog Output"):
        assert CAPABILITY_METADATA[name]["risk_level"] == "high", name
        assert "DRIVES" in CAPABILITY_METADATA[name]["notes"], name


def test_five_mixins_own_disjoint_state():
    from keysight34970.library import Keysight34970

    assert set(vars(Keysight34970())) == {
        "_connection",
        "_declared_cards",
        "_measurement_engine",
        "_scanner_engine",
        "_last_scan_result",
        "_temperature_engine",
        "_digital_engine",
    }


def test_digital_engine_guard_before_connection():
    from keysight34970.library import Keysight34970

    with pytest.raises(AssertionError, match="Connect To Instrument"):
        Keysight34970()._require_digital_engine()
