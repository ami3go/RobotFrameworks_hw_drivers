import logging

from keysight34970.logging_config import (
    LOGGER_NAME,
    configure_logging,
    get_logger,
)


def _reset_package_logger():
    logger = logging.getLogger(LOGGER_NAME)
    logger.handlers.clear()
    logger.filters.clear()
    logger.setLevel(logging.NOTSET)


def test_configure_logging_adds_handler_and_filter():
    _reset_package_logger()
    configure_logging(level=logging.DEBUG)

    logger = logging.getLogger(LOGGER_NAME)
    assert logger.level == logging.DEBUG
    assert len(logger.handlers) == 1
    assert len(logger.filters) == 1


def test_configure_logging_is_idempotent():
    _reset_package_logger()
    configure_logging()
    configure_logging()
    configure_logging()

    logger = logging.getLogger(LOGGER_NAME)
    assert len(logger.handlers) == 1, "handlers must not accumulate"
    assert len(logger.filters) == 1, "filters must not accumulate"


def test_instrument_field_defaults_when_absent(caplog):
    _reset_package_logger()
    configure_logging(level=logging.INFO, propagate=True)

    logger = logging.getLogger(LOGGER_NAME)
    with caplog.at_level(logging.INFO, logger=LOGGER_NAME):
        logger.info("message with no instrument context")

    record = caplog.records[-1]
    assert getattr(record, "instrument", None) == "-"


def test_get_logger_tags_records_with_alias(caplog):
    _reset_package_logger()
    configure_logging(level=logging.INFO, propagate=True)

    adapter = get_logger("daq1")
    with caplog.at_level(logging.INFO, logger=LOGGER_NAME):
        adapter.info("tagged message")

    record = caplog.records[-1]
    assert record.instrument == "daq1"


def test_propagate_defaults_to_false():
    _reset_package_logger()
    configure_logging()
    assert logging.getLogger(LOGGER_NAME).propagate is False
