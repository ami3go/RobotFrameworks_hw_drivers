"""Phase 3 Gate 3 extended features: monitoring and per-channel statistics."""

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from mock_instrument import MockScpiServer  # noqa: E402

from keysight34970.exceptions import ConfigurationError  # noqa: E402
from keysight34970.library import Keysight34970  # noqa: E402
from keysight34970.measurement.models import Unit  # noqa: E402


@pytest.fixture
def lib():
    server = MockScpiServer()
    server.start()
    library = Keysight34970()
    library.connect_to_instrument("34972A", "TCP", server.host, port=server.port)
    yield library
    try:
        library.disconnect_from_instrument()
    except Exception:
        pass
    server.stop()


# -- monitoring -----------------------------------------------------


def test_monitor_start_read_stop(lib):
    lib.configure_measurement("DCV", "(@101)")
    lib.start_monitoring_channel("101")
    assert lib.read_monitored_channel() == pytest.approx(1.01)
    lib.stop_monitoring()


def test_read_monitor_without_starting_fails(lib):
    with pytest.raises(Exception, match="No channel is being monitored"):
        lib.read_monitored_channel()


def test_stop_monitoring_is_safe_when_inactive(lib):
    lib.stop_monitoring()
    lib.stop_monitoring()


def test_monitor_rejects_switch_only_channel(lib):
    """A 34903A actuator channel cannot reach the DMM, so monitoring it
    would silently return nothing useful."""
    lib.set_installed_card(1, "34903A")
    lib.configure_measurement("DCV", "(@201)")  # force engine creation
    with pytest.raises(Exception, match="cannot be routed to the internal DMM"):
        lib.start_monitoring_channel("101")


def test_monitored_channel_tracked(lib):
    lib.configure_measurement("DCV", "(@102)")
    lib.start_monitoring_channel("102")
    engine = lib._require_scanner_engine()
    assert engine.monitored_channel.address == 102
    lib.stop_monitoring()
    assert engine.monitored_channel is None


# -- per-channel statistics -----------------------------------------


def test_channel_statistics_are_scoped_to_the_channel(lib):
    """Per-channel registers must not report the whole scan's spread."""
    lib.configure_measurement("DCV", "(@101,102)")
    lib.run_scan("(@101,102)", sweeps="3", timeout=5)

    ch101 = lib.get_channel_statistics("101")
    ch102 = lib.get_channel_statistics("102")

    assert ch101["count"] == 3
    assert ch102["count"] == 3
    assert ch101["maximum"] < ch102["minimum"]  # distinct channels
    assert ch101["span"] == pytest.approx(
        ch101["maximum"] - ch101["minimum"]
    )
    assert ch101["unit"] == "V"


def test_channel_statistics_differ_from_whole_scan_statistics(lib):
    lib.configure_measurement("DCV", "(@101,102)")
    lib.run_scan("(@101,102)", sweeps="3", timeout=5)

    overall = lib.get_instrument_statistics()
    ch101 = lib.get_channel_statistics("101")

    assert overall["count"] == 6
    assert ch101["count"] == 3


def test_channel_statistics_unit_unknown_when_unconfigured(lib):
    lib.configure_measurement("DCV", "(@101)")
    stats = lib.get_channel_statistics("105")
    assert stats["unit"] == Unit.UNKNOWN.value


def test_clear_statistics_is_callable(lib):
    lib.configure_measurement("DCV", "(@101)")
    lib.clear_instrument_statistics()


# -- fallback unit honesty (Gate 2 finding) -------------------------


def test_mixed_function_scan_does_not_mislabel_untagged_readings():
    """Closes a Gate 2 finding: an unattributable reading used to be
    tagged DC volts regardless of what it actually measured."""

    from keysight34970.config import ConnectionConfig, InstrumentModel, TransportKind
    from keysight34970.connection import Connection
    from keysight34970.measurement.channels import ChannelList
    from keysight34970.measurement.engine import ScpiMeasurementEngine
    from keysight34970.measurement.models import MeasurementConfig, MeasurementFunction
    from keysight34970.scanner.engine import ScpiScannerEngine
    from keysight34970.scanner.models import ScanConfig

    from .fakes import FakeTransport

    fake = FakeTransport(
        responses={"*IDN?": "Keysight,34972A,MY1,1.0", "FETC?": "+1.0E+00,+2.0E+00", "DATA:POIN?": "2"}
    )
    conn = Connection(
        ConnectionConfig(
            transport=TransportKind.TCP_SOCKET,
            model=InstrumentModel.DAQ_34972A,
            host="10.0.0.5",
        ),
        transport=fake,
    )
    conn.connect()
    measurement = ScpiMeasurementEngine(conn)
    measurement.configure(
        ChannelList.parse("(@101)"), MeasurementConfig(MeasurementFunction.DC_VOLTAGE)
    )
    measurement.configure(
        ChannelList.parse("(@102)"),
        MeasurementConfig(MeasurementFunction.RESISTANCE_2W),
    )

    scanner = ScpiScannerEngine(conn, measurement_engine=measurement)
    scanner.configure_scan(
        ScanConfig(
            channels=ChannelList.parse("(@101,102)"),
            include_channel=False,
            include_timestamp=False,
        )
    )
    result = scanner.fetch_readings()

    # Channels were not included in the response, so neither reading can
    # be attributed. Mixed functions mean the unit is genuinely unknown.
    assert all(r.unit is Unit.UNKNOWN for r in result.readings)


def test_single_function_scan_keeps_its_unit():
    from keysight34970.config import ConnectionConfig, InstrumentModel, TransportKind
    from keysight34970.connection import Connection
    from keysight34970.measurement.channels import ChannelList
    from keysight34970.measurement.engine import ScpiMeasurementEngine
    from keysight34970.measurement.models import MeasurementConfig, MeasurementFunction
    from keysight34970.scanner.engine import ScpiScannerEngine
    from keysight34970.scanner.models import ScanConfig

    from .fakes import FakeTransport

    fake = FakeTransport(
        responses={"*IDN?": "Keysight,34972A,MY1,1.0", "FETC?": "+1.0E+00,+2.0E+00", "DATA:POIN?": "2"}
    )
    conn = Connection(
        ConnectionConfig(
            transport=TransportKind.TCP_SOCKET,
            model=InstrumentModel.DAQ_34972A,
            host="10.0.0.5",
        ),
        transport=fake,
    )
    conn.connect()
    measurement = ScpiMeasurementEngine(conn)
    measurement.configure(
        ChannelList.parse("(@101,102)"),
        MeasurementConfig(MeasurementFunction.RESISTANCE_2W),
    )
    scanner = ScpiScannerEngine(conn, measurement_engine=measurement)
    scanner.configure_scan(
        ScanConfig(
            channels=ChannelList.parse("(@101,102)"),
            include_channel=False,
            include_timestamp=False,
        )
    )
    result = scanner.fetch_readings()
    assert all(r.unit is Unit.OHM for r in result.readings)


# -- fetched_at semantics (Gate 2 finding) --------------------------


def test_scan_result_timestamp_is_named_for_the_fetch():
    """Closes a Gate 2 finding: the field was called completed_at while
    being stamped at fetch time, which was a lie for a partial fetch."""

    from keysight34970.scanner.models import ScanResult

    assert "fetched_at" in ScanResult.__dataclass_fields__
    assert "completed_at" not in ScanResult.__dataclass_fields__


# -- DMM contention interlock (Gate 3 finding) ----------------------


def test_monitoring_refused_while_scan_running(lib):
    """Both claim the internal DMM and the instrument does not
    arbitrate; collecting data whose source is ambiguous is worse than
    a refusal."""
    lib.configure_measurement("DCV", "(@101,102)")
    lib.configure_scan("(@101,102)", sweeps="INF")
    lib.start_scan()
    try:
        with pytest.raises(Exception, match="while a scan is running"):
            lib.start_monitoring_channel("101")
    finally:
        lib.abort_scan()


def test_monitoring_allowed_after_abort(lib):
    lib.configure_measurement("DCV", "(@101)")
    lib.configure_scan("(@101)", sweeps="INF")
    lib.start_scan()
    lib.abort_scan()
    lib.start_monitoring_channel("101")
    lib.stop_monitoring()


def test_starting_a_scan_stops_monitoring(lib):
    """A scan is the more specific request; leaving a monitor running
    would corrupt it silently."""
    lib.configure_measurement("DCV", "(@101,102)")
    lib.start_monitoring_channel("101")
    engine = lib._require_scanner_engine()
    assert engine.monitored_channel is not None

    lib.run_scan("(@101,102)", sweeps="2", timeout=5)
    assert engine.monitored_channel is None


# -- coverage of remaining paths ------------------------------------


def test_trigger_count_rejects_float_and_bool():
    from keysight34970.scanner.models import TriggerCount

    for bad in (1.5, True, None, [1]):
        with pytest.raises(ConfigurationError, match="positive integer or INF"):
            TriggerCount(bad)


def test_scan_result_sweep_count_without_sweep_numbers():
    """Falls back to ceiling division when readings carry no sweep."""
    from keysight34970.measurement.channels import ChannelList
    from keysight34970.measurement.models import MeasurementFunction
    from keysight34970.scanner.models import ScanConfig, ScanResult
    from keysight34970.scanner.parsing import parse_scan_response

    readings = parse_scan_response(
        "+1.0E+00,+2.0E+00,+3.0E+00",
        MeasurementFunction.DC_VOLTAGE,
        include_timestamp=False,
        include_channel=False,
    )
    result = ScanResult(
        readings=readings, config=ScanConfig(channels=ChannelList.parse("(@101,102)"))
    )
    assert result.sweep_count == 2  # ceil(3/2)


def test_statistics_for_channel_rejects_overrange():
    from keysight34970.measurement.channels import ChannelList
    from keysight34970.measurement.models import MeasurementFunction
    from keysight34970.scanner.models import ScanConfig, ScanResult
    from keysight34970.scanner.parsing import parse_scan_response

    readings = parse_scan_response(
        "+9.9E+37,101", MeasurementFunction.DC_VOLTAGE, include_timestamp=False
    )
    result = ScanResult(
        readings=readings, config=ScanConfig(channels=ChannelList.parse("(@101)"))
    )
    with pytest.raises(ConfigurationError, match="over-range"):
        result.statistics_for_channel(101)


def test_estimated_duration_none_for_bus_trigger():
    from keysight34970.measurement.channels import ChannelList
    from keysight34970.scanner.models import ScanConfig, TriggerSource

    cfg = ScanConfig(
        channels=ChannelList.parse("(@101)"), trigger_source=TriggerSource.BUS
    )
    assert cfg.estimated_duration_s() is None


def test_monitor_without_measurement_engine_skips_card_check():
    """A scanner built without a measurement engine cannot know card
    types; it must not block monitoring on knowledge it lacks."""
    from keysight34970.config import ConnectionConfig, InstrumentModel, TransportKind
    from keysight34970.connection import Connection
    from keysight34970.scanner.engine import ScpiScannerEngine

    from .fakes import FakeTransport

    fake = FakeTransport(
        responses={"*IDN?": "Keysight,34972A,MY1,1.0", "ROUT:MON:DATA?": "+1.0E+00"}
    )
    conn = Connection(
        ConnectionConfig(
            transport=TransportKind.TCP_SOCKET,
            model=InstrumentModel.DAQ_34972A,
            host="10.0.0.5",
        ),
        transport=fake,
    )
    conn.connect()
    engine = ScpiScannerEngine(conn)
    engine.start_monitor("101")
    assert engine.read_monitor().value == 1.0


def test_monitoring_allowed_after_bounded_scan_completes(lib):
    """A finished bounded scan is not a running scan; refusing here
    would give a message claiming a scan was running when none was."""
    lib.configure_measurement("DCV", "(@101)")
    lib.run_scan("(@101)", sweeps="2", timeout=5)

    lib.start_monitoring_channel("101")
    assert lib.read_monitored_channel() > 0
    lib.stop_monitoring()


def test_wait_polls_adaptively_not_at_a_fixed_interval():
    """A fixed 50 ms poll added up to a full interval of latency after
    the scan had already finished. Short scans must not pay that."""
    from keysight34970.scanner import engine as engine_module

    assert engine_module._POLL_INITIAL_S < engine_module._POLL_MAX_S
    assert engine_module._POLL_BACKOFF > 1.0
    assert engine_module._POLL_INITIAL_S <= 0.005


def test_short_scan_completes_promptly(lib):
    """End-to-end guard on the above: a trivially short scan must not
    take anything like the maximum poll interval."""
    import time

    lib.configure_measurement("DCV", "(@101,102)")
    start = time.perf_counter()
    lib.run_scan("(@101,102)", sweeps="2", timeout=5)
    elapsed_ms = (time.perf_counter() - start) * 1000

    assert elapsed_ms < 40, (
        f"short scan took {elapsed_ms:.1f} ms; a fixed 50 ms poll interval "
        "would show up here"
    )
