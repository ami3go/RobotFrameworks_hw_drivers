"""Phase 5 Gate 2: SCPI digital engine and keywords."""

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from mock_instrument import MockScpiServer  # noqa: E402

from keysight34970.config import ConnectionConfig, InstrumentModel, TransportKind  # noqa: E402
from keysight34970.connection import Connection  # noqa: E402
from keysight34970.digital.engine import ScpiDigitalEngine  # noqa: E402
from keysight34970.digital.models import (  # noqa: E402
    EdgeSlope,
    InputThreshold,
    TotalizerConfig,
    TotalizerMode,
)
from keysight34970.exceptions import CommandError, ConfigurationError  # noqa: E402
from keysight34970.library import Keysight34970  # noqa: E402
from keysight34970.measurement.channels import CardType  # noqa: E402

from .fakes import FakeTransport  # noqa: E402


def make_engine(responses=None, cards=None):
    fake = FakeTransport(
        responses={"*IDN?": "Keysight,34972A,MY1,1.0", **(responses or {})}
    )
    conn = Connection(
        ConnectionConfig(
            transport=TransportKind.TCP_SOCKET,
            model=InstrumentModel.DAQ_34972A,
            host="10.0.0.5",
        ),
        transport=fake,
    )
    conn.connect()
    fake.sent.clear()
    return ScpiDigitalEngine(conn, cards=cards), fake


def sent(fake):
    return [c for c in fake.sent if c != "SYST:ERR?"]


@pytest.fixture
def lib():
    server = MockScpiServer()
    server.start()
    library = Keysight34970()
    library.connect_to_instrument("34972A", "TCP", server.host, port=server.port)
    yield library
    try:
        library.disconnect_from_instrument()
    except Exception:
        pass
    server.stop()


# -- digital ports --------------------------------------------------


def test_read_port_emits_expected_query():
    engine, fake = make_engine(responses={"SENS:DIG:DATA:BYTE? (@101)": "165"})
    state = engine.read_port(101)
    assert sent(fake) == ["SENS:DIG:DATA:BYTE? (@101)"]
    assert state.value == 165
    assert state.channel.address == 101


def test_write_port_emits_expected_command():
    engine, fake = make_engine()
    engine.write_port(101, 0b10100101)
    assert sent(fake) == ["SOUR:DIG:DATA:BYTE 165,(@101)"]


def test_write_port_validates_before_driving_anything():
    """An out-of-range value must be rejected before a line is driven."""
    engine, fake = make_engine()
    with pytest.raises(ConfigurationError, match="8 bits"):
        engine.write_port(101, 256)
    assert sent(fake) == []


def test_write_port_rejects_non_port_channel():
    engine, fake = make_engine()
    with pytest.raises(ConfigurationError, match="not a digital port"):
        engine.write_port(104, 1)
    assert sent(fake) == []


def test_read_port_rejects_non_port_channel():
    engine, _ = make_engine()
    with pytest.raises(ConfigurationError, match="not a digital port"):
        engine.read_port(103)


def test_write_bit_is_read_modify_write():
    engine, fake = make_engine(responses={"SENS:DIG:DATA:BYTE? (@101)": "0"})
    engine.write_port_bit(101, 3, True)
    assert sent(fake) == [
        "SENS:DIG:DATA:BYTE? (@101)",
        "SOUR:DIG:DATA:BYTE 8,(@101)",
    ]


def test_write_bit_preserves_other_bits():
    engine, fake = make_engine(responses={"SENS:DIG:DATA:BYTE? (@101)": "165"})
    engine.write_port_bit(101, 1, True)
    assert "SOUR:DIG:DATA:BYTE 167,(@101)" in sent(fake)


def test_write_bit_skips_the_write_when_already_correct():
    """Avoids driving lines for a no-op, which on an output matters
    more than the round trip saved."""
    engine, fake = make_engine(responses={"SENS:DIG:DATA:BYTE? (@101)": "8"})
    engine.write_port_bit(101, 3, True)
    assert not any("SOUR:DIG" in c for c in sent(fake))


# -- totalizer ------------------------------------------------------


def test_configure_totalizer_emits_type_and_slope():
    engine, fake = make_engine()
    engine.configure_totalizer(103, TotalizerConfig())
    assert sent(fake) == [
        "SENS:TOT:TYPE READ,(@103)",
        "SENS:TOT:SLOP POS,(@103)",
    ]


def test_configure_totalizer_with_threshold():
    engine, fake = make_engine()
    engine.configure_totalizer(
        103,
        TotalizerConfig(
            mode=TotalizerMode.READ_RESET,
            slope=EdgeSlope.NEGATIVE,
            threshold=InputThreshold.AC,
        ),
    )
    commands = sent(fake)
    assert "SENS:TOT:TYPE RRES,(@103)" in commands
    assert "SENS:TOT:SLOP NEG,(@103)" in commands
    assert "SENS:TOT:THR AC,(@103)" in commands


def test_threshold_omitted_sends_nothing():
    engine, fake = make_engine()
    engine.configure_totalizer(103, TotalizerConfig())
    assert not any("THR" in c for c in sent(fake))


def test_read_totalizer_flags_destructive_read():
    """The count is gone from the instrument; the returned object is the
    only copy, and the reading has to say so."""
    engine, _ = make_engine(responses={"SENS:TOT:DATA? (@103)": "4242"})
    engine.configure_totalizer(103, TotalizerConfig(mode=TotalizerMode.READ_RESET))
    reading = engine.read_totalizer(103)
    assert reading.count == 4242
    assert reading.was_reset_by_read


def test_read_totalizer_non_destructive_by_default():
    engine, _ = make_engine(responses={"SENS:TOT:DATA? (@103)": "7"})
    engine.configure_totalizer(103, TotalizerConfig())
    assert not engine.read_totalizer(103).was_reset_by_read


def test_read_totalizer_without_configuration_assumes_non_destructive():
    """Assuming destructive would falsely claim the count was consumed;
    assuming non-destructive at worst under-warns about a mode the
    driver did not set."""
    engine, _ = make_engine(responses={"SENS:TOT:DATA? (@103)": "7"})
    assert not engine.read_totalizer(103).was_reset_by_read


def test_totalizer_rejects_non_totalizer_channel():
    engine, _ = make_engine()
    with pytest.raises(ConfigurationError, match="not a totalizer"):
        engine.read_totalizer(101)


def test_clear_totalizer_emits_immediate_clear():
    engine, fake = make_engine()
    engine.clear_totalizer(103)
    assert sent(fake) == ["SENS:TOT:CLE:IMM (@103)"]


def test_near_wrap_flagged_on_high_counts():
    engine, _ = make_engine(responses={"SENS:TOT:DATA? (@103)": "67000000"})
    assert engine.read_totalizer(103).is_near_wrap


# -- analogue outputs -----------------------------------------------


def test_write_dac_emits_expected_command():
    engine, fake = make_engine()
    engine.write_dac(104, 5.25)
    assert sent(fake) == ["SOUR:VOLT 5.25,(@104)"]


def test_write_dac_rejects_out_of_range_before_driving():
    engine, fake = make_engine()
    with pytest.raises(ConfigurationError, match="clamping silently"):
        engine.write_dac(104, 15.0)
    assert sent(fake) == []


def test_write_dac_rejects_non_dac_channel():
    engine, fake = make_engine()
    with pytest.raises(ConfigurationError, match="not an analogue output"):
        engine.write_dac(101, 1.0)
    assert sent(fake) == []


def test_read_dac_setting_parses_scientific_notation():
    engine, _ = make_engine(responses={"SOUR:VOLT? (@104)": "+5.250000E+00"})
    assert engine.read_dac_setting(104).volts == pytest.approx(5.25)


def test_read_dac_setting_rejects_garbage():
    engine, _ = make_engine(responses={"SOUR:VOLT? (@104)": "NOT_A_VOLTAGE"})
    with pytest.raises(CommandError, match="Could not parse"):
        engine.read_dac_setting(104)


# -- card guard -----------------------------------------------------


def test_declared_wrong_card_blocks_digital_access():
    engine, fake = make_engine(cards={1: CardType.MUX_34901A})
    with pytest.raises(ConfigurationError, match="34907A multifunction"):
        engine.write_port(101, 1)
    assert sent(fake) == []


def test_declared_34907a_allows_access():
    engine, fake = make_engine(cards={1: CardType.MFM_34907A})
    engine.write_port(101, 1)
    assert sent(fake) == ["SOUR:DIG:DATA:BYTE 1,(@101)"]


def test_undeclared_slot_is_not_blocked():
    """The driver cannot discover cards; refusing everything undeclared
    would make the module unusable on a partially-described bench."""
    engine, fake = make_engine(cards={2: CardType.MUX_34901A})
    engine.write_port(101, 1)
    assert sent(fake)


def test_set_card_validates_slot():
    engine, _ = make_engine()
    with pytest.raises(ConfigurationError, match="slot must be 1-3"):
        engine.set_card(9, CardType.MFM_34907A)


# -- output tracking ------------------------------------------------


def test_written_outputs_records_every_drive():
    engine, _ = make_engine(responses={"SENS:DIG:DATA:BYTE? (@101)": "0"})
    engine.write_port(101, 5)
    engine.write_dac(104, 2.5)
    outputs = engine.written_outputs()
    assert len(outputs) == 2
    assert "@101" in str(outputs[0])
    assert "@104" in str(outputs[1])


def test_written_outputs_is_a_snapshot():
    engine, _ = make_engine()
    engine.write_dac(104, 1.0)
    snapshot = engine.written_outputs()
    engine.write_dac(105, 2.0)
    assert len(snapshot) == 1


def test_failed_write_is_not_recorded():
    engine, _ = make_engine()
    with pytest.raises(ConfigurationError):
        engine.write_dac(104, 99.0)
    assert engine.written_outputs() == ()


# -- integer parsing ------------------------------------------------


def test_parse_accepts_scientific_notation_for_counts():
    engine, _ = make_engine(responses={"SENS:TOT:DATA? (@103)": "+1.024000E+03"})
    assert engine.read_totalizer(103).count == 1024


def test_parse_rejects_fractional_count():
    engine, _ = make_engine(responses={"SENS:TOT:DATA? (@103)": "12.5"})
    with pytest.raises(CommandError, match="Expected an integer"):
        engine.read_totalizer(103)


def test_parse_rejects_empty_response():
    engine, _ = make_engine(responses={"SENS:DIG:DATA:BYTE? (@101)": ""})
    with pytest.raises(CommandError, match="empty response"):
        engine.read_port(101)


# -- keyword layer --------------------------------------------------


def test_port_round_trip_through_keywords(lib):
    lib.write_digital_port("101", "0b10100101")
    assert lib.read_digital_port("101") == 165
    assert lib.read_digital_port_bits("101") == "10100101"


@pytest.mark.parametrize("form,expected", [("165", 165), ("0b10100101", 165), ("0xA5", 165)])
def test_port_value_notations(lib, form, expected):
    lib.write_digital_port("101", form)
    assert lib.read_digital_port("101") == expected


def test_bad_port_notation_rejected(lib):
    with pytest.raises(AssertionError, match="must be an integer"):
        lib.write_digital_port("101", "ten")


def test_destructive_read_visible_through_keywords(lib):
    """The hazard has to be visible at the keyword layer, not only in
    the model: a second read returns 0, which is a plausible count."""
    lib.configure_totalizer("103", mode="READ_RESET")
    first = lib.read_totalizer_details("103")
    assert first["reset_by_read"] is True
    assert lib.read_totalizer("103") == 0


def test_non_destructive_read_preserves_count(lib):
    lib.configure_totalizer("103", mode="READ")
    first = lib.read_totalizer("103")
    assert lib.read_totalizer("103") == first


@pytest.mark.parametrize("alias", ["READ_RESET", "RESET", "RRES", "read_reset"])
def test_totalizer_mode_aliases(lib, alias):
    lib.configure_totalizer("103", mode=alias)


@pytest.mark.parametrize("alias", ["NEGATIVE", "NEG", "FALLING"])
def test_slope_aliases(lib, alias):
    lib.configure_totalizer("103", slope=alias)


def test_bad_mode_lists_valid_options(lib):
    with pytest.raises(AssertionError, match="mode must be one of"):
        lib.configure_totalizer("103", mode="SOMETIMES")


def test_analog_output_round_trip(lib):
    lib.write_analog_output("104", 5.25)
    assert lib.read_analog_output_setting("104") == pytest.approx(5.25)


def test_driven_outputs_reported_for_teardown(lib):
    lib.write_digital_port("101", "3")
    lib.write_analog_output("104", 1.5)
    driven = lib.get_driven_outputs()
    assert len(driven) == 2
    assert any("@104" in d for d in driven)


def test_digital_keywords_require_connection():
    library = Keysight34970()
    for call in (
        lambda: library.read_digital_port("101"),
        lambda: library.write_digital_port("101", "1"),
        lambda: library.read_totalizer("103"),
        lambda: library.write_analog_output("104", 1.0),
        lambda: library.get_driven_outputs(),
    ):
        with pytest.raises(AssertionError, match="No instrument connection"):
            call()


def test_digital_state_cleared_on_disconnect(lib):
    lib.write_analog_output("104", 1.0)
    assert lib.get_driven_outputs()
    lib.disconnect_from_instrument()
    with pytest.raises(AssertionError, match="No instrument connection"):
        lib.get_driven_outputs()


# -- session reset hook declaration ---------------------------------


def test_every_mixin_declares_its_reset_hook():
    """Regression guard. DigitalKeywords defined _reset_digital_state
    and omitted the SESSION_RESET_HOOKS declaration, so the engine --
    and the record of every output driven -- survived a disconnect. The
    existing validator could not catch it: nothing was declared, so
    nothing was declared wrongly."""

    for owner in Keysight34970.__mro__:
        declared = set(owner.__dict__.get("SESSION_RESET_HOOKS", ()))
        defined = {
            name
            for name, value in owner.__dict__.items()
            if name.startswith("_reset_")
            and name.endswith("_state")
            and callable(value)
        }
        assert defined <= declared, (
            f"{owner.__name__} defines {sorted(defined - declared)} "
            "without declaring them in SESSION_RESET_HOOKS"
        )


def test_undeclared_hook_fails_at_construction():
    class Broken(Keysight34970):
        def _reset_broken_state(self):  # pragma: no cover - never called
            pass

    with pytest.raises(AttributeError, match="does not list it"):
        Broken()


def test_misspelled_hook_still_fails_at_construction():
    class Typo(Keysight34970):
        SESSION_RESET_HOOKS = ("_reset_nonexistent_state",)

    with pytest.raises(AttributeError, match="not a callable attribute"):
        Typo()
