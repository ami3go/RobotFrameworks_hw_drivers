"""Phase 4 Gate 2: temperature engine and keywords."""

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from mock_instrument import MockScpiServer  # noqa: E402

from keysight34970.config import ConnectionConfig, InstrumentModel, TransportKind  # noqa: E402
from keysight34970.connection import Connection  # noqa: E402
from keysight34970.exceptions import ConfigurationError  # noqa: E402
from keysight34970.library import Keysight34970  # noqa: E402
from keysight34970.measurement.channels import CardType, ChannelList  # noqa: E402
from keysight34970.measurement.engine import ScpiMeasurementEngine  # noqa: E402
from keysight34970.measurement.models import Unit  # noqa: E402
from keysight34970.temperature.engine import ScpiTemperatureEngine  # noqa: E402
from keysight34970.temperature.models import (  # noqa: E402
    ReferenceJunction,
    TemperatureConfig,
    TemperatureUnit,
    ThermocoupleType,
    TransducerType,
)

from .fakes import FakeTransport  # noqa: E402


def make_engine(responses=None, cards=None):
    fake = FakeTransport(
        responses={"*IDN?": "Keysight,34972A,MY1,1.0", **(responses or {})}
    )
    conn = Connection(
        ConnectionConfig(
            transport=TransportKind.TCP_SOCKET,
            model=InstrumentModel.DAQ_34972A,
            host="10.0.0.5",
        ),
        transport=fake,
    )
    conn.connect()
    fake.sent.clear()
    measurement = ScpiMeasurementEngine(conn, cards=cards) if cards is not None else None
    return ScpiTemperatureEngine(conn, measurement_engine=measurement), fake


def sent(fake):
    return [c for c in fake.sent if c != "SYST:ERR?"]


@pytest.fixture
def lib():
    server = MockScpiServer()
    server.start()
    library = Keysight34970()
    library.connect_to_instrument("34972A", "TCP", server.host, port=server.port)
    yield library
    try:
        library.disconnect_from_instrument()
    except Exception:
        pass
    server.stop()


# -- SCPI emission --------------------------------------------------


def test_thermocouple_configuration_order():
    """CONF:TEMP must precede SENS:TEMP:TRAN:*, which are keyed by the
    transducer the instrument does not yet know about otherwise."""
    engine, fake = make_engine()
    engine.configure(
        ChannelList.parse("(@101)"),
        TemperatureConfig(
            TransducerType.THERMOCOUPLE,
            thermocouple_type=ThermocoupleType.K,
            reference_junction=ReferenceJunction.INTERNAL,
        ),
    )
    commands = sent(fake)
    assert commands[0] == "CONF:TEMP TC,K,(@101)"
    assert "SENS:TEMP:TRAN:TC:RJUN:TYPE INT,(@101)" in commands
    assert commands[-1] == "UNIT:TEMP C,(@101)"


def test_fixed_reference_emits_temperature():
    engine, fake = make_engine()
    engine.configure(
        ChannelList.parse("(@101)"),
        TemperatureConfig(
            TransducerType.THERMOCOUPLE,
            thermocouple_type=ThermocoupleType.J,
            reference_junction=ReferenceJunction.FIXED,
            fixed_reference_c=0.0,
        ),
    )
    commands = sent(fake)
    assert "SENS:TEMP:TRAN:TC:RJUN:TYPE FIX,(@101)" in commands
    assert "SENS:TEMP:TRAN:TC:RJUN 0,(@101)" in commands


def test_rtd_emits_nominal_and_alpha():
    engine, fake = make_engine()
    engine.configure(
        ChannelList.parse("(@101)"),
        TemperatureConfig(
            TransducerType.RTD, rtd_nominal_ohms=100.0, rtd_alpha=0.00385
        ),
    )
    commands = sent(fake)
    assert commands[0] == "CONF:TEMP RTD,100,(@101)"
    assert "SENS:TEMP:TRAN:RTD:RES 100,(@101)" in commands
    assert "SENS:TEMP:TRAN:RTD:ALPH 0.00385,(@101)" in commands


def test_four_wire_rtd_uses_frtd():
    engine, fake = make_engine()
    engine.configure(
        ChannelList.parse("(@101)"),
        TemperatureConfig(TransducerType.RTD_4WIRE, rtd_nominal_ohms=100.0),
    )
    assert sent(fake)[0].startswith("CONF:TEMP FRTD,")


def test_thermistor_emits_nominal():
    engine, fake = make_engine()
    engine.configure(
        ChannelList.parse("(@101)"),
        TemperatureConfig(
            TransducerType.THERMISTOR, thermistor_nominal_ohms=5000.0
        ),
    )
    assert sent(fake)[0] == "CONF:TEMP THER,5000,(@101)"


def test_unit_is_applied_per_channel():
    engine, fake = make_engine()
    engine.configure(
        ChannelList.parse("(@101)"),
        TemperatureConfig(
            TransducerType.THERMOCOUPLE,
            thermocouple_type=ThermocoupleType.T,
            unit=TemperatureUnit.KELVIN,
        ),
    )
    assert "UNIT:TEMP K,(@101)" in sent(fake)


def test_channels_normalised_ascending():
    """Same correctness requirement as Phase 2: readings are matched to
    channels positionally and the instrument scans ascending."""
    engine, fake = make_engine()
    engine.configure(
        ChannelList.parse("(@105,101)"),
        TemperatureConfig(
            TransducerType.THERMOCOUPLE, thermocouple_type=ThermocoupleType.K
        ),
    )
    assert sent(fake)[0] == "CONF:TEMP TC,K,(@101,105)"


# -- validation -----------------------------------------------------


def test_empty_channel_list_rejected():
    engine, _ = make_engine()
    with pytest.raises(ConfigurationError, match="empty channel list"):
        engine.configure(
            ChannelList(),
            TemperatureConfig(
                TransducerType.THERMOCOUPLE, thermocouple_type=ThermocoupleType.K
            ),
        )


def test_switch_only_card_rejected():
    engine, fake = make_engine(cards={1: CardType.ACT_34903A})
    with pytest.raises(ConfigurationError, match="cannot be routed to the internal DMM"):
        engine.configure(
            ChannelList.parse("(@101)"),
            TemperatureConfig(
                TransducerType.THERMOCOUPLE, thermocouple_type=ThermocoupleType.K
            ),
        )
    assert sent(fake) == []


def test_four_wire_rtd_pair_conflict_rejected():
    engine, _ = make_engine()
    engine.configure(
        ChannelList.parse("(@111)"),
        TemperatureConfig(
            TransducerType.THERMOCOUPLE, thermocouple_type=ThermocoupleType.K
        ),
    )
    with pytest.raises(ConfigurationError, match="already configured"):
        engine.configure(
            ChannelList.parse("(@101)"),
            TemperatureConfig(TransducerType.RTD_4WIRE),
        )


def test_four_wire_pair_out_of_range_rejected():
    engine, _ = make_engine(cards={1: CardType.MUX_34901A})
    with pytest.raises(ConfigurationError, match="does not exist on the 34901A"):
        engine.configure(
            ChannelList.parse("(@115)"),
            TemperatureConfig(TransducerType.RTD_4WIRE),
        )


def test_read_unconfigured_channel_refused():
    engine, _ = make_engine()
    with pytest.raises(ConfigurationError, match="not configured for temperature"):
        engine.read(ChannelList.parse("(@101)"))


def test_read_without_configuration_refused():
    engine, _ = make_engine()
    with pytest.raises(ConfigurationError, match="No temperature channels"):
        engine.read()


# -- units travel with readings -------------------------------------


def test_reading_carries_the_configured_unit(lib):
    """Phase 2 hardcoded TEMPERATURE to Celsius; that was the bug this
    phase exists to fix."""
    lib.configure_thermocouple("(@101)", "K", unit="F")
    rows = lib.read_temperature_details()
    assert rows[0]["unit"] == "degF"


def test_mixed_units_across_channels_are_each_correct(lib):
    """A single unit for the whole response would mislabel some."""
    lib.configure_thermocouple("(@101)", "K", unit="C")
    lib.configure_thermocouple("(@102)", "K", unit="F")
    rows = lib.read_temperature_details()
    units = {r["channel"]: r["unit"] for r in rows}
    assert units["101"] == "degC"
    assert units["102"] == "degF"


def test_set_unit_updates_driver_record(lib):
    lib.configure_thermocouple("(@101)", "K", unit="C")
    lib.set_temperature_unit("K")
    assert "in K" in lib.get_temperature_configuration("101")
    rows = lib.read_temperature_details()
    assert rows[0]["unit"] == "K"


def test_reference_junction_is_always_celsius(lib):
    engine = lib._require_temperature_engine()
    assert engine.read_reference_junction().unit is Unit.CELSIUS


# -- keywords -------------------------------------------------------


def test_thermocouple_requires_explicit_type(lib):
    with pytest.raises(AssertionError, match="thermocouple type is required"):
        lib.configure_thermocouple("(@101)", "")


def test_invalid_thermocouple_type_rejected(lib):
    with pytest.raises(AssertionError, match="Invalid thermocouple type"):
        lib.configure_thermocouple("(@101)", "Z")


def test_all_alloys_accepted_via_keyword(lib):
    for alloy in "BEJKNRST":
        lib.configure_thermocouple("(@101)", alloy)
        assert f"type {alloy} thermocouple" in lib.get_temperature_configuration("101")


def test_thermistor_keyword_rejects_nonstandard(lib):
    with pytest.raises(Exception, match="not a standard value"):
        lib.configure_thermistor("(@101)", nominal="3000")


def test_rtd_four_wire_keyword(lib):
    lib.configure_rtd("(@101)", four_wire=True)
    assert "4-wire RTD" in lib.get_temperature_configuration("101")


def test_temperature_keywords_require_connection():
    library = Keysight34970()
    with pytest.raises(AssertionError, match="No instrument connection"):
        library.read_temperature()


def test_disconnect_clears_temperature_state(lib):
    lib.configure_thermocouple("(@101)", "K")
    assert lib.get_temperature_configuration("101")
    lib.disconnect_from_instrument()
    with pytest.raises(AssertionError, match="No instrument connection"):
        lib.get_temperature_configuration("101")


def test_get_configuration_empty_for_unconfigured(lib):
    lib.configure_thermocouple("(@101)", "K")
    assert lib.get_temperature_configuration("105") == ""


# -- assertions and plausibility ------------------------------------


def test_temperature_within_range_passes(lib):
    lib.configure_thermocouple("(@101)", "K")
    value = lib.temperature_should_be_within("101", 0, 100)
    assert 0 <= value <= 100


def test_temperature_outside_range_fails(lib):
    lib.configure_thermocouple("(@101)", "K")
    with pytest.raises(AssertionError, match="outside"):
        lib.temperature_should_be_within("101", 500, 600)


def test_temperature_within_rejects_multiple_channels(lib):
    lib.configure_thermocouple("(@101,102)", "K")
    with pytest.raises(AssertionError, match="exactly one channel"):
        lib.temperature_should_be_within("(@101,102)", 0, 100)


def test_implausible_reading_flagged():
    """An open junction returns a wild value that would otherwise be
    recorded as data."""
    engine, _ = make_engine(responses={"READ?": "+5.00000000E+03"})
    engine.configure(
        ChannelList.parse("(@101)"),
        TemperatureConfig(
            TransducerType.THERMISTOR, thermistor_nominal_ohms=5000.0
        ),
    )
    readings = list(engine.read())
    assert engine.implausible_readings(readings)


def test_plausible_reading_not_flagged():
    engine, _ = make_engine(responses={"READ?": "+2.50000000E+01"})
    engine.configure(
        ChannelList.parse("(@101)"),
        TemperatureConfig(
            TransducerType.THERMISTOR, thermistor_nominal_ohms=5000.0
        ),
    )
    assert engine.implausible_readings(list(engine.read())) == []


def test_temperature_channels_are_visible_to_scanning(lib):
    """A temperature channel in a scan list must be tagged TEMPERATURE,
    not treated as unconfigured."""
    lib.configure_thermocouple("(@101,102)", "K")
    assert lib.get_configured_function("101") == "TEMP"
