"""
Enforces RFDS-017 conformance rules for ai/ai_contract.yaml.

The contract is hand-authored through Phases 1-9 (Phase 10 automates
generation), which makes drift the main risk: a keyword added or
renamed without a matching contract update would silently mislead any
AI planner consuming it. These tests make that drift a build failure.
"""

import hashlib
import json
from pathlib import Path

import pytest

yaml = pytest.importorskip("yaml")

from keysight34970 import __version__  # noqa: E402
from keysight34970.library import Keysight34970  # noqa: E402

AI_DIR = Path(__file__).resolve().parents[2] / "ai"
CONTRACT_PATH = AI_DIR / "ai_contract.yaml"
LOCK_PATH = AI_DIR / "ai_contract.lock"

REQUIRED_SECTIONS = [
    "identity",
    "mental_model",
    "state_machine",
    "resources",
    "dependencies",
    "capabilities",
    "error_catalogue",
    "safety_rules",
    "verification_objectives",
    "setup_teardown_contract",
    "limitations",
    "planning_hints",
    "unknown_handling",
    "conformance_rules",
]

# RFDS-017 "Capability Requirements": each Robot keyword SHALL define
# every one of these. The earlier version of this list held only six of
# them, so the suite reported the contract conformant while 58 of 59
# capabilities were missing mandated fields -- the check agreed with the
# artifact it was checking, and neither agreed with the spec.
REQUIRED_CAPABILITY_FIELDS = [
    "signature",
    "purpose",
    "inputs",
    "outputs",
    "preconditions",
    "postconditions",
    "side_effects",
    "risk_level",
    "timing",
    "stabilization_delay",
    "retry_policy",
    "errors",
    "exclusive_resources",
]


@pytest.fixture(scope="module")
def contract():
    return yaml.safe_load(CONTRACT_PATH.read_text(encoding="utf-8"))


@pytest.fixture(scope="module")
def lock():
    return json.loads(LOCK_PATH.read_text(encoding="utf-8"))


def test_contract_files_exist():
    assert CONTRACT_PATH.is_file(), "ai/ai_contract.yaml is required by RFDS-017"
    assert LOCK_PATH.is_file(), "ai/ai_contract.lock is required by RFDS-017"


def test_all_mandatory_sections_present(contract):
    missing = [s for s in REQUIRED_SECTIONS if s not in contract]
    assert not missing, f"RFDS-017 mandatory sections missing: {missing}"


def test_capabilities_match_implementation_exactly(contract):
    """The core conformance rule: a planner must never be told about a
    keyword that doesn't exist, nor miss one that does."""

    contract_caps = {c["name"] for c in contract["capabilities"]}
    implemented = set(Keysight34970.get_capability_metadata().keys())

    assert contract_caps == implemented, (
        f"in contract only: {sorted(contract_caps - implemented)}; "
        f"in code only: {sorted(implemented - contract_caps)}"
    )


def test_capabilities_match_robot_discovered_keywords(contract):
    """Stronger than matching CAPABILITY_METADATA: validates against the
    keywords Robot Framework actually exposes.

    Regression guard. `get_capability_metadata()` was silently exposed
    as a keyword named "Get Capability Metadata" from Phase 1 Gate 3
    until Phase 2 Gate 1, because every conformance check compared the
    contract to CAPABILITY_METADATA -- and the two agreed with each
    other while both disagreeing with reality. Any public method added
    to the library or a mixin becomes a keyword unless marked
    @not_keyword.
    """

    from robot.running.testlibraries import TestLibrary

    library = TestLibrary.from_name("keysight34970.Keysight34970")
    discovered = {kw.name for kw in library.keywords}
    contract_caps = {c["name"] for c in contract["capabilities"]}

    assert discovered == contract_caps, (
        f"Robot exposes but contract omits: {sorted(discovered - contract_caps)}; "
        f"contract declares but Robot lacks: {sorted(contract_caps - discovered)}"
    )


def test_every_capability_has_required_fields(contract):
    for capability in contract["capabilities"]:
        for field in REQUIRED_CAPABILITY_FIELDS:
            assert field in capability, (
                f"capability {capability['name']!r} is missing {field!r}"
            )


def test_risk_levels_agree_with_capability_metadata(contract):
    metadata = Keysight34970.get_capability_metadata()
    for capability in contract["capabilities"]:
        expected = metadata[capability["name"]]["risk_level"]
        assert capability["risk_level"] == expected, (
            f"{capability['name']}: contract says {capability['risk_level']!r}, "
            f"CAPABILITY_METADATA says {expected!r}"
        )


def test_exclusive_resources_agree_with_capability_metadata(contract):
    metadata = Keysight34970.get_capability_metadata()
    for capability in contract["capabilities"]:
        expected = set(metadata[capability["name"]]["exclusive_resources"])
        actual = set(capability["exclusive_resources"])
        assert actual == expected, f"{capability['name']}: {actual} != {expected}"


def test_driver_version_matches_package(contract):
    assert contract["identity"]["driver_version"] == __version__


def test_state_machine_matches_implementation(contract):
    from keysight34970.connection import ConnectionState

    declared = set(contract["state_machine"]["states"])
    actual = {state.name for state in ConnectionState}
    assert declared == actual


def test_robot_library_scope_matches_implementation(contract):
    assert contract["identity"]["robot_library_scope"] == (
        Keysight34970.ROBOT_LIBRARY_SCOPE
    )


def test_error_catalogue_names_are_real_exceptions(contract):
    import keysight34970.exceptions as exc_module

    for entry in contract["error_catalogue"]:
        assert hasattr(exc_module, entry["name"]), (
            f"error_catalogue lists {entry['name']!r}, which does not exist"
        )


def test_lock_file_hash_matches_contract(lock):
    digest = hashlib.sha256(CONTRACT_PATH.read_bytes()).hexdigest()
    assert lock["contract_sha256"] == digest, (
        "ai_contract.lock is stale - regenerate it after editing the contract"
    )


def test_lock_file_agrees_with_contract(contract, lock):
    assert lock["driver_version"] == contract["identity"]["driver_version"]
    assert lock["contract_revision"] == contract["contract_revision"]
    assert lock["capability_count"] == len(contract["capabilities"])
    assert sorted(lock["capabilities"]) == sorted(
        c["name"] for c in contract["capabilities"]
    )


def test_partial_scope_is_declared(contract):
    """A partial contract must say so, or a planner will assume the
    absence of a capability means the instrument lacks it."""

    conformance = " ".join(contract["conformance_rules"]).lower()
    assert "partial" in conformance

    status = contract["identity"]["phase_status"]
    completed = status["completed_phases"]
    assert completed, "completed_phases must not be empty"
    assert completed == list(range(1, len(completed) + 1)), (
        f"completed_phases {completed} is not a contiguous run from 1; "
        "a phase appears to have been skipped"
    )
    assert max(completed) < status["total_phases"], (
        "contract still declares itself partial while claiming all phases "
        "are complete"
    )


def test_required_field_list_matches_the_spec(contract):
    """Guards the guard.

    RFDS-017 section "Capability Requirements" enumerates thirteen
    fields. If this list is ever trimmed, every other conformance test
    silently weakens, which is exactly how 58 non-conformant
    capabilities passed review.
    """

    assert len(REQUIRED_CAPABILITY_FIELDS) == 13
    for field in ("stabilization_delay", "retry_policy", "postconditions"):
        assert field in REQUIRED_CAPABILITY_FIELDS


def test_destructive_capabilities_declare_retry_unsafe(contract):
    """A capability that consumes or destroys state must say so, or a
    planner will retry it after a timeout and destroy the evidence."""

    must_not_retry = {
        "Read Totalizer",
        "Clear Totalizer",
        "Drain Instrument Error Queue",
        "Write Digital Port",
        "Write Analog Output",
        "Return Outputs To Safe State",
        "Reset Instrument",
    }
    by_name = {c["name"]: c for c in contract["capabilities"]}

    for name in must_not_retry:
        policy = by_name[name]["retry_policy"]
        assert isinstance(policy, dict), f"{name}: retry_policy must be structured"
        assert policy["safe_to_retry"] is False, f"{name} must be marked unsafe to retry"
        assert policy.get("reason"), f"{name} must say why"


def test_high_risk_capabilities_declare_side_effects(contract):
    """Anything that can damage hardware must state what it does."""

    for cap in contract["capabilities"]:
        if cap["risk_level"] == "high":
            assert cap["side_effects"], (
                f"{cap['name']} is high risk but declares no side effects"
            )
