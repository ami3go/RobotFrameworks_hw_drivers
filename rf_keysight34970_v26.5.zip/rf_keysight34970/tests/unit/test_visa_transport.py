import builtins
from unittest.mock import MagicMock, patch

import pyvisa
import pytest

from keysight34970.exceptions import ConnectionError34970, TransportError
from keysight34970.transport.visa_transport import VisaTransport


def _visa_io_error(status_code) -> pyvisa.errors.VisaIOError:
    return pyvisa.errors.VisaIOError(status_code)


def test_resource_not_found_translated_to_connection_error():
    transport = VisaTransport("GPIB0::99::INSTR", timeout_s=1.0)

    fake_rm = MagicMock()
    fake_rm.open_resource.side_effect = _visa_io_error(
        pyvisa.constants.StatusCode.error_resource_not_found
    )

    with patch("pyvisa.ResourceManager", return_value=fake_rm):
        with pytest.raises(ConnectionError34970, match="Cannot open VISA resource"):
            transport.open()


def test_resource_busy_translated_to_connection_error():
    transport = VisaTransport("GPIB0::9::INSTR", timeout_s=1.0)

    fake_rm = MagicMock()
    fake_rm.open_resource.side_effect = _visa_io_error(
        pyvisa.constants.StatusCode.error_resource_busy
    )

    with patch("pyvisa.ResourceManager", return_value=fake_rm):
        with pytest.raises(ConnectionError34970, match="already be held open"):
            transport.open()


def test_generic_visa_io_error_stays_transport_error():
    transport = VisaTransport("GPIB0::9::INSTR", timeout_s=1.0)

    fake_rm = MagicMock()
    fake_rm.open_resource.side_effect = _visa_io_error(
        pyvisa.constants.StatusCode.error_system_error
    )

    with patch("pyvisa.ResourceManager", return_value=fake_rm):
        with pytest.raises(TransportError):
            transport.open()


def test_successful_open_sets_timeout_in_milliseconds():
    transport = VisaTransport("GPIB0::9::INSTR", timeout_s=2.5)

    fake_resource = MagicMock()
    fake_rm = MagicMock()
    fake_rm.open_resource.return_value = fake_resource

    with patch("pyvisa.ResourceManager", return_value=fake_rm):
        transport.open()

    assert fake_resource.timeout == 2500.0
    assert transport.is_open


def test_query_timeout_translated():
    transport = VisaTransport("GPIB0::9::INSTR", timeout_s=1.0)

    fake_resource = MagicMock()
    fake_resource.query.side_effect = _visa_io_error(
        pyvisa.constants.StatusCode.error_timeout
    )
    fake_rm = MagicMock()
    fake_rm.open_resource.return_value = fake_resource

    with patch("pyvisa.ResourceManager", return_value=fake_rm):
        transport.open()
        from keysight34970.exceptions import TimeoutError34970

        with pytest.raises(TimeoutError34970):
            transport.query("*IDN?")


def _open_with_fake_resource(transport, fake_resource):
    fake_rm = MagicMock()
    fake_rm.open_resource.return_value = fake_resource
    with patch("pyvisa.ResourceManager", return_value=fake_rm):
        transport.open()


def test_write_and_query_round_trip():
    transport = VisaTransport("GPIB0::9::INSTR", timeout_s=1.0)
    fake_resource = MagicMock()
    fake_resource.query.return_value = "  Keysight,34972A,MY1,1.0  \n"
    _open_with_fake_resource(transport, fake_resource)

    transport.write("*CLS")
    fake_resource.write.assert_called_once_with("*CLS")

    # Response must be stripped of surrounding whitespace/terminators.
    assert transport.query("*IDN?") == "Keysight,34972A,MY1,1.0"


def test_write_timeout_translated():
    from keysight34970.exceptions import TimeoutError34970

    transport = VisaTransport("GPIB0::9::INSTR", timeout_s=1.0)
    fake_resource = MagicMock()
    fake_resource.write.side_effect = _visa_io_error(
        pyvisa.constants.StatusCode.error_timeout
    )
    _open_with_fake_resource(transport, fake_resource)

    with pytest.raises(TimeoutError34970):
        transport.write("*CLS")


def test_non_timeout_write_error_is_transport_error():
    transport = VisaTransport("GPIB0::9::INSTR", timeout_s=1.0)
    fake_resource = MagicMock()
    fake_resource.write.side_effect = _visa_io_error(
        pyvisa.constants.StatusCode.error_connection_lost
    )
    _open_with_fake_resource(transport, fake_resource)

    with pytest.raises(TransportError, match="VISA I/O error"):
        transport.write("*CLS")


def test_write_and_query_before_open_raise():
    transport = VisaTransport("GPIB0::9::INSTR", timeout_s=1.0)

    with pytest.raises(TransportError, match="not open"):
        transport.write("*CLS")
    with pytest.raises(TransportError, match="not open"):
        transport.query("*IDN?")


def test_close_is_idempotent_and_safe_before_open():
    transport = VisaTransport("GPIB0::9::INSTR", timeout_s=1.0)
    transport.close()  # before open - must not raise

    fake_resource = MagicMock()
    _open_with_fake_resource(transport, fake_resource)
    assert transport.is_open

    transport.close()
    transport.close()  # twice - must not raise
    assert not transport.is_open
    fake_resource.close.assert_called_once()


def test_close_tolerates_failing_underlying_close():
    transport = VisaTransport("GPIB0::9::INSTR", timeout_s=1.0)
    fake_resource = MagicMock()
    fake_resource.close.side_effect = RuntimeError("driver blew up")
    _open_with_fake_resource(transport, fake_resource)

    transport.close()  # best-effort: must swallow and still mark closed
    assert not transport.is_open


def test_open_is_idempotent():
    transport = VisaTransport("GPIB0::9::INSTR", timeout_s=1.0)
    fake_resource = MagicMock()
    fake_rm = MagicMock()
    fake_rm.open_resource.return_value = fake_resource

    with patch("pyvisa.ResourceManager", return_value=fake_rm):
        transport.open()
        transport.open()  # no-op

    assert fake_rm.open_resource.call_count == 1


def test_non_visa_exception_during_open_is_transport_error():
    transport = VisaTransport("GPIB0::9::INSTR", timeout_s=1.0)
    fake_rm = MagicMock()
    fake_rm.open_resource.side_effect = RuntimeError("backend exploded")

    with patch("pyvisa.ResourceManager", return_value=fake_rm):
        with pytest.raises(TransportError, match="Failed to open VISA resource"):
            transport.open()


def test_set_timeout_rejects_non_positive_and_applies_when_open():
    transport = VisaTransport("GPIB0::9::INSTR", timeout_s=1.0)

    with pytest.raises(TransportError, match="must be > 0"):
        transport.set_timeout(-1)

    transport.set_timeout(3.0)  # before open: stored for next open

    fake_resource = MagicMock()
    _open_with_fake_resource(transport, fake_resource)
    assert fake_resource.timeout == 3000.0

    transport.set_timeout(4.0)  # after open: applied immediately
    assert fake_resource.timeout == 4000.0


def test_missing_pyvisa_raises_configuration_error():
    """If pyvisa isn't installed, open() must give an actionable
    ConfigurationError naming the install command, not an ImportError."""

    from keysight34970.exceptions import ConfigurationError

    transport = VisaTransport("GPIB0::9::INSTR", timeout_s=1.0)

    real_import = builtins.__import__

    def _fake_import(name, *args, **kwargs):
        if name == "pyvisa":
            raise ImportError("No module named 'pyvisa'")
        return real_import(name, *args, **kwargs)

    with patch.object(builtins, "__import__", side_effect=_fake_import):
        with pytest.raises(ConfigurationError, match="pip install pyvisa"):
            transport.open()
