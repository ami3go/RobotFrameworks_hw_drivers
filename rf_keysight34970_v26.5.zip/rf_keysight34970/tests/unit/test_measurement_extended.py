"""Tests for Phase 2 Gate 3 extended features."""

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from mock_instrument import MockScpiServer  # noqa: E402

from keysight34970.exceptions import ConfigurationError  # noqa: E402
from keysight34970.library import Keysight34970  # noqa: E402
from keysight34970.measurement.channels import (  # noqa: E402
    CardType,
    ChannelId,
    ChannelList,
)
from keysight34970.measurement.models import (  # noqa: E402
    AcquisitionSettings,
    AutoZero,
    InputImpedance,
    MeasurementConfig,
    MeasurementFunction,
    Nplc,
)

from .test_measurement_engine import make_engine, sent_commands  # noqa: E402


@pytest.fixture
def lib():
    server = MockScpiServer()
    server.start()
    library = Keysight34970()
    library.connect_to_instrument("34972A", "TCP", server.host, port=server.port)
    yield library
    try:
        library.disconnect_from_instrument()
    except Exception:
        pass
    server.stop()


# -- NPLC semantics -------------------------------------------------


@pytest.mark.parametrize(
    "nplc,rejects",
    [
        (Nplc.N_0_02, False),
        (Nplc.N_0_2, False),
        (Nplc.N_1, True),
        (Nplc.N_10, True),
        (Nplc.N_200, True),
        (Nplc.MAX, True),
        (Nplc.MIN, False),
    ],
)
def test_line_noise_rejection_threshold(nplc, rejects):
    """1 NPLC is the threshold for mains rejection; below it there is
    none. Making this queryable keeps the trade-off explicit."""
    assert nplc.rejects_line_noise is rejects


def test_nplc_rejected_for_frequency():
    with pytest.raises(ConfigurationError, match="NPLC does not apply"):
        MeasurementConfig(
            MeasurementFunction.FREQUENCY,
            acquisition=AcquisitionSettings(nplc=Nplc.N_1),
        )


def test_nplc_rejected_for_continuity_and_diode():
    for function in (MeasurementFunction.CONTINUITY, MeasurementFunction.DIODE):
        with pytest.raises(ConfigurationError, match="NPLC does not apply"):
            MeasurementConfig(
                function, acquisition=AcquisitionSettings(nplc=Nplc.N_1)
            )


def test_input_impedance_only_for_dc_voltage():
    with pytest.raises(ConfigurationError, match="only to DC voltage"):
        MeasurementConfig(
            MeasurementFunction.RESISTANCE_2W,
            acquisition=AcquisitionSettings(input_impedance=InputImpedance.HIGH),
        )


def test_empty_acquisition_is_detected():
    assert AcquisitionSettings().is_empty
    assert not AcquisitionSettings(nplc=Nplc.N_1).is_empty


# -- acquisition SCPI emission --------------------------------------


def test_acquisition_settings_sent_after_conf():
    """Order matters: SENS: subsystems are keyed by function, so CONF:
    must establish the function first."""
    engine, fake = make_engine()
    engine.configure(
        ChannelList.parse("(@101)"),
        MeasurementConfig(
            MeasurementFunction.DC_VOLTAGE,
            acquisition=AcquisitionSettings(
                nplc=Nplc.N_10,
                autozero=AutoZero.OFF,
                input_impedance=InputImpedance.HIGH,
            ),
        ),
    )
    commands = sent_commands(fake)
    assert commands[0].startswith("CONF:VOLT:DC")
    assert "SENS:VOLT:DC:NPLC 10,(@101)" in commands
    assert "SENS:VOLT:DC:IMP:AUTO OFF,(@101)" in commands
    assert "SENS:VOLT:DC:ZERO:AUTO OFF,(@101)" in commands


def test_no_acquisition_commands_when_unset():
    """Each setting costs an error-queue round trip, so nothing is sent
    unless explicitly requested."""
    engine, fake = make_engine()
    engine.configure(
        ChannelList.parse("(@101)"), MeasurementConfig(MeasurementFunction.DC_VOLTAGE)
    )
    assert sent_commands(fake) == ["CONF:VOLT:DC AUTO,DEF,(@101)"]


def test_high_impedance_maps_to_auto_off():
    engine, fake = make_engine()
    engine.configure(
        ChannelList.parse("(@101)"),
        MeasurementConfig(
            MeasurementFunction.DC_VOLTAGE,
            acquisition=AcquisitionSettings(input_impedance=InputImpedance.AUTO),
        ),
    )
    assert "SENS:VOLT:DC:IMP:AUTO ON,(@101)" in sent_commands(fake)


# -- 4-wire pairing -------------------------------------------------


def test_four_wire_pair_is_n_plus_ten():
    engine, _ = make_engine()
    assert engine.four_wire_pair(ChannelId.parse("101")).address == 111
    assert engine.four_wire_pair(ChannelId.parse("210")).address == 220


def test_four_wire_pair_out_of_range_rejected():
    engine, _ = make_engine(cards={1: CardType.MUX_34901A})
    with pytest.raises(ConfigurationError, match="does not exist on the 34901A"):
        engine.configure(
            ChannelList.parse("(@115)"),  # pair would be 125, beyond 22
            MeasurementConfig(MeasurementFunction.RESISTANCE_4W),
        )


def test_four_wire_conflicts_with_configured_pair():
    """The instrument silently consumes the paired channel; a
    measurement already configured there would fight the pairing."""
    engine, _ = make_engine()
    engine.configure(
        ChannelList.parse("(@111)"), MeasurementConfig(MeasurementFunction.DC_VOLTAGE)
    )
    with pytest.raises(ConfigurationError, match="already configured for VOLT:DC"):
        engine.configure(
            ChannelList.parse("(@101)"),
            MeasurementConfig(MeasurementFunction.RESISTANCE_4W),
        )


def test_four_wire_allowed_when_pair_free():
    engine, fake = make_engine()
    engine.configure(
        ChannelList.parse("(@101)"), MeasurementConfig(MeasurementFunction.RESISTANCE_4W)
    )
    assert sent_commands(fake) == ["CONF:FRES AUTO,DEF,(@101)"]


def test_four_wire_pair_keyword(lib):
    assert lib.get_four_wire_pair("101") == "111"


# -- detailed readings ----------------------------------------------


def test_read_details_returns_full_records(lib):
    lib.configure_measurement("DCV", "(@101,102)")
    rows = lib.read_measurement_details()
    assert len(rows) == 2
    assert rows[0]["channel"] == "101"
    assert rows[0]["unit"] == "V"
    assert rows[0]["function"] == "VOLT:DC"
    assert rows[0]["overrange"] is False
    assert "timestamp" in rows[0]


def test_read_details_flags_overrange(lib):
    """Read Measurement returns the raw sentinel, which passes naive
    numeric assertions; the details form flags it explicitly."""
    lib.configure_measurement("DCV", "(@199)")
    rows = lib.read_measurement_details()
    assert rows[0]["overrange"] is True

    plain = lib.read_measurement()
    assert plain[0] > 9.0e37  # the trap this keyword exists to avoid


# -- statistics -----------------------------------------------------


def test_statistics_over_configured_channels(lib):
    lib.configure_measurement("DCV", "(@101:105)")
    stats = lib.get_measurement_statistics()
    assert stats["count"] == 5
    assert stats["minimum"] == pytest.approx(1.01)
    assert stats["maximum"] == pytest.approx(1.05)
    assert stats["average"] == pytest.approx(1.03)
    assert stats["span"] == pytest.approx(0.04)
    assert stats["unit"] == "V"


def test_statistics_reject_overrange(lib):
    lib.configure_measurement("DCV", "(@199)")
    with pytest.raises(Exception, match="over-range"):
        lib.get_measurement_statistics()


def test_statistics_reject_mixed_units(lib):
    lib.configure_measurement("DCV", "(@101)")
    lib.configure_measurement("Resistance", "(@102)")
    with pytest.raises(Exception, match="mixed units"):
        lib.get_measurement_statistics()


# -- range assertion ------------------------------------------------


def test_measurement_within_range_passes(lib):
    value = lib.measurement_should_be_within("DCV", "101", 1.0, 1.1)
    assert value == pytest.approx(1.01)


def test_measurement_outside_range_fails(lib):
    with pytest.raises(AssertionError, match="outside"):
        lib.measurement_should_be_within("DCV", "101", 5.0, 6.0)


def test_measurement_within_rejects_overrange_explicitly(lib):
    """Must not compare the sentinel numerically against the bounds."""
    with pytest.raises(AssertionError, match="over-range"):
        lib.measurement_should_be_within("DCV", "199", 0, 1e40)


def test_measurement_within_rejects_multiple_channels(lib):
    with pytest.raises(AssertionError, match="exactly one channel"):
        lib.measurement_should_be_within("DCV", "(@101,102)", 0, 2)


# -- keyword argument validation ------------------------------------


def test_invalid_nplc_lists_valid_options(lib):
    with pytest.raises(AssertionError, match="Invalid nplc"):
        lib.configure_measurement("DCV", "(@101)", nplc="7")


def test_invalid_autozero_rejected(lib):
    with pytest.raises(AssertionError, match="Invalid autozero"):
        lib.configure_measurement("DCV", "(@101)", autozero="MAYBE")


def test_acquisition_via_keyword(lib):
    lib.configure_measurement("DCV", "(@101)", range="10", nplc="10", autozero="ON")
    assert lib.get_configured_function("101") == "VOLT:DC"


def test_none_acquisition_arguments_are_ignored(lib):
    lib.configure_measurement("DCV", "(@101)", nplc="NONE", autozero="")
    assert lib.get_configured_function("101") == "VOLT:DC"


# -- configuration accumulation -------------------------------------


def test_configuration_accumulates_across_calls(lib):
    """Documented behaviour: one session per suite means configured
    channels accumulate, so a bare read grows silently."""
    lib.configure_measurement("DCV", "(@101)")
    lib.configure_measurement("DCV", "(@102)")
    assert len(lib.read_measurement()) == 2


def test_clear_configuration_resets_bare_read(lib):
    lib.configure_measurement("DCV", "(@101:105)")
    lib.clear_measurement_configuration()
    lib.configure_measurement("DCV", "(@101)")
    assert len(lib.read_measurement()) == 1


def test_clear_configuration_for_specific_channels(lib):
    lib.configure_measurement("DCV", "(@101:103)")
    lib.clear_measurement_configuration("(@102)")
    values = lib.read_measurement()
    assert len(values) == 2


def test_clear_configuration_does_not_touch_instrument(lib):
    """Only driver-side bookkeeping is reset."""
    lib.configure_measurement("DCV", "(@101)")
    lib.clear_measurement_configuration()
    assert lib.get_configured_function("101") == ""


def test_clear_unknown_channel_is_harmless(lib):
    lib.clear_measurement_configuration("(@107)")


def test_engine_clear_all_and_subset():
    from keysight34970.measurement.channels import ChannelList as CL

    engine, _ = make_engine()
    engine.configure(
        CL.parse("(@101:103)"), MeasurementConfig(MeasurementFunction.DC_VOLTAGE)
    )
    engine.clear_configuration(CL.parse("(@102)"))
    assert engine.get_configured_function(102) is None
    assert engine.get_configured_function(101) is not None

    engine.clear_configuration()
    assert engine.get_configured_function(101) is None


def test_measure_refuses_acquisition_settings_rather_than_dropping_them():
    """MEAS: reads immediately and resets unspecified parameters, so
    acquisition settings could never take effect. Silently ignoring them
    would return a reading the caller believes was taken at 10 NPLC."""
    from keysight34970.measurement.channels import ChannelList as CL

    engine, fake = make_engine()
    with pytest.raises(ConfigurationError, match="cannot apply NPLC"):
        engine.measure(
            CL.parse("(@101)"),
            MeasurementConfig(
                MeasurementFunction.DC_VOLTAGE,
                acquisition=AcquisitionSettings(nplc=Nplc.N_10),
            ),
        )
    assert sent_commands(fake) == []


def test_measure_still_works_without_acquisition_settings():
    from keysight34970.measurement.channels import ChannelList as CL

    engine, fake = make_engine(
        responses={"MEAS:VOLT:DC? AUTO,DEF,(@101)": "+1.0E+00"}
    )
    result = engine.measure(
        CL.parse("(@101)"), MeasurementConfig(MeasurementFunction.DC_VOLTAGE)
    )
    assert result[0].value == 1.0


# -- remaining edge paths -------------------------------------------


def test_parse_range_passthrough_forms():
    from keysight34970.keywords.measurement_keywords import _parse_range
    from keysight34970.measurement.models import AutoRange

    assert _parse_range(None) is AutoRange.AUTO
    assert _parse_range(AutoRange.AUTO) is AutoRange.AUTO
    assert _parse_range("DEF") is AutoRange.AUTO
    assert _parse_range(10) == 10.0


def test_set_card_after_engine_exists_propagates(lib):
    """Declaring a card mid-session must reach the live engine, not just
    the pending map."""
    lib.configure_measurement("DCV", "(@101)")  # forces engine creation
    lib.set_installed_card(1, "34903A")
    with pytest.raises(Exception, match="internal DMM"):
        lib.configure_measurement("DCV", "(@101)")


def test_four_wire_pair_beyond_channel_range_rejected():
    """Channel 90+ has no valid N+10 pair (max channel is 99)."""
    from keysight34970.measurement.channels import ChannelList as CL

    engine, _ = make_engine()
    with pytest.raises(ConfigurationError, match="out of range"):
        engine.configure(
            CL.parse("(@195)"),
            MeasurementConfig(MeasurementFunction.RESISTANCE_4W),
        )
