"""Phase 5 Gate 3: output-state honesty and safe-state restoration."""

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from mock_instrument import MockScpiServer  # noqa: E402

from keysight34970.library import Keysight34970  # noqa: E402


@pytest.fixture
def lib():
    server = MockScpiServer()
    server.start()
    library = Keysight34970()
    library.connect_to_instrument("34972A", "TCP", server.host, port=server.port)
    library.set_installed_card(3, "34907A")
    yield library
    try:
        library.disconnect_from_instrument()
    except Exception:
        pass
    server.stop()


# -- the distinction that matters -----------------------------------


def test_driven_outputs_records_only_driver_writes(lib):
    lib.write_digital_port("301", "0b10101010")
    driven = lib.get_driven_outputs()
    assert len(driven) == 1
    assert "301" in driven[0]


def test_read_output_state_asks_the_instrument(lib):
    lib.write_digital_port("301", 170)
    state = lib.read_output_state()
    assert state["301"] == 170


def test_read_output_state_can_query_untouched_channels(lib):
    """The default covers only driven outputs; a caller checking whether
    it is safe to disconnect needs to ask about channels this driver
    never wrote."""
    state = lib.read_output_state("(@301,302)")
    assert set(state) == {"301", "302"}


def test_driven_outputs_empty_before_any_write(lib):
    assert lib.get_driven_outputs() == []


def test_read_output_state_empty_default_when_nothing_driven(lib):
    """With nothing driven the default target set is empty, and that
    must not silently become 'query everything'."""
    assert lib.read_output_state() == {}


def test_driven_record_does_not_track_external_change(lib):
    """The record says what the driver wrote, not what is energised.
    A raw SCPI write is invisible to it -- this asymmetry is the whole
    reason Read Output State exists."""
    lib.write_digital_port("301", 15)
    lib.send_scpi_command("SOUR:DIG:DATA:BYTE 240,(@301)")

    assert "15" in lib.get_driven_outputs()[0]
    assert lib.read_output_state()["301"] == 240


# -- safe state -----------------------------------------------------


def test_safe_state_zeroes_driven_outputs(lib):
    lib.write_digital_port("301", 255)
    reset = lib.return_outputs_to_safe_state()

    assert reset == {"301": 0.0}
    assert lib.read_output_state()["301"] == 0


def test_safe_state_covers_dac_and_port(lib):
    lib.write_digital_port("301", 255)
    lib.write_analog_output("304", 5.0)

    reset = lib.return_outputs_to_safe_state()

    assert set(reset) == {"301", "304"}
    state = lib.read_output_state()
    assert state["301"] == 0
    assert state["304"] == 0


def test_safe_state_with_nothing_driven_is_a_no_op(lib):
    assert lib.return_outputs_to_safe_state() == {}


def test_safe_state_does_not_touch_undriven_outputs(lib):
    """Only what this driver drove is reset. Zeroing an output the
    driver never set could de-energise hardware it knows nothing
    about."""
    lib.send_scpi_command("SOUR:DIG:DATA:BYTE 240,(@302)")
    lib.write_digital_port("301", 15)

    lib.return_outputs_to_safe_state()

    assert lib.read_output_state("(@302)")["302"] == 240


def test_safe_state_is_recorded_as_a_write(lib):
    """Zeroing is itself a drive and must appear in the record, or a
    later audit would miss that the driver energised the line at all."""
    lib.write_digital_port("301", 255)
    lib.return_outputs_to_safe_state()

    assert len(lib.get_driven_outputs()) == 2


# -- risk metadata --------------------------------------------------


def test_safe_state_is_marked_high_risk():
    """It drives physical lines; zero is not universally safe."""
    metadata = Keysight34970.get_capability_metadata()
    entry = metadata["Return Outputs To Safe State"]
    assert entry["risk_level"] == "high"
    assert "DRIVES PHYSICAL OUTPUT LINES" in entry["notes"]


def test_read_output_state_is_low_risk():
    metadata = Keysight34970.get_capability_metadata()
    assert metadata["Read Output State"]["risk_level"] == "low"


# -- remaining engine paths -----------------------------------------


def _engine():
    from keysight34970.config import ConnectionConfig, InstrumentModel, TransportKind
    from keysight34970.connection import Connection
    from keysight34970.digital.engine import ScpiDigitalEngine

    from .fakes import FakeTransport

    fake = FakeTransport(responses={"*IDN?": "Keysight,34972A,MY1,1.0"})
    conn = Connection(
        ConnectionConfig(
            transport=TransportKind.TCP_SOCKET,
            model=InstrumentModel.DAQ_34972A,
            host="10.0.0.5",
        ),
        transport=fake,
    )
    conn.connect()
    fake.sent.clear()
    return ScpiDigitalEngine(conn), fake


def test_unparseable_output_state_raises_command_error():
    """A garbled response must fail loudly rather than becoming a
    plausible number -- this reads back physical output state."""
    from keysight34970.exceptions import CommandError

    engine, fake = _engine()
    engine.write_port("301", 15)
    fake.responses["SENS:DIG:DATA:BYTE? (@301)"] = "NOT_A_NUMBER"

    with pytest.raises(CommandError, match="Could not parse output state"):
        engine.read_output_state()


def test_get_totalizer_config_returns_none_when_unconfigured():
    engine, _ = _engine()
    assert engine.get_totalizer_config("303") is None


def test_set_card_rejects_bad_slot():
    from keysight34970.exceptions import ConfigurationError

    engine, _ = _engine()
    with pytest.raises(ConfigurationError, match="slot must be 1-3"):
        engine.set_card(9, None)


def test_dac_detection_uses_shared_role_map():
    """The write path and the state-read path must agree about what a
    channel is; both resolve through role_of()."""
    from keysight34970.digital.models import ChannelRole, role_of
    from keysight34970.measurement.channels import ChannelId

    engine, _ = _engine()
    for address, is_dac in [(304, True), (305, True), (301, False), (302, False)]:
        channel = ChannelId.parse(address)
        assert engine._is_dac_channel(channel) is is_dac
        assert (role_of(channel) is ChannelRole.DAC) is is_dac


# -- bounded write history (Gate 5 finding) -------------------------


def test_write_history_is_bounded():
    """A soak test writing an output in a loop must not grow the record
    without limit: measured at 3 ms for 5000 entries on a call that
    performs no instrument I/O."""
    from keysight34970.digital.models import WRITE_HISTORY_LIMIT

    engine, _ = _engine()
    for _ in range(WRITE_HISTORY_LIMIT + 500):
        engine.write_port("301", 1)

    assert len(engine.written_outputs()) == WRITE_HISTORY_LIMIT


def test_latest_outputs_survives_history_trimming():
    """The bound is on the ordered history only. Which outputs are
    energised, and to what, must stay exactly answerable however long
    the session runs -- that is the safety question."""
    from keysight34970.digital.models import WRITE_HISTORY_LIMIT

    engine, _ = _engine()
    engine.write_dac("304", 7.0)
    for _ in range(WRITE_HISTORY_LIMIT + 100):
        engine.write_port("301", 1)

    latest = engine.latest_outputs()
    assert set(latest) == {301, 304}
    assert latest[304].volts == 7.0  # not trimmed away


def test_safe_state_still_covers_channels_trimmed_from_history():
    """The regression this bound could have introduced: an output driven
    early and pushed out of the history must still be reset."""
    from keysight34970.digital.models import WRITE_HISTORY_LIMIT

    engine, _ = _engine()
    engine.write_dac("304", 9.0)
    for _ in range(WRITE_HISTORY_LIMIT + 100):
        engine.write_port("301", 1)

    reset = engine.safe_output_state()
    assert 304 in reset, "an early output must not escape safe-state reset"


def test_read_output_state_default_covers_trimmed_channels():
    from keysight34970.digital.models import WRITE_HISTORY_LIMIT

    engine, fake = _engine()
    engine.write_dac("304", 3.0)
    for _ in range(WRITE_HISTORY_LIMIT + 50):
        engine.write_port("301", 1)

    fake.responses["SOUR:VOLT? (@304)"] = "3.0"
    fake.responses["SENS:DIG:DATA:BYTE? (@301)"] = "1"
    assert set(engine.read_output_state()) == {301, 304}
