import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from mock_instrument import MockScpiServer  # noqa: E402

from keysight34970.keywords.measurement_keywords import parse_function  # noqa: E402
from keysight34970.library import Keysight34970  # noqa: E402
from keysight34970.measurement.models import MeasurementFunction  # noqa: E402


@pytest.fixture
def lib():
    server = MockScpiServer()
    server.start()
    library = Keysight34970()
    library.connect_to_instrument("34972A", "TCP", server.host, port=server.port)
    yield library
    try:
        library.disconnect_from_instrument()
    except Exception:
        pass
    server.stop()


# -- function name parsing ------------------------------------------


@pytest.mark.parametrize(
    "text,expected",
    [
        ("DCV", MeasurementFunction.DC_VOLTAGE),
        ("dcv", MeasurementFunction.DC_VOLTAGE),
        ("DC Voltage", MeasurementFunction.DC_VOLTAGE),
        ("DC_VOLTAGE", MeasurementFunction.DC_VOLTAGE),
        ("VOLT:DC", MeasurementFunction.DC_VOLTAGE),
        ("ACI", MeasurementFunction.AC_CURRENT),
        ("4W Resistance", MeasurementFunction.RESISTANCE_4W),
        ("FRES", MeasurementFunction.RESISTANCE_4W),
        ("Resistance", MeasurementFunction.RESISTANCE_2W),
        ("Frequency", MeasurementFunction.FREQUENCY),
        ("  Diode  ", MeasurementFunction.DIODE),
    ],
)
def test_function_aliases(text, expected):
    assert parse_function(text) is expected


def test_unknown_function_lists_valid_options():
    with pytest.raises(AssertionError, match="DC_VOLTAGE"):
        parse_function("VOLTS_MAYBE")


# -- keywords -------------------------------------------------------


def test_measure_returns_values(lib):
    assert lib.measure("DCV", "(@101,102)") == [1.01, 1.02]


def test_measure_value_returns_single_float(lib):
    value = lib.measure_value("DCV", "101")
    assert isinstance(value, float)
    assert value == 1.01


def test_measure_value_rejects_multiple_channels(lib):
    with pytest.raises(AssertionError, match="exactly one channel"):
        lib.measure_value("DCV", "(@101,102)")


def test_configure_then_read(lib):
    lib.configure_measurement("DCV", "(@103:105)")
    assert lib.read_measurement() == [1.03, 1.04, 1.05]


def test_read_specific_channels(lib):
    lib.configure_measurement("DCV", "(@101:105)")
    assert lib.read_measurement("(@102,104)") == [1.02, 1.04]


def test_get_configured_function(lib):
    lib.configure_measurement("4W Resistance", "(@107)")
    assert lib.get_configured_function("107") == "FRES"


def test_get_configured_function_empty_for_unconfigured(lib):
    assert lib.get_configured_function("109") == ""


def test_configure_with_range(lib):
    lib.configure_measurement("DCV", "(@101)", range="10")
    assert lib.get_configured_function("101") == "VOLT:DC"


def test_resolution_without_range_fails(lib):
    with pytest.raises(Exception, match="resolution cannot be set"):
        lib.configure_measurement("DCV", "(@101)", resolution="0.001")


def test_bad_range_value_rejected(lib):
    with pytest.raises(AssertionError, match="must be a number or AUTO"):
        lib.configure_measurement("DCV", "(@101)", range="ten volts")


def test_read_without_configuration_fails(lib):
    with pytest.raises(Exception, match="No channels have been configured"):
        lib.read_measurement()


def test_overrange_channel_reports_sentinel(lib):
    """Channel 199 is wired in the mock to return the over-range value."""
    assert lib.measure("DCV", "(@199)")[0] > 9.0e37


# -- card declaration -----------------------------------------------


def test_set_installed_card_enables_validation(lib):
    lib.set_installed_card(1, "34903A")  # actuator: no DMM path
    with pytest.raises(Exception, match="internal DMM"):
        lib.configure_measurement("DCV", "(@101)")


def test_set_installed_card_rejects_unknown_card(lib):
    with pytest.raises(AssertionError, match="Unknown card"):
        lib.set_installed_card(1, "34999Z")


def test_set_installed_card_rejects_bad_slot(lib):
    with pytest.raises(AssertionError, match="slot must be 1-3"):
        lib.set_installed_card(7, "34901A")


def test_card_declared_before_connect_is_applied():
    server = MockScpiServer()
    server.start()
    try:
        library = Keysight34970()
        library.set_installed_card(1, "34903A")
        library.connect_to_instrument("34972A", "TCP", server.host, port=server.port)
        with pytest.raises(Exception, match="internal DMM"):
            library.configure_measurement("DCV", "(@101)")
        library.disconnect_from_instrument()
    finally:
        server.stop()


# -- guards ---------------------------------------------------------


def test_measurement_keywords_require_connection():
    library = Keysight34970()
    for call in (
        lambda: library.measure("DCV", "(@101)"),
        lambda: library.read_measurement(),
        lambda: library.configure_measurement("DCV", "(@101)"),
        lambda: library.get_configured_function("101"),
    ):
        with pytest.raises(AssertionError, match="No instrument connection"):
            call()


def test_disconnect_clears_measurement_state(lib):
    """Per-channel configuration must not survive a session; the
    instrument does not keep it, so the driver must not claim it does."""
    lib.configure_measurement("DCV", "(@101)")
    assert lib.get_configured_function("101") == "VOLT:DC"

    lib.disconnect_from_instrument()

    with pytest.raises(AssertionError, match="No instrument connection"):
        lib.get_configured_function("101")


def test_reconnect_clears_measurement_state(lib):
    lib.configure_measurement("DCV", "(@101)")
    lib.reconnect_to_instrument()
    assert lib.get_configured_function("101") == ""
