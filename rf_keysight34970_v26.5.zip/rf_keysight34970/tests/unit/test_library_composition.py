"""
Guards the mixin composition pattern in library.py.

The Phase 1 Gate 5 review flagged that composition had only ever been
exercised with a single mixin, and that Phase 2 would be its first real
test. These tests make the property explicit so a future phase adding a
third or fourth mixin gets a clear failure rather than a subtle one.
"""

import pytest
from robot.running.testlibraries import TestLibrary as RobotTestLibrary

from keysight34970.exceptions import CommandError, Keysight34970Error
from keysight34970.keywords.connection_keywords import ConnectionKeywords
from keysight34970.keywords.measurement_keywords import MeasurementKeywords
from keysight34970.library import Keysight34970


def test_library_composes_both_mixins():
    assert issubclass(Keysight34970, ConnectionKeywords)
    assert issubclass(Keysight34970, MeasurementKeywords)


def test_both_mixins_initialise_their_own_state():
    lib = Keysight34970()
    assert lib._connection is None
    assert lib._measurement_engine is None


def test_mixin_states_are_disjoint():
    """Each mixin must own distinct attributes; a collision would mean
    one silently clobbering another's state.

    Derived from the mixins themselves rather than hardcoded, so adding
    a phase does not require editing this test -- only a genuine
    collision fails it.
    """

    instance = Keysight34970()
    attrs = set(vars(instance))

    seen: dict[str, str] = {}
    for owner in type(instance).__mro__:
        if owner in (object, Keysight34970):
            continue
        probe = object.__new__(owner)
        try:
            owner.__init__(probe)
        except Exception:
            continue
        for name in vars(probe):
            assert name not in seen, (
                f"{name!r} is initialised by both {seen[name]} and "
                f"{owner.__name__}"
            )
            seen[name] = owner.__name__

    assert attrs == set(seen), (
        f"library state {sorted(attrs)} does not match the union of mixin "
        f"state {sorted(seen)}"
    )


def test_mro_is_unambiguous():
    Keysight34970.mro()  # raises at class creation if inconsistent
    assert Keysight34970.mro().index(ConnectionKeywords) < Keysight34970.mro().index(
        MeasurementKeywords
    )


def test_robot_keyword_surface_matches_merged_metadata():
    """Both mixins contribute keywords; the merged metadata registry
    must match exactly what Robot exposes."""
    library = RobotTestLibrary.from_name("keysight34970.Keysight34970")
    names = {kw.name for kw in library.keywords}
    assert names == set(Keysight34970.get_capability_metadata().keys())


def test_each_mixin_contributes_its_own_keywords():
    library = RobotTestLibrary.from_name("keysight34970.Keysight34970")
    names = {kw.name for kw in library.keywords}
    assert "Connect To Instrument" in names      # ConnectionKeywords
    assert "Measure" in names                     # MeasurementKeywords


def test_metadata_registries_do_not_collide():
    """Two mixins defining the same capability name would silently
    overwrite one another in the merge."""
    from keysight34970.keywords.connection_keywords import (
        CAPABILITY_METADATA as conn_meta,
    )
    from keysight34970.keywords.measurement_keywords import (
        CAPABILITY_METADATA as meas_meta,
    )

    assert not (set(conn_meta) & set(meas_meta))


def test_measurement_engine_guard_message_is_actionable():
    lib = Keysight34970()
    with pytest.raises(AssertionError, match="Connect To Instrument"):
        lib._require_measurement_engine()


# -- CommandError context regression --------------------------------


def test_command_error_accepts_context_like_other_exceptions():
    """Regression: CommandError previously rejected `context=`, unlike
    every other exception in the hierarchy."""
    error = CommandError("boom", context={"reading_count": 2})
    assert error.context["reading_count"] == 2


def test_command_error_still_carries_scpi_fields():
    error = CommandError(
        "boom", scpi_code=-113, scpi_message="Undefined header", command="BOGUS"
    )
    assert error.scpi_code == -113
    assert error.context["scpi_code"] == -113
    assert error.command == "BOGUS"


def test_command_error_merges_both_sources():
    error = CommandError("boom", scpi_code=-222, context={"channel": 101})
    assert error.context["channel"] == 101
    assert error.context["scpi_code"] == -222


def test_every_driver_exception_accepts_context():
    """The property that was violated; assert it across the hierarchy."""
    for cls in _all_subclasses(Keysight34970Error) | {Keysight34970Error}:
        instance = cls("msg", context={"k": "v"})
        assert instance.context["k"] == "v", cls


def _all_subclasses(cls):
    found = set(cls.__subclasses__())
    for sub in list(found):
        found |= _all_subclasses(sub)
    return found



# -- session reset hook registry (Phase 3 Gate 1) -------------------


def test_all_declared_reset_hooks_exist():
    """Every name in a mixin's SESSION_RESET_HOOKS must be callable.

    Replaces a getattr-by-name lookup flagged in three consecutive
    reviews: a mixin that misspelled or forgot its hook would silently
    never be reset and would carry stale state across sessions.
    """

    lib = Keysight34970()
    declared = []
    for owner in type(lib).__mro__:
        declared.extend(owner.__dict__.get("SESSION_RESET_HOOKS", ()))

    assert declared, "no reset hooks declared; the registry is not wired up"
    for name in declared:
        assert callable(getattr(lib, name, None)), name


def test_every_stateful_mixin_declares_a_reset_hook():
    """A mixin holding session-bound state must declare how to clear it."""
    from keysight34970.keywords.measurement_keywords import MeasurementKeywords
    from keysight34970.keywords.scanner_keywords import ScannerKeywords

    for mixin in (MeasurementKeywords, ScannerKeywords):
        assert mixin.__dict__.get("SESSION_RESET_HOOKS"), mixin.__name__


def test_bad_hook_name_fails_at_construction():
    """A typo must fail immediately, not silently skip the reset."""
    from keysight34970.keywords.connection_keywords import ConnectionKeywords

    class Broken(ConnectionKeywords):
        SESSION_RESET_HOOKS = ("_does_not_exist",)

    broken = Broken()
    with pytest.raises(AttributeError, match="_does_not_exist"):
        broken._validate_session_reset_hooks()


def test_scanner_state_cleared_on_disconnect():
    lib = Keysight34970()
    lib._scanner_engine = object()
    lib.disconnect_from_instrument()
    assert lib._scanner_engine is None


def test_all_hooks_fire_not_just_the_first():
    """Regression guard: the previous implementation called exactly one
    hook by name, so a second stateful mixin would have been missed."""
    lib = Keysight34970()
    lib._measurement_engine = object()
    lib._scanner_engine = object()

    lib.disconnect_from_instrument()

    assert lib._measurement_engine is None
    assert lib._scanner_engine is None
