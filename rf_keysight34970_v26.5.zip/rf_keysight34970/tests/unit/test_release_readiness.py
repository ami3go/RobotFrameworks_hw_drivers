"""
Release-readiness checks.

The RFDS Driver Implementation Lifecycle requires every gate to produce
a CHANGELOG entry, a history record and a review record. Gates 2 and 3
of Phase 2 shipped without CHANGELOG entries, and nothing detected it —
the gate checklist was being satisfied from memory.

These tests make the mandated artifacts a build requirement. They are
deliberately structural rather than semantic: they cannot tell whether a
CHANGELOG entry is *good*, only that it exists, which is exactly the
failure that actually occurred.
"""

import re
from pathlib import Path

import pytest

from keysight34970 import __version__

ROOT = Path(__file__).resolve().parents[2]
HISTORY_DIR = ROOT / "history"
REVIEW_DIR = ROOT / "review"
CHANGELOG = ROOT / "CHANGELOG.md"

VERSION_RE = re.compile(r"v?(\d{2}\.\d{2}\.\d{2})")


def _history_versions() -> set[str]:
    return {
        m.group(1)
        for path in HISTORY_DIR.glob("v*.md")
        if (m := VERSION_RE.search(path.name))
    }


def _review_versions() -> set[str]:
    return {
        m.group(1)
        for path in REVIEW_DIR.glob("v*.md")
        if (m := VERSION_RE.search(path.name))
    }


def _changelog_versions() -> set[str]:
    return set(re.findall(r"^## \[(\d{2}\.\d{2}\.\d{2})\]", CHANGELOG.read_text(), re.M))


def test_every_history_record_has_a_review_record():
    history, review = _history_versions(), _review_versions()
    assert history == review, (
        f"history without review: {sorted(history - review)}; "
        f"review without history: {sorted(review - history)}"
    )


def test_every_gate_has_a_changelog_entry():
    """The check that would have caught the Phase 2 Gates 2-3 omission."""
    history = _history_versions()
    changelog = _changelog_versions()
    missing = sorted(history - changelog)
    assert not missing, (
        f"versions with a history record but no CHANGELOG entry: {missing}. "
        "The lifecycle requires a CHANGELOG update at every gate."
    )


def test_no_changelog_entry_without_a_gate_record():
    changelog = _changelog_versions()
    history = _history_versions()
    orphans = sorted(changelog - history)
    assert not orphans, f"CHANGELOG entries with no history record: {orphans}"


def test_current_version_has_all_three_artifacts():
    version = __version__
    assert version in _history_versions(), f"no history/v{version}.md"
    assert version in _review_versions(), f"no review/v{version}_review.md"
    assert version in _changelog_versions(), f"no CHANGELOG entry for {version}"


def test_gate_versions_are_contiguous():
    """Gates must run 1-5 in sequence within a phase; a gap means a gate
    was skipped, which the lifecycle forbids."""
    versions = sorted(_history_versions())
    by_phase: dict[str, list[int]] = {}
    for version in versions:
        _, phase, gate = version.split(".")
        by_phase.setdefault(phase, []).append(int(gate))

    for phase, gates in by_phase.items():
        expected = list(range(1, len(gates) + 1))
        assert sorted(gates) == expected, (
            f"phase {phase} gates are {sorted(gates)}, expected {expected} "
            "- a gate appears to have been skipped"
        )


def test_versions_agree_across_the_package():
    """The three code locations plus the AI contract must all match."""
    pyproject = (ROOT / "pyproject.toml").read_text()
    library = (ROOT / "src/keysight34970/library.py").read_text()

    # pyproject uses PEP 440 (leading zeros stripped): 26.02.05 -> 26.2.5
    year, phase, gate = __version__.split(".")
    pep440 = f"{int(year)}.{int(phase)}.{int(gate)}"
    assert f'version = "{pep440}"' in pyproject, f"pyproject.toml is not at {pep440}"
    assert f'ROBOT_LIBRARY_VERSION = "{__version__}"' in library

    yaml = pytest.importorskip("yaml")
    contract = yaml.safe_load((ROOT / "ai/ai_contract.yaml").read_text())
    assert contract["identity"]["driver_version"] == __version__


def test_release_notes_exist_for_completed_phases():
    assert (ROOT / "RELEASE_NOTES.md").is_file()
