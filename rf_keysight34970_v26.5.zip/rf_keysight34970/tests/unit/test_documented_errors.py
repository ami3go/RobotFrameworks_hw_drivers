"""
Guards the symptom->cause table in docs/user_guide.md.

That table lists literal error-message fragments users will search for.
If a message is reworded without updating the guide, the documentation
becomes actively misleading. These tests pin the fragments, so a
rewording fails CI and forces the doc update.

Closes the Gate 4 Minor finding regarding documentation drift risk.
"""

import socket
import sys
import threading
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from mock_instrument import MockScpiServer  # noqa: E402

from keysight34970 import (  # noqa: E402
    Connection,
    ConnectionConfig,
    InstrumentModel,
    TransportKind,
)
from keysight34970.exceptions import (  # noqa: E402
    CommandError,
    ConfigurationError,
    TimeoutError34970,
    TransportError,
)

DOC_PATH = Path(__file__).resolve().parents[2] / "docs" / "user_guide.md"

# fragment -> short description of the documented symptom
DOCUMENTED_FRAGMENTS = {
    "Instrument reported error": "bad SCPI syntax / unsupported command",
    "does not match": "wrong unit addressed or wrong model argument",
    "already be held open": "another process holds the VISA session",
    "Timed out waiting": "operation slower than the configured timeout",
    "closed by instrument": "instrument dropped the link mid-response",
}


def _config(**overrides):
    defaults = dict(
        transport=TransportKind.TCP_SOCKET,
        model=InstrumentModel.DAQ_34972A,
    )
    defaults.update(overrides)
    return ConnectionConfig(**defaults)


def test_all_documented_fragments_appear_in_user_guide():
    """Every fragment asserted below must actually be in the guide."""
    text = DOC_PATH.read_text(encoding="utf-8")
    missing = [f for f in DOCUMENTED_FRAGMENTS if f not in text]
    assert not missing, f"fragments missing from user_guide.md: {missing}"


def test_instrument_error_message_fragment():
    server = MockScpiServer()
    server.start()
    try:
        conn = Connection(_config(host=server.host, port=server.port))
        conn.connect()
        with pytest.raises(CommandError, match="Instrument reported error"):
            conn.write("BOGUS:COMMAND")
        conn.close()
    finally:
        server.stop()


def test_model_mismatch_message_fragment():
    server = MockScpiServer()
    server.start()
    try:
        conn = Connection(
            _config(
                host=server.host,
                port=server.port,
                model=InstrumentModel.DAQ_34970A,  # mock reports 34972A
            )
        )
        with pytest.raises(ConfigurationError, match="does not match"):
            conn.connect()
    finally:
        server.stop()


def test_visa_resource_busy_message_fragment():
    from unittest.mock import MagicMock, patch

    import pyvisa

    from keysight34970.exceptions import ConnectionError34970
    from keysight34970.transport.visa_transport import VisaTransport

    transport = VisaTransport("GPIB0::9::INSTR", timeout_s=1.0)
    fake_rm = MagicMock()
    fake_rm.open_resource.side_effect = pyvisa.errors.VisaIOError(
        pyvisa.constants.StatusCode.error_resource_busy
    )
    with patch("pyvisa.ResourceManager", return_value=fake_rm):
        with pytest.raises(ConnectionError34970, match="already be held open"):
            transport.open()


def test_read_timeout_message_fragment():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(("127.0.0.1", 0))
    server.listen(1)
    host, port = server.getsockname()
    held = []

    threading.Thread(
        target=lambda: held.append(server.accept()[0]), daemon=True
    ).start()

    from keysight34970.transport.tcp_transport import TcpSocketTransport

    transport = TcpSocketTransport(host, port, timeout_s=0.3)
    transport.open()
    try:
        with pytest.raises(TimeoutError34970, match="Timed out waiting"):
            transport.query("*IDN?")
    finally:
        transport.close()
        for conn in held:
            conn.close()
        server.close()


def test_connection_closed_message_fragment():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(("127.0.0.1", 0))
    server.listen(1)
    host, port = server.getsockname()

    def _hangup():
        try:
            conn, _ = server.accept()
            conn.recv(4096)
            conn.sendall(b"PARTIAL")
            conn.close()
        except OSError:
            pass

    threading.Thread(target=_hangup, daemon=True).start()

    from keysight34970.transport.tcp_transport import TcpSocketTransport

    transport = TcpSocketTransport(host, port, timeout_s=2.0)
    transport.open()
    try:
        with pytest.raises(TransportError, match="closed by instrument"):
            transport.query("*IDN?")
    finally:
        transport.close()
        server.close()
