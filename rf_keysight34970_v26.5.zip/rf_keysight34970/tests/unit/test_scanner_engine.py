import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from mock_instrument import MockScpiServer  # noqa: E402

from keysight34970 import (  # noqa: E402
    Connection,
    ConnectionConfig,
    InstrumentModel,
    TransportKind,
)
from keysight34970.exceptions import ConfigurationError  # noqa: E402
from keysight34970.library import Keysight34970  # noqa: E402
from keysight34970.measurement.channels import ChannelList  # noqa: E402
from keysight34970.measurement.models import MeasurementFunction  # noqa: E402
from keysight34970.scanner.engine import ScpiScannerEngine  # noqa: E402
from keysight34970.scanner.models import (  # noqa: E402
    ScanConfig,
    TriggerCount,
    TriggerSource,
)


@pytest.fixture
def server():
    s = MockScpiServer()
    s.start()
    yield s
    s.stop()


@pytest.fixture
def engine(server):
    conn = Connection(
        ConnectionConfig(
            transport=TransportKind.TCP_SOCKET,
            model=InstrumentModel.DAQ_34972A,
            host=server.host,
            port=server.port,
        )
    )
    conn.connect()
    yield ScpiScannerEngine(conn)
    conn.close()


@pytest.fixture
def lib(server):
    library = Keysight34970()
    library.connect_to_instrument("34972A", "TCP", server.host, port=server.port)
    yield library
    try:
        library.disconnect_from_instrument()
    except Exception:
        pass


def cfg(channels="(@101,102)", **kwargs):
    return ScanConfig(channels=ChannelList.parse(channels), **kwargs)


# -- engine ---------------------------------------------------------


def test_run_scan_end_to_end(engine):
    result = engine.run_scan(cfg(trigger_count=TriggerCount(3)), timeout_s=5)
    assert result.reading_count == 6
    assert result.sweep_count == 3
    assert result.is_complete


def test_scan_readings_carry_channels_and_timestamps(engine):
    result = engine.run_scan(cfg(), timeout_s=5)
    assert [r.channel.address for r in result.readings] == [101, 102]
    assert all(r.instrument_timestamp for r in result.readings)


def test_for_channel_across_sweeps(engine):
    result = engine.run_scan(cfg(trigger_count=TriggerCount(4)), timeout_s=5)
    assert len(result.for_channel(101)) == 4
    assert len(result.for_channel(102)) == 4


def test_configure_then_start_then_fetch(engine):
    engine.configure_scan(cfg(trigger_count=TriggerCount(2)))
    engine.start_scan()
    assert engine.wait_for_scan(timeout_s=5)
    assert engine.fetch_readings().reading_count == 4


def test_reading_count_reflects_memory(engine):
    engine.configure_scan(cfg(trigger_count=TriggerCount(5)))
    engine.start_scan()
    assert engine.reading_count() == 10


def test_fetch_with_clear_erases_memory(engine):
    """R? reads and erases in one command; fetch-then-clear would race a
    running scan."""
    engine.configure_scan(cfg())
    engine.start_scan()
    assert engine.reading_count() == 2
    engine.fetch_readings(clear=True)
    assert engine.reading_count() == 0


def test_fetch_without_clear_leaves_memory(engine):
    engine.configure_scan(cfg())
    engine.start_scan()
    engine.fetch_readings()
    assert engine.reading_count() == 2


def test_fetch_on_empty_memory_returns_empty_result(engine):
    """Polling a scan that has produced nothing yet is ordinary; it must
    not surface as a SCPI fault."""
    engine.configure_scan(cfg())
    result = engine.fetch_readings()
    assert result.reading_count == 0
    assert not result.is_complete


def test_operations_require_configuration(engine):
    for call in (engine.start_scan, engine.fetch_readings, engine.wait_for_scan):
        with pytest.raises(ConfigurationError, match="No scan has been configured"):
            call()


def test_abort_is_safe_without_a_running_scan(engine):
    engine.abort_scan()


def test_wait_refuses_infinite_scan(engine):
    engine.configure_scan(cfg(trigger_count=TriggerCount("INF")))
    with pytest.raises(ConfigurationError, match="never completes"):
        engine.wait_for_scan(timeout_s=1)


def test_wait_refuses_externally_triggered_scan(engine):
    """Waiting on a scan that needs an outside stimulus would block
    indefinitely and look like broken hardware."""
    engine.configure_scan(cfg(trigger_source=TriggerSource.EXTERNAL))
    with pytest.raises(ConfigurationError, match="external stimulus"):
        engine.wait_for_scan(timeout_s=1)


def test_wait_refuses_bus_triggered_scan(engine):
    engine.configure_scan(cfg(trigger_source=TriggerSource.BUS))
    with pytest.raises(ConfigurationError, match="external stimulus"):
        engine.wait_for_scan(timeout_s=1)


def test_memory_overflow_warns_but_proceeds(engine, caplog):
    """The capacity constant is documented, not verified; refusing a
    valid scan on a wrong constant would be worse than warning."""
    import logging

    with caplog.at_level(logging.WARNING, logger="keysight34970"):
        engine.configure_scan(
            cfg("(@101:110)", trigger_count=TriggerCount(6000))
        )
    assert any("reading memory" in r.message for r in caplog.records)


def test_instrument_statistics(engine):
    engine.run_scan(cfg(trigger_count=TriggerCount(2)), timeout_s=5)
    stats = engine.get_instrument_statistics()
    assert stats.count == 4
    assert stats.minimum <= stats.average <= stats.maximum
    assert stats.span >= 0


def test_scan_readings_use_measurement_engine_functions(server):
    """A scan spanning functions must tag each reading with its own
    channel's function, not one assumed for all."""
    from keysight34970.measurement.engine import ScpiMeasurementEngine
    from keysight34970.measurement.models import MeasurementConfig

    conn = Connection(
        ConnectionConfig(
            transport=TransportKind.TCP_SOCKET,
            model=InstrumentModel.DAQ_34972A,
            host=server.host,
            port=server.port,
        )
    )
    conn.connect()
    try:
        measurement = ScpiMeasurementEngine(conn)
        measurement.configure(
            ChannelList.parse("(@101)"),
            MeasurementConfig(MeasurementFunction.DC_VOLTAGE),
        )
        measurement.configure(
            ChannelList.parse("(@102)"),
            MeasurementConfig(MeasurementFunction.RESISTANCE_2W),
        )
        scanner = ScpiScannerEngine(conn, measurement_engine=measurement)
        result = scanner.run_scan(cfg(), timeout_s=5)

        by_channel = {r.channel.address: r.measurement.function for r in result.readings}
        assert by_channel[101] is MeasurementFunction.DC_VOLTAGE
        assert by_channel[102] is MeasurementFunction.RESISTANCE_2W
    finally:
        conn.close()


def test_values_only_format(engine):
    result = engine.run_scan(
        cfg(include_timestamp=False, include_channel=False), timeout_s=5
    )
    assert result.reading_count == 2
    assert result.readings[0].channel is None


# -- keywords -------------------------------------------------------


def test_run_scan_keyword_returns_records(lib):
    rows = lib.run_scan("(@101,102)", sweeps="3")
    assert len(rows) == 6
    assert rows[0]["channel"] == "101"
    assert rows[0]["sweep"] == 1
    assert rows[-1]["sweep"] == 3
    assert rows[0]["overrange"] is False


def test_configure_start_wait_fetch_keywords(lib):
    lib.configure_scan("(@101:103)", sweeps="2")
    lib.start_scan()
    assert lib.wait_for_scan(timeout="5") is True
    rows = lib.fetch_scan_readings()
    assert len(rows) == 6


def test_reading_count_keyword(lib):
    lib.configure_scan("(@101,102)", sweeps="4")
    lib.start_scan()
    assert lib.get_scan_reading_count() == 8


def test_readings_for_channel_keyword(lib):
    lib.run_scan("(@101,102)", sweeps="3")
    assert len(lib.get_scan_readings_for_channel("101")) == 3


def test_readings_for_channel_requires_a_scan(lib):
    with pytest.raises(AssertionError, match="No scan readings available"):
        lib.get_scan_readings_for_channel("101")


def test_instrument_statistics_keyword(lib):
    lib.run_scan("(@101,102)", sweeps="2")
    stats = lib.get_instrument_statistics()
    assert stats["count"] == 4
    assert stats["span"] >= 0


def test_timer_scan_via_keyword(lib):
    lib.configure_scan("(@101)", trigger_source="TIMER", interval="0.01", sweeps="3")
    lib.start_scan()
    assert lib.wait_for_scan(timeout="5")


def test_interval_required_for_timer(lib):
    with pytest.raises(Exception, match="requires trigger_timer_s"):
        lib.configure_scan("(@101)", trigger_source="TIMER", sweeps="2")


def test_unknown_trigger_source_lists_options(lib):
    with pytest.raises(AssertionError, match="Unknown trigger source"):
        lib.configure_scan("(@101)", trigger_source="COSMIC_RAY")


def test_bad_interval_rejected(lib):
    with pytest.raises(AssertionError, match="interval must be a number"):
        lib.configure_scan("(@101)", trigger_source="TIMER", interval="soon")


def test_scanner_keywords_require_connection():
    library = Keysight34970()
    for call in (
        lambda: library.configure_scan("(@101)"),
        library.start_scan,
        library.abort_scan,
        library.get_scan_reading_count,
        library.get_instrument_statistics,
        lambda: library.run_scan("(@101)"),
    ):
        with pytest.raises(AssertionError, match="No instrument connection"):
            call()


def test_abort_keyword_is_safe(lib):
    lib.abort_scan()


def test_scanner_state_cleared_on_disconnect(lib):
    lib.run_scan("(@101)")
    assert lib.get_scan_readings_for_channel("101")
    lib.disconnect_from_instrument()
    with pytest.raises(AssertionError):
        lib.get_scan_readings_for_channel("101")
