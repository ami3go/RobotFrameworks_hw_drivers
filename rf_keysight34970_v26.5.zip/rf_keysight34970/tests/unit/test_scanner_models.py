import pytest

from keysight34970.exceptions import CommandError, ConfigurationError
from keysight34970.measurement.channels import ChannelList
from keysight34970.measurement.models import MeasurementFunction, Unit
from keysight34970.scanner.models import (
    READING_MEMORY_CAPACITY,
    InstrumentStatistics,
    ScanConfig,
    ScanReading,
    ScanResult,
    TriggerCount,
    TriggerSource,
)
from keysight34970.scanner.parsing import fields_per_reading, parse_scan_response


def config(channels="(@101,102)", **kwargs):
    return ScanConfig(channels=ChannelList.parse(channels), **kwargs)


# -- TriggerCount ---------------------------------------------------


@pytest.mark.parametrize("value,sweeps", [(1, 1), (5, 5), ("10", 10), ("INF", None)])
def test_trigger_count_forms(value, sweeps):
    assert TriggerCount(value).sweeps == sweeps


def test_trigger_count_infinite_variants():
    assert TriggerCount("inf").is_infinite
    assert TriggerCount("INFINITE").is_infinite
    assert TriggerCount("INF").to_scpi() == "INF"


def test_trigger_count_copy_construction():
    assert TriggerCount(TriggerCount(7)).sweeps == 7


@pytest.mark.parametrize("bad", [0, -1, "zero", 1.5, ""])
def test_trigger_count_rejects_invalid(bad):
    with pytest.raises(ConfigurationError, match="positive integer or INF"):
        TriggerCount(bad)


def test_trigger_count_equality_and_repr():
    assert TriggerCount(3) == TriggerCount(3)
    assert TriggerCount(3) != TriggerCount(4)
    assert "3" in repr(TriggerCount(3))
    assert TriggerCount(3).__eq__("3") is NotImplemented


# -- TriggerSource --------------------------------------------------


def test_timer_requires_interval_flag():
    assert TriggerSource.TIMER.requires_timer_interval
    assert not TriggerSource.IMMEDIATE.requires_timer_interval


@pytest.mark.parametrize(
    "source,self_starting",
    [
        (TriggerSource.IMMEDIATE, True),
        (TriggerSource.TIMER, True),
        (TriggerSource.EXTERNAL, False),
        (TriggerSource.BUS, False),
        (TriggerSource.ALARM, False),
    ],
)
def test_self_starting_classification(source, self_starting):
    """A non-self-starting scan waited on without an external stimulus
    looks exactly like a hung instrument."""
    assert source.is_self_starting is self_starting


# -- ScanConfig -----------------------------------------------------


def test_empty_scan_rejected():
    with pytest.raises(ConfigurationError, match="at least one channel"):
        ScanConfig(channels=ChannelList())


def test_timer_source_requires_interval():
    with pytest.raises(ConfigurationError, match="requires trigger_timer_s"):
        config(trigger_source=TriggerSource.TIMER)


def test_interval_without_timer_source_rejected():
    """Setting an interval that will be ignored is a mistake worth
    naming, not silently dropping."""
    with pytest.raises(ConfigurationError, match="applies only to"):
        config(trigger_source=TriggerSource.IMMEDIATE, trigger_timer_s=5)


@pytest.mark.parametrize("interval", [-1, 400_000])
def test_interval_bounds(interval):
    with pytest.raises(ConfigurationError, match="trigger_timer_s must be"):
        config(trigger_source=TriggerSource.TIMER, trigger_timer_s=interval)


@pytest.mark.parametrize("delay", [-0.1, 61])
def test_channel_delay_bounds(delay):
    with pytest.raises(ConfigurationError, match="channel_delay_s"):
        config(channel_delay_s=delay)


def test_readings_and_totals():
    cfg = config("(@101:110)", trigger_count=TriggerCount(100))
    assert cfg.readings_per_sweep == 10
    assert cfg.total_readings == 1000
    assert not cfg.exceeds_reading_memory()


def test_infinite_scan_has_no_total():
    cfg = config(trigger_count=TriggerCount("INF"))
    assert cfg.total_readings is None
    assert cfg.exceeds_reading_memory()


def test_memory_overflow_detection():
    cfg = config("(@101:110)", trigger_count=TriggerCount(6000))
    assert cfg.total_readings == 60_000 > READING_MEMORY_CAPACITY
    assert cfg.exceeds_reading_memory()


def test_duration_estimate_for_timer_scan():
    cfg = config(
        trigger_source=TriggerSource.TIMER,
        trigger_timer_s=2.0,
        trigger_count=TriggerCount(10),
    )
    assert cfg.estimated_duration_s() == pytest.approx(20.0)


def test_duration_estimate_uses_channel_delay_when_larger():
    cfg = config("(@101:110)", channel_delay_s=1.0, trigger_count=TriggerCount(2))
    assert cfg.estimated_duration_s() == pytest.approx(20.0)


def test_duration_unknown_for_external_trigger():
    cfg = config(trigger_source=TriggerSource.EXTERNAL, trigger_count=TriggerCount(5))
    assert cfg.estimated_duration_s() is None


def test_duration_unknown_for_infinite_scan():
    assert config(trigger_count=TriggerCount("INF")).estimated_duration_s() is None


# -- parsing --------------------------------------------------------


def test_fields_per_reading_combinations():
    assert fields_per_reading(include_timestamp=True, include_channel=True) == 8
    assert fields_per_reading(include_timestamp=True, include_channel=False) == 7
    assert fields_per_reading(include_timestamp=False, include_channel=True) == 2
    assert fields_per_reading(include_timestamp=False, include_channel=False) == 1


def test_parse_full_format():
    readings = parse_scan_response(
        "+1.04E+00,2026,07,22,14,30,15.250,101", MeasurementFunction.DC_VOLTAGE
    )
    assert readings[0].value == pytest.approx(1.04)
    assert readings[0].channel.address == 101
    assert readings[0].instrument_timestamp == "2026-07-22T14:30:15.250"
    assert readings[0].measurement.unit is Unit.VOLT


def test_parse_values_only():
    readings = parse_scan_response(
        "+1.0E+00,+2.0E+00",
        MeasurementFunction.DC_VOLTAGE,
        include_timestamp=False,
        include_channel=False,
    )
    assert [r.value for r in readings] == [1.0, 2.0]
    assert readings[0].channel is None


def test_parse_channel_only():
    readings = parse_scan_response(
        "+1.0E+00,101,+2.0E+00,102",
        MeasurementFunction.DC_VOLTAGE,
        include_timestamp=False,
    )
    assert [r.channel.address for r in readings] == [101, 102]


def test_misaligned_field_count_rejected():
    """A field count that is not a whole number of readings means the
    instrument's format does not match what the driver expects; every
    reading after the first would be misaligned."""
    with pytest.raises(CommandError, match="not a whole number"):
        parse_scan_response("+1.0E+00,2026,07", MeasurementFunction.DC_VOLTAGE)


def test_empty_scan_response_rejected():
    with pytest.raises(CommandError, match="empty scan response"):
        parse_scan_response("   ", MeasurementFunction.DC_VOLTAGE)


def test_unparseable_value_rejected():
    with pytest.raises(CommandError, match="Could not parse"):
        parse_scan_response(
            "NOTANUMBER,101",
            MeasurementFunction.DC_VOLTAGE,
            include_timestamp=False,
        )


def test_sweep_numbering():
    response = ",".join(f"+{i}.0E+00,10{(i % 2) + 1}" for i in range(4))
    readings = parse_scan_response(
        response,
        MeasurementFunction.DC_VOLTAGE,
        include_timestamp=False,
        readings_per_sweep=2,
    )
    assert [r.sweep for r in readings] == [1, 1, 2, 2]


def test_per_channel_functions_applied():
    """A scan spanning functions must tag each reading with its own
    channel's function, not the first channel's."""
    readings = parse_scan_response(
        "+1.0E+00,101,+2.0E+00,102",
        MeasurementFunction.DC_VOLTAGE,
        include_timestamp=False,
        channel_functions={102: MeasurementFunction.RESISTANCE_2W},
    )
    assert readings[0].measurement.function is MeasurementFunction.DC_VOLTAGE
    assert readings[1].measurement.function is MeasurementFunction.RESISTANCE_2W
    assert readings[1].measurement.unit is Unit.OHM


def test_unparseable_channel_does_not_discard_the_reading():
    readings = parse_scan_response(
        "+1.0E+00,XYZ", MeasurementFunction.DC_VOLTAGE, include_timestamp=False
    )
    assert readings[0].value == 1.0
    assert readings[0].channel is None


def test_malformed_timestamp_becomes_none():
    readings = parse_scan_response(
        "+1.0E+00,YYYY,07,22,14,30,15.0,101", MeasurementFunction.DC_VOLTAGE
    )
    assert readings[0].instrument_timestamp is None
    assert readings[0].value == 1.0


# -- ScanResult -----------------------------------------------------


def _result(values, channels=("101", "102"), sweeps=2):
    cfg = config(trigger_count=TriggerCount(sweeps))
    response = ",".join(
        f"+{v}E+00,{channels[i % len(channels)]}" for i, v in enumerate(values)
    )
    readings = parse_scan_response(
        response,
        MeasurementFunction.DC_VOLTAGE,
        include_timestamp=False,
        readings_per_sweep=len(channels),
    )
    return ScanResult(readings=readings, config=cfg)


def test_scan_result_counts():
    result = _result([1.0, 2.0, 3.0, 4.0])
    assert result.reading_count == 4
    assert result.sweep_count == 2
    assert result.is_complete


def test_incomplete_scan_detected():
    """A short scan is not an error the instrument reports; it just
    returns fewer readings and silently truncates any analysis."""
    result = _result([1.0, 2.0])
    assert not result.is_complete


def test_for_channel_slices_by_channel_not_position():
    result = _result([1.0, 2.0, 3.0, 4.0])
    assert [r.value for r in result.for_channel(101)] == [1.0, 3.0]
    assert [r.value for r in result.for_channel("102")] == [2.0, 4.0]


def test_statistics_for_channel():
    result = _result([1.0, 2.0, 3.0, 4.0])
    stats = result.statistics_for_channel(101)
    assert stats.count == 2
    assert stats.minimum == 1.0
    assert stats.maximum == 3.0


def test_statistics_for_absent_channel_rejected():
    result = _result([1.0, 2.0, 3.0, 4.0])
    with pytest.raises(ConfigurationError, match="No readings for channel"):
        result.statistics_for_channel(199)


def test_values_and_overrange_listing():
    result = _result([1.0, 2.0, 3.0, 4.0])
    assert result.values() == [1.0, 2.0, 3.0, 4.0]
    assert result.overrange_readings() == []


def test_overrange_readings_detected():
    readings = parse_scan_response(
        "+9.9E+37,101", MeasurementFunction.DC_VOLTAGE, include_timestamp=False
    )
    result = ScanResult(readings=readings, config=config())
    assert len(result.overrange_readings()) == 1


# -- InstrumentStatistics -------------------------------------------


def test_instrument_statistics_span():
    stats = InstrumentStatistics(minimum=1.0, maximum=5.0, average=3.0, count=10)
    assert stats.span == pytest.approx(4.0)
    assert stats.unit is Unit.UNKNOWN
