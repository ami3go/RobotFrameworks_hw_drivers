from keysight34970.models import InstrumentIdentity, ScpiError


def test_identity_parse_well_formed():
    idn = InstrumentIdentity.parse("Keysight Technologies,34972A,MY58012345,1.13-1.09-1.03")
    assert idn.manufacturer == "Keysight Technologies"
    assert idn.model == "34972A"
    assert idn.serial_number == "MY58012345"
    assert idn.firmware_version == "1.13-1.09-1.03"


def test_identity_parse_short_response_does_not_raise():
    idn = InstrumentIdentity.parse("Keysight,34970A")
    assert idn.manufacturer == "Keysight"
    assert idn.model == "34970A"
    assert idn.serial_number == ""
    assert idn.firmware_version == ""


def test_scpi_error_parse_no_error():
    err = ScpiError.parse('0,"No error"')
    assert err.is_no_error
    assert err.code == 0


def test_scpi_error_parse_with_error():
    err = ScpiError.parse('-113,"Undefined header"')
    assert not err.is_no_error
    assert err.code == -113
    assert err.message == "Undefined header"


def test_scpi_error_parse_malformed_code_defaults_to_zero():
    """A non-numeric code must not crash parsing; treat as no-error
    rather than raising inside an error-handling path."""

    err = ScpiError.parse('NOT_A_NUMBER,"weird firmware"')
    assert err.code == 0
    assert err.message == "weird firmware"


def test_scpi_error_parse_bare_response():
    err = ScpiError.parse("0")
    assert err.code == 0
    assert err.is_no_error
