import pytest

from keysight34970.config import ConnectionConfig, InstrumentModel, TransportKind
from keysight34970.connection import Connection
from keysight34970.exceptions import ConfigurationError
from keysight34970.measurement.channels import CardType, ChannelList
from keysight34970.measurement.engine import ScpiMeasurementEngine
from keysight34970.measurement.models import (
    AutoRange,
    MeasurementConfig,
    MeasurementFunction,
    Unit,
)

from .fakes import FakeTransport


def make_engine(responses=None, cards=None):
    fake = FakeTransport(
        responses={"*IDN?": "Keysight,34972A,MY1,1.0", **(responses or {})}
    )
    conn = Connection(
        ConnectionConfig(
            transport=TransportKind.TCP_SOCKET,
            model=InstrumentModel.DAQ_34972A,
            host="10.0.0.5",
        ),
        transport=fake,
    )
    conn.connect()
    fake.sent.clear()
    return ScpiMeasurementEngine(conn, cards=cards), fake


def sent_commands(fake):
    """Commands actually issued, excluding error-queue polling."""
    return [c for c in fake.sent if c != "SYST:ERR?"]


# -- configure ------------------------------------------------------


def test_configure_sends_expected_scpi():
    engine, fake = make_engine()
    engine.configure(
        ChannelList.parse("(@101,102)"),
        MeasurementConfig(MeasurementFunction.DC_VOLTAGE),
    )
    assert sent_commands(fake) == ["CONF:VOLT:DC AUTO,DEF,(@101,102)"]


def test_configure_with_explicit_range_and_resolution():
    engine, fake = make_engine()
    engine.configure(
        ChannelList.parse("(@101)"),
        MeasurementConfig(MeasurementFunction.DC_VOLTAGE, range=10, resolution=0.001),
    )
    assert sent_commands(fake) == ["CONF:VOLT:DC 10,0.001,(@101)"]


def test_configure_records_per_channel_state():
    engine, _ = make_engine()
    engine.configure(
        ChannelList.parse("(@101:103)"),
        MeasurementConfig(MeasurementFunction.RESISTANCE_4W),
    )
    for address in (101, 102, 103):
        config = engine.get_configured_function(address)
        assert config.function is MeasurementFunction.RESISTANCE_4W


def test_configure_rejects_empty_channel_list():
    engine, _ = make_engine()
    with pytest.raises(ConfigurationError, match="empty channel list"):
        engine.configure(ChannelList(), MeasurementConfig(MeasurementFunction.DC_VOLTAGE))


def test_configure_rejects_resolution_without_range_before_sending():
    """The failure must arrive before any instrument interaction."""
    engine, fake = make_engine()
    with pytest.raises(ConfigurationError, match="resolution cannot be set"):
        engine.configure(
            ChannelList.parse("(@101)"),
            MeasurementConfig(MeasurementFunction.DC_VOLTAGE, resolution=0.001),
        )
    assert sent_commands(fake) == []


# -- card-aware validation ------------------------------------------


def test_measurement_rejected_on_switch_only_card():
    engine, fake = make_engine(cards={1: CardType.ACT_34903A})
    with pytest.raises(ConfigurationError, match="cannot be routed to the internal DMM"):
        engine.configure(
            ChannelList.parse("(@101)"),
            MeasurementConfig(MeasurementFunction.DC_VOLTAGE),
        )
    assert sent_commands(fake) == []


def test_current_requires_a_current_channel():
    engine, _ = make_engine(cards={1: CardType.MUX_34901A})
    with pytest.raises(ConfigurationError, match="requires a dedicated current channel"):
        engine.configure(
            ChannelList.parse("(@101)"),
            MeasurementConfig(MeasurementFunction.DC_CURRENT),
        )


def test_current_allowed_on_current_channel():
    engine, fake = make_engine(cards={1: CardType.MUX_34901A})
    engine.configure(
        ChannelList.parse("(@121)"), MeasurementConfig(MeasurementFunction.DC_CURRENT)
    )
    assert sent_commands(fake) == ["CONF:CURR:DC AUTO,DEF,(@121)"]


def test_invalid_channel_for_declared_card_rejected():
    engine, _ = make_engine(cards={1: CardType.MUX_34902A})
    with pytest.raises(ConfigurationError, match="not valid on a 34902A"):
        engine.configure(
            ChannelList.parse("(@117)"), MeasurementConfig(MeasurementFunction.DC_VOLTAGE)
        )


def test_undeclared_slot_skips_card_validation():
    """A partially-described bench must remain usable."""
    engine, fake = make_engine(cards={1: CardType.MUX_34901A})
    engine.configure(
        ChannelList.parse("(@201)"), MeasurementConfig(MeasurementFunction.DC_VOLTAGE)
    )
    assert sent_commands(fake) == ["CONF:VOLT:DC AUTO,DEF,(@201)"]


def test_set_card_validates_slot():
    engine, _ = make_engine()
    with pytest.raises(ConfigurationError, match="slot must be 1-3"):
        engine.set_card(4, CardType.MUX_34901A)


def test_set_card_enables_validation_afterwards():
    engine, _ = make_engine()
    engine.configure(
        ChannelList.parse("(@101)"), MeasurementConfig(MeasurementFunction.DC_VOLTAGE)
    )  # allowed while slot undeclared
    engine.set_card(1, CardType.ACT_34903A)
    with pytest.raises(ConfigurationError, match="internal DMM"):
        engine.configure(
            ChannelList.parse("(@101)"), MeasurementConfig(MeasurementFunction.DC_VOLTAGE)
        )


# -- read -----------------------------------------------------------


def test_read_sets_scan_list_then_reads():
    engine, fake = make_engine(responses={"READ?": "+1.0E+00,+2.0E+00"})
    engine.configure(
        ChannelList.parse("(@101,102)"), MeasurementConfig(MeasurementFunction.DC_VOLTAGE)
    )
    fake.sent.clear()

    result = engine.read()

    assert sent_commands(fake) == ["ROUT:SCAN (@101,102)", "READ?"]
    assert [m.value for m in result] == [1.0, 2.0]
    assert [m.channel.address for m in result] == [101, 102]
    assert all(m.unit is Unit.VOLT for m in result)


def test_read_without_configuration_fails_clearly():
    engine, _ = make_engine()
    with pytest.raises(ConfigurationError, match="No channels have been configured"):
        engine.read()


def test_read_of_unconfigured_channel_refuses():
    engine, _ = make_engine(responses={"READ?": "+1.0E+00"})
    engine.configure(
        ChannelList.parse("(@101)"), MeasurementConfig(MeasurementFunction.DC_VOLTAGE)
    )
    with pytest.raises(ConfigurationError, match="have not been configured"):
        engine.read(ChannelList.parse("(@105)"))


def test_read_of_empty_explicit_list_rejected():
    engine, _ = make_engine()
    with pytest.raises(ConfigurationError, match="empty channel list"):
        engine.read(ChannelList())


def test_read_subset_of_configured_channels():
    engine, fake = make_engine(responses={"READ?": "+1.0E+00"})
    engine.configure(
        ChannelList.parse("(@101:103)"), MeasurementConfig(MeasurementFunction.DC_VOLTAGE)
    )
    fake.sent.clear()
    result = engine.read(ChannelList.parse("(@102)"))
    assert sent_commands(fake) == ["ROUT:SCAN (@102)", "READ?"]
    assert result[0].channel.address == 102


def test_read_with_mixed_functions_tags_each_channel_correctly():
    """A scan may span functions; each reading must carry its own
    channel's function and unit, not the first channel's."""
    engine, fake = make_engine(responses={"READ?": "+1.0E+00,+2.0E+00"})
    engine.configure(
        ChannelList.parse("(@101)"), MeasurementConfig(MeasurementFunction.DC_VOLTAGE)
    )
    engine.configure(
        ChannelList.parse("(@102)"), MeasurementConfig(MeasurementFunction.RESISTANCE_2W)
    )
    fake.sent.clear()

    result = engine.read()

    assert result[0].function is MeasurementFunction.DC_VOLTAGE
    assert result[0].unit is Unit.VOLT
    assert result[1].function is MeasurementFunction.RESISTANCE_2W
    assert result[1].unit is Unit.OHM


# -- measure --------------------------------------------------------


def test_measure_sends_one_shot_command():
    engine, fake = make_engine(responses={"MEAS:VOLT:DC? AUTO,DEF,(@101)": "+1.5E+00"})
    result = engine.measure(
        ChannelList.parse("(@101)"), MeasurementConfig(MeasurementFunction.DC_VOLTAGE)
    )
    assert sent_commands(fake) == ["MEAS:VOLT:DC? AUTO,DEF,(@101)"]
    assert result[0].value == 1.5


def test_measure_records_configuration_it_applied():
    engine, _ = make_engine(responses={"MEAS:RES? AUTO,DEF,(@104)": "+100.0E+00"})
    engine.measure(
        ChannelList.parse("(@104)"), MeasurementConfig(MeasurementFunction.RESISTANCE_2W)
    )
    assert (
        engine.get_configured_function(104).function
        is MeasurementFunction.RESISTANCE_2W
    )


def test_measure_validates_before_sending():
    engine, fake = make_engine(cards={1: CardType.ACT_34903A})
    with pytest.raises(ConfigurationError, match="internal DMM"):
        engine.measure(
            ChannelList.parse("(@101)"), MeasurementConfig(MeasurementFunction.DC_VOLTAGE)
        )
    assert sent_commands(fake) == []


def test_measure_detects_overrange():
    engine, _ = make_engine(
        responses={"MEAS:VOLT:DC? AUTO,DEF,(@101)": "+9.90000000E+37"}
    )
    result = engine.measure(
        ChannelList.parse("(@101)"), MeasurementConfig(MeasurementFunction.DC_VOLTAGE)
    )
    assert result[0].is_overrange


# -- misc -----------------------------------------------------------


def test_get_configured_function_returns_none_for_unknown_channel():
    engine, _ = make_engine()
    assert engine.get_configured_function(101) is None


def test_cards_property_returns_a_copy():
    engine, _ = make_engine(cards={1: CardType.MUX_34901A})
    engine.cards[2] = CardType.MUX_34902A
    assert 2 not in engine.cards


def test_engine_uses_connection_error_checking():
    """The engine must not bypass the Phase 1 error-queue policy."""
    engine, fake = make_engine()
    engine.configure(
        ChannelList.parse("(@101)"), MeasurementConfig(MeasurementFunction.DC_VOLTAGE)
    )
    assert "SYST:ERR?" in fake.sent


# -- channel order normalisation ------------------------------------


def test_read_normalises_channel_order_ascending():
    """Readings are attached positionally, and the instrument scans in
    ascending channel order. If the driver sent a non-ascending scan
    list and mapped positionally, every reading would be attributed to
    the wrong channel -- counts would still match, so the mismatch
    guard cannot catch it."""

    engine, fake = make_engine(responses={"READ?": "+1.0E+00,+5.0E+00"})
    engine.configure(
        ChannelList.parse("(@105)"), MeasurementConfig(MeasurementFunction.DC_VOLTAGE)
    )
    engine.configure(
        ChannelList.parse("(@101)"), MeasurementConfig(MeasurementFunction.DC_VOLTAGE)
    )
    fake.sent.clear()

    result = engine.read()

    assert sent_commands(fake)[0] == "ROUT:SCAN (@101,105)"
    assert [m.channel.address for m in result] == [101, 105]


def test_explicit_read_list_is_also_normalised():
    engine, fake = make_engine(responses={"READ?": "+1.0E+00,+2.0E+00"})
    engine.configure(
        ChannelList.parse("(@101:110)"), MeasurementConfig(MeasurementFunction.DC_VOLTAGE)
    )
    fake.sent.clear()

    result = engine.read(ChannelList.parse("(@107,103)"))

    assert sent_commands(fake)[0] == "ROUT:SCAN (@103,107)"
    assert [m.channel.address for m in result] == [103, 107]


def test_measure_normalises_channel_order():
    engine, fake = make_engine(
        responses={"MEAS:VOLT:DC? AUTO,DEF,(@101,105)": "+1.0E+00,+5.0E+00"}
    )
    result = engine.measure(
        ChannelList.parse("(@105,101)"),
        MeasurementConfig(MeasurementFunction.DC_VOLTAGE),
    )
    assert sent_commands(fake) == ["MEAS:VOLT:DC? AUTO,DEF,(@101,105)"]
    assert [m.channel.address for m in result] == [101, 105]
    assert [m.value for m in result] == [1.0, 5.0]


def test_normalisation_spans_slots_correctly():
    engine, fake = make_engine(responses={"READ?": "+1.0E+00,+2.0E+00,+3.0E+00"})
    engine.configure(
        ChannelList.parse("(@301,101,205)"),
        MeasurementConfig(MeasurementFunction.DC_VOLTAGE),
    )
    fake.sent.clear()
    result = engine.read()
    assert [m.channel.address for m in result] == [101, 205, 301]
