"""
Integration tests: full stack (keyword layer -> Connection -> real TCP
socket -> mock SCPI instrument), as opposed to the unit tests which
isolate individual layers.

Two tiers:

- ``@pytest.mark.integration`` — runs against the in-repo mock
  instrument. Always run in CI; no hardware needed.
- ``@pytest.mark.hardware`` — runs against a real 34970A/34972A.
  Deselected by default (see ``addopts`` in pyproject.toml). Enable
  with::

      KEYSIGHT_HOST=10.0.0.12 pytest -m hardware

  This is the mechanism by which the lifecycle's Gate 4 criterion
  "examples verified on supported hardware where applicable" is
  satisfied on a real bench; the mock cannot substitute for it.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from mock_instrument import MockScpiServer  # noqa: E402

from keysight34970 import Connection, ConnectionConfig, InstrumentModel, TransportKind  # noqa: E402
from keysight34970.library import Keysight34970  # noqa: E402

pytestmark = pytest.mark.integration


@pytest.fixture
def mock_server():
    server = MockScpiServer()
    server.start()
    yield server
    server.stop()


# -- full-stack lifecycle -------------------------------------------


def test_full_connect_measure_disconnect_cycle(mock_server):
    lib = Keysight34970()
    lib.connect_to_instrument(
        "34972A", "TCP", mock_server.host, port=mock_server.port, alias="daq1"
    )
    try:
        lib.instrument_should_be_connected()
        assert "34972A" in lib.get_instrument_identity()
        lib.clear_instrument_status()
        assert lib.query_scpi_command("*IDN?").startswith("Keysight")
    finally:
        lib.disconnect_from_instrument()

    assert lib.get_connection_state() == "IDLE"


def test_repeated_connect_disconnect_cycles_do_not_leak_state(mock_server):
    """Robot suites commonly connect/disconnect per test case; verify
    the library survives repeated cycles on one instance."""

    lib = Keysight34970()
    for _ in range(5):
        lib.connect_to_instrument(
            "34972A", "TCP", mock_server.host, port=mock_server.port
        )
        assert lib.get_connection_state() == "CONNECTED"
        lib.disconnect_from_instrument()
        assert lib.get_connection_state() == "IDLE"


def test_error_then_recovery_over_real_socket(mock_server):
    lib = Keysight34970()
    lib.connect_to_instrument(
        "34972A", "TCP", mock_server.host, port=mock_server.port
    )
    try:
        with pytest.raises(Exception, match="Instrument reported error"):
            lib.send_scpi_command("BOGUS:COMMAND")

        # Connection must still be usable after an instrument-side error.
        lib.instrument_should_be_connected()
        assert "34972A" in lib.query_scpi_command("*IDN?")

        lib.reconnect_to_instrument()
        lib.instrument_should_be_connected()
    finally:
        lib.disconnect_from_instrument()


def test_cls_clears_pending_errors_end_to_end(mock_server):
    """*CLS should empty the queue, so a subsequent drain returns
    nothing even after errors were generated."""

    config = ConnectionConfig(
        transport=TransportKind.TCP_SOCKET,
        model=InstrumentModel.DAQ_34972A,
        host=mock_server.host,
        port=mock_server.port,
    )
    with Connection(config) as conn:
        conn.write("BOGUS:COMMAND", check_errors=False)
        conn.write("BOGUS:COMMAND", check_errors=False)
        conn.clear_status()
        assert conn.drain_error_queue() == []


def test_connection_context_manager_closes_socket(mock_server):
    config = ConnectionConfig(
        transport=TransportKind.TCP_SOCKET,
        model=InstrumentModel.DAQ_34972A,
        host=mock_server.host,
        port=mock_server.port,
    )
    with Connection(config) as conn:
        assert conn.is_connected
    assert not conn.is_connected


def test_model_mismatch_rejected_end_to_end(mock_server):
    lib = Keysight34970()
    with pytest.raises(Exception, match="does not match"):
        lib.connect_to_instrument(
            "34970A", "TCP", mock_server.host, port=mock_server.port
        )
    # A rejected connect must not leave a usable connection behind.
    assert lib.get_connection_state() in {"ERROR", "IDLE"}


def test_connect_to_wrong_port_fails_cleanly():
    lib = Keysight34970()
    with pytest.raises(Exception):
        lib.connect_to_instrument("34972A", "TCP", "127.0.0.1", port=1, timeout=1.0)


# -- real hardware (opt-in) -----------------------------------------


@pytest.mark.hardware
def test_real_instrument_identity():
    host = os.environ.get("KEYSIGHT_HOST")
    if not host:
        pytest.skip("KEYSIGHT_HOST not set")

    model = os.environ.get("KEYSIGHT_MODEL", "34972A")
    lib = Keysight34970()
    lib.connect_to_instrument(model, "TCP", host, alias="hw")
    try:
        idn = lib.get_instrument_identity()
        assert model in idn
        assert lib.drain_instrument_error_queue() == []
    finally:
        lib.disconnect_from_instrument()


# -- measurement integration (Phase 2) ------------------------------


def test_configure_read_cycle_over_real_socket(mock_server):
    lib = Keysight34970()
    lib.connect_to_instrument("34972A", "TCP", mock_server.host, port=mock_server.port)
    try:
        lib.configure_measurement("DCV", "(@101:105)", range="10")
        first = lib.read_measurement()
        second = lib.read_measurement()
        assert len(first) == 5
        assert first == second  # configuration persists between reads
    finally:
        lib.disconnect_from_instrument()


def test_measurement_survives_an_instrument_error(mock_server):
    """An instrument-side error must not poison subsequent measurement."""
    lib = Keysight34970()
    lib.connect_to_instrument("34972A", "TCP", mock_server.host, port=mock_server.port)
    try:
        lib.configure_measurement("DCV", "(@101)")
        with pytest.raises(Exception):
            lib.send_scpi_command("BOGUS:COMMAND")
        assert len(lib.read_measurement()) == 1
    finally:
        lib.disconnect_from_instrument()


def test_measurement_state_does_not_leak_across_sessions(mock_server):
    lib = Keysight34970()
    for _ in range(3):
        lib.connect_to_instrument(
            "34972A", "TCP", mock_server.host, port=mock_server.port
        )
        lib.configure_measurement("DCV", "(@101:103)")
        assert len(lib.read_measurement()) == 3
        lib.disconnect_from_instrument()


def test_card_validation_end_to_end(mock_server):
    lib = Keysight34970()
    lib.connect_to_instrument("34972A", "TCP", mock_server.host, port=mock_server.port)
    try:
        lib.set_installed_card(1, "34901A")
        lib.configure_measurement("DCV", "(@101)")          # fine
        lib.configure_measurement("DCI", "(@121)")          # current channel
        with pytest.raises(Exception, match="current channel"):
            lib.configure_measurement("DCI", "(@101)")
        with pytest.raises(Exception, match="not valid on a 34901A"):
            lib.configure_measurement("DCV", "(@130)")
    finally:
        lib.disconnect_from_instrument()


def test_statistics_and_details_end_to_end(mock_server):
    lib = Keysight34970()
    lib.connect_to_instrument("34972A", "TCP", mock_server.host, port=mock_server.port)
    try:
        lib.configure_measurement("DCV", "(@101:104)")
        rows = lib.read_measurement_details()
        assert [r["channel"] for r in rows] == ["101", "102", "103", "104"]
        assert all(r["unit"] == "V" for r in rows)

        stats = lib.get_measurement_statistics()
        assert stats["count"] == 4
        assert stats["minimum"] <= stats["average"] <= stats["maximum"]
    finally:
        lib.disconnect_from_instrument()


def test_acquisition_settings_reach_the_instrument(mock_server):
    """Settings must survive the whole stack, not just unit-level mocks."""
    lib = Keysight34970()
    lib.connect_to_instrument("34972A", "TCP", mock_server.host, port=mock_server.port)
    try:
        lib.configure_measurement("DCV", "(@101)", range="10", nplc="10", autozero="OFF")
        assert lib.get_configured_function("101") == "VOLT:DC"
        assert len(lib.read_measurement()) == 1
    finally:
        lib.disconnect_from_instrument()


@pytest.mark.hardware
def test_real_instrument_dc_voltage():
    """Requires a real mainframe with a multiplexer in slot 1.

    This is the test that would confirm the ascending-scan assumption
    the driver's channel-order normalisation depends on: if readings
    come back mapped to the wrong channels, that assumption is wrong.
    """

    host = os.environ.get("KEYSIGHT_HOST")
    if not host:
        pytest.skip("KEYSIGHT_HOST not set")

    model = os.environ.get("KEYSIGHT_MODEL", "34972A")
    channels = os.environ.get("KEYSIGHT_CHANNELS", "(@101,102)")

    lib = Keysight34970()
    lib.connect_to_instrument(model, "TCP", host, alias="hw", timeout=30)
    try:
        lib.configure_measurement("DCV", channels, range="10")
        rows = lib.read_measurement_details()

        assert rows, "no readings returned"
        addresses = [r["channel"] for r in rows]
        assert addresses == sorted(addresses), (
            "readings did not come back in ascending channel order; the "
            "driver's normalisation assumption is wrong and multi-channel "
            "readings may be misattributed"
        )
        assert not any(r["overrange"] for r in rows)
        assert lib.drain_instrument_error_queue() == []
    finally:
        lib.disconnect_from_instrument()


# -- temperature integration (Phase 4) ------------------------------


def test_temperature_configure_and_read(mock_server):
    lib = Keysight34970()
    lib.connect_to_instrument("34972A", "TCP", mock_server.host, port=mock_server.port)
    try:
        lib.configure_thermocouple("(@101:103)", "K", open_detect="ON")
        values = lib.read_temperature()
        assert len(values) == 3
    finally:
        lib.disconnect_from_instrument()


def test_temperature_channels_are_scannable(mock_server):
    """Temperature channels must be visible to the scanner and tagged as
    temperature, not treated as unconfigured."""
    lib = Keysight34970()
    lib.connect_to_instrument("34972A", "TCP", mock_server.host, port=mock_server.port)
    try:
        lib.configure_thermocouple("(@101,102)", "K")
        result = lib.run_scan("(@101,102)", sweeps="2", timeout=5)
        assert result

        rows = lib.fetch_scan_readings()
        assert rows
    finally:
        lib.disconnect_from_instrument()


def test_mixed_temperature_and_voltage_scan(mock_server):
    """A scan spanning temperature and voltage must report each channel
    in its own units rather than assuming one function throughout."""
    lib = Keysight34970()
    lib.connect_to_instrument("34972A", "TCP", mock_server.host, port=mock_server.port)
    try:
        lib.configure_thermocouple("(@101)", "K")
        lib.configure_measurement("DCV", "(@102)")

        rows = lib.read_measurement_details("(@102)")
        assert rows[0]["unit"] == "V"

        temps = lib.read_temperature("(@101)")
        assert len(temps) == 1
    finally:
        lib.disconnect_from_instrument()


def test_temperature_state_cleared_on_disconnect(mock_server):
    lib = Keysight34970()
    lib.connect_to_instrument("34972A", "TCP", mock_server.host, port=mock_server.port)
    lib.configure_thermocouple("(@101)", "K")
    assert lib.get_temperature_configuration("101")
    lib.disconnect_from_instrument()

    lib.connect_to_instrument("34972A", "TCP", mock_server.host, port=mock_server.port)
    try:
        assert lib.get_temperature_configuration("101") in ("", {}, None)
    finally:
        lib.disconnect_from_instrument()


# -- digital I/O integration (Phase 5) ------------------------------


def test_digital_output_state_survives_reconnect_but_record_does_not(mock_server):
    """The instrument keeps driving; the driver forgets. A reconnected
    session must not claim to know what is energised -- and must still
    be able to find out by asking."""
    lib = Keysight34970()
    lib.connect_to_instrument("34972A", "TCP", mock_server.host, port=mock_server.port)
    lib.set_installed_card(3, "34907A")
    lib.write_digital_port("301", 170)
    assert lib.get_driven_outputs()
    lib.disconnect_from_instrument()

    lib.connect_to_instrument("34972A", "TCP", mock_server.host, port=mock_server.port)
    try:
        assert lib.get_driven_outputs() == []
        # The output is still driven; asking the instrument finds it.
        assert lib.read_output_state("(@301)")["301"] == 170
    finally:
        lib.disconnect_from_instrument()


def test_safe_state_end_to_end(mock_server):
    lib = Keysight34970()
    lib.connect_to_instrument("34972A", "TCP", mock_server.host, port=mock_server.port)
    lib.set_installed_card(3, "34907A")
    try:
        lib.write_digital_port("301", 255)
        lib.write_analog_output("304", 8.0)
        reset = lib.return_outputs_to_safe_state()
        assert set(reset) == {"301", "304"}

        state = lib.read_output_state()
        assert state["301"] == 0
        assert state["304"] == 0
    finally:
        lib.disconnect_from_instrument()


def test_digital_and_measurement_coexist(mock_server):
    """The 34907A cannot be routed to the DMM; digital access must not
    weaken that refusal."""
    lib = Keysight34970()
    lib.connect_to_instrument("34972A", "TCP", mock_server.host, port=mock_server.port)
    lib.set_installed_card(3, "34907A")
    try:
        lib.write_digital_port("301", 15)
        with pytest.raises(Exception, match="internal DMM"):
            lib.configure_measurement("DCV", "(@301)")
    finally:
        lib.disconnect_from_instrument()
