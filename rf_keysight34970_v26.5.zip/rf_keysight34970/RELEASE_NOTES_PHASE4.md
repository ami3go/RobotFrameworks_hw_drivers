# Release Notes — v26.04.05 (Phase 4 Complete)

**Release date:** 2026-07-22
**Phase:** 4 of 12 — Temperature
**Status:** All five gates approved. Phases 1–4 complete.

---

## What this release adds

**Temperature measurement.** Thermocouples (all eight alloys), RTDs
(2- and 4-wire, with calibrated reference resistance), and thermistors —
with cold-junction compensation, unit selection, open-junction
detection, and physical-plausibility checking.

## Keywords (9 new; 46 total)

| Keyword | Purpose |
|---|---|
| `Configure Thermocouple` | Alloy, reference junction, open-detect |
| `Configure RTD` | Nominal and calibrated R0, alpha, 4-wire |
| `Configure Thermistor` | Nominal resistance |
| `Read Temperature` | Values |
| `Read Temperature Details` | Full records incl. unit and plausibility |
| `Set Temperature Unit` | C, F or K |
| `Get Temperature Configuration` | What the driver configured |
| `Read Reference Junction Temperature` | Cold-junction reference |
| `Temperature Should Be Within` | Assertion, plausibility-aware |

---

## Read this before wiring a thermocouple

Temperature is the subsystem where a wrong reading is least likely to
*look* wrong. Every failure below returns a believable number.

**The alloy is required and has no default.** The wrong type converts
the junction voltage with the wrong curve — wrong by tens of degrees,
never by an error message.

**Enable `open_detect` on anything that matters.** A thermocouple with a
broken junction reports a temperature, not a fault. Open-detect makes
the instrument test continuity before each reading. It costs a little
speed; that is the only reason it is opt-in.

**Cold-junction compensation defaults to internal.** An uncompensated
junction is wrong by roughly ambient — again, plausibly.

**`nominal` and `reference_ohms` are different things.** Nominal says
"this is a PT100". Reference says "this particular PT100 measures
100.02 ohms at 0 C". The calibrated figure is worth tenths of a degree.

### What the plausibility check cannot do

Readings are checked against the physical range of the configured
sensor, narrowed per alloy. It catches open sensors, grossly wrong
alloys (a type-T channel reporting 1500 C), and unit confusion.

It does **not** catch a moderately wrong alloy. A type-J channel
configured as type K reads about 20 C high at 500 C, and 520 C is
perfectly plausible. **No logic in this driver can detect that.** Verify
the alloy against the physical sensor.

This limit is structural — the information is not present in the
reading — so it is documented rather than papered over. A check whose
limits are unstated implies coverage it does not have.

---

## Verification

| Check | Result |
|---|---|
| Unit + integration tests | **570 passed** |
| Statement coverage | **98.1%** (enforced floor 90%) |
| Robot examples | **52/52** across 5 suites |
| AI contract | revision 17, 46 capabilities, conformance-tested |

Performance: configuring a thermocouple takes 0.169 ms (0.258 ms with
all options); ten channels 0.297 ms, since configuration is
channel-list based. Reading ten channels 0.177 ms.

---

## Still unverified against hardware, and now more so

**No part of this driver has touched a physical 34970A or 34972A.**
Four phases, 570 tests and 98% coverage validated entirely against a
mock this project wrote to match its own assumptions.

Two specific risks now stack:

1. **Channel ordering** (Phase 2). The driver assumes the mainframe
   scans ascending and matches readings to channels by position. If it
   does not, every multi-channel result — now including temperature —
   is misattributed, with correct-looking counts.
2. **Sensor data** (Phase 4). Per-alloy thermocouple ranges and RTD
   coefficients follow published figures, not measurement.

```bash
KEYSIGHT_HOST=10.0.0.12 KEYSIGHT_MODEL=34972A pytest -m hardware
```

Temperature has no hardware test at all yet, and it is the subsystem
where a silent wrong answer is most likely.

---

## What's next

**Phase 5 — Digital I/O:** 34907A digital I/O and counter support.
