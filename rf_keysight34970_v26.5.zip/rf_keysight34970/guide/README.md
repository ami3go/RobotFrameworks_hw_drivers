# Guides

| Guide | Purpose |
|---|---|
| [PyCharm and Robot Framework setup](pycharm_setup.md) | Environment, plugin, interpreter, run configurations |
| [Quick start](quick_start.md) | First working measurement in five minutes |

For driver usage see [`../docs/user_guide.md`](../docs/user_guide.md).
For hardware verification see
[`../examples/robot/hardware/README.md`](../examples/robot/hardware/README.md).
