# Setting up PyCharm and Robot Framework for this driver

Takes about ten minutes. Written for PyCharm Community or Professional;
where they differ, both routes are given.

---

## 1. Prerequisites

- Python 3.9 or newer
- PyCharm 2023.1 or newer
- Network access to the instrument, or nothing at all if you only intend
  to run against the mock

Check your Python:

```bash
python3 --version
```

---

## 2. Open the project and create an interpreter

1. **File → Open**, select the `rf_keysight34970` folder, open it.
2. **File → Settings → Project → Python Interpreter**
   (macOS: **PyCharm → Settings**).
3. Click the gear, **Add… → Virtualenv Environment → New**.
4. Location: `<project>/.venv`. Base interpreter: your Python 3.9+.
5. **OK**. PyCharm creates and selects the environment.

Creating the venv *inside* the project matters: PyCharm indexes it, so
keyword completion in `.robot` files works.

---

## 3. Install the driver in editable mode

Open the PyCharm terminal (**View → Tool Windows → Terminal** — it
activates the venv automatically) and run:

```bash
pip install -e ".[dev]"
```

`-e` means edits to `src/` take effect without reinstalling. The `dev`
extra brings in pytest, pyvisa and pyyaml, which is everything the test
suite needs.

For GPIB or USB instead of LAN, add the VISA extra:

```bash
pip install -e ".[dev,visa]"
```

Verify:

```bash
python -c "import keysight34970; print(keysight34970.__version__)"
```

---

## 4. Install the Robot Framework plugin

**Settings → Plugins → Marketplace**, search **Robot Framework Language
Server**, install, restart.

Then point it at your interpreter:

**Settings → Languages & Frameworks → Robot Framework Language Server**
- *Python executable*: `<project>/.venv/bin/python`
  (Windows: `<project>\.venv\Scripts\python.exe`)
- *Additional PYTHONPath entries*: add `<project>/src`

Without that PYTHONPath entry the plugin cannot resolve
`Library    keysight34970.Keysight34970`, and every keyword shows as
unresolved even though the suite runs correctly.

---

## 5. Confirm keyword resolution

Open `examples/robot/connection_example.robot`. You should see:

- `Connect To Instrument` in colour, not grey
- Ctrl-click (Cmd-click) on it jumps to the Python source
- Ctrl-Q shows its documentation

If keywords are grey, revisit step 4 — it is almost always the missing
PYTHONPath entry.

---

## 6. Run a suite without hardware

Everything here can be exercised against the in-repo mock instrument.

**Terminal:**

```bash
./scripts/run_examples.sh
```

**Or as a PyCharm run configuration:**

1. **Run → Edit Configurations… → + → Python**
2. Name: `Robot examples (mock)`
3. Script path: `scripts/run_examples.py`
4. Working directory: the project root
5. **OK**, then run it.

Results land in `results/`. Open `results/report.html` in a browser.

---

## 7. Run against a real instrument

```bash
robot --variable HOST:10.0.0.12 --outputdir results examples/robot/connection_example.robot
```

As a run configuration, use a **Robot Framework** configuration if your
plugin provides one, otherwise a shell script configuration with the
command above.

Before trusting results from a new bench, run the hardware suites in
order — see `examples/robot/hardware/README.md`. Start with
`01_bench_survey.robot`, which is read-only.

> **Digital outputs.** `02_verify_commands.robot` will not drive any
> physical line unless you pass `--variable ALLOW_OUTPUT_WRITES:yes`.
> Only do that with nothing consequential wired to the 34907A.

---

## 8. Run the unit tests

**Settings → Tools → Python Integration Tools → Default test runner:
pytest.**

Then right-click `tests/` → **Run 'pytest in tests'**, or:

```bash
pytest
```

Hardware-marked tests are deselected automatically. To include them:

```bash
KEYSIGHT_HOST=10.0.0.12 pytest -m hardware
```

---

## Troubleshooting

**Keywords unresolved in `.robot` files.** The PYTHONPath entry from
step 4 is missing, or the plugin is pointed at a different interpreter
than the one holding the install.

**`ModuleNotFoundError: keysight34970`.** The terminal is not using the
project venv. Close and reopen it, or `source .venv/bin/activate`.

**Connection refused.** Confirm the IP on the instrument's front panel
(LAN menu) and that port 5025 is reachable:
`telnet <ip> 5025`. Confirm no other session holds the instrument.

**`pyvisa` not found.** Only needed for GPIB/USB. Install the extra:
`pip install -e ".[dev,visa]"`.

**Tests pass but the instrument does nothing.** You are running against
the mock. That is the default for the example suites; pass
`--variable HOST:<real ip>` to reach hardware.
