# Quick start

Assumes the driver is installed (`pip install -e ".[dev]"`).

## Without hardware

```bash
./scripts/run_examples.sh
```

Runs every example suite against the in-repo mock instrument. Open
`results/report.html`.

## With hardware

Find the instrument's IP on the front panel (LAN menu), then:

```bash
robot --variable HOST:10.0.0.12 --outputdir results \
      examples/robot/connection_example.robot
```

## Your first suite

```robotframework
*** Settings ***
Library           keysight34970.Keysight34970
Suite Setup       Connect To Instrument    34972A    TCP    ${HOST}
Suite Teardown    Disconnect From Instrument

*** Variables ***
${HOST}           10.0.0.12

*** Test Cases ***
Read A Voltage
    Set Installed Card    1    34901A
    ${volts}=    Measure Value    DCV    101
    Log    ${volts}
```

Declaring the card is worth the one line: it turns several classes of
mistake into clear driver-side errors instead of opaque SCPI faults.

## Next

- [User guide](../docs/user_guide.md) — every subsystem, and the limits
  of each
- [Hardware verification](../examples/robot/hardware/README.md) — run
  before trusting a new bench
