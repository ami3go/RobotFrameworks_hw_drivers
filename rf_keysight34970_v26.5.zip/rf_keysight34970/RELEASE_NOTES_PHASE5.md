# Release Notes — v26.05.05 (Phase 5 Complete)

**Release date:** 2026-07-22
**Phase:** 5 of 12 — Digital I/O
**Status:** All five gates approved. Phases 1–5 complete.

---

## What this release adds

**34907A multifunction module support**: 8-bit digital ports, the
totalizer, and ±12 V analog outputs — with output tracking, state
readback, and explicit safe-state restoration.

**These are the first keywords in this driver that can damage connected
hardware.** Everything before this measures. These drive physical
lines.

## Keywords (13 new; 59 total)

Ports: `Read Digital Port`, `Read Digital Port Bits`,
`Write Digital Port`, `Write Digital Port Bit`.
Totalizer: `Configure Totalizer`, `Read Totalizer`,
`Read Totalizer Details`, `Clear Totalizer`.
Analog: `Write Analog Output`, `Read Analog Output Setting`.
Safety: `Get Driven Outputs`, `Read Output State`,
`Return Outputs To Safe State`.

---

## Read this before wiring anything

**`Get Driven Outputs` does not tell you what is energised.** It records
what *this driver* wrote. An output set from the front panel, by a
previous session, or through `Send Scpi Command` never appears in it —
and one this driver set that something else later changed still shows
the driver's value.

Use `Read Output State` to ask the instrument. With no argument it
covers the outputs this driver drove; pass channels explicitly to check
ones it never touched.

The distinction matters most in exactly the situation where you would
reach for either: deciding whether it is safe to disconnect.

**Zero is not a safe default.** `Return Outputs To Safe State` sets
driven outputs to zero. An active-low relay driver *energises* at zero.
A valve held closed by a high line opens when that line drops. The
driver deliberately does not do this on disconnect, because
de-energising at teardown can be exactly the wrong action and only you
know which way your hardware fails. If zero is wrong for your setup,
drive safe values explicitly and leave this keyword alone.

**`Write Digital Port Bit` is not atomic.** The instrument has no
bit-scoped write, so the driver reads the port, changes one bit, and
writes it back. Anything that changes the port in between is lost.
Write whole bytes for patterns you care about.

**Reading the totalizer in `READ_RESET` mode consumes the count.** A
retry after a timeout returns 0 — and the retry is what destroyed the
evidence. Do not wrap totalizer reads in generic retry logic.

**Declare your card.** `Set Installed Card 3 34907A` lets the driver
reject a write aimed at the wrong kind of channel before it reaches the
instrument.

---

## Verification

| Check | Result |
|---|---|
| Unit + integration tests | **692 passed** |
| Statement coverage | **98%** (enforced floor 90%) |
| Robot examples | **64/64** across 6 suites |
| AI contract | revision 22, 59 capabilities, conformance-tested |

Performance: port write 0.044 ms, read 0.041 ms, DAC write 0.042 ms,
single-bit write 0.049 ms (1.13× a whole-byte write — the honest cost
of read-modify-write).

---

## Before you connect this to anything that matters

**No digital write in this driver has ever reached a real 34907A.**
Five phases, 692 tests and 98% coverage, validated entirely against a
mock this project wrote to match its own assumptions.

That has been true since Phase 1, but it changes character here. Through
Phase 4 an untested assumption produced a wrong *number* — visible in a
test report, if you looked. A digital output left energised is wrong at
the *wiring*, and no test report shows it.

Specifically unverified: `Return Outputs To Safe State` has never
zeroed a real output; the ±12 V DAC range has never been checked
against hardware; the 34907A channel layout follows published
documentation, not measurement.

```bash
KEYSIGHT_HOST=10.0.0.12 KEYSIGHT_MODEL=34972A pytest -m hardware
```

There is no hardware test for digital output at all. Before driving
anything real, verify manually on a bench with nothing consequential
connected.

---

## What's next

**Phase 6 — Alarms:** alarm limits, alarm queue, and alarm-driven
outputs on the 34907A alarm lines.
