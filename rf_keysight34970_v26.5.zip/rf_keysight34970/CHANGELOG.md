# Changelog

All notable changes to this project are documented here, versioned per
gate as defined by the RFDS Driver Implementation Lifecycle v1.1
(`v{phase:02d}.{gate:02d}` within each phase's `26.NN.MM` scheme).

## [26.05.05] — Phase 5, Gate 5 — Review & Release — **PHASE 5 COMPLETE**

### Fixed
- **The driven-output record grew without bound.** Every write appended
  to a list that was never trimmed, so `Get Driven Outputs` — a call
  that performs no instrument I/O — cost 3 ms after 5000 recorded
  drives, and would have kept growing for the life of a soak test.

  The history is now capped at 1000 entries. Critically, the bound is
  on the *ordered history only*: the latest value per channel is kept
  separately and never trimmed, so "which outputs has this driver
  energised, and to what" — the question a teardown actually asks —
  stays exactly answerable however long the session runs. Tests assert
  that an output driven early and pushed out of the history is still
  covered by `Return Outputs To Safe State`.

### Added
- `latest_outputs()` on the engine; `RELEASE_NOTES_PHASE5.md`.

### Changed
- AI contract revision 22: Phase 5 recorded complete, 59 capabilities.

### Phase 5 acceptance
All five gates approved. No Critical findings. Two Major found and
fixed in-gate (undeclared reset hook in Gate 2; unbounded output record
in Gate 5). All Minor findings closed.

## [26.05.04] — Phase 5, Gate 4 — Tests & Documentation

### Fixed
- **DAC detection now resolves through the shared `role_of()` map**
  rather than an inline channel-number test. The write path already
  used the shared map, so the two could have disagreed about what a
  channel is — and disagreeing here means sending a DAC voltage to a
  digital port, which is a write to physical hardware.

### Added
- Three digital integration tests, including one asserting that the
  driven-output record is cleared on reconnect **while the instrument
  keeps driving** — a reconnected session must not claim to know what
  is energised, but must still be able to find out by asking.
- A test confirming digital access does not weaken the measurement
  engine's refusal to route a 34907A to the DMM.
- Coverage tests for unparseable output state, unconfigured totalizer,
  bad slot, and role-map agreement.

### Coverage
- 688 tests passing; 98% statement coverage. Robot examples 64/64.

## [26.05.03] — Phase 5, Gate 3 — Extended Features

### Added
- **`Read Output State`** — asks the *instrument* what its outputs are
  actually doing, regardless of who set them. With no argument it
  covers the outputs this driver drove; channels can be passed
  explicitly to check ones it never touched.
- **`Return Outputs To Safe State`** — sets every driver-driven output
  to zero and reports what it reset. Marked `high` risk, because zero
  is **not** universally safe: an active-low relay driver energises at
  zero, and a valve held closed by a high line opens when it drops.
  Deliberately not run automatically on disconnect for that reason.
- **User-guide digital I/O section.** Escalated from Gate 4 to Gate 3
  because these are the only keywords in this driver that can damage
  connected hardware, and shipping them undocumented for a further gate
  was not defensible.
- 59 keywords; four Robot examples covering the record/state
  distinction.

### Changed
- **`Get Driven Outputs` now states what it is not.** It records what
  *this driver* wrote — not what is energised. An output set from the
  front panel, by a previous session, or through `Send Scpi Command`
  never appears in it, and one this driver set that something else
  later changed still shows the driver's value. The two are easy to
  conflate in exactly the situation where the difference matters:
  deciding whether it is safe to disconnect.

## [26.05.02] — Phase 5, Gate 2 — Core Implementation

### Added
- **`ScpiDigitalEngine`** implementing the Gate 1 interface over the
  Phase 1 `Connection`. Owns no I/O, so it inherits the established
  error-queue policy.
- **Eleven keywords** (57 total): `Read Digital Port`,
  `Read Digital Port Bits`, `Write Digital Port`,
  `Write Digital Port Bit`, `Configure Totalizer`, `Read Totalizer`,
  `Read Totalizer Details`, `Clear Totalizer`, `Write Analog Output`,
  `Read Analog Output Setting`, `Get Driven Outputs`.
- **Output tracking.** Every drive is recorded so a teardown can report
  or restore it. An output left energised after a test is a hazard that
  instrument state inspection cannot attribute back to the test that
  caused it.
- **Port values accept `0b` and `0x` notation**, because binary is the
  natural way to write a bit pattern and requiring decimal conversion
  by hand is where transcription errors enter.
- Robot example (12 cases) including a teardown that returns outputs to
  a safe state.

### Fixed
- **`DigitalKeywords` defined `_reset_digital_state` but never declared
  it in `SESSION_RESET_HOOKS`**, so the engine — and the record of every
  output driven — survived a disconnect and would have been reported
  against the next session. The existing validator could not catch this:
  it checked that declared hooks exist, and nothing was declared.
- **The hook validator now also rejects a hook that exists but is not
  declared**, closing that gap for every future mixin.

### Safety
- Three capabilities are marked `high` risk and say `DRIVES PHYSICAL
  OUTPUT LINES` in their metadata. These are the first capabilities in
  this driver that can damage connected hardware.
- `Write Digital Port Bit` documents that it is read-modify-write and
  therefore not atomic; the instrument offers no bit-scoped write.
- `Read Totalizer` carries an explicit **never retry blindly** planning
  note: in READ_RESET mode the count is consumed and a second read
  returns 0.

## [26.05.01] — Phase 5, Gate 1 — Architecture & Skeleton

Digital I/O **architecture** only. No digital keywords yet — Gate 2.

### Added
- **`digital/models.py`** — the 34907A multifunction module's data
  types: `ChannelRole` with fixed-by-hardware role assignment,
  `DigitalPortState` (8-bit, bit accessors, non-mutating `with_bit`),
  `TotalizerConfig`/`TotalizerReading` (26-bit, wrap detection),
  `DacOutput` (±12 V).
- **Channel-role validation** (`role_of`, `require_role`). The 34907A's
  five channels have fixed roles — two digital ports, a totalizer, two
  analogue outputs — and addressing one as another would drive an
  unintended output. Errors name both the actual and expected role.
- **`digital/base.py`** — `DigitalEngine` interface, with read and
  write operations deliberately separated and every write-shaped method
  named for the fact that it writes.
- **`keywords/digital_keywords.py`** — skeleton mixin, composed into
  `Keysight34970` but registering no keywords.
- 43 tests. Keyword surface unchanged at 46, asserted.

### Notes
- This is the first phase whose capabilities drive signals **out** of
  the instrument. `DacOutput` rejects out-of-range voltages rather than
  clamping, because clamping would drive a different voltage than the
  caller requested — on an output that is a hardware event, not a
  rounding error.
- `TotalizerMode.READ_RESET.is_destructive` exists because a second
  read in that mode returns 0, which is a plausible count rather than
  an error.

## [26.04.05] — Phase 4, Gate 5 — Review & Release — **PHASE 4 COMPLETE**

### Added
- `RELEASE_NOTES_PHASE4.md`.

### Changed
- AI contract revision 17: Phase 4 recorded complete, 46 capabilities.
  The temperature limitation is replaced with a precise statement of
  what the plausibility check cannot detect.

### Performance
- Temperature path measured: configure a thermocouple 0.169 ms
  (0.258 ms with all options), 10 channels 0.297 ms, read 10 channels
  0.177 ms, reference junction 0.044 ms. Configuration is channel-list
  based, so cost is near-flat in channel count. No defect found — the
  first phase of the last three where the performance review did not
  uncover one.

### Phase 4 acceptance
All five gates approved. No Critical findings. One Major found and
fixed in-gate (the union plausibility range that could not detect the
failure it was built for). All Minor findings closed.

## [26.04.04] — Phase 4, Gate 4 — Tests & Documentation

### Added
- **User-guide temperature section** (carried since Gate 2). Covers
  alloy selection, open-detect, cold-junction compensation, RTD nominal
  vs calibrated reference, units, temperature in a scan — and, most
  importantly, **what the plausibility check cannot do**: a type-J
  channel configured as type K reads ~20 C high at 500 C, and 520 C is
  perfectly plausible. Nothing in this driver can detect that.
- Four temperature integration tests, including a mixed
  temperature/voltage scan and state clearing across sessions.
- Four Robot examples covering open-detect, calibrated RTD reference,
  and the limits of plausibility checking.
- Coverage tests for optional-argument blank forms, reference-junction
  reads, and range assertions.

### Fixed
- **`plausible_range_for` used `getattr` with a default**, which would
  have silently widened the check to the union range if the field were
  renamed — turning a precise check into a permissive one with no
  error. Now a direct attribute access that fails loudly.

### Coverage
- 570 tests passing; **98.1% statement coverage**. Robot examples 52/52.

## [26.04.03] — Phase 4, Gate 3 — Extended Features

### Added
- **Thermocouple open-junction detection** (`open_detect` on
  `Configure Thermocouple`, emitting `SENS:TEMP:TRAN:TC:CHEC`). This is
  the instrument's own defence against the failure this phase cares
  about most: a broken thermocouple does not report an error, it
  reports a plausible temperature. Opt-in, because it costs a little
  speed per reading, and omitting it leaves the instrument's setting
  untouched rather than forcing a default.
- **RTD calibrated reference resistance** (`reference_ohms`, emitting
  `SENS:TEMP:TRAN:<type>:RES:REF`). Distinct from the nominal value:
  nominal says "this is a PT100", reference says "this particular PT100
  measures 100.02 ohms at 0 C". Worth tenths of a degree.
- **Per-alloy plausibility ranges** (`THERMOCOUPLE_RANGE_C`,
  `plausible_range_for`).

### Fixed
- **The plausibility check used one union range for all eight
  thermocouple alloys**, spanning -270 to 1820 C. A type-T reading of
  1500 C — far outside anything type T can physically measure — passed
  as plausible, which is precisely the wrong-alloy misconfiguration the
  check exists to catch. Now narrowed per alloy, falling back to the
  union only when the alloy is unknown.
- **Private-attribute reach removed.** The temperature engine wrote
  directly into `ScpiMeasurementEngine._configured`. Replaced with a
  public `record_external_configuration()`, named for what it does and
  explicit that it sends nothing to the instrument.

### Validation
- `open_detect` rejected for non-thermocouples (only a thermocouple has
  a junction that can go open); `rtd_reference_ohms` rejected for
  non-RTDs and for non-positive values.

## [26.04.02] — Phase 4, Gate 2 — Core Implementation

### Added
- **`ScpiTemperatureEngine`** implementing the Gate 1 interface over
  the Phase 1 `Connection`, owning no I/O. Configuration is applied in
  a fixed order — `CONF:TEMP` first, then the `SENS:TEMP:TRAN:*`
  subsystems that are keyed by the transducer, then `UNIT:TEMP` —
  because the instrument rejects the subsystem commands otherwise.
- **Nine keywords:** `Configure Thermocouple`, `Configure RTD`,
  `Configure Thermistor`, `Read Temperature`,
  `Read Temperature Details`, `Set Temperature Unit`,
  `Get Temperature Configuration`,
  `Read Reference Junction Temperature`,
  `Temperature Should Be Within`. Library surface is 46 keywords.
- **Units travel with readings.** Each channel's reading carries the
  unit configured for that channel, and a scan spanning channels with
  different units labels each correctly. Phase 2 hardcoded
  `TEMPERATURE` to Celsius; that is what this fixes.
- **Plausibility flagging** — `Read Temperature Details` reports a
  `plausible` field, and `Temperature Should Be Within` fails
  explicitly on an implausible reading rather than comparing it against
  the bounds.
- **4-wire RTD pair validation**, reusing the Phase 2 rule so the two
  cannot drift.
- **Temperature channels are visible to scanning** — configuring one
  records `TEMPERATURE` in the measurement engine, so a scan tags it
  correctly rather than treating it as unconfigured.
- 31 tests and 11 Robot examples; 48/48 Robot tests across five suites.

### Changed
- `TemperatureKeywords` declares `SESSION_RESET_HOOKS`, so its engine
  is dropped on disconnect like the other mixins.
- `test_mixin_states_are_disjoint` now derives expected state from the
  mixins rather than hardcoding it, so adding a phase no longer
  requires editing the test — only a real collision fails it.

## [26.04.01] — Phase 4, Gate 1 — Architecture & Skeleton

Temperature **architecture** only. No temperature keywords yet.

### Added
- **`temperature/models.py`** — `TransducerType` (thermocouple, 2- and
  4-wire RTD, thermistor), `ThermocoupleType` (all eight alloys),
  `ReferenceJunction`, `TemperatureUnit` with parsing and mapping to the
  Phase 2 `Unit`, and `TemperatureConfig` with strict cross-transducer
  validation.
- **`temperature/base.py`** — `TemperatureEngine` ABC, including
  `read_reference_junction()` so a suspect thermocouple reading can be
  diagnosed rather than guessed at.
- **Plausibility checking** — `is_plausible()` and `PLAUSIBLE_RANGE_C`
  catch open junctions, disconnected sensors and unit confusion. Offered
  as a helper, not enforced.
- `docs/architecture_phase4.md`.
- 44 tests covering unit parsing and conversion, every transducer's
  required and forbidden settings, and plausibility.

### Design notes
- **No default thermocouple type.** Defaulting to K would give a
  confident wrong answer for the other seven alloys.
- **Cross-transducer settings are rejected, not ignored.** Setting a
  fixed reference temperature on an internally-compensated junction, or
  an RTD nominal on a thermistor, means the caller believes the reading
  is derived one way while it is derived another.
- **Non-standard thermistor nominals are rejected** — the instrument's
  conversion assumes one of three curves, and a 3000 ohm sensor would
  produce believable wrong temperatures.
- **The configured unit travels with the reading.** `Unit.FAHRENHEIT`
  and `Unit.KELVIN` have existed unused since Phase 2 Gate 1; this is
  what they were for. Phase 2 hardcoded `TEMPERATURE` to Celsius.

## [26.03.05] — Phase 3, Gate 5 — Review & Release — **PHASE 3 COMPLETE**

### Fixed
- **Adaptive poll backoff in `wait_for_scan`.** The fixed 50 ms poll
  added up to a full interval of latency *after* the scan had already
  finished — for a ~100 ms scan, 50% overhead on the measured duration.
  Polling now starts at 1 ms and backs off to 50 ms, so short scans are
  responsive while long scans settle at the previous query rate.
- **`_started_at` replaced as the "scan running" test.** It stayed set
  after a bounded scan completed naturally, so monitoring was refused
  with a message claiming a scan was running when none was. A scan is
  now considered running only if it is unbounded or has not yet
  produced its expected readings.

### Added
- `RELEASE_NOTES_PHASE3.md`.
- Regression tests for adaptive polling and for monitoring after a
  completed bounded scan.

### Changed
- AI contract revision 12: Phase 3 recorded complete, 37 capabilities.

### Phase 3 acceptance
All five gates approved. No Critical findings. All Minor findings
closed. One process failure (destructive edits without inspecting
existing state) recorded in the Gate 3 review, recovered in full.

## [26.03.04] — Phase 3, Gate 4 — Tests & Documentation

### Fixed
- **DMM contention between scanning and monitoring is now enforced,
  not merely documented.** Both take over the internal DMM and the
  instrument does not arbitrate: starting a monitor mid-scan produced
  readings from whichever won, with no error. Starting a monitor while
  a scan runs is now refused; starting a scan while monitoring stops
  the monitor first, since a scan is the more specific request and a
  live monitor would corrupt it silently. Closes a Gate 3 finding that
  had left the contract warning planners off something the driver
  allowed.

### Changed
- **Corrected an unverifiable claim about statistics accumulation.**
  Gate 3 documentation, the keyword docstring, and the contract all
  asserted that instrument statistics accumulate across scans. Writing
  the example exposed that the mock resets them, and the real
  behaviour is firmware-dependent and unverified here. All four places
  now say what is actually known: clear before a scan whose statistics
  will be read, and the result is well-defined either way.

### Added
- Monitoring and statistics sections in the user guide, including the
  accumulation-nothing distinction that makes `Fetch Scan Readings`
  return nothing after monitoring.
- Four Robot examples covering monitoring, the contention refusal, and
  per-channel statistic scoping.
- Coverage tests for remaining scanner paths (TriggerCount rejection of
  float/bool/None, sweep-count fallback, over-range statistics refusal,
  BUS-trigger duration, monitoring without a measurement engine).

### Coverage
- 457 tests passing; **98.4% statement coverage**. Robot examples 37/37.

## [26.03.03] — Phase 3, Gate 3 — Extended Features

### Added
- **Monitor mode** — `Start Monitoring Channel`, `Stop Monitoring`,
  `Read Monitored Channel`. Continuous single-channel reading, with the
  crucial distinction documented everywhere it appears: monitoring is
  *not* scanning, nothing accumulates in reading memory, and only the
  newest value exists. Monitoring a channel that cannot reach the DMM
  is rejected up front.
- **Per-channel instrument statistics** — `Get Channel Statistics`
  returns the instrument's own registers scoped to one channel, which
  cover every reading it took including any lost to memory overflow.
- **`Clear Instrument Statistics`** — statistics accumulate across
  scans; without clearing, a second scan reports a min/max spanning the
  first.
- 37 keywords total.

### Fixed — the three findings assigned by the Gate 2 review
- **Silent DC_VOLTAGE fallback.** A scan reading that could not be
  attributed to a channel was tagged DC volts regardless of what it
  measured. On a mixed-function scan that meant labelling ohms as
  volts. The unit is now `UNKNOWN` unless every configured channel
  shares one function — less convenient and honest. This is the third
  variant of the misattribution class this driver has produced.
- **`ScanResult.completed_at` renamed to `fetched_at`.** It was stamped
  when the fetch happened, so for a partial fetch of a running scan it
  named a completion that had not occurred.
- **Polling vs `*OPC?` in `wait_for_scan`** — reconsidered and kept,
  with the reasoning now recorded at the call site: `*OPC?` blocks the
  session, which would make `reading_count()` unavailable during a long
  scan and turn a timeout into a transport failure with the instrument
  still running.

### Changed
- `_channel_functions()` no longer requires a configured scan.
  Monitoring and per-channel statistics are independent of scanning,
  and demanding a scan config there failed with an error naming the
  wrong problem.

## [26.03.02] — Phase 3, Gate 2 — Core Implementation

### Added
- **`ScpiScannerEngine`** implementing the Gate 1 interface over the
  Phase 1 `Connection`. Consumes the measurement engine's per-channel
  configuration, so a scan spanning functions tags each reading with
  its own channel's function and unit.
- **Nine scanner keywords** (32 total): `Configure Scan`, `Start Scan`,
  `Abort Scan`, `Wait For Scan`, `Run Scan`, `Fetch Scan Readings`,
  `Get Scan Reading Count`, `Get Scan Readings For Channel`,
  `Get Instrument Statistics`.
- **`Wait For Scan` refuses scans that cannot self-complete** —
  infinite sweep counts, and trigger sources awaiting an external
  stimulus. Blocking forever on a misconfigured scan is
  indistinguishable from broken hardware.
- **`Fetch Scan Readings` returns an empty result on empty memory**
  rather than surfacing the instrument's `FETC?`-on-empty fault.
  Polling a scan that has not yet produced anything is ordinary.
- **`clear=True` uses `R?`, not fetch-then-clear.** `R?` reads and
  erases in one command; two commands would race a running scan and
  lose readings arriving between them.
- **Memory overflow warns rather than refuses.** The 50,000-reading
  capacity is documented, not measured, and a driver blocking a valid
  scan on a wrong constant would be worse than one that warns.
- Robot example `scanning_example.robot` (10 cases); user guide
  scanning section; mock instrument scan support with genuine memory
  semantics.
- AI contract revision 9, 32 capabilities.

## [26.03.01] — Phase 3, Gate 1 — Architecture & Skeleton

Scanner **architecture** only. No scanner keywords yet — those arrive
in Gate 2.

### Added
- **`scanner/models.py`** — `ScanConfig`, `TriggerSource`,
  `TriggerCount`, `ScanReading`, `ScanResult`, `InstrumentStatistics`.
  Trigger count is a type rather than `int | None` because "run
  forever" is a distinct operating mode: it fills memory without bound
  and cannot be waited on. `TriggerSource.is_self_starting`
  distinguishes sources that proceed on their own from those awaiting
  an external stimulus.
- **Pre-arm safety checks** — `exceeds_reading_memory()` against the
  documented 50,000-reading capacity, and `estimated_duration_s()` as a
  lower bound useful for choosing a timeout.
- **`scanner/parsing.py`** — multi-field scan response parsing
  (value + 6 timestamp fields + channel). **Validates field alignment**:
  a field count that is not a whole multiple of the expected stride
  means the instrument's formatting differs from what the driver
  assumed, and continuing would read a timestamp component as the next
  reading's value. Same failure shape as the Phase 2 misattribution
  defect — right count, wrong mapping — so the check was written before
  the engine rather than after.
- **`scanner/base.py`** — `ScannerEngine` ABC keeping *arming* separate
  from *waiting*, so an infinite or externally-triggered scan is not
  indistinguishable from a hung instrument.
- **`ScanResult.for_channel()` / `statistics_for_channel()`** as the
  intended way to slice a multi-sweep scan, rather than replicating
  sweep interleaving arithmetic at the call site.
- `docs/architecture_phase3.md`; skeleton `ScannerKeywords` mixin.
- 57 new tests (406 total).

### Fixed
- **Session reset hooks called only one mixin.** The
  `getattr(self, "_reset_measurement_state")` lookup flagged in three
  consecutive Phase 2 reviews was not merely fragile — it called
  exactly **one** hook by name, so a second stateful mixin would have
  been missed entirely. Phase 3 adds that second mixin, so this was a
  latent bug about to be triggered. Mixins now declare
  `SESSION_RESET_HOOKS`; the connection mixin walks the MRO and calls
  every declared hook, and a typo fails at construction rather than
  surfacing later as stale state.

## [26.02.05] — Phase 2, Gate 5 — Review & Release — **PHASE 2 COMPLETE**

### Fixed
- **Nagle's algorithm was costing ~40 ms on every command
  (677x slowdown).** SCPI is a request/response protocol of tiny
  messages and this driver routinely issues two writes back to back (a
  command, then the `SYST:ERR?` check). With Nagle enabled the second
  write waited for the first to be acknowledged, and the peer's
  delayed-ACK timer does not fire for ~40 ms. `TCP_NODELAY` is now set
  on connect: configure went from **44 ms to 0.065 ms**, read from
  44 ms to 0.089 ms.

  Present since Phase 1 Gate 1. It survived a dedicated Phase 1
  performance review because that review benchmarked `connect()` and
  single queries — write-then-read patterns, which Nagle does not
  penalise. Two regression tests now guard it: one asserting the socket
  option, one asserting five round trips complete in under 50 ms.

  On a real bench this cost ~40 ms per configure and per read — roughly
  800 ms to configure a 20-channel scan.

### Added
- **`tests/unit/test_release_readiness.py`** — structural checks that
  every version has a CHANGELOG entry, a history record and a review
  record; that gate numbers are contiguous within a phase; and that the
  version agrees across `pyproject.toml`, `__init__.py`, `library.py`
  and the AI contract. Remediation for the missing Gate 2-3 CHANGELOG
  entries found in Gate 4.
- `RELEASE_NOTES_PHASE2.md`.
- Architecture document index linking the Phase 1 and Phase 2
  documents, closing a Gate 4 Minor finding.

### Changed
- AI contract revision 7: Phase 2 recorded complete.
- `test_partial_scope_is_declared` now asserts completed phases form a
  contiguous run rather than hardcoding `[1]`.

### Phase 2 acceptance
All five gates approved. No Critical findings. Four Major findings
raised and resolved during the phase, three of them predating it. All
Minor findings closed except the `_reset_measurement_state` hook
fragility, deferred to Phase 3 Gate 1 with a recommendation not to
defer again.

## [26.02.04] — Phase 2, Gate 4 — Tests & Documentation

### Added
- **Measurement integration tests** (7): configure/read cycles over a
  real socket, error recovery, session isolation across reconnects,
  card validation, statistics and detailed readings, and acquisition
  settings surviving the full stack.
- **Hardware test for the channel-ordering assumption**
  (`test_real_instrument_dc_voltage`). Driver correctness now depends
  on the mainframe scanning in ascending channel order; this asserts it
  on real hardware and states what is wrong if it fails.
- **Measurement API reference** — `docs/api_reference.md` gained a full
  Phase 2 section: channel addressing, measurement types, the engine
  method table, reading order, why `measure()` rejects acquisition
  settings, pre-flight validation, and configuration accumulation.
- Coverage tests for the last uncovered measurement paths.

### Changed
- `Measure` docstring explains why it takes no acquisition arguments
  while `Configure Measurement` does — the asymmetry is deliberate.

### Coverage
- 342 tests passing; **99.03% statement coverage**.

## [26.02.03] — Phase 2, Gate 3 — Extended Features

### Added
- **Acquisition tuning:** `AcquisitionSettings` (NPLC, autozero, input
  impedance), applied via `SENS:` after `CONF:` establishes the
  function. `Nplc.rejects_line_noise` makes the 1-NPLC mains-rejection
  threshold queryable rather than folklore. Commands are only sent when
  explicitly requested, since each costs an error-queue round trip.
- **4-wire pair validation** — a 4-wire measurement on channel N
  consumes N+10. Configurations whose pair is missing on the declared
  card, or already configured for another function, are rejected.
  `Get Four Wire Pair` exposes the pairing.
- **`Read Measurement Details`** — dicts carrying value, unit,
  function, channel, over-range flag and timestamp.
- **`Get Measurement Statistics`** — min/max/average/span/count/unit,
  failing on over-range or mixed units rather than computing a lie.
- **`Measurement Should Be Within`** — range assertion failing
  explicitly on over-range instead of comparing the sentinel.
- **`Clear Measurement Configuration`** — configured channels
  accumulate across a session; without this a bare `Read Measurement`
  silently grows across a suite.
- 23 keywords total.

### Fixed
- **`measure()` silently discarded acquisition settings.** A caller
  could request 10 NPLC and receive a reading taken at the default with
  no indication. `MEAS:` reads immediately and resets unspecified
  parameters, so it genuinely cannot honour them — now rejected with a
  message directing the caller to `configure()` + `read()`.
- `Measurement Should Be Within` was registered as low risk while the
  contract said medium. The contract was right; it calls `Measure` and
  inherits its parameter reset. Caught by the conformance tests.

### Changed
- NPLC rejected for frequency, period, continuity and diode; input
  impedance rejected for anything but DC voltage.
- User guide rewritten with a full measurement section; architecture
  doc's channel-ordering claim corrected.

## [26.02.02] — Phase 2, Gate 2 — Core Implementation

### Added
- **`ScpiMeasurementEngine`** implementing the Gate 1 interface over
  the Phase 1 `Connection`. Owns no I/O, so it inherits the established
  error-queue policy rather than reimplementing it.
- **Six keywords:** `Configure Measurement`, `Read Measurement`,
  `Measure`, `Measure Value`, `Get Configured Function`,
  `Set Installed Card`.
- **Per-mixin capability metadata.** Each mixin owns its own registry;
  `library.py` merges them, so adding a phase means adding a module
  rather than editing a registry every phase contends over.
- **Card-aware pre-flight validation:** measurement on switch-only
  cards, and current measurement on non-current channels, fail in the
  driver before any command is sent.
- **Mixed-function scans** tag each reading with its own channel's
  function and unit.
- **Session-state hygiene:** disconnect and reconnect clear per-channel
  configuration via a guarded hook, so the connection mixin stays
  independent of later phases.
- Robot example `measurement_example.robot`; mock instrument support
  for `CONF:`, `ROUT:SCAN`, `READ?` and `MEAS:`.

### Fixed
- **Silent reading misattribution on non-ascending channel lists.**
  Readings are matched to channels positionally and the mainframe scans
  ascending regardless of list order, so `(@105,101)` would have
  reported each channel's reading as the other's. The Gate 1
  count-mismatch guard cannot catch this: counts match, only the
  mapping is wrong. `read()` and `measure()` now normalise to ascending
  order, and readings are returned in that order.

## [26.02.01] — Phase 2, Gate 1 — Architecture & Skeleton

Measurement **architecture** only. No measurement keywords yet — those
arrive in Gate 2.

### Added
- **`measurement/channels.py`** — `ChannelId` and `ChannelList` with
  full SCPI channel-list parsing and rendering (`(@101,105:108)`),
  slot/channel validation, order-preserving de-duplication, and
  rejection of slot-spanning and reversed ranges.
- **Card awareness** — `CardType` and `CARD_SPECS` for the eight
  documented plug-in modules, distinguishing channels that exist from
  channels that can be measured through (a 34903A actuator has 20
  addressable channels and no DMM path). `CardType.UNKNOWN` relaxes
  validation rather than blocking an unrecognised card.
- **`measurement/models.py`** — `MeasurementFunction` (11 functions,
  values are the SCPI mnemonics), `Unit`, `MeasurementConfig` with
  range/resolution handling and `AutoRange` sentinel, the structured
  `Measurement` result object with over-range detection, and
  `MeasurementStatistics`.
- **`measurement/parsing.py`** — instrument response parsing into
  `Measurement` objects, with over-range sentinel handling and a hard
  failure on reading/channel count mismatch rather than positional
  guessing.
- **`measurement/base.py`** — `MeasurementEngine` ABC defining the
  Gate 2 contract, with `configure`/`read`/`measure` kept as three
  distinct operations because they map to genuinely different
  instrument behaviors.
- **`keywords/measurement_keywords.py`** — skeleton mixin, composed
  into `Keysight34970` but intentionally declaring no keywords.
- `docs/architecture_phase2.md`.
- 111 new tests (229 total, up from 117). All new measurement modules
  at 100% coverage; overall coverage 98.55%.

### Fixed
- **`CommandError` rejected `context=`**, unlike every other exception
  in the hierarchy — it overrode `__init__` and dropped the argument.
  Caller context is now merged with the SCPI-specific fields.
  `test_library_composition.py` asserts the property across the whole
  hierarchy.
- **`get_capability_metadata()` was an undeclared Robot Framework
  keyword.** As a public method it was auto-exposed as `Get Capability
  Metadata` from Phase 1 Gate 3 onward, appearing in neither
  `CAPABILITY_METADATA` nor the RFDS-017 contract — so a planner
  reading the contract saw 12 capabilities while the library offered
  13. Marked `@not_keyword`.

### Changed
- **AI contract conformance is now anchored to reality.**
  `test_ai_contract.py` validates the contract against Robot
  Framework's *live* keyword surface (`TestLibrary.from_name`) rather
  than against `CAPABILITY_METADATA`. The previous check compared two
  artifacts the project controls, which agreed with each other while
  both disagreed with the actual library — which is how the undeclared
  keyword survived three gates.
- `ai/ai_contract.yaml` at revision 2: phase status records Phase 2
  Gate 1 in progress and states explicitly that no new capabilities
  were added.

## [26.01.05] — Phase 1, Gate 5 — Review & Release — **PHASE 1 COMPLETE**

### Added
- **`ai/ai_contract.yaml`** — RFDS-017 v3.0 structured AI Driver
  Contract covering all 12 Phase 1 capabilities, with every mandatory
  section present (identity, mental model, state machine, resources,
  dependencies, capabilities, error catalogue, safety rules,
  verification objectives with oracles, setup/teardown contract,
  limitations, planning hints, UNKNOWN handling, conformance rules).
  Explicitly declared **partial**, so a planner cannot mistake an
  absent capability for an unsupported instrument feature.
- **`ai/ai_contract.lock`** — integrity file carrying a SHA-256 of the
  contract, capability list, and validation results.
- **`tests/unit/test_ai_contract.py`** — 13 conformance tests binding
  the contract to the implementation: capability set, risk levels, and
  exclusive resources must match `CAPABILITY_METADATA`; state machine
  must match `ConnectionState`; error catalogue entries must be real
  exception classes; driver version and library scope must match the
  package; lock hash must be current. Contract drift is now a build
  failure.
- **`tests/unit/test_documented_errors.py`** — pins the error-message
  fragments listed in the user guide's symptom→cause table, and
  asserts they appear in the guide. Closes the Gate 4 Minor finding on
  documentation drift.
- **`RELEASE_NOTES.md`** — Phase 1 release notes, including the
  `ROBOT_LIBRARY_SCOPE` behavioral change, measured performance
  figures, and an explicit statement of hardware verification status.
- Performance review data (see `review/v26.01.05_review.md`).

### Changed
- `pyyaml` added to the `dev` extra (required by the contract
  conformance tests).

### Fixed — open review findings closed
- **Minor (Gate 2):** `FakeTransport.set_timeout` validation
  duplication now carries an inline rationale explaining that each
  Transport implementation guards its own invariants deliberately.
- **Minor (Gate 3):** VISA status-code substring matching now
  documents why it is preferred over enum identity (PyVISA has renamed
  and aliased codes across releases; dedicated tests make a rename a
  CI failure rather than a silent fallback).
- **Minor (Gate 4):** documentation drift risk closed by
  `test_documented_errors.py`.

### Verified
- 117 tests passing (up from 98); 98% statement coverage against an
  enforced 90% floor.
- 10/10 Robot Framework example tests across two suites.
- No socket or memory leak across 200 reconnect cycles and 500 queries
  (4 open file descriptors after; ~384 KB RSS growth).
- Package builds cleanly as sdist and wheel at `26.1.5`.

### Phase 1 acceptance
All five gates approved. No Critical findings. No open Major findings.
All Minor findings from Gates 1–4 closed. Phase approved for
continuation to Phase 2 (Measurement Engine).

## [26.01.04] — Phase 1, Gate 4 — Tests & Documentation

### Fixed
- **`ROBOT_LIBRARY_SCOPE` changed from `TEST` to `SUITE`.** Under `TEST`
  scope Robot Framework constructs a fresh library instance per test
  case, which silently discarded any connection opened in `Suite Setup`
  — the standard structure for an instrument suite. Found by the new
  `suite_patterns_example.robot`, which failed all six of its cases
  before the fix. This is a behavioral change for any suite relying on
  per-test isolation of the library instance.

### Added
- **Integration test tier** (`tests/integration/`): full-stack tests
  through the keyword layer, a real TCP socket, and the mock
  instrument — repeated connect/disconnect cycles, error-then-recovery,
  `*CLS` clearing the queue end to end, context-manager cleanup, and
  model-mismatch rejection.
- **Opt-in hardware test tier** (`@pytest.mark.hardware`, deselected by
  default via `addopts`), driven by `KEYSIGHT_HOST`/`KEYSIGHT_MODEL`.
  This is the mechanism satisfying the lifecycle's "examples verified
  on supported hardware where applicable" criterion on a real bench.
- **Second Robot example** (`suite_patterns_example.robot`)
  demonstrating suite-level setup/teardown, per-test status clearing,
  error handling, and timeout scoping.
- **Documentation:** `docs/user_guide.md`, `docs/api_reference.md`,
  `docs/developer_guide.md`, and a generated
  `docs/keyword_reference.html` (`libdoc`). README gained a
  documentation index and updated development instructions.
- **Coverage enforcement:** `fail_under = 90` in `pyproject.toml`, plus
  pytest markers for the `integration`/`hardware` tiers.
- 55 new tests (98 total, up from 44): keyword-layer tests including
  all not-connected guards and invalid-argument rejection; logging
  configuration (idempotency, alias tagging, default fields); TCP
  transport error paths (read timeout, mid-response hangup, open
  failure, idempotent open/close, context manager); VISA transport
  write/close/set_timeout/guard paths and the missing-`pyvisa`
  `ConfigurationError`; malformed SCPI error-code parsing; and
  `Connection` context-manager, `check_errors=False`, and
  transport-failure-during-error-check paths.

### Changed
- `Connect To Instrument` now accepts `verify_model` and `terminator`
  arguments, resolving the Gate 3 Minor finding that these were
  reachable only through the Python API.

### Coverage
- 98 tests passing; **98% statement coverage** (up from 78% at the
  start of this gate). `config.py`, `exceptions.py`, `models.py`,
  `logging_config.py`, `library.py`, `transport/base.py`, and
  `transport/visa_transport.py` are at 100%.

## [26.01.03] — Phase 1, Gate 3 — Extended Features

### Added
- **Model verification:** `ConnectionConfig.verify_model` (default
  `True`). `connect()` now compares the instrument's reported `*IDN?`
  model against the configured `model` and raises `ConfigurationError`
  on mismatch, guarding against bench misaddressing.
- **Configurable line terminator:** `ConnectionConfig.terminator`
  (default `"\n"`), plumbed through to `TcpSocketTransport`. Commands
  containing an embedded terminator are now rejected with a clear
  `TransportError` rather than silently desyncing the response stream.
- **Refined VISA error translation:** `VisaTransport.open()` now
  distinguishes resource-not-found / resource-busy / resource-locked
  VISA status codes and raises `ConnectionError34970` with an
  actionable message, instead of a generic `TransportError` for every
  failure mode.
- A lightweight `CAPABILITY_METADATA` registry (risk level, blocking
  behavior, exclusive resources per keyword) plus
  `Keysight34970.get_capability_metadata()`, staged ahead of the full
  RFDS-017 AI Driver Contract generation planned for Phase 10. This is
  *not* itself a conformant `ai_contract.yaml`.
- 18 new unit tests (44 total, up from 26): config edge cases
  (whitespace-only host/resource, empty terminator), model
  match/mismatch/bypass, real-socket terminator round-trips (default
  and custom), embedded-terminator rejection, and VISA error
  translation (resource-not-found, resource-busy, generic, timeout,
  and successful-open timeout-in-ms conversion) using pyvisa directly
  with a mocked `ResourceManager`.
- `pyvisa` added to the `dev` extra so the full test suite runs
  out of the box with `pip install -e ".[dev]"`.

### Changed
- `ConnectionConfig.validate()` now rejects whitespace-only
  `host`/`visa_resource` values (previously only rejected falsy/empty
  strings).

## [26.01.02] — Phase 1, Gate 2 — Core Implementation

### Added
- `Transport.set_timeout()` added to the abstract interface and
  implemented in `TcpSocketTransport` and `VisaTransport`, so timeout
  can be changed on an already-open connection.
- `Connection.reset()` (`*RST` + stabilization delay), `clear_status()`
  (`*CLS`), `reconnect()` (disconnect+connect convenience), and
  `set_timeout()` — all previously only reachable implicitly via
  `connect()`'s handshake are now explicit, callable operations.
- `Connection.drain_error_queue()` — pops every pending SCPI error (up
  to a safety bound) for diagnostics, distinct from the assert-on-error
  behavior of `write`/`query`.
- `Connection.__repr__` for readable logs/debugging.
- New Robot Framework keywords: `Reconnect To Instrument`,
  `Get Connection State`, `Reset Instrument`, `Clear Instrument Status`,
  `Set Instrument Timeout`, `Drain Instrument Error Queue`.
- 8 new unit tests covering all of the above (26 total, up from 18).
- Expanded `examples/robot/connection_example.robot` with
  `Reset And Timeout Control` and `Recover From A Bad Command`
  scenarios; mock instrument (`tests/mock_instrument.py`) now models a
  real SCPI error queue (`*CLS` clears it, a known-bad command enqueues
  an error) so the recovery scenario is genuinely exercised, not just
  mocked as always-clean.

### Changed
- `_check_error_queue` now distinguishes a transport failure *during*
  the post-command error check from a `CommandError` reported by the
  instrument itself, addressing the Minor finding from the Gate 1
  review (nested-exception clarity).

### Fixed
- N/A

## [26.01.01] — Phase 1, Gate 1 — Architecture & Skeleton

### Added
- Project skeleton (`src/keysight34970/...`) with `pyproject.toml`
  packaging.
- `ConnectionConfig`, `TransportKind`, `InstrumentModel` configuration
  models with validation (`config.py`).
- Exception hierarchy rooted at `Keysight34970Error` (`exceptions.py`).
- Per-instrument structured logging (`logging_config.py`).
- `Transport` abstract base class, plus `TcpSocketTransport` and
  `VisaTransport` implementations (`transport/`).
- `Connection` class implementing the SCPI session state machine
  (IDLE → CONNECTING → CONNECTED → CLOSED/ERROR), `*IDN?`/`*CLS`/`*RST`
  handshake, and error-queue checking (`connection.py`).
- `InstrumentIdentity` and `ScpiError` data models (`models.py`).
- `ConnectionKeywords` Robot Framework keyword mixin and the public
  `Keysight34970` library class exposing: `Connect To Instrument`,
  `Disconnect From Instrument`, `Get Instrument Identity`,
  `Instrument Should Be Connected`, `Send Scpi Command`,
  `Query Scpi Command`.
- Unit tests for config validation, connection state machine, and data
  model parsing, using an injectable fake transport (18 tests).
- Runnable Robot Framework example (`examples/robot/connection_example.robot`),
  verified against an in-repo mock SCPI-over-TCP server
  (`tests/mock_instrument.py`).
- Architecture documentation (`docs/architecture.md`).

### Planned (not yet implemented)
- Measurement engine (Phase 2)
- Scanner engine: scan lists, triggering, buffered acquisition (Phase 3)
- Temperature: thermocouple/RTD/thermistor (Phase 4)
- 34907A Digital I/O and counters (Phase 5)
- Alarm subsystem and engineering scaling (Phase 6)
- Configuration profiles and snapshot import/export (Phase 7)
- Automatic reconnect, retry engine, comms statistics (Phase 8)
- Safe-mode protected operations and interlocks (Phase 9)
- RFDS-017 AI Driver Contract + RFDS-018 Test Bench Contract metadata
  (Phase 10)
- Full documentation site (Phase 11)
- Regression/performance validation and production release (Phase 12)
