# Release Notes — v26.02.05 (Phase 2 Complete)

**Release date:** 2026-07-22
**Phase:** 2 of 12 — Measurement Engine
**Status:** All five gates approved. Phases 1 and 2 complete.

---

## What this release adds

**Measurement.** The driver can now configure and read the mainframe's
internal DMM: DC/AC voltage and current, 2- and 4-wire resistance,
frequency, period, continuity, diode and temperature — with range,
resolution and integration-time control, statistics, and range
assertions.

## What it still cannot do

Scanning with triggering and buffered acquisition (Phase 3),
temperature transducer setup (Phase 4), digital I/O (Phase 5), and
alarms (Phase 6). The `TEMPERATURE` function exists but the transducer
cannot yet be configured. Use `Send Scpi Command` for those.

---

## Upgrade note: measurements got 677x faster

If you piloted an interim Phase 2 build, upgrade. `TCP_NODELAY` was not
being set, so Nagle's algorithm collided with the peer's delayed-ACK
timer and **every configure and every read cost about 40 ms**.
Configuring a 20-channel scan took roughly 800 ms of pure stall.

| Operation | Before | After |
|---|---|---|
| Configure 1 channel | 44 ms | 0.065 ms |
| Configure + 2 acquisition settings | 132 ms | 0.118 ms |
| Read 1 channel | 44 ms | 0.089 ms |
| Read 20 channels | 44 ms | 0.225 ms |

The defect dated from Phase 1 Gate 1 and survived a dedicated Phase 1
performance review, which benchmarked only write-then-read patterns
that Nagle does not penalise.

---

## New keywords (11; 23 total)

| Keyword | Purpose |
|---|---|
| `Configure Measurement` | Set a function on channels; persists until changed |
| `Read Measurement` | Trigger a scan, return floats |
| `Read Measurement Details` | As above, returning full records incl. over-range flag |
| `Measure` | Configure and read in one shot |
| `Measure Value` | Single channel, single float |
| `Measurement Should Be Within` | Range assertion |
| `Get Measurement Statistics` | min/max/average/span/count/unit |
| `Get Configured Function` | What the driver configured on a channel |
| `Clear Measurement Configuration` | Reset driver-side channel bookkeeping |
| `Set Installed Card` | Declare slot contents to enable validation |
| `Get Four Wire Pair` | The channel a 4-wire measurement also consumes |

---

## Behaviour worth knowing before you write tests

**Readings come back in ascending channel order.** Not the order you
requested. The instrument scans ascending and readings are matched to
channels by position, so the driver normalises to keep that matching
correct. Map results by channel, never by position in your request.

**Over-range readings are the sentinel `9.9e37`.** That is a perfectly
ordinary float and **will pass a naive assertion**. Use
`Read Measurement Details` and check the `overrange` field, or use
`Get Measurement Statistics` / `Measurement Should Be Within`, both of
which fail explicitly rather than computing with the sentinel.

**Configured channels accumulate.** One session serves a whole suite,
so every `Configure Measurement` adds to the set a bare
`Read Measurement` scans. Call `Clear Measurement Configuration` in
`Test Setup`, or always pass explicit channels.

**`Measure` takes no acquisition arguments.** `MEAS:` reads immediately
and resets unspecified parameters, so NPLC and autozero could never
take effect. Passing them raises rather than silently returning a
reading taken at different settings. Use `Configure Measurement` then
`Read Measurement`.

**Declare your cards.** `Set Installed Card` converts whole classes of
mistake — channels that don't exist, measurement on a switch-only card,
current on a non-current channel, 4-wire with an occupied pair — from
opaque SCPI faults into clear driver-side errors.

**NPLC of 1 or above rejects mains hum; below 1 does not.**

---

## Verification

| Check | Result |
|---|---|
| Unit + integration tests | **351 passed** |
| Statement coverage | **99%** (enforced floor 90%) |
| Robot examples | **24/24** across 3 suites |
| Package build | sdist + wheel clean |
| AI contract conformance | revision 7, 23 capabilities, tested against the live library |

---

## Before you deploy this to a bench: read this

**Every automated check in this release ran against a mock instrument
that this project wrote.** No part of this driver has touched a
physical 34970A or 34972A.

One assumption in particular now gates correctness. The driver assumes
the mainframe scans channel lists in **ascending channel order**, and
matches readings to channels by position on that basis. If a real
instrument returns readings in the order written instead, every
multi-channel reading is silently attributed to the wrong channel. The
reading count would still be correct, so nothing in the driver — and
nothing in your test suite — would notice.

Run this before trusting any multi-channel result:

```bash
KEYSIGHT_HOST=10.0.0.12 KEYSIGHT_MODEL=34972A pytest -m hardware
```

`test_real_instrument_dc_voltage` checks exactly this and reports
plainly what is wrong if it fails.

Also unverified: the per-card channel ranges in `CARD_SPECS` come from
published specifications, not from measurement.

---

## Honest note on what the process caught

Four Major defects were found and fixed during this phase, three of them
predating it: an undeclared Robot keyword that falsified the Phase 1 AI
contract, silent reading misattribution, silently dropped acquisition
settings, and the Nagle latency.

None was found by the test suite passing or failing. Each was found by
deliberately probing a property nothing had thought to assert. Three
share a shape: the code did something plausible and wrong, and every
existing test agreed with it.

That is the argument for running the hardware tier before production
use, rather than reading 99% coverage as assurance.

---

## What's next

**Phase 3 — Scanner Engine:** scan lists, triggering, buffered
acquisition and instrument-side statistics.
