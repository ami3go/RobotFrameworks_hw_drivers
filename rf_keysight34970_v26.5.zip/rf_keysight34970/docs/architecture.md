# Architecture — Phase 1 (Core Framework)

> **This document covers Phase 1 only.** For the measurement layer see
> [`architecture_phase2.md`](architecture_phase2.md). Each phase adds
> its own architecture document rather than rewriting earlier ones, so
> the reasoning behind a decision stays attached to the gate that made
> it.
>
> | Phase | Document |
> |---|---|
> | 1 — Core Framework | this file |
> | 2 — Measurement Engine | [`architecture_phase2.md`](architecture_phase2.md) |

## Status

Phase 1 / Gate 1 — Architecture & Skeleton. Follows
`RFDS Driver Implementation Lifecycle v1.1`.

## Layering

```
Robot Framework .robot suites
            │
            ▼
keysight34970.library.Keysight34970        (public Robot Framework library)
            │  composed of mixins
            ▼
keywords.connection_keywords.ConnectionKeywords   (Phase 1)
  (future: MeasurementKeywords, ScannerKeywords, ...)
            │  drives
            ▼
connection.Connection                       (SCPI session + state machine)
            │  uses
            ▼
transport.Transport (ABC)
   ├── transport.tcp_transport.TcpSocketTransport
   └── transport.visa_transport.VisaTransport
```

Supporting, cross-cutting modules:

- `config.py` — `ConnectionConfig`, `TransportKind`, `InstrumentModel`.
  Validated once, up front, by `Connection.connect()`.
- `exceptions.py` — single-rooted exception hierarchy
  (`Keysight34970Error`) so AI planners and Robot suites can catch
  broadly or narrowly.
- `models.py` — small, frozen dataclasses for wire-format data
  (`InstrumentIdentity`, `ScpiError`). Phase 2+ will add
  `Measurement`, `ScanChannel`, etc. in their own modules.
- `logging_config.py` — per-instrument-tagged logging, since a bench
  (see RFDS-018) may have several 34970/34972 units connected at once.

## Why Transport is separate from Connection

`Transport` only moves bytes; it has no SCPI semantics. `Connection`
owns the state machine, `*IDN?`/`*CLS`/`*RST` handshake, and error-queue
checking. This split means:

- A new physical transport (e.g. a future USB-TMC-only backend) only
  needs to implement 4 methods (`open`, `close`, `write`, `query`).
- Unit tests can inject a `FakeTransport` and exercise the entire state
  machine and error-handling logic without hardware or sockets
  (see `tests/unit/test_connection.py`).
- PyVISA remains an *optional* dependency — `VisaTransport` only
  imports `pyvisa` inside `open()`, so importing `keysight34970` (e.g.
  for an AI planner reading contract metadata, RFDS-017) never requires
  a VISA runtime to be installed.

## Connection state machine

```
IDLE --connect()--> CONNECTING --success--> CONNECTED
  ^                      |
  |                   failure
  |                      v
  +<---close()------- ERROR
CONNECTED --close()--> CLOSED
CONNECTED --disconnect()--> IDLE   (reusable)
```

`ERROR` and `CLOSED` are both terminal for the current transport
instance. `disconnect()` is provided as a "soft" reset back to `IDLE`
so a `Connection` object (and by extension a Robot Framework library
instance held for `ROBOT_LIBRARY_SCOPE = TEST`) can be reconnected
without re-instantiating the whole object graph.

## Error handling policy

Every `write`/`query` on `Connection` (not `Transport` — see above)
optionally checks `SYST:ERR?` after the operation and raises
`CommandError` with the SCPI code/message if the queue was non-empty.
This is opt-out (`check_errors=False`) rather than opt-in, because
silent SCPI errors are the most common source of flaky/misleading test
failures in bench automation, and the RFDS-017 contract requires
pass/fail oracles to be explicit.

## Gate 3 additions (edge-case hardening + config enhancements)

- **Model verification.** `Connection._verify_model()` compares the
  `*IDN?`-reported model against `ConnectionConfig.model` after
  identify, raising `ConfigurationError` (not a bare assertion) on
  mismatch, since this is a *configuration* problem, not a runtime
  transport fault. Opt-out via `verify_model=False`.
- **Configurable terminator.** SCPI-over-LAN is conventionally
  newline-terminated, but not every firmware agrees, so
  `TcpSocketTransport` now accepts any non-empty terminator.
  Symmetrically, `write()` rejects any command that itself contains the
  terminator string, since sending one would silently corrupt framing
  for the *next* command/response rather than failing loudly.
- **VISA error translation.** `VisaTransport.open()` inspects the
  `pyvisa.errors.VisaIOError.error_code`'s enum name for
  `resource_not_found` / `resource_busy` / `resource_locked` and raises
  `ConnectionError34970` (actionable: fix the address, or another
  session/process is holding it open) instead of a generic
  `TransportError`. All other VISA I/O errors remain `TransportError`
  (or `TimeoutError34970` for the timeout case, unchanged from Gate 1).
- **Capability metadata registry.** `keywords/connection_keywords.py`
  now carries a `CAPABILITY_METADATA` dict (risk level, blocking,
  exclusive resources) per keyword, exposed via
  `Keysight34970.get_capability_metadata()`. This is explicitly *not*
  the RFDS-017 `ai_contract.yaml` - it has none of the required
  sections (state machine, error catalogue, verification oracles,
  UNKNOWN handling, etc). It exists so Phase 10 has real,
  gate-reviewed data to draw from rather than starting from nothing.

## Deferred to later phases

- Measurement configuration/execution — Phase 2.
- Scan lists, triggering, buffered acquisition — Phase 3.
- Temperature channels — Phase 4.
- 34907A Digital I/O / counters — Phase 5.
- Alarms, engineering scaling — Phase 6.
- Configuration profiles / snapshot import-export — Phase 7.
- Auto-reconnect, retry engine, comms statistics — Phase 8.
- Safe-mode interlocks — Phase 9.
- `ai/ai_contract.yaml` (RFDS-017) generation — Phase 10.
- Full docs site / guides — Phase 11.
- Regression + performance validation, production release — Phase 12.

The `ai/` directory exists in this Phase-1 skeleton but is
intentionally empty until Phase 10, per the task's phase plan.
