---
layout: default
title: rf_keysight34970
---

# rf_keysight34970

Robot Framework driver for the Keysight/Agilent **34970A** and **34972A**
Data Acquisition / Switch Unit.

**Current release: v26.5 — Phases 1–5 complete of 12.** 59 keywords,
694 tests, 98% coverage.

---

## Start here

| I want to… | Go to |
|---|---|
| Set up PyCharm and run something | [PyCharm setup](../guide/pycharm_setup.md) |
| Get a reading in five minutes | [Quick start](../guide/quick_start.md) |
| Write test suites | [User guide](user_guide.md) |
| Look up a keyword | [Keyword reference](keyword_reference.html) |
| Use the Python API | [API reference](api_reference.md) |
| Understand the internals | [Architecture](architecture.md) · [Phase 2](architecture_phase2.md) |
| Extend the driver | [Developer guide](developer_guide.md) |

---

## What works today

| Subsystem | Phase | Status |
|---|---|---|
| Connection: VISA and LAN, error handling, diagnostics | 1 | Complete |
| Measurement: DC/AC volts and current, resistance, frequency | 2 | Complete |
| Scanning: scan lists, triggering, monitoring, statistics | 3 | Complete |
| Temperature: thermocouples, RTDs, thermistors | 4 | Complete |
| Digital I/O: ports, totalizer, DAC output | 5 | Complete |
| Alarms | 6 | Not started |
| Configuration profiles | 7 | Not started |
| Recovery and diagnostics | 8 | Not started |
| Safe mode | 9 | Not started |
| AI integration tooling | 10 | Not started |
| Documentation site | 11 | Not started |
| Production release | 12 | Not started |

---

## Before you trust it on a bench

**No part of this driver has been run against a physical instrument.**
Five phases, 694 tests and 98% coverage were validated entirely against
an in-repo mock written to match this project's own assumptions about
the hardware.

Two consequences worth knowing before you wire anything:

- **Multi-channel readings rest on an unverified assumption.** The
  driver matches readings to channels by position, on the basis that the
  mainframe scans in ascending channel order. If that is wrong, every
  multi-channel result is attributed to the wrong channel — and the
  reading counts still look correct.
- **Digital output has never driven a real line.** `Return Outputs To
  Safe State` has never zeroed a physical output, and the ±12 V DAC
  range has never been checked against hardware.

Three verification suites exist to settle this. Run them first:

```bash
./scripts/verify_bench.sh 10.0.0.12
```

`01_bench_survey` and `03_verify_assumptions` are read-only.
`02_verify_commands` drives no output line unless you explicitly opt in.
See [hardware verification](../examples/robot/hardware/README.md).

---

## Install

```bash
pip install -e ".[dev]"          # LAN only
pip install -e ".[dev,visa]"     # + GPIB / USB
```

## Example

```robotframework
*** Settings ***
Library           keysight34970.Keysight34970
Suite Setup       Connect To Instrument    34972A    TCP    ${HOST}
Suite Teardown    Disconnect From Instrument

*** Test Cases ***
Read A Voltage
    Set Installed Card    1    34901A
    ${volts}=    Measure Value    DCV    101
    Log    ${volts}
```

---

## Project process

Built to the RFDS Driver Implementation Lifecycle: 12 phases, five gates
each, every gate producing a versioned release with history and review
records. Conformance to [RFDS-017](https://example.invalid) is enforced
by tests rather than asserted — `ai/ai_contract.yaml` is checked against
the live keyword surface on every run.

- [Changelog](../CHANGELOG.md)
- [Release notes](../RELEASE_NOTES_PHASE5.md)
