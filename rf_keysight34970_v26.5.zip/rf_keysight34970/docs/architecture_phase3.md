# Architecture — Phase 3 (Scanner Engine)

**Status:** Phase 3 / Gate 1 — Architecture & Skeleton (v26.03.01).
Scan models, trigger semantics, response parsing and the engine
interface are complete. The engine and its keywords arrive in Gate 2.

## What changes conceptually

Phase 2 could ignore instrument memory entirely, because `READ?` fuses
`INIT` and `FETC?`: a measurement was always taken and retrieved in one
breath. Phase 3 breaks that apart. Once a scan can be *armed and left
running*, three things become real that were not before:

- **Memory is a finite resource.** 50,000 readings, and a scan can be
  configured to exceed it before it is ever started.
- **A scan has a lifetime**, so arming and waiting must be separable —
  otherwise an infinite or externally-triggered scan is
  indistinguishable from a hung instrument.
- **Readings arrive interleaved across sweeps**, so position in the
  flat reading list no longer identifies a channel.

Each of those drove a design decision below.

## Layering

```
Keysight34970 = ConnectionKeywords + MeasurementKeywords + ScannerKeywords
                                                            (Phase 3)
                          │
                          ▼
        scanner.base.ScannerEngine   (ABC — Gate 2 implements)
                          │
        ├── scanner.models    ScanConfig, TriggerSource/Count, ScanResult
        └── scanner.parsing   multi-field scan responses → ScanReading
                          │
                          ▼
        measurement.*  (Phase 2, unchanged — channels, functions, units)
                          │
                          ▼
        connection.Connection → transport.Transport  (Phase 1, unchanged)
```

The scanner reuses Phase 2's channel and measurement vocabulary rather
than introducing its own. A `ScanReading` *contains* a `Measurement`
instead of duplicating its fields, so an over-range check or a unit
means the same thing in both layers.

## Design decisions

**Arming and waiting are separate operations.** `start_scan()` returns
immediately; `wait_for_scan()` blocks. `run_scan()` composes them for
the common case. `wait_for_scan()` *refuses* to wait on a scan that
cannot complete on its own — infinite count, or a trigger source
awaiting an external stimulus — because blocking forever on a
misconfigured scan is the failure mode most likely to be misread as
broken hardware.

**`TriggerCount` is a type, not `int | None`.** "Run forever" is a
different operating mode, not a missing value: it fills memory without
bound and cannot be waited on. Giving it a type means every place that
handles a count is forced to consider it.

**`TriggerSource.is_self_starting` is queryable.** The distinction
between "will proceed on its own" and "waits for something external" is
what makes the `wait_for_scan()` guard possible, so it belongs on the
enum rather than in an `if` somewhere.

**Memory overflow is detectable before arming.**
`ScanConfig.exceeds_reading_memory()` uses the documented 50,000-reading
capacity. The driver reports it rather than enforcing it: the capacity
is unverified, and a driver that silently refused a valid scan because
its constant was wrong would be worse than one that warns.

**Scan response parsing validates field alignment.** With timestamp and
channel formatting enabled, one reading occupies eight comma-separated
fields. If the actual field count is not a whole multiple of the
expected stride, the formatting on the instrument does not match what
the driver assumed — and continuing would read a timestamp component as
the next reading's *value*. That is a plausible number in the right
units. The parser refuses.

This is the same failure shape as the Phase 2 reading-misattribution
defect: right count, wrong mapping. Having been caught by it once, the
alignment check was written before the engine, not after.

**`ScanResult.for_channel()` is the intended access path.** Slicing a
multi-sweep scan by position requires the caller to replicate the
interleaving arithmetic, which is exactly where off-by-one
misattribution comes from. `statistics_for_channel()` raises on a
channel that produced no readings rather than returning an empty
aggregate.

**Instrument timestamps stay strings.** The mainframe's clock is
independent of the host's and may be unset. Presenting it as a
`datetime` would invite comparison against host time as though the two
were commensurate.

**`InstrumentStatistics` is distinct from `MeasurementStatistics`.**
The former is read from the instrument's CALC registers and remains
available for a scan too large to fetch; the latter is computed by the
driver over values it holds. They can legitimately disagree — the
instrument accumulates over its own notion of the current set — and
collapsing them would hide that.

## Session reset hooks: a finding closed after three deferrals

Phase 2 used `getattr(self, "_reset_measurement_state", None)` to let
the connection mixin clear sibling state on disconnect. Reviews in
Gate 2, Gate 4 and Gate 5 all flagged that a mixin which misspelled or
forgot the method would silently never be reset, and all three deferred
it on the grounds that two mixins did not justify a registry.

Phase 3 adds the third mixin, which is where the implicit contract
stops being obvious. Mixins now declare `SESSION_RESET_HOOKS` as a
class attribute; the connection mixin walks the MRO and calls every
declared hook, and `_validate_session_reset_hooks()` runs at
construction so a typo fails at import rather than surfacing later as
stale state.

Worth noting what the old implementation actually did: it called
**exactly one** hook, by name. A second stateful mixin would have been
missed entirely — so this was not merely a robustness improvement, it
was a latent bug that Phase 3 would have triggered.

## Gate 1 skeleton: no keywords by design

`ScannerKeywords` is composed in but declares no keywords, for the same
reason as Phase 2 Gate 1: non-functional keywords in the public surface
and generated docs are worse than absent ones. It does declare its
reset hook, giving the new registry a second consumer immediately.

## Deferred to Gate 2 and later

- Concrete `ScpiScannerEngine`: `ROUT:SCAN`, `TRIG:*`, `INIT`, `FETC?`.
- Scanner keywords and their capability metadata.
- Monitor mode (`ROUT:MON`) — continuous single-channel observation.
- Instrument statistics registers (`CALC:AVER:*`).
- Memory management (`DATA:POIN?`, clearing).

## Verification status

Unchanged from Phase 2 and now more consequential: nothing has been run
against physical hardware. Phase 3 builds directly on the ascending-scan
assumption that Phase 2's correctness already depends on, and adds a
second unverified constant (the 50,000-reading memory capacity).
