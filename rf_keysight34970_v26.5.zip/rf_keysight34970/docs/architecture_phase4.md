# Architecture — Phase 4 (Temperature)

**Status:** Phase 4 / Gate 1 — Architecture & Skeleton (v26.04.01).
Data models and the engine interface are complete; the engine and its
keywords arrive in Gate 2.

Builds on [Phase 1](architecture.md), [Phase 2](architecture_phase2.md)
and [Phase 3](architecture_phase3.md).

## Why temperature is its own subsystem

Temperature is nominally just another `MeasurementFunction`, and Phase 2
already has `TEMPERATURE = "TEMP"`. It would have been possible to add a
`unit=` argument to `Configure Measurement` and call the phase done.

That would have been wrong, because a temperature reading depends on
things no other measurement does:

- A **thermocouple** produces a voltage that means nothing without
  knowing the alloy and the reference-junction temperature.
- An **RTD** needs its nominal resistance and temperature coefficient,
  and in 4-wire form consumes a paired channel.
- A **thermistor** needs its nominal resistance, and the instrument's
  conversion assumes one of three standard curves.

Each of those, configured wrongly, produces a number in degrees that
looks entirely reasonable. This driver has now shipped three separate
defects of exactly that shape — an undeclared keyword, positional
reading misattribution, and a fallback labelling ohms as volts. A
subsystem whose whole failure mode is *plausible wrong numbers* deserves
types that make each choice explicit.

## Design decisions

**No default thermocouple type.** `ThermocoupleType` has eight members
and no default. Defaulting to K — by far the most common — would give a
confident wrong answer for the other seven, off by tens of degrees.
Requiring it costs the caller one argument.

**`fixed_reference_c` is rejected unless the junction is FIXED.**
Setting a reference temperature that will be ignored is not harmless:
the caller believes the reading is compensated one way and it is
compensated another. The same logic rejects thermocouple settings on
RTDs, RTD settings on thermistors, and so on. Every cross-transducer
combination that would be silently dropped is refused instead.

**Non-standard thermistor nominals are rejected.** 2252, 5000 and 10000
ohm are the curves the instrument implements. A 3000 ohm thermistor will
produce readings; they will be wrong.

**The unit travels with the configuration.** `TemperatureUnit` maps to
the Phase 2 `Unit`, so a reading configured in Fahrenheit carries
`Unit.FAHRENHEIT` rather than the assumed `Unit.CELSIUS` that Phase 2
hardcoded for `TEMPERATURE`. `Unit.FAHRENHEIT` and `Unit.KELVIN` have
existed unused since Phase 2 Gate 1; this is what they were for.

**Plausibility checking is offered, not enforced.** `is_plausible()`
compares a reading against the configured transducer's physical range.
It will not catch a wrong thermocouple type — that usually yields an
in-range number — but it does catch open junctions, disconnected
sensors and unit confusion, which are the failures that produce wild
values. It is a helper rather than a gate because a legitimate reading
near a range boundary should not fail.

**`read_reference_junction()` is on the interface.** When thermocouple
readings look wrong, the first question is whether the junction
reference is bad or the alloy is wrong, and those have completely
different fixes. Making the reference directly readable turns a
guessing game into one query.

## Layering

```
Keysight34970 = ConnectionKeywords + MeasurementKeywords
              + ScannerKeywords + TemperatureKeywords   (Gate 2)
            │
            ▼
temperature.base.TemperatureEngine   (ABC — Gate 2 implements)
            │  uses
            ├── temperature.models    TransducerType, TemperatureConfig, ...
            └── measurement.channels  ChannelId, ChannelList  (Phase 2)
            │
            ▼
connection.Connection                (Phase 1, unchanged)
```

The engine will consume `Connection` and own no I/O, consistent with
Phases 2 and 3.

## Deferred to Gate 2 and later

- `ScpiTemperatureEngine`: `CONF:TEMP`, `SENS:TEMP:TRAN:*`,
  `UNIT:TEMP`, reference-junction reads.
- Temperature keywords and their capability metadata.
- 4-wire RTD pair validation, reusing the Phase 2 mechanism.
- Interaction with scanning: a temperature channel in a scan list must
  report its own unit, which touches the Phase 3 per-channel function
  map.

## Verification status

Thermocouple type letters, RTD alpha options and thermistor nominals
come from published module specifications and are **not** hardware
verified. The plausibility ranges are approximate by design.
