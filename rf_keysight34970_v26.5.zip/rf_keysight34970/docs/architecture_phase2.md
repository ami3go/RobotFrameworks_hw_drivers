# Architecture — Phase 2 (Measurement Engine)

**Status:** Phase 2 / Gate 1 — Architecture & Skeleton (v26.02.01).
Data models, channel addressing, response parsing, and the engine
interface are complete. The engine implementation and its Robot
Framework keywords arrive in Gate 2.

See [`architecture.md`](architecture.md) for the Phase 1 foundation
this builds on.

## Layering

```
Robot Framework .robot suites
            │
            ▼
Keysight34970  =  ConnectionKeywords + MeasurementKeywords
                        (Phase 1)        (Phase 2, empty at Gate 1)
            │
            ▼
measurement.base.MeasurementEngine   (ABC — Gate 2 implements)
            │  uses
            ├── measurement.channels   ChannelId, ChannelList, CardType
            ├── measurement.models     MeasurementFunction, Measurement, ...
            └── measurement.parsing    instrument response → Measurement
            │
            ▼
connection.Connection                 (Phase 1, unchanged)
            │
            ▼
transport.Transport                   (Phase 1, unchanged)
```

Phase 2 adds a layer *beside* `Connection`, not beneath it. The engine
will consume `Connection.write`/`query` and owns no I/O of its own —
the same discipline that kept SCPI semantics out of the transport layer
in Phase 1.

## What Gate 1 deliberately front-loads

Gate 1's remit is architecture and skeleton, but three pieces are
fully implemented here rather than sketched, because they are pure
logic with no I/O and therefore fully testable without hardware.
Deferring them would mean writing them in Gate 2 under the pressure of
also getting SCPI interaction right.

**Channel addressing (`channels.py`).** Every later capability —
scanning, temperature, alarms, digital I/O — addresses channels. An
error in the addressing model propagates into five phases. It is also
the single most likely place for a silent fault: `108:203` looks
reasonable and is meaningless, since ranges cannot span slots.

**Card awareness (`CardType`, `CARD_SPECS`).** Distinguishes channels
that *exist* from channels that can be *measured through*. A 34903A
actuator has 20 perfectly addressable channels and no path to the DMM;
`measurable_channels` is empty for exactly that reason. `UNKNOWN`
relaxes validation rather than blocking, so an unrecognised card is
usable.

**Response parsing (`parsing.py`).** The over-range sentinel `9.9E+37`
is a correctness trap: parsed naively it is a valid float that will
pass numeric assertions and quietly corrupt statistics.
`Measurement.is_overrange` and the guard in
`MeasurementStatistics.from_measurements` exist to make that
un-ignorable.

## Design decisions

**`configure` / `read` / `measure` are three methods, not one.** They
map to genuinely different instrument behaviors: `CONF:` sets up
without reading, `READ?` triggers configured channels, and `MEAS:` does
both *and resets unspecified parameters to defaults*. Collapsing them
would hide that reset behavior, which is precisely the kind of surprise
that produces a passing test against a mis-configured instrument.

**Channel order: preserved in the value type, normalised at
submission.** `ChannelList` de-duplicates and keeps first-occurrence
order, because it is a value type and should not silently rewrite what
the caller wrote.

But `read()` and `measure()` normalise to **ascending** order before
submitting a scan list. This is a correctness requirement, not a
preference: readings are matched to channels positionally, and the
mainframe scans in ascending channel order regardless of how the list
was written. Submitting `(@105,101)` and mapping positionally would
report each channel's reading as the other's — counts match, so the
Gate 1 count-mismatch guard cannot detect it.

Gate 2's review found this. It is a good example of a guard that
protects against the obvious failure (wrong number of readings) while
leaving the subtle one (right number, wrong mapping) wide open.

Consequence: readings are returned in ascending channel order. Each
`Measurement` carries its own channel, so callers map by channel rather
than position.

**`to_scpi()` expands ranges explicitly.** `(@101,102,103)` rather than
`(@101:103)`. The instrument accepts both; the explicit form is far
easier to read in a failing test log.

**`AutoRange.AUTO` is a sentinel, not `None`.** "Unset" and "explicitly
autoranging" are different intentions and stay distinguishable.
Specifying a resolution without a range raises rather than silently
dropping the resolution.

**Reading/channel count mismatch is an error.** If the instrument
returns three readings for two channels, attributing them positionally
would misreport which channel produced what. Failing is strictly better.

**Statistics refuse mixed units and over-range readings.** Averaging
volts with ohms, or averaging in `9.9E+37`, produces a
plausible-looking number that is a lie.

## Two defects found during this gate

Both were found by tests written for the new architecture, and both
predate Phase 2.

**`CommandError` rejected `context=`.** Every other exception in the
hierarchy accepted it; `CommandError` overrode `__init__` and dropped
it. Fixed by merging caller context with the SCPI-specific fields.
`test_library_composition.py` now asserts the property across the whole
hierarchy.

**`get_capability_metadata()` was an undeclared Robot keyword.** Being a
public method, Robot Framework auto-exposed it as `Get Capability
Metadata` from Phase 1 Gate 3 onward. It appeared in neither
`CAPABILITY_METADATA` nor the RFDS-017 contract, so an AI planner
reading the contract saw 12 capabilities while the library offered 13.

The conformance tests missed it because they compared the contract
against `CAPABILITY_METADATA` — the two agreed with each other while
both disagreed with reality. Fixed with `@not_keyword`, and
`test_ai_contract.py` now validates against Robot's *live* keyword
surface via `TestLibrary.from_name`. The general lesson: a conformance
check between two artifacts the project controls proves consistency,
not correctness. At least one end must be anchored to something
external.

## Gate 1 skeleton: no keywords by design

`MeasurementKeywords` is composed into `Keysight34970` now but declares
no `@keyword` methods. Registering keywords that raise
`NotImplementedError` would place non-functional capabilities in the
public surface and in generated documentation — worse than absence,
since a test author or AI planner would see a capability that cannot be
used.

Composing the empty mixin now was deliberate: the Phase 1 Gate 5 review
noted the composition pattern had only been exercised with one mixin.
`test_library_composition.py` asserts MRO consistency, disjoint mixin
state, and an unchanged keyword surface — and it was this test that
surfaced the undeclared-keyword defect above.

## Deferred to Gate 2 and later

- Concrete `MeasurementEngine`: `CONF:`/`READ?`/`MEAS:` interaction.
- Measurement keywords, and their `CAPABILITY_METADATA` entries.
- Per-channel configuration state tracking.
- Card-type discovery via `SYST:CTYP?` — currently the driver has no
  way to learn what is installed, so `validate_against` requires a
  caller-supplied slot→card map. Phase 7 (Configuration Manager) is the
  natural home for auto-discovery.
- Temperature units beyond the model (`Unit.FAHRENHEIT`/`KELVIN` exist
  but nothing sets them yet) — Phase 4.
- `MeasurementStatistics` is defined but unused until Phase 3.

## Verification status

Card channel ranges in `CARD_SPECS` come from published module
specifications and have **not** been verified against physical cards.
The Phase 1 hardware-verification recommendation still stands and now
extends to confirming these ranges on a populated mainframe.
