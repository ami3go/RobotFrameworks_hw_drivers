# Developer Guide

For contributors extending this driver. Read
[`architecture.md`](architecture.md) first for the layering rationale.

## Setup

```bash
git clone <repo> && cd keysight34970
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
```

The `dev` extra includes `pytest`, `pytest-cov`, and `pyvisa` — enough
to run the entire suite without a VISA runtime or any hardware.

## Running tests

```bash
pytest                      # unit + integration (hardware deselected)
pytest tests/unit           # unit only
pytest -m integration       # integration only
pytest --cov=keysight34970  # with coverage (fails below 90%)
```

Against real hardware:

```bash
KEYSIGHT_HOST=10.0.0.12 KEYSIGHT_MODEL=34972A pytest -m hardware
```

Robot examples against the mock instrument:

```python
import sys, time, robot
sys.path.insert(0, "tests")
from mock_instrument import MockScpiServer

server = MockScpiServer(); server.start(); time.sleep(0.2)
robot.run("examples/robot",
          variable=[f"HOST:{server.host}", f"PORT:{server.port}"],
          outputdir="/tmp/robot_out")
server.stop()
```

## Test tiers

| Tier | Location | Marker | Hardware? |
|---|---|---|---|
| Unit | `tests/unit/` | none | No — fakes or loopback sockets |
| Integration | `tests/integration/` | `integration` | No — mock SCPI server |
| Hardware | `tests/integration/` | `hardware` | **Yes** — deselected by default |

`addopts = "-m 'not hardware'"` in `pyproject.toml` keeps hardware tests
out of default runs. The mock instrument is a **framing and control-flow**
substitute, not a behavioral model of the real firmware — anything
touching real measurement semantics needs a `hardware` test.

## Test doubles

- **`tests/unit/fakes.py` — `FakeTransport`.** In-memory, no sockets.
  Inject via `Connection(config, transport=fake)`. Use for state
  machine and error-handling logic. Note it re-validates `set_timeout`
  arguments; that duplication is deliberate — each layer guards its own
  invariants independently.
- **`tests/mock_instrument.py` — `MockScpiServer`.** Real TCP socket
  speaking newline-framed SCPI, with a working error queue (`*CLS`
  clears it; `BOGUS:COMMAND` enqueues `-113`). Use where framing,
  terminators, or timeouts matter. Single-connection and not
  thread-safe by design.
- **Ad-hoc servers** in `test_tcp_transport.py` for pathological cases
  (accept-then-silence for timeouts, partial-response-then-hangup).

## Adding a keyword

1. Add the method to the appropriate mixin in `keywords/`, decorated
   with `@keyword("Human Readable Name")`.
2. Keep SCPI/session logic in `Connection` — the keyword layer should
   only translate arguments and surface failures. Robot-facing errors
   are `AssertionError`; driver errors propagate as
   `Keysight34970Error` subclasses.
3. Return Robot-friendly types (`str`, `list`, `dict`, numbers) — not
   enums or dataclasses. `Get Connection State` returns `state.name`
   for exactly this reason.
4. Add an entry to `CAPABILITY_METADATA` in
   `keywords/connection_keywords.py`. `test_capability_metadata.py`
   asserts full keyword coverage and will fail if you forget.
5. Add unit tests (both the happy path and the not-connected guard) and
   extend an example suite if the keyword changes recommended usage.
6. Update `CHANGELOG.md` and regenerate the keyword reference.

## Adding a phase (mixin)

Each phase adds a mixin rather than modifying existing ones:

```python
# keywords/measurement_keywords.py
class MeasurementKeywords:
    @keyword("Measure DC Voltage")
    def measure_dc_voltage(self, channel: str) -> float: ...

# library.py
class Keysight34970(ConnectionKeywords, MeasurementKeywords):
    ...
```

Mixins must not define `__init__` state that collides with
`ConnectionKeywords._connection`; reach the session via
`self._require_connection()`.

## Adding a transport

Subclass `Transport` and implement all five members. Then extend
`TransportKind` and `Connection._build_transport()`. Keep the backend
import lazy (inside `open()`), as `VisaTransport` does, so the package
stays importable without the dependency installed — an AI planner
reading contract metadata should never need a VISA runtime.

## Conventions

- Type hints on all public signatures; `from __future__ import annotations`
  at the top of every module.
- Errors carry a `context` dict — put the command, resource, or state
  in it rather than only in the message string.
- Never raise a bare `Exception`; every failure maps to the hierarchy
  in `exceptions.py`.
- Log through `logging_config.get_logger(alias)` so records stay
  attributable on multi-instrument benches.
- Docstrings explain *why*, not *what* — the signature covers what.

## Versioning and gates

This project follows the RFDS Driver Implementation Lifecycle v1.1:
12 phases × 5 gates. Version format `26.<phase>.<gate>` (e.g.
`26.01.04` = Phase 1, Gate 4). Each gate updates source, tests,
examples, docs, README, `history/`, `review/`, `CHANGELOG.md`, the
version number, and produces a buildable package.

Bump the version in **three** places: `pyproject.toml` (as `26.1.4` —
PEP 440 strips leading zeros), `src/keysight34970/__init__.py`, and
`ROBOT_LIBRARY_VERSION` in `library.py`.

## Regenerating documentation

```bash
python -m robot.libdoc keysight34970.Keysight34970 docs/keyword_reference.html
```

## Building

```bash
python -m build     # sdist + wheel into dist/
```
