# User Guide

For test engineers writing Robot Framework suites against a
34970A/34972A. For the Python API, see
[`api_reference.md`](api_reference.md); for internals, see
[`architecture.md`](architecture.md).

> **Current scope.** Connection management (Phase 1), measurement
> (Phase 2) and scanning (Phase 3). Temperature transducers (Phase 4),
> digital I/O (Phase 5) and alarms (Phase 6) are not implemented yet;
> use `Send Scpi Command` / `Query Scpi Command` for those.

## Install

```bash
pip install keysight34970            # TCP/LAN only
pip install "keysight34970[visa]"    # + GPIB / USB-TMC / VISA-LAN
```

## Connecting

### Over LAN (recommended — no VISA runtime required)

```robotframework
*** Settings ***
Library    keysight34970.Keysight34970

*** Test Cases ***
Read Identity
    Connect To Instrument    34972A    TCP    10.0.0.12
    ${idn}=    Get Instrument Identity
    Log    ${idn}
    [Teardown]    Disconnect From Instrument
```

The 34970A needs the 34970A-to-LAN option or a GPIB/USB gateway; the
34972A has LAN built in. Default SCPI port is 5025.

### Over GPIB or USB

```robotframework
Connect To Instrument    34970A    VISA    GPIB0::9::INSTR
Connect To Instrument    34972A    VISA    USB0::0x0957::0x2007::MY12345678::INSTR
```

Requires `pip install "keysight34970[visa]"` and a VISA runtime
(Keysight IO Libraries, NI-VISA, or `pyvisa-py`).

### Connection arguments

| Argument | Default | Purpose |
|---|---|---|
| `model` | *required* | `34970A` or `34972A` |
| `transport` | *required* | `TCP` or `VISA` |
| `resource` | *required* | Hostname/IP (TCP) or VISA resource string |
| `port` | `5025` | TCP only |
| `timeout` | `5` | Seconds per command/query |
| `alias` | none | Name shown in logs — use it on multi-instrument benches |
| `reset` | `False` | Send `*RST` on connect |
| `verify_model` | `True` | Fail if the instrument reports a different model |
| `terminator` | `\n` | TCP line terminator |

## Recommended suite structure

Connect once per suite rather than once per test — cheaper, and on a
shared bench it holds the instrument for a predictable window. The
library uses `SUITE` scope, so the session persists across test cases:

```robotframework
*** Settings ***
Library           keysight34970.Keysight34970
Suite Setup       Connect To Instrument    34972A    TCP    ${HOST}    alias=daq1
Suite Teardown    Disconnect From Instrument
Test Setup        Clear Instrument Status
```

Clearing status in `Test Setup` means each test starts with an empty
error queue, so a failure in one test can't cascade into the next.

See `examples/robot/suite_patterns_example.robot` for a complete
worked example.

## Error handling

Every command checks the instrument's error queue afterwards. If the
instrument reports a fault, the keyword **fails** — tests stop loudly
rather than continuing against a faulted instrument:

```robotframework
Run Keyword And Expect Error    *Instrument reported error*
...    Send Scpi Command    BOGUS:COMMAND
```

An instrument-side error does **not** drop the connection; the session
remains usable. To inspect (rather than fail on) pending errors:

```robotframework
${errors}=    Drain Instrument Error Queue
Log    ${errors}
```

If you suspect the instrument is in a bad state:

```robotframework
Reconnect To Instrument
Instrument Should Be Connected
```

### What each failure means

| Symptom | Likely cause |
|---|---|
| `Instrument reported error -113` | Bad SCPI syntax / unsupported command |
| `Configured model ... does not match` | Wrong unit addressed, or wrong `model` argument |
| `Cannot open VISA resource ... already be held open` | Another process (NI MAX, Connection Expert, another suite) holds the session |
| `Timed out waiting for instrument response` | Operation slower than `timeout` — raise it (see below) |
| `Connection closed by instrument` | Instrument dropped the link mid-response; check cabling/power |

## Timeouts

The default 5 s suits identity and configuration commands. Raise it
before slow operations and lower it afterwards:

```robotframework
Set Instrument Timeout    30
${result}=    Query Scpi Command    ${SLOW_QUERY}
[Teardown]    Set Instrument Timeout    5
```

## Resetting

`Reset Instrument` sends `*RST`, which **clears channel and scan
configuration**. Prefer `Clear Instrument Status` (`*CLS`, error queue
only) for routine cleanup between tests, and reset deliberately:

```robotframework
Reset Instrument            # full instrument reset — destructive
Clear Instrument Status     # error queue only — safe between tests
```

If your instrument needs settling time after a reset, set
`stabilization_delay_s` via the Python `ConnectionConfig` API; the
driver sleeps for it automatically after `*RST`.

## Multiple instruments

Give each unit a distinct `alias` so log lines are attributable. Robot
Framework's `WITH NAME` gives you independent library instances:

```robotframework
*** Settings ***
Library    keysight34970.Keysight34970    WITH NAME    DAQ1
Library    keysight34970.Keysight34970    WITH NAME    DAQ2

*** Test Cases ***
Two Units
    DAQ1.Connect To Instrument    34972A    TCP    10.0.0.12    alias=daq1
    DAQ2.Connect To Instrument    34972A    TCP    10.0.0.13    alias=daq2
```

## Measurement

### One-shot

```robotframework
${volts}=     Measure Value    DCV    101
${values}=    Measure          DCV    (@101:104)
```

`Measure` resets measurement parameters you did not specify to their
defaults. When other settings must persist, configure first.

### Configure once, read repeatedly

Cheaper when reading the same channels repeatedly — configuration
persists on the instrument, so each read is one round trip instead of
two:

```robotframework
Configure Measurement    DCV    (@101:110)    range=10
${first}=     Read Measurement
${second}=    Read Measurement
```

### Reading order

**Readings come back in ascending channel order**, which may differ
from the order you listed channels in. The instrument scans ascending
and readings are matched to channels by position, so the driver
normalises the order to keep that matching correct. Map results by
channel, not by the order you wrote.

### Over-range readings

An out-of-range reading returns the sentinel `9.9e37`, which is a
perfectly ordinary large float and **will pass a naive assertion**. Use
the details form, which flags it:

```robotframework
${rows}=    Read Measurement Details
Should Not Be True    ${rows}[0][overrange]
```

`Get Measurement Statistics` and `Measurement Should Be Within` both
fail explicitly on over-range rather than computing with the sentinel.

### Declaring installed cards

The driver cannot discover what is plugged into each slot. Declaring it
turns several classes of mistake into clear driver-side errors instead
of opaque SCPI faults:

```robotframework
Set Installed Card    1    34901A
```

With the card declared, the driver rejects channels that do not exist
on it, measurements on switch-only cards (a 34903A actuator has no path
to the DMM), and current measurements on non-current channels.

### Accuracy and speed

Integration time is the main lever:

```robotframework
Configure Measurement    DCV    (@101)    range=10    nplc=10
```

**NPLC of 1 or above rejects mains hum; below 1 does not.** Higher
values are slower and quieter. `autozero=OFF` is faster but lets offset
drift accumulate. `input_impedance=HIGH` forces >10 Gohm on all ranges —
use it when the source impedance is high enough that a 10 Mohm input
would load the signal down.

### 4-wire resistance

A 4-wire measurement on channel N also consumes channel N+10:

```robotframework
${paired}=    Get Four Wire Pair    101      # -> 111
```

The driver refuses to configure 4-wire if the paired channel is already
configured for something else, or does not exist on the declared card.

## Scanning

A scan sweeps a list of channels, optionally repeatedly, storing
readings in instrument memory.

### The simple case

```robotframework
${rows}=    Run Scan    (@101:105)    sweeps=10
```

Each row carries `value`, `channel`, `unit`, `function`, `sweep`,
`overrange` and `instrument_timestamp`.

### Slice results by channel, not by position

A multi-sweep scan interleaves channels: with two channels and four
sweeps you get eight readings in the order 101, 102, 101, 102, ...
Reproducing that arithmetic yourself is where off-by-one
misattribution comes from.

```robotframework
${values}=    Get Scan Readings For Channel    101
```

### Long scans: arm, poll, fetch

`Run Scan` blocks. For a scan you want to inspect while it runs, arm it
and poll:

```robotframework
Configure Scan    (@101:110)    trigger_source=TIMER    interval=60    sweeps=1440
Start Scan
${count}=    Get Scan Reading Count
${rows}=     Fetch Scan Readings    clear=True
```

`Fetch Scan Readings` does not wait, so it may return a partial scan.
With `clear=True` the readings are erased as they are read, which is
how you keep a long scan from overflowing memory.

### Scans that never finish

`Wait For Scan` **refuses** to wait on a scan that cannot complete on
its own — an infinite sweep count, or a trigger source waiting on an
external stimulus. Blocking forever on a misconfigured scan is
indistinguishable from broken hardware, so the driver fails instead.

For those scans, poll `Get Scan Reading Count` and call `Abort Scan`
when you are done. Put `Abort Scan` in teardown unconditionally — it is
safe when no scan is running.

```robotframework
*** Settings ***
Test Teardown    Abort Scan
```

### Trigger sources

| Source | Starts a sweep when | Can be waited on |
|---|---|---|
| `IMMEDIATE` | as fast as possible | yes |
| `TIMER` | the interval elapses (`interval=` required) | yes |
| `EXTERNAL` | an external trigger input fires | no |
| `BUS` | a software trigger arrives | no |
| `ALARM` | a configured alarm fires | no |

### Reading memory

The instrument holds about 50,000 readings. `Configure Scan` warns if
your scan will produce more — it does not refuse, because the capacity
figure is taken from documentation rather than measured. Fetch with
`clear=True` periodically for long runs.

### Two kinds of statistics

`Get Measurement Statistics` computes over values the driver has
fetched. `Get Instrument Statistics` reads the instrument's own
registers, which stay available even for a scan too large to retrieve.
They are accumulated over different sets and can legitimately disagree.



## Temperature

Temperature is the subsystem where a wrong reading is least likely to
look wrong. Every failure mode below returns a believable number.

### Thermocouples

```robotframework
Configure Thermocouple    (@101:105)    K    open_detect=ON
${temps}=    Read Temperature
```

**The alloy has no default and is required.** Selecting the wrong type
does not fail — it converts the junction voltage with the wrong curve
and returns a temperature wrong by tens of degrees. There is no way for
the driver to detect this for you beyond the plausibility check below.

**Enable `open_detect` on anything that matters.** A thermocouple with
a broken junction does not report an error; it reports a temperature.
Open-detect makes the instrument test continuity before each reading.
It costs a little speed, which is the only reason it is opt-in.

**Cold-junction compensation** defaults to the instrument's internal
reference. An uncompensated junction is wrong by roughly the ambient
temperature — tens of degrees, in the plausible direction:

```robotframework
Configure Thermocouple    (@101)    K    reference=FIXED    reference_temperature=0
```

### RTDs and thermistors

```robotframework
Configure RTD           (@106)    nominal=100    reference_ohms=100.02
Configure RTD           (@107)    nominal=100    four_wire=True
Configure Thermistor    (@108)    nominal=5000
```

`nominal` says *this is a PT100*. `reference_ohms` says *this
particular PT100 measures 100.02 ohms at 0 C*. Supplying the calibrated
figure is worth tenths of a degree; omitting it uses the nominal value.

Prefer `four_wire=True` where lead resistance matters — it eliminates
the lead error rather than compensating for it, at the cost of the
paired channel (N+10, as with 4-wire resistance).

### Units

```robotframework
Set Temperature Unit    F
```

The unit is part of the configuration, not a display setting. A reading
carries the unit it was taken in, so `Read Temperature Details` tells
you what you actually got rather than what you assumed.

### The plausibility check, and what it cannot do

Readings are checked against the physical range of the configured
sensor, narrowed per thermocouple alloy. It catches:

- open or disconnected sensors returning wild values
- a grossly wrong alloy — a type-T channel reporting 1500 C
- unit confusion

It does **not** catch a moderately wrong alloy. A type-J channel
configured as type K reads about 20 C high at 500 C, and 520 C is
perfectly plausible. Nothing in this driver can tell you that. Verify
the alloy against the physical sensor.

`Temperature Should Be Within` fails on an implausible reading even
when your bounds would accept it, because the cause is a broken or
misconfigured sensor rather than an out-of-spec measurement:

```robotframework
Temperature Should Be Within    101    20    30
```

### Temperature in a scan

Temperature channels are visible to scanning and are tagged as
temperature rather than as unconfigured, so a mixed scan reports each
channel in its own units.

## Monitoring a single channel

Monitoring continuously reads **one** channel and keeps only the newest
value:

```robotframework
Configure Measurement       DCV    (@101)
Start Monitoring Channel    101
${live}=    Read Monitored Channel
[Teardown]    Stop Monitoring
```

**Monitoring is not scanning, and the difference matters.** A scan
accumulates readings in instrument memory that you fetch afterwards.
Monitoring accumulates nothing — each reading replaces the last. So:

- `Fetch Scan Readings` returns **nothing** from monitoring.
- There is no history. If you need one, poll `Read Monitored Channel`
  and keep the values yourself, or use a scan.
- `Read Monitored Channel` fails if monitoring was never started,
  rather than handing back a stale or unrelated value.

Monitoring and scanning both take over the internal DMM, and the
instrument does not arbitrate between them. The driver enforces this
rather than letting you collect data whose source is ambiguous:

- Starting a monitor **while a scan is running** is refused.
- Starting a scan **while monitoring** stops the monitor first — a scan
  is the more specific request, and leaving a monitor running would
  corrupt it silently.

`Stop Monitoring` is safe whether or not monitoring is active, so it
can go in teardown unconditionally.

## Instrument statistics

The instrument computes its own statistics, covering **every** reading
it took — including readings lost to reading-memory overflow, which
statistics computed from fetched readings cannot see:

```robotframework
${all}=    Get Instrument Statistics
${ch}=     Get Channel Statistics    101
```

Two things to watch:

- **Clear statistics before a scan whose statistics you intend to
  read.** Whether the registers survive the start of a new scan is
  firmware-dependent and is not verified by this driver's test suite.
  Calling `Clear Instrument Statistics` first makes the result
  well-defined either way — that is the whole reason the keyword
  exists.
- The unit is `?` (unknown) unless this driver configured that channel,
  because the statistics registers do not carry one.


## Digital I/O and analog output (34907A)

**These are the only keywords in this driver that can damage connected
hardware.** Everything else measures; these drive physical lines. Read
this section before wiring anything to a 34907A.

### Channel layout

On a 34907A in slot 3: `301` and `302` are 8-bit digital ports, `303`
is the totalizer, `304` and `305` are DAC outputs. Declaring the card
lets the driver reject a write aimed at the wrong kind of channel:

```robotframework
Set Installed Card    3    34907A
```

Without that declaration, writing a DAC voltage to a digital port
address is a command the instrument will attempt.

### Digital ports

```robotframework
Write Digital Port      301    0b10101010
${value}=    Read Digital Port         301
${bits}=     Read Digital Port Bits    301
```

Binary and hex notation are accepted because that is how bit patterns
are actually written; converting to decimal by hand is where
transcription errors enter.

**`Write Digital Port Bit` is read-modify-write and not atomic.** The
instrument offers no bit-scoped write, so the driver reads the port,
changes one bit, and writes it back. If anything else changes the port
between those two operations, that change is lost. For patterns you
care about, write the whole byte.

### Analog output

```robotframework
Write Analog Output    304    5.0
```

Range is ±12 V. Out-of-range values are rejected before anything is
driven.

### Totalizer

```robotframework
Configure Totalizer    303    mode=READ_RESET
${count}=    Read Totalizer    303
```

**In `READ_RESET` mode, reading consumes the count.** A retry after a
timeout returns 0 — and the retry itself is what destroyed the
evidence. Do not wrap totalizer reads in generic retry logic.

### Knowing what is energised

Two keywords answer different questions, and conflating them is
dangerous in exactly the situation where it matters:

```robotframework
${mine}=     Get Driven Outputs     # what THIS DRIVER drove
${actual}=   Read Output State      # what the INSTRUMENT reports
```

`Get Driven Outputs` is a driver-side record. An output set from the
front panel, by a previous session, or through `Send Scpi Command`
never appears in it — and one this driver set that something else later
changed still shows the driver's value.

`Read Output State` asks the hardware. With no argument it covers the
outputs this driver drove; **pass channels explicitly to check ones it
never touched.**

### Teardown

```robotframework
[Teardown]    Return Outputs To Safe State
```

This sets every output the driver drove to zero and reports what it
reset.

**Zero is not universally safe.** An active-low relay driver energises
at zero. A valve held closed by a high line opens when that line drops.
The driver does not do this automatically on disconnect for exactly
that reason — de-energising at teardown can be the wrong move, and only
you know which way your hardware fails.

If zero is wrong for your setup, drive the safe values explicitly
instead and leave this keyword alone.

## Raw SCPI

For anything not yet covered by a keyword (scanning, temperature
transducers, digital I/O, alarms), the escape hatches still perform the
error-queue check:

```robotframework
Send Scpi Command     ROUT:CHAN:DELAY 0.1,(@101)
${value}=    Query Scpi Command    SYST:CTYP? 100
```

Prefer dedicated keywords once they arrive — they carry preconditions,
risk metadata, and pass/fail oracles that raw SCPI cannot.

## Troubleshooting

**Enable debug logging:**

```python
from keysight34970.logging_config import configure_logging
import logging
configure_logging(level=logging.DEBUG)
```

Every line is tagged with the instrument alias.

**Connection refused over TCP:** confirm the IP, that port 5025 is
reachable (`telnet <ip> 5025`), and that no other session holds the
instrument. The 34972A's front panel shows its IP under the LAN menu.

**VISA resource not found:** list what VISA can actually see:

```python
import pyvisa
print(pyvisa.ResourceManager().list_resources())
```
