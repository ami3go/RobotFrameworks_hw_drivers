# API Reference — Python

This documents the **Python** API. For the Robot Framework keyword
reference, open [`keyword_reference.html`](keyword_reference.html)
(generated with `libdoc`; regenerate with
`python -m robot.libdoc keysight34970.Keysight34970 docs/keyword_reference.html`).

Everything below is available from the package root:

```python
from keysight34970 import (
    Keysight34970, Connection, ConnectionConfig, ConnectionState,
    TransportKind, InstrumentModel,
    Keysight34970Error, ConnectionError34970, TransportError,
    CommandError, TimeoutError34970, ConfigurationError, StateError,
)
```

---

## `ConnectionConfig`

Dataclass describing how to reach and manage one instrument.

| Field | Type | Default | Notes |
|---|---|---|---|
| `transport` | `TransportKind` | *required* | `VISA` or `TCP_SOCKET` |
| `model` | `InstrumentModel` | *required* | `DAQ_34970A` or `DAQ_34972A` |
| `visa_resource` | `str \| None` | `None` | Required when `transport=VISA` |
| `host` | `str \| None` | `None` | Required when `transport=TCP_SOCKET` |
| `port` | `int` | `5025` | TCP only |
| `timeout_s` | `float` | `5.0` | Must be > 0 |
| `stabilization_delay_s` | `float` | `0.0` | Slept after `*RST`; must be ≥ 0 |
| `identify_on_connect` | `bool` | `True` | Issue `*IDN?` during connect |
| `clear_on_connect` | `bool` | `True` | Issue `*CLS` during connect |
| `reset_on_connect` | `bool` | `False` | Issue `*RST` during connect |
| `verify_model` | `bool` | `True` | Fail if `*IDN?` model ≠ `model` |
| `terminator` | `str` | `"\n"` | TCP only; must be non-empty |
| `alias` | `str \| None` | `None` | Name used in logs |
| `extra` | `dict` | `{}` | Forward-compat escape hatch |

**Methods**

- `validate() -> None` — raises `ConfigurationError` if the config is
  internally inconsistent. Called automatically by `Connection.connect()`.
- `display_name() -> str` — alias if set, else the VISA resource or
  `host:port`.

---

## `Connection`

Owns one instrument's SCPI session and its state machine.

```
IDLE --connect()--> CONNECTING --success--> CONNECTED
  ^                      |
  |                   failure
  |                      v
  +<---close()------- ERROR
CONNECTED --close()--> CLOSED
CONNECTED --disconnect()--> IDLE   (reusable)
```

**Constructor**

```python
Connection(config: ConnectionConfig, *, transport: Transport | None = None)
```

`transport` is **testing only** — it injects a pre-built transport
instead of constructing one from `config`. Not part of the supported
production API.

**Properties**

| Property | Type | Notes |
|---|---|---|
| `state` | `ConnectionState` | Current state machine state |
| `config` | `ConnectionConfig` | The active configuration |
| `identity` | `InstrumentIdentity \| None` | Populated after connect |
| `is_connected` | `bool` | True iff state is `CONNECTED` |

**Lifecycle methods**

- `connect()` — validate config, open transport, run the configured
  `*CLS`/`*RST`/`*IDN?` handshake, optionally verify model.
  Raises `ConfigurationError`, `StateError`, `TransportError`,
  `ConnectionError34970`.
- `disconnect()` — close transport, return to `IDLE` (reusable). Safe
  from any state.
- `close()` — terminally close; state becomes `CLOSED`.
- `reconnect()` — `disconnect()` then `connect()`.
- Usable as a context manager (`__enter__` connects, `__exit__` closes).

**SCPI methods**

- `write(command, *, check_errors=True)` — send a command with no
  response expected.
- `query(command, *, check_errors=True) -> str` — send a query, return
  the stripped response.
- `query_error_queue_once() -> ScpiError` — pop one error queue entry
  without raising.
- `drain_error_queue(*, max_entries=20) -> list[ScpiError]` — pop all
  pending errors without raising.
- `reset()` — `*RST` plus the configured stabilization delay.
- `clear_status()` — `*CLS`.
- `set_timeout(timeout_s)` — update timeout on the live transport and
  in `config`. Raises `ConfigurationError` if not positive.

When `check_errors=True` (the default), `SYST:ERR?` is queried after
the operation and a non-empty result raises `CommandError`. If that
check itself fails at the transport level, a `TransportError` is raised
instead, so a link problem is never misreported as a bad SCPI command.

---

## `Transport` (abstract)

Moves bytes only; no SCPI semantics. Implement to add a new backend.

| Method | Notes |
|---|---|
| `open()` | Idempotent; raises `TransportError` on failure |
| `close()` | Idempotent; safe before `open()`; best-effort |
| `write(command)` | Raises `TransportError` / `TimeoutError34970` |
| `query(command) -> str` | Returns response with terminators stripped |
| `set_timeout(timeout_s)` | Must work before and after `open()` |
| `is_open` (property) | Local state only; does not probe the instrument |

Implementations: `TcpSocketTransport(host, port, timeout_s, *, alias, terminator)`
and `VisaTransport(resource_name, timeout_s, *, alias)`.

`TcpSocketTransport.write()` rejects commands containing the terminator,
since sending one would desync framing for subsequent responses.

---

## Data models

**`InstrumentIdentity`** (frozen) — `manufacturer`, `model`,
`serial_number`, `firmware_version`, `raw`. `InstrumentIdentity.parse(raw)`
tolerates non-conformant `*IDN?` responses by padding missing fields
rather than raising.

**`ScpiError`** (frozen) — `code: int`, `message: str`,
`is_no_error: bool` (code 0). `ScpiError.parse(raw)` defaults a
non-numeric code to 0 rather than raising inside an error path.

---

## Exception hierarchy

```
Keysight34970Error
├── ConfigurationError      invalid config / model mismatch / bad timeout
├── ConnectionError34970    cannot establish; VISA resource missing/busy/locked
├── CommandError            instrument reported a SCPI error (has scpi_code,
│                           scpi_message, command)
├── StateError              operation not valid in the current state
└── TransportError          low-level I/O failure
    └── TimeoutError34970   operation exceeded its timeout
```

All carry a `.message` and a `.context` dict. Catch `Keysight34970Error`
to handle any driver failure.

---

## `Keysight34970` (Robot Framework library)

Composed from keyword mixins; `ROBOT_LIBRARY_SCOPE = "SUITE"` so one
instrument session persists across the test cases in a suite.

`Keysight34970.get_capability_metadata() -> dict` returns per-keyword
planning hints (`risk_level`, `blocking`, `exclusive_resources`, and
sometimes `notes`). This is **staged data for Phase 10**, not a
conformant RFDS-017 `ai_contract.yaml`.

---

# Measurement API (Phase 2)

Available from `keysight34970.measurement`:

```python
from keysight34970.measurement import (
    ChannelId, ChannelList, CardType, CARD_SPECS,
    MeasurementFunction, Unit, AutoRange, MeasurementConfig,
    Measurement, MeasurementStatistics, MeasurementEngine,
    parse_reading, parse_readings,
)
from keysight34970.measurement.models import (
    AcquisitionSettings, Nplc, AutoZero, InputImpedance,
)
from keysight34970.measurement.engine import ScpiMeasurementEngine
```

## Channel addressing

**`ChannelId(slot, channel)`** — a single channel. `slot` is 1–3,
`channel` 1–99. `address` gives the three-digit SCPI form (`101`).
`ChannelId.parse()` accepts `ChannelId`, `101`, `"101"`, or `"@101"`.
`validate_against(card)` raises `ConfigurationError` if the channel
doesn't exist on that card type.

**`ChannelList`** — ordered, de-duplicated collection.
`ChannelList.parse()` accepts `"(@101,105:108)"`, `"101,103"`,
`[101, "102"]`, or an existing list. `to_scpi()` renders
`(@101,102,103)`, expanding ranges explicitly. Ranges spanning slots or
written in reverse are rejected.

Order is preserved as supplied. Note that `ScpiMeasurementEngine`
normalises to ascending order at scan submission — see "Reading order"
below.

**`CardType` / `CARD_SPECS`** — the eight documented plug-in modules
plus `UNKNOWN`. Each `CardSpec` carries `valid_channels`,
`measurable_channels` (empty for switch-only cards) and
`current_channels`. Channel ranges come from published specifications
and are **not hardware-verified**.

## Measurement types

**`MeasurementFunction`** — 11 functions; values are the SCPI mnemonics
(`DC_VOLTAGE` → `"VOLT:DC"`). Properties: `unit`,
`requires_current_channel`, `requires_four_wire`, `supports_nplc`.

**`MeasurementConfig(function, range=AUTO, resolution=AUTO, acquisition=...)`**
— frozen. `scpi_arguments()` renders `"<range>,<resolution>"` and
raises if a resolution was given without an explicit range.

**`AcquisitionSettings(nplc=None, autozero=None, input_impedance=None)`**
— frozen. `validate_for(function)` rejects NPLC on frequency, period,
continuity and diode, and input impedance on anything but DC voltage.
`Nplc.rejects_line_noise` is `True` at 1 NPLC and above.

**`Measurement`** — frozen result: `value`, `unit`, `function`,
`channel`, `timestamp` (UTC), `raw`. **`is_overrange`** is the reliable
over-range check; the raw value is the sentinel `9.9e37`, which is a
valid float and will pass naive comparisons.

**`MeasurementStatistics.from_measurements(list)`** — raises on an empty
set, mixed units, or any over-range reading.

## `ScpiMeasurementEngine`

```python
ScpiMeasurementEngine(connection, *, cards=None)
```

| Method | Notes |
|---|---|
| `configure(channels, config)` | `CONF:` then any `SENS:` acquisition commands |
| `read(channels=None)` | `ROUT:SCAN` then `READ?`; `None` reads all configured |
| `measure(channels, config)` | `MEAS:`; **rejects** acquisition settings (see below) |
| `clear_configuration(channels=None)` | Driver-side only |
| `get_configured_function(channel)` | Driver-side state, no round trip |
| `four_wire_pair(channel)` | Returns channel N+10 |
| `set_card(slot, card)` / `cards` | Declare / inspect installed modules |

### Reading order

`read()` and `measure()` normalise channel lists to **ascending** order
before submission. Readings are matched to channels positionally and
the mainframe scans ascending regardless of list order, so submitting
`(@105,101)` and mapping positionally would swap the two channels'
results — counts would match, so the count-mismatch guard cannot detect
it. Results are therefore returned in ascending channel order; map by
each `Measurement.channel`, not by position.

This assumption is drawn from the programmer's reference and is
**not hardware-verified**. `tests/integration/test_end_to_end.py::test_real_instrument_dc_voltage`
checks it on real hardware.

### Why `measure()` rejects acquisition settings

`MEAS:` configures, triggers and returns in one operation, resetting
parameters the caller did not specify. There is no point at which
`SENS:` settings could apply and still affect the reading, so passing
them raises `ConfigurationError` rather than silently returning a
reading taken at different settings than the caller believes.

### Pre-flight validation

Before sending anything, `configure()`/`measure()` reject: empty
channel lists, resolution without range, channels invalid on a declared
card, measurement on switch-only cards, current on non-current
channels, and 4-wire configurations whose N+10 pair is missing or
already configured for another function.

### Configuration accumulation

`configure()` adds to a driver-side set that a bare `read()` covers.
Because the Robot library holds one session per suite, this accumulates
across test cases. Use `clear_configuration()` or pass explicit
channels to `read()`.
