# ai/

This directory will hold the RFDS-017 AI Driver Contract
(`ai_contract.yaml`, `ai_contract.lock`) generated in **Phase 10 (AI
Integration)**. It is intentionally empty in Phase 1.
