# Release Notes — v26.03.05 (Phase 3 Complete)

**Release date:** 2026-07-22
**Phase:** 3 of 12 — Scanner Engine
**Status:** All five gates approved. Phases 1–3 complete.

---

## What this release adds

**Scanning.** Configure a scan list, choose how sweeps are triggered
(immediate, timer, external, bus, alarm), run it, and retrieve readings
with per-channel and per-sweep structure intact.

**Monitoring.** Continuously read a single channel.

**Instrument statistics.** Read the mainframe's own statistics
registers, overall or per channel.

## What it still cannot do

Temperature transducer setup (Phase 4), digital I/O (Phase 5), alarms
(Phase 6). The `TEMPERATURE` function exists but no thermocouple, RTD
or thermistor can be configured.

---

## New keywords (14; 37 total)

| Keyword | Purpose |
|---|---|
| `Configure Scan` | Define channels, trigger source, sweeps, delays |
| `Start Scan` | Arm the scan and return immediately |
| `Wait For Scan` | Block until complete; returns False on timeout |
| `Run Scan` | Configure, arm, wait and fetch in one call |
| `Abort Scan` | Stop a scan; safe when none is running |
| `Fetch Scan Readings` | Retrieve readings from instrument memory |
| `Get Scan Reading Count` | Readings currently in memory |
| `Get Scan Readings For Channel` | One channel's readings across sweeps |
| `Start Monitoring Channel` | Continuously read one channel |
| `Read Monitored Channel` | Newest monitored value |
| `Stop Monitoring` | Stop; safe when inactive |
| `Get Instrument Statistics` | Instrument's own statistics, overall |
| `Get Channel Statistics` | Instrument's statistics for one channel |
| `Clear Instrument Statistics` | Reset the statistics registers |

---

## Behaviour worth knowing before you write tests

**Monitoring is not scanning.** A scan accumulates readings in
instrument memory for you to fetch. Monitoring accumulates *nothing* —
each reading replaces the last. `Fetch Scan Readings` returns nothing
after monitoring. If you need history, use a scan.

**Scanning and monitoring both seize the internal DMM**, and the
instrument does not arbitrate between them. The driver does: starting a
monitor during a running scan is refused, and starting a scan while
monitoring stops the monitor first.

**Unbounded scans cannot be waited on.** `Wait For Scan` refuses a scan
with `sweeps=INF`, and refuses externally triggered sources
(`EXT`/`BUS`/`ALARM`) where a sweep may never arrive — waiting would be
indistinguishable from a hung instrument. Poll
`Get Scan Reading Count` instead.

**Reading memory holds 50,000 readings.** Beyond that the oldest are
lost. `Configure Scan` warns when a scan would exceed it rather than
refusing, because draining memory during a long scan is a valid
strategy.

**A short scan is not an error.** The instrument simply returns fewer
readings. Check `is_complete` on the result rather than assuming the
expected count arrived.

**Clear statistics before a scan whose statistics you intend to read.**
Whether the registers survive the start of a new scan is
firmware-dependent and **not verified here**. Clearing first makes the
result well-defined either way.

**Readings that cannot be attributed to a channel carry unit
`?` (UNKNOWN)**, not a guessed unit. If your scan spans multiple
measurement functions and you disable channel tagging, the driver will
not tell you a resistance reading is in volts.

---

## Performance

| Operation | Median |
|---|---|
| `Configure Scan` (10 channels) | 0.290 ms |
| `Run Scan` 10ch × 2 sweeps | 1.039 ms |
| `Run Scan` 10ch × 10 sweeps | 2.183 ms |
| Fetch 100 readings | 1.523 ms |
| `Get Instrument Statistics` | 0.472 ms |
| `Read Monitored Channel` | 0.175 ms |

Driver overhead only, against the mock over loopback. Scaling is
sublinear in sweeps, so fixed overhead dominates at these sizes.

`Wait For Scan` now polls adaptively (1 ms backing off to 50 ms). The
previous fixed 50 ms interval added up to a full interval of latency
*after* a scan had already completed — roughly 50% overhead on a 100 ms
scan, and invisible to every benchmark here because the mock finishes
instantly.

---

## Verification

| Check | Result |
|---|---|
| Unit + integration tests | **460 passed** |
| Statement coverage | **98%** (enforced floor 90%) |
| Robot examples | **37/37** across 4 suites |
| AI contract conformance | revision 12, 37 capabilities, tested against the live library |

---

## Before you deploy this to a bench

**No part of this driver has touched a physical 34970A or 34972A.**

The risk has grown with this release. Phase 2 shipped depending on an
unverified assumption — that the mainframe scans channel lists in
ascending channel order, with readings matched to channels by position.
Phase 3 has now built scanning, monitoring and statistics on top of it.

If that assumption is wrong, every multi-channel scan result is
attributed to the wrong channels, and every reading count will be
correct. Nothing in the driver or your suite would notice.

```bash
KEYSIGHT_HOST=10.0.0.12 KEYSIGHT_MODEL=34972A pytest -m hardware
```

Also unverified: per-card channel ranges, and whether statistics
registers survive a new scan.

---

## An honest note on what this phase found

Three defects, none caught by the test suite passing or failing:

- A scan reading that could not be attributed to a channel was silently
  labelled **DC volts** regardless of what it measured — the third
  variant of this misattribution class in three phases.
- Monitoring and scanning could both seize the DMM with no error; the
  contract warned planners off something the driver allowed.
- A fixed poll interval added up to 50 ms of latency after every scan,
  which no benchmark here could expose because the mock has no scan
  duration.

And one documentation error: a claim about statistics accumulating
across scans, asserted confidently in four separate places, that turned
out never to have been verified. Four consistent copies read as
well-documented behaviour until an example was written to demonstrate
it and failed.

That is the argument for the hardware tier, rather than reading 98%
coverage as assurance.

---

## What's next

**Phase 4 — Temperature:** thermocouple, RTD and thermistor support
with transducer configuration and temperature units.
