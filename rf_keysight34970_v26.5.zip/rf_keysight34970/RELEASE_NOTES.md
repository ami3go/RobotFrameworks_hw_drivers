# Release Notes — v26.01.05 (Phase 1 Complete)

**Release date:** 2026-07-22
**Phase:** 1 of 12 — Core Framework
**Status:** All five gates approved. Phase 1 complete.

---

## What this release is

A production-quality **connection framework** for the Keysight/Agilent
34970A and 34972A Data Acquisition / Switch Unit, packaged as a Robot
Framework library.

## What this release is *not*

**It cannot take a measurement.** There are no keywords for voltage,
current, resistance, frequency, temperature, scanning, digital I/O, or
alarms. Those arrive in Phases 2–6. Until then, measurement work goes
through the `Send Scpi Command` / `Query Scpi Command` escape hatches.

If you are evaluating whether this release solves a measurement
problem today: it does not. It solves the connection, error-handling,
and diagnostics problem underneath one.

---

## Installation

```bash
pip install keysight34970            # LAN/TCP only, no VISA runtime needed
pip install "keysight34970[visa]"    # + GPIB / USB-TMC / VISA-managed LAN
```

Requires Python 3.9+ and Robot Framework 6.0+.

## Quick start

```robotframework
*** Settings ***
Library           keysight34970.Keysight34970
Suite Setup       Connect To Instrument    34972A    TCP    10.0.0.12    alias=daq1
Suite Teardown    Disconnect From Instrument
Test Setup        Clear Instrument Status

*** Test Cases ***
Instrument Is Present
    ${idn}=    Get Instrument Identity
    Should Contain    ${idn}    34972A
```

---

## Keywords (12)

| Keyword | Purpose |
|---|---|
| `Connect To Instrument` | Open a session (VISA or TCP), identify, verify model |
| `Disconnect From Instrument` | Close the session; safe from any state |
| `Reconnect To Instrument` | Disconnect + reconnect with the same configuration |
| `Get Instrument Identity` | The `*IDN?` string captured at connect |
| `Get Connection State` | IDLE / CONNECTING / CONNECTED / ERROR / CLOSED |
| `Instrument Should Be Connected` | Assertion keyword |
| `Reset Instrument` | `*RST` + stabilization delay (**destructive**) |
| `Clear Instrument Status` | `*CLS` — error queue only |
| `Set Instrument Timeout` | Change the timeout on a live session |
| `Send Scpi Command` | Raw SCPI write + error-queue check |
| `Query Scpi Command` | Raw SCPI query + error-queue check |
| `Drain Instrument Error Queue` | Pop all pending errors for diagnostics |

Full documentation: [user guide](docs/user_guide.md),
[keyword reference](docs/keyword_reference.html),
[API reference](docs/api_reference.md).

---

## Behavioral change to note

**`ROBOT_LIBRARY_SCOPE` is `SUITE`** (changed from `TEST` during
Gate 4). Under `TEST` scope, Robot Framework builds a fresh library
instance per test case, which silently discarded any connection opened
in `Suite Setup` — breaking the recommended suite structure. `SUITE`
scope means one instrument session persists across the test cases of a
suite.

This is a behavioral change relative to the interim gate builds
(v26.01.01–v26.01.03). Since Phase 1 is the first release and has no
external consumers, no deprecation path is provided. If you piloted an
interim build and relied on per-test library isolation, connect
per-test explicitly rather than in `Suite Setup`.

---

## Design decisions worth knowing

**Errors fail loudly.** Every command checks `SYST:ERR?` afterwards and
raises `CommandError` if the instrument reported a fault. This costs a
second round trip (measured 2.31× per-command latency); it is opt-out
per call via the Python API's `check_errors=False`. The default is
deliberate: a silently-swallowed SCPI error produces a test that passes
against a faulted instrument, which is worse than a slow test.

**An instrument error does not drop the session.** After a
`CommandError`, the connection remains `CONNECTED` and usable.

**PyVISA is optional.** The package imports and runs without a VISA
runtime; `pyvisa` is imported lazily inside `VisaTransport.open()`.

**Model verification is on by default.** Connecting with `34970A` to a
unit reporting `34972A` fails rather than proceeding against the wrong
instrument. Disable with `verify_model=False`.

---

## Verification

| Check | Result |
|---|---|
| Unit + integration tests | **117 passed** |
| Statement coverage | **98%** (enforced floor: 90%) |
| Robot Framework examples | **10/10** across 2 suites |
| Package build | sdist + wheel clean |
| Socket/memory leak | None over 200 reconnect cycles + 500 queries |
| AI contract conformance | 13 checks passing |

**Hardware verification status:** all automated verification ran
against the in-repo mock SCPI instrument over loopback. The TCP
transport path is exercised end to end; **the VISA transport has not
been verified against physical GPIB/USB hardware.** An opt-in hardware
test tier exists for bench validation:

```bash
KEYSIGHT_HOST=10.0.0.12 KEYSIGHT_MODEL=34972A pytest -m hardware
```

Run this before deploying to a production bench.

---

## Performance (driver overhead, mock instrument over loopback)

| Operation | Median | p95 |
|---|---|---|
| `connect()` full handshake | 0.23 ms | 0.44 ms |
| Query with error check | 0.031 ms | 0.066 ms |
| Query without error check | 0.013 ms | 0.026 ms |

These figures exclude real instrument and network latency, which
dominate in practice (typically 1–5 ms per round trip on LAN). The
practical reading: **driver overhead is negligible; round trips are
not.** Since error checking doubles the round-trip count, later phases
performing per-channel operations should batch SCPI where possible
rather than disabling error checking.

---

## Known limitations

- No measurement, scanning, temperature, digital I/O, or alarm support.
- No card/slot awareness — the driver does not know what occupies
  slots 100/200/300.
- No automatic reconnect or retry engine (Phase 8); `Reconnect To
  Instrument` is manual.
- No safety interlocks (Phase 9). Do not rely on this driver to prevent
  electrically unsafe configurations.
- VISA transport unverified on physical hardware (see above).

---

## AI integration

`ai/ai_contract.yaml` provides an RFDS-017-structured contract covering
Phase 1 capabilities, with `ai/ai_contract.lock` for integrity. The
contract is **explicitly declared partial** — it describes 12
connection keywords and lists everything absent under `limitations`, so
a planner does not mistake "not in the contract" for "not supported by
the instrument."

The contract is hand-authored and human-reviewed at each phase
boundary; Phase 10 replaces this with generation tooling. Conformance
(capabilities, risk levels, exclusive resources, state machine,
version, lock hash) is enforced by
`tests/unit/test_ai_contract.py`, so the contract cannot drift from the
code without failing the build.

---

## What's next

**Phase 2 — Measurement Engine:** voltage, current, resistance,
frequency, continuity, diode, and structured `Measurement` objects.

Full roadmap in [CHANGELOG.md](CHANGELOG.md).
