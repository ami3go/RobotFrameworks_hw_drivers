"""Generate the canonical RFDS-017 AI contract and integrity lock."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "ai" / "ai_contract.yaml"
LOCK = ROOT / "ai" / "ai_contract.lock"


def cap(name, signature, purpose, *, inputs=None, output="None", pre=None,
        post=None, side=None, risk="low", timing="<3 s typical; bounded by configured transport timeout and retries",
        delay="none", retry="transport retries only; do not retry state changes at test level unless state is read back",
        errors=None, resources=None):
    return {
        "keyword": name, "signature": signature, "purpose": purpose,
        "inputs": inputs or {}, "output": output,
        "preconditions": pre or [], "postconditions": post or [],
        "side_effects": side or [], "risk_level": risk, "timing": timing,
        "stabilization_delay": delay, "retry_policy": retry,
        "errors": errors or ["NOT_CONNECTED", "TRANSPORT_ERROR", "DEVICE_ERROR"],
        "exclusive_resources": resources or ["eresistor.scpi_session"],
    }


CONNECTED = ["state == CONNECTED"]
READ = dict(pre=CONNECTED, risk="low", side=[])
WRITE = dict(pre=CONNECTED, risk="medium", side=["May change physical resistance/output state"],
             resources=["eresistor.scpi_session", "dut.resistance_outputs"])
CAL = ["state == CONNECTED", "valid calibration is loaded or downloadable"]

CAPABILITIES = [
    cap("Connect To EResistor", "host=None, all_off_on_connect=False", "Open SCPI session and verify identity.", inputs={"host":"IPv4/hostname or None", "all_off_on_connect":"strict Boolean"}, output="*IDN? string", pre=["state != CONNECTED", "network route to device exists"], post=["state == CONNECTED", "identity was read", "all channels open if all_off_on_connect is true"], side=["Opens TCP session", "Optionally sends ALL:OFF"], risk="medium", errors=["CONNECTION_ERROR", "IDENTITY_ERROR", "FIRMWARE_INCOMPATIBLE"], resources=["eresistor.scpi_session", "network"]),
    cap("Disconnect From EResistor", "all_off=True", "Stop watchdog, optionally open outputs, and close session.", inputs={"all_off":"strict Boolean"}, pre=[], post=["state is disconnected/closed", "all channels commanded open when all_off is true"], side=["Default sends ALL:OFF", "Closes TCP session"], risk="high", retry="idempotent; call once in suite teardown; ALL:OFF failure is logged and transport still closes", errors=["SAFE_SHUTDOWN_UNCONFIRMED"], resources=["eresistor.scpi_session", "dut.resistance_outputs"]),
    cap("E-Resistor Should Be Connected", "", "Assert connection state.", output="None or assertion failure", **READ),
    cap("Get EResistor Identity", "", "Read IEEE-488.2 identity.", output="manufacturer,model,serial,firmware string", **READ),
    cap("Ping EResistor", "", "Check HTTP, then SCPI reachability.", output="Boolean", **READ),
    cap("Identify EResistor", "duration_s=5.0", "Request physical identify LED action.", inputs={"duration_s":"seconds; compatibility argument, firmware may ignore"}, output="HTTP response string", side=["Blinks device LED"], risk="low", pre=CONNECTED, resources=["eresistor.http_session"]),
    cap("Get EResistor Information", "", "Return identity, serial, firmware and endpoint information.", output="dictionary", **READ),
    cap("Send EResistor SCPI Query", "command, multiline_until=None", "Advanced escape hatch for a known SCPI command.", inputs={"command":"SCPI text", "multiline_until":"optional terminator"}, output="raw response string", pre=CONNECTED, post=["UNKNOWN: depends on supplied command"], side=["UNKNOWN: command may change any device state"], risk="high", errors=["RAW_COMMAND_REJECTED", "TRANSPORT_ERROR", "DEVICE_ERROR"], resources=["eresistor.scpi_session", "dut.resistance_outputs"]),
    cap("Get EResistor Status", "", "Read and parse system status.", output="dictionary[str,str]", **READ),
    cap("Get EResistor Error", "", "Read one device error queue entry.", output="error string", pre=CONNECTED, side=["May consume one error queue entry"], risk="low"),
    cap("Clear EResistor Errors", "", "Clear device error queue.", output="device response string", pre=CONNECTED, side=["Destroys queued diagnostic errors"], risk="medium"),
    cap("Set EResistor Mask", "channel, mask, force=False", "Set one channel's 16-bit branch mask.", inputs={"channel":"integer 1..8", "mask":"0000..FFFF integer/hex", "force":"strict Boolean; simulation lock override only"}, output="normalized 4-digit uppercase hex mask", post=["readback/response accepted by device"], **WRITE),
    cap("Get EResistor Mask", "channel", "Read one channel mask.", inputs={"channel":"integer 1..8"}, output="4-digit uppercase hex string", **READ),
    cap("Get All EResistor Masks", "", "Read all eight masks.", output="dictionary channel-string -> mask", **READ),
    cap("Set All EResistor Masks", "*masks, force=False", "Atomically request masks for all channels.", inputs={"masks":"eight scalars or one 8-item list", "force":"strict Boolean"}, output="dictionary channel-string -> mask", post=["all eight values accepted"], **WRITE),
    cap("Set Selected EResistor Masks", "masks, force=False", "Set a channel-to-mask mapping.", inputs={"masks":"dictionary with channel keys 1..8", "force":"strict Boolean"}, output="dictionary channel-string -> mask", post=["selected values accepted"], **WRITE),
    cap("Open All EResistor Channels", "", "Command ALL:OFF safe output state.", output="device response string", post=["all channels commanded to mask 0000"], side=["Opens every resistance path"], risk="high", pre=CONNECTED, resources=["eresistor.scpi_session", "dut.resistance_outputs"]),
    cap("EResistor Mask Should Be", "channel, expected", "Assert normalized mask readback.", inputs={"channel":"integer 1..8", "expected":"mask"}, output="None or assertion failure", **READ),
    cap("Download EResistor Calibration", "", "Download and validate all channel calibration.", output="device calibration dictionary", post=["calibration and resistance solver cached"], side=["Updates in-memory calibration cache"], pre=CONNECTED, timing="May exceed normal command time; bounded by calibration transfer timeout", risk="low"),
    cap("Download EResistor Channel Calibration", "channel", "Download and merge one channel calibration.", inputs={"channel":"integer 1..8"}, output="channel calibration dictionary", post=["channel merged into in-memory calibration"], side=["Updates cache"], pre=CONNECTED, risk="low"),
    cap("Load EResistor Calibration", "path", "Load and validate local JSON calibration.", inputs={"path":"readable calibration JSON path"}, output="device calibration dictionary", pre=["file exists and matches schema"], post=["calibration and solver cached"], side=["Reads local file"], resources=["calibration.file"], errors=["FILE_NOT_FOUND", "CALIBRATION_INVALID"]),
    cap("Save EResistor Calibration", "path", "Persist current calibration to JSON.", inputs={"path":"writable path"}, output="None", pre=["calibration is loaded"], post=["file contains calibration"], side=["Creates/overwrites local file"], resources=["calibration.file"], errors=["CALIBRATION_MISSING", "FILE_IO_ERROR"]),
    cap("Build EResistor Resistance Cache", "", "Precompute mask resistance lookup.", output="None", pre=CAL, post=["solver cache built for calibrated channels"], side=["Uses CPU and memory"], timing="Potentially several seconds per channel; 65,535 combinations", resources=["eresistor.solver_cache"]),
    cap("Calculate EResistor Resistance", "channel, mask", "Calculate resistance without changing output.", inputs={"channel":"integer 1..8", "mask":"16-bit mask"}, output="float ohms", pre=CAL, resources=["eresistor.solver_cache"]),
    cap("Find Closest EResistor Resistance", "channel, resistance_ohm, allow_closest_out_of_range=False", "Solve closest calibrated mask without applying it.", inputs={"channel":"integer 1..8", "resistance_ohm":"finite positive ohms", "allow_closest_out_of_range":"strict Boolean"}, output="SetResistanceResult dictionary", pre=CAL, resources=["eresistor.solver_cache"], errors=["CALIBRATION_MISSING", "RESISTANCE_OUT_OF_RANGE", "SAFETY_LIMIT"]),
    cap("Set EResistor Resistance", "channel, resistance_ohm, allow_closest_out_of_range=False, force=False", "Solve and apply closest calibrated resistance.", inputs={"channel":"integer 1..8", "resistance_ohm":"finite positive ohms", "allow_closest_out_of_range":"strict Boolean", "force":"strict Boolean"}, output="SetResistanceResult dictionary", pre=CAL, post=["returned mask accepted by device"], **{k:v for k,v in WRITE.items() if k!='pre'}),
    cap("Set Multiple EResistor Resistances", "values, atomic=True, force=False", "Solve and apply multiple resistance targets.", inputs={"values":"channel mapping or 8-item sequence; None skips sequence entry", "atomic":"strict Boolean", "force":"strict Boolean"}, output="list of SetResistanceResult dictionaries", pre=CAL, post=["requested channel masks accepted; atomic path validates all before write"], **{k:v for k,v in WRITE.items() if k!='pre'}),
    cap("Load EResistor Temperature Table", "channel, path", "Load CSV temperature/resistance mapping for one channel.", inputs={"channel":"integer 1..8", "path":"CSV path"}, output="table range dictionary", pre=["valid CSV exists"], post=["table cached for channel"], side=["Reads local file"], resources=["temperature.file"], errors=["FILE_NOT_FOUND", "TABLE_INVALID"]),
    cap("Load EResistor Temperature Table For All Channels", "path", "Load one mapping shared by all channels.", inputs={"path":"CSV path"}, output="table range dictionary", pre=["valid CSV exists"], post=["global table cached"], side=["Reads local file"], resources=["temperature.file"], errors=["FILE_NOT_FOUND", "TABLE_INVALID"]),
    cap("Set EResistor Temperature", "channel, temperature_c, interpolation=linear, allow_extrapolation=False, force=False", "Convert temperature to resistance and apply it.", inputs={"channel":"integer 1..8", "temperature_c":"finite Celsius", "interpolation":"linear or supported table mode", "allow_extrapolation":"strict Boolean", "force":"strict Boolean"}, output="SetTemperatureResult dictionary", pre=["state == CONNECTED", "calibration loaded", "temperature table loaded"], post=["derived mask accepted"], **{k:v for k,v in WRITE.items() if k!='pre'}),
    cap("Start EResistor Watchdog", "", "Start background keepalive worker.", output="None", pre=CONNECTED, post=["watchdog thread running"], side=["Periodic SCPI traffic", "May reconnect on failure"], risk="medium", resources=["eresistor.scpi_session", "eresistor.watchdog"]),
    cap("Stop EResistor Watchdog", "", "Stop background keepalive worker.", output="None", pre=[], post=["watchdog thread stopped or absent"], side=["May wait up to 2 s for thread"], risk="low", timing="<=2 s join target", resources=["eresistor.watchdog"]),
    cap("Get EResistor Metrics", "", "Return local driver counters and durations.", output="dictionary", pre=[], side=[], resources=[]),
    cap("Discover EResistor Boards", "subnet, timeout=0.25, max_workers=64", "Scan one IPv4 subnet for boards.", inputs={"subnet":"IPv4 CIDR", "timeout":"seconds per probe", "max_workers":"positive integer"}, output="list of BoardInfo dictionaries", pre=["network scan is authorized"], side=["Concurrent HTTP/SCPI network probes"], risk="medium", timing="Depends on subnet size and concurrency", retry="no automatic full-scan retry", errors=["INVALID_SUBNET", "NETWORK_ERROR"], resources=["network.discovery"]),
    cap("Auto Discover EResistor Boards", "timeout=0.25, max_workers=64", "Discover boards on detected local IPv4 networks.", inputs={"timeout":"seconds per probe", "max_workers":"positive integer"}, output="list of BoardInfo dictionaries", pre=["network scan is authorized"], side=["Concurrent network probes"], risk="medium", timing="Depends on local networks", retry="no automatic full-scan retry", errors=["NETWORK_ENUMERATION_ERROR", "NETWORK_ERROR"], resources=["network.discovery"]),
]

CONTRACT = {
    "contract": {"id":"RFDS-017", "specification_version":"3.0", "driver_contract_version":"26.02", "status":"conformant-with-declared-unknowns", "generated_by":"tools/generate_ai_contract.py"},
    "identity": {"library":"rf_eresistor", "class":"rf_eresistor.library.EResistorLibrary", "robot_scope":"SUITE", "library_version":"26.02", "instrument":"OpenBench E-Resistor", "channels":8, "branches_per_channel":16, "transport":{"primary":"SCPI/TCP", "default_host":"192.168.0.55", "default_port":5025, "secondary":"HTTP/TCP port 80"}},
    "mental_model": ["Each channel is an independent 16-branch programmable resistance network.", "Mask 0000 opens a channel; a set bit activates a branch.", "Bit 0 maps to Q16 (lowest branch) and bit 15 maps to Q1 (highest branch).", "Resistance and temperature operations require calibrated branch data; computed values are not DMM measurements."],
    "state_machine": {"initial":"DISCONNECTED", "states":["DISCONNECTED","CONNECTED","RECONNECTING","LOST","CLOSED"], "transitions":[{"from":"DISCONNECTED","via":"Connect To EResistor","to":"CONNECTED"},{"from":"CONNECTED","via":"transport failure","to":"LOST or RECONNECTING"},{"from":"CONNECTED|LOST|RECONNECTING","via":"Disconnect From EResistor","to":"CLOSED"}], "operation_rule":"All device I/O keywords except discovery require CONNECTED; local metrics/file-table actions declare their own preconditions."},
    "resources": {"consumed":["one IPv4 address", "SCPI TCP port 5025", "optional HTTP port 80", "optional calibration JSON", "optional temperature CSV"], "provided":["eresistor.scpi_session", "eight logical resistance outputs", "calibration/solver cache", "optional watchdog"]},
    "dependencies": {"python":">=3.10", "robotframework":">=6.1", "optional":{"PyYAML":">=6.0 for YAML profiles"}, "firmware_protocol":"Compatibility must be confirmed by *IDN? and staged HIL tests; minimum version is UNKNOWN unless a profile configures it."},
    "capabilities": CAPABILITIES,
    "error_catalogue": {"NOT_CONNECTED":"Device I/O requested before connect.", "CONNECTION_ERROR":"TCP session could not open or was lost.", "TRANSPORT_ERROR":"Timeout, socket, framing, or retry exhaustion.", "DEVICE_ERROR":"Firmware returned an error/unexpected response.", "CALIBRATION_MISSING":"Resistance operation lacks calibration/solver.", "CALIBRATION_INVALID":"Calibration schema/content/checksum failed.", "RESISTANCE_OUT_OF_RANGE":"Target outside permitted/calibrated range.", "SAFETY_LIMIT":"Resistance or active-bit safety rule rejected request.", "SAFE_SHUTDOWN_UNCONFIRMED":"ALL:OFF could not be confirmed before close.", "UNKNOWN":"Preserve raw exception text and stop unsafe planning."},
    "safety_rules": ["Use Connect To EResistor with all_off_on_connect=True before any state-changing test unless preserving state is an explicit objective.", "Always register Disconnect From EResistor as Suite Teardown; its default all_off=True is mandatory for normal tests.", "Never assume PC/network loss makes outputs safe; firmware-side watchdog or external isolation is required.", "Verify mask readback after state-changing operations and physically qualify channel mapping before DUT connection.", "Do not use force=True unless overriding a known simulation lock; it does not authorize bypass of electrical safety limits.", "Raw SCPI is high risk and forbidden to an AI planner unless the command semantics are supplied by an approved bench contract."],
    "verification_objectives": [{"id":"VO-IDENTITY", "action":"Connect and read identity", "oracle":"Four comma-separated identity fields; expected manufacturer/model/serial/firmware match bench contract"},{"id":"VO-SAFE-START", "action":"Connect with all_off_on_connect=True then Get All EResistor Masks", "oracle":"Every channel equals 0000"},{"id":"VO-MASK", "action":"Set a qualified nonzero mask then read it back", "oracle":"Normalized written and read masks are identical"},{"id":"VO-RESISTANCE", "action":"Set calibrated target and independently measure with routed DMM", "oracle":"DMM result is within bench-contract tolerance; driver calculated_ohm alone is not a physical oracle"},{"id":"VO-TEARDOWN", "action":"Disconnect with all_off=True and independently observe outputs", "oracle":"All channels open; if communication is unavailable result is UNKNOWN, not PASS"}],
    "setup_teardown_contract": {"suite_setup":["Connect To EResistor    all_off_on_connect=${True}", "Get EResistor Identity", "Open All EResistor Channels"], "test_setup":["Open All EResistor Channels", "Clear EResistor Errors when error history is not under test"], "test_teardown":["Open All EResistor Channels"], "suite_teardown":["Disconnect From EResistor    all_off=${True}"], "failure_rule":"Attempt safe teardown even after assertion/keyword failure; record safe-state confirmation separately."},
    "limitations": ["No real-hardware qualification is encoded as complete in this package.", "Driver resistance is calculated from calibration, not independently measured.", "Identify duration may be ignored by current firmware.", "Solver cache generation can be slow.", "Network loss prevents guaranteed ALL:OFF.", "RFDS-018 v1.0 source supplied during release was empty, so bench topology and inter-driver orchestration remain UNKNOWN."],
    "planning_hints": ["Plan read-only identity and safe-state checks before writes.", "Load/download calibration before resistance operations and temperature table before temperature operations.", "Serialize all keywords sharing eresistor.scpi_session.", "Treat outputs as exclusive with any DMM multiplexer switching sequence: open all relays, select one route, settle, measure, open route.", "Use returned dictionaries for requested/calculated/error/mask evidence and use an independent instrument for physical pass/fail."],
    "unknown_handling": {"token":"UNKNOWN", "rules":["Never invent an argument, firmware command, resource owner, tolerance, stabilization time, or safe state.", "Ask for the bench contract or preserve UNKNOWN when a missing value affects safety or pass/fail.", "UNKNOWN cannot satisfy a PASS oracle.", "On unclassified exceptions, stop state-changing steps and execute safe teardown."]},
    "conformance": {"required_files":["ai/ai_contract.yaml","ai/ai_contract.lock"], "keyword_coverage":"Every @keyword in rf_eresistor/library.py appears exactly once.", "machine_readable":"JSON text, which is valid YAML 1.2.", "lock_rule":"SHA-256 and capability count must match generated contract.", "source_of_truth":"Keyword implementation governs execution; contract mismatch is a release-blocking defect."},
}


def main():
    OUT.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(CONTRACT, indent=2, ensure_ascii=False) + "\n"
    OUT.write_text(payload, encoding="utf-8")
    digest = hashlib.sha256(payload.encode()).hexdigest()
    lock = {"contract_file":"ai_contract.yaml", "sha256":digest, "capability_count":len(CAPABILITIES), "driver_contract_version":"26.02", "specification":"RFDS-017 v3.0"}
    LOCK.write_text(json.dumps(lock, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
