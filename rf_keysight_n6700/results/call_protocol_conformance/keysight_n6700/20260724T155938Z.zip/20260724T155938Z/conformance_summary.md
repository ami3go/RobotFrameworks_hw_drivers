# N6775A RFDS-019 self-check summary

- Public keyword inventory: **63/63**
- Protocol vectors: **45**
- Approved exclusions: **18**
- Robot test results: **{'PASS': 17, 'FAIL': 2, 'SKIP': 2}**
- Protocol vector results: **{'PASS': 27, 'SKIP': 7, 'FAIL': 11}**
- Protocol trace records: **243**

The active-output and reset vectors are SKIP unless explicitly enabled. Hardware PASS status requires a real N6700 mainframe with an N6775A in the selected channel.
