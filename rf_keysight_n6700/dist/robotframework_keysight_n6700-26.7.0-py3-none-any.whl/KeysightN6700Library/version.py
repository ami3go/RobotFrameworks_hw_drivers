"""Package version."""

__version__ = "26.7.0"
