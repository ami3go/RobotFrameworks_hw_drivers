# Release History

Each release or package update has a dedicated Markdown record. Older records are retained for traceability.

Naming convention: `vYY.RR.md`

- [v26.04](v26.04.md) — current RFDS-017/RFDS-018 AI-contract update
- [v26.02](v26.02.md) — package-integrity and automated verifier update
- [v26.01](v26.01.md) — initial Robot Framework library and project-format release
