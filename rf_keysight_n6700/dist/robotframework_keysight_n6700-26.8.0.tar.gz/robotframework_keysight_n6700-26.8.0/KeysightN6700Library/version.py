"""Package version."""

__version__ = "26.8.0"
