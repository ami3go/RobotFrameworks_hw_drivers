import pytest

from keysight_n6700 import (
    N6700,
    ElectronicLoadChannel,
    PowerSupplyChannel,
    SMUChannel,
    UnsupportedFeatureError,
)
from keysight_n6700.capabilities import classify_module
from keysight_n6700.simulator import SimN6700Instrument
from keysight_n6700.transport import SimulatedTransport


def make_inst():
    return N6700(SimulatedTransport(SimN6700Instrument()))


def test_discovery_and_channel_types():
    with make_inst() as inst:
        assert inst.channel_count() == 4
        assert isinstance(inst.power_supply(1), PowerSupplyChannel)
        assert isinstance(inst.smu(2), SMUChannel)
        assert isinstance(inst.load(3), ElectronicLoadChannel)


def test_power_supply_config_does_not_enable_by_default():
    with make_inst() as inst:
        ps = inst.power_supply(1)
        ps.set_voltage_setpoint(5.0)
        ps.set_current_limit(1.0)
        assert ps.get_output() is False
        ps.output_on()
        assert ps.get_output() is True
        ps.output_off()


def test_smu_mode_and_config():
    with make_inst() as inst:
        smu = inst.smu(2)
        smu.set_smu_mode("current")
        assert smu.get_smu_mode() == "current"
        smu.configure_voltage_priority(1.2, 0.2, output=False)
        assert smu.get_output() is False


def test_sim_load_and_unsupported_policy():
    with make_inst() as inst:
        load = inst.load(3)
        load.set_load_mode("cc")
        load.set_load_current(0.1)
        assert load.get_load_mode() == "cc"
        assert load.get_input() is False
        load.input_on()
        assert load.get_input() is True
    caps = classify_module("N6799X")
    assert caps.module_type == "unknown"


def test_wrong_channel_type_raises():
    with make_inst() as inst:
        with pytest.raises(UnsupportedFeatureError):
            inst.load(1)
        with pytest.raises(UnsupportedFeatureError):
            inst.smu(1)


def test_measurement_power_source():
    with make_inst() as inst:
        meas = inst.power_supply(1).measure()
        assert meas.power_source in {"instrument", "calculated", "unavailable"}


def test_shutdown_all_attempts_all():
    with make_inst() as inst:
        inst.power_supply(1).output_on()
        inst.smu(2).output_on()
        inst.load(3).input_on()
        result = inst.shutdown_all()
        assert len(result.results) == 4
        assert not inst.power_supply(1).get_output()
        assert not inst.smu(2).get_output()
        assert not inst.load(3).get_input()


def test_safe_clear_protection_keeps_output_off():
    with make_inst() as inst:
        ps = inst.power_supply(1)
        ps.output_on()
        result = ps.clear_protection()
        assert result.output_state_before is True
        assert result.output_state_after is False
        assert result.restored_output is False


def test_transport_clear_capability():
    with make_inst() as inst:
        assert inst.transport.supports_clear is True
        inst.transport.clear()


def test_protocol_audit_trace_records_write_query_and_response(tmp_path):
    trace = tmp_path / "protocol_trace.jsonl"
    with N6700(
        SimulatedTransport(SimN6700Instrument(models={1: "N6775A"})),
        audit_log_path=trace,
    ) as inst:
        inst.power_supply(1).set_voltage_setpoint(1.25)
        assert inst.power_supply(1).get_voltage_setpoint() == pytest.approx(1.25)

    lines = trace.read_text(encoding="utf-8").splitlines()
    assert any('"operation": "write"' in line and '"command": "VOLT 1.25,(@1)"' in line for line in lines)
    assert any(
        '"operation": "query"' in line
        and '"command": "VOLT? (@1)"' in line
        and '"response": "1.25"' in line
        for line in lines
    )
