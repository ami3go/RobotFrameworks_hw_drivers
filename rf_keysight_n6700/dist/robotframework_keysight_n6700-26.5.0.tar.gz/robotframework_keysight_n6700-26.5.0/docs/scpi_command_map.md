# SCPI Command Map

| Python API method | SCPI command/query | Official source | Supported module models | Capability flag | Simulator test | Hardware test | Safety notes |
|---|---|---|---|---|---|---|---|
| `N6700.idn` | `*IDN?` | N6700 Programmer's Reference, Common Commands | All mainframes | n/a | `test_idn_parse` | `test_hw_idn` | Read-only |
| `N6700.channel_count` | `SYSTem:CHANnel:COUNt?` | N6700 Programmer's Reference, SYSTem subsystem | All mainframes | n/a | `test_discovery` | `test_hw_discovery` | Read-only |
| `N6700.channel_model` | `SYSTem:CHANnel:MODel?` | N6700 Programmer's Reference, SYSTem subsystem | All mainframes | n/a | `test_discovery` | `test_hw_discovery` | Read-only |
| `N6700.channel_options` | `SYSTem:CHANnel:OPTion?` | N6700 Programmer's Reference, SYSTem subsystem | All mainframes | n/a | `test_discovery` | `test_hw_discovery` | Read-only |
| `PowerSupplyChannel.output_on/off` | `OUTPut <Bool>,(@ch)` | N6700 Programmer's Reference, OUTPut subsystem | Power/SMU modules | `supports_voltage_source` | `test_power_output` | level 2 only | Energizes DUT when ON |
| `PowerSupplyChannel.set_voltage_setpoint` | `VOLTage[:LEVel] <value>,(@ch)` | N6700 Programmer's Reference, SOURce subsystem | Power/SMU modules | `supports_voltage_source` | `test_voltage_current_config` | level 1 output off | Does not enable output |
| `PowerSupplyChannel.set_current_limit` | `CURRent[:LEVel] <value>,(@ch)` | N6700 Programmer's Reference, SOURce subsystem | Power/SMU modules | n/a | `test_voltage_current_config` | level 1 output off | Does not enable output |
| `SMUChannel.set_smu_mode` | `FUNCtion:MODE VOLT/CURR,(@ch)` | N6700 Programmer's Reference, SOURce/SMU function mode | N678xA | `supports_smu_priority_mode` | `test_smu_mode` | optional | Does not enable output |
| `ElectronicLoadChannel.*` | `SIM:LOAD:*` | Simulator-only, not real hardware SCPI | `SIM_LOAD` only | `supports_load_*` | `test_sim_load` | none | Real load commands blocked until exact official source is added |
| `BaseChannel.clear_protection` | `OUTPut:PROTection:CLEar (@ch)` | N6700 Programmer's Reference, OUTPut subsystem | Output modules | n/a | `test_safe_clear_protection` | guarded | Driver forces output off first by default |
