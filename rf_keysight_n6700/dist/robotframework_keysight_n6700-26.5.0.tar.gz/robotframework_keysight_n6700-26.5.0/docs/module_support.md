# Module Support Matrix

| Model | Type | Status |
|---|---|---|
| N673x/N674x/N675x/N676x/N677x | Power supply | Implemented for core CV/CC APIs |
| N678xA | SMU | Implemented for voltage/current priority wrapper APIs |
| SIM_LOAD | Simulator-only electronic load | Implemented for no-hardware tests |
| Real electronic load models | Electronic load | Blocked until exact official command docs are added |
