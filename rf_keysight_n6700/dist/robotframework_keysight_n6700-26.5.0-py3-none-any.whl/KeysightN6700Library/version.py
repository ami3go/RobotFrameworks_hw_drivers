"""Package version."""

__version__ = "26.5.0"
