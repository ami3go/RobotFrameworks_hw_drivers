# keysight34970

Robot Framework driver for the Keysight/Agilent **34970A** and **34972A**
Data Acquisition / Switch Unit mainframes.

> **Status: Phase 1 COMPLETE — v26.01.05** (1 of 12 phases)
> Connection framework only. **This release cannot take a
> measurement** — no voltage, current, resistance, temperature,
> scanning, digital I/O, or alarm keywords exist yet. Those arrive in
> Phases 2–6; until then use the raw SCPI escape hatches. See
> [RELEASE_NOTES.md](RELEASE_NOTES.md) and [CHANGELOG.md](CHANGELOG.md).

## Documentation

| Document | For |
|---|---|
| [Release Notes](RELEASE_NOTES.md) | What shipped, what didn't, verification status |
| [User Guide](docs/user_guide.md) | Writing Robot Framework suites against the instrument |
| [Keyword Reference](docs/keyword_reference.html) | Generated Robot keyword docs (`libdoc`) |
| [API Reference](docs/api_reference.md) | The Python API |
| [Architecture: Phase 1](docs/architecture.md) | Connection framework internals |
| [Architecture: Phase 2](docs/architecture_phase2.md) | Measurement engine internals |
| [Developer Guide](docs/developer_guide.md) | Contributing and extending |
| [AI Driver Contract](ai/ai_contract.yaml) | RFDS-017 contract for AI test planners |

This project follows the
[RFDS Driver Implementation Lifecycle v1.1](../RFDS_Driver_Implementation_Lifecycle_v1.1-1.md):
12 phases, each split into 5 gates (Architecture & Skeleton → Core
Implementation → Extended Features → Tests & Documentation → Review &
Release).

## Install

```bash
pip install -e .            # TCP-socket transport only
pip install -e ".[visa]"    # + PyVISA, for GPIB/USB-TMC/VISA-LAN
pip install -e ".[dev]"     # + pytest for running the test suite
```

## Quick start (Robot Framework)

```robotframework
*** Settings ***
Library    keysight34970.Keysight34970

*** Test Cases ***
Read Identity Over LAN
    Connect To Instrument    34972A    TCP    10.0.0.12    alias=daq1
    ${idn}=    Get Instrument Identity
    Log    ${idn}
    Disconnect From Instrument
```

See `examples/robot/connection_example.robot` for a runnable example.

## Configuration notes (Gate 3 additions)

- **Model verification:** `Connect To Instrument` compares the
  instrument's reported `*IDN?` model against the `model` argument you
  passed, and fails the connection if they don't match (guards against
  addressing the wrong bench slot/unit). This is a `ConnectionConfig`
  field (`verify_model`, default `True`); it isn't yet exposed as a
  `Connect To Instrument` argument, so bypassing it currently requires
  using the `Connection`/`ConnectionConfig` Python API directly rather
  than the Robot keyword.
- **Custom line terminator:** the TCP transport defaults to `\n` but
  supports any non-empty terminator via `ConnectionConfig.terminator`,
  for instruments/firmware that expect e.g. `\r\n`. Commands containing
  an embedded terminator are rejected before being sent, since they
  would desync the response stream.
- **VISA error translation:** resource-not-found / resource-busy /
  resource-locked VISA errors are now surfaced as `ConnectionError34970`
  with an actionable message (e.g. "another session may be holding this
  resource open"), rather than a generic `TransportError`.

## Currently available keywords (Phase 1)

| Keyword                         | Purpose                                          |
|----------------------------------|---------------------------------------------------|
| `Connect To Instrument`          | Open a connection (VISA or TCP) and identify it   |
| `Disconnect From Instrument`     | Close the connection                              |
| `Reconnect To Instrument`        | Disconnect + reconnect with the same config       |
| `Get Instrument Identity`        | Return the `*IDN?` string captured at connect     |
| `Get Connection State`           | IDLE / CONNECTING / CONNECTED / ERROR / CLOSED    |
| `Instrument Should Be Connected` | Assertion keyword for connection state            |
| `Reset Instrument`               | Send `*RST` and wait the stabilization delay      |
| `Clear Instrument Status`        | Send `*CLS`                                       |
| `Set Instrument Timeout`         | Update the command/query timeout, in seconds      |
| `Send Scpi Command`              | Escape hatch: raw SCPI write + error check        |
| `Query Scpi Command`             | Escape hatch: raw SCPI query + error check        |
| `Drain Instrument Error Queue`   | Pop all pending SCPI errors for diagnostics/logs  |

Measurement, scanning, temperature, digital I/O, alarms, configuration
profiles, recovery/diagnostics, and safe-mode keywords are planned for
Phases 2–9 respectively (see CHANGELOG.md).

## Development

```bash
pip install -e ".[dev]"
pytest                       # unit + integration (117 tests, no hardware needed)
pytest --cov=keysight34970   # coverage; gate fails below 90%
```

Hardware tests are deselected by default. To run them against a real
instrument:

```bash
KEYSIGHT_HOST=10.0.0.12 pytest -m hardware
```

See the [Developer Guide](docs/developer_guide.md) for test tiers, test
doubles, and how to add keywords, phases, or transports.

## Project layout

```
src/keysight34970/
  config.py           Connection configuration + validation
  exceptions.py        Exception hierarchy
  logging_config.py    Per-instrument structured logging
  models.py             Wire-format data models (Identity, ScpiError)
  connection.py         SCPI session + state machine
  transport/            Transport abstraction (TCP socket, VISA)
  keywords/              Robot Framework keyword mixins
  library.py             Public Robot Framework library class
tests/unit/             pytest unit tests (fakes, loopback sockets)
tests/integration/      end-to-end tests vs mock instrument + opt-in hardware
tests/mock_instrument.py  mock SCPI-over-TCP server used by tests
examples/robot/         Runnable .robot example suites
docs/                     User guide, API reference, architecture, dev guide
history/                  Per-gate delivery notes
review/                   Per-gate review records
ai/                       RFDS-017 AI Driver Contract (Phase 10)
```
