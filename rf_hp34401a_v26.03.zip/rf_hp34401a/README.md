# RF HP34401A

Production-oriented Robot Framework library for the HP/Agilent/Keysight 34401A 6½-digit digital multimeter.

**Release:** 26.03  
**Python distribution:** `rf-hp34401a` 26.3.0  
**Core driver:** `hp34401a_dmm` 1.2.8  
**Python:** 3.10–3.13  
**Robot Framework:** 7.x  
**AI contract:** RFDS-017 v3.0

## Design

The Robot library is a thin adapter over the reviewed production SCPI driver. It does not duplicate instrument commands. It adds explicit Robot keywords, named sessions, Robot-friendly conversion, strict scalar validation, detailed measurement metadata, assertions, deterministic simulation, cleanup, unified driver metadata, runtime capability discovery, and a machine-readable AI contract.

The library never converts overload, missing, unstable, or invalid data into a plausible scalar. Calibration commands are blocked unless permission is explicitly enabled when the session is opened.

## Installation with uv

From the extracted project root containing `pyproject.toml`:

```powershell
uv pip install -e ".[hardware]"
```

For simulation and documentation only:

```powershell
uv pip install -e ".[dev]"
```

A vendor VISA runtime such as Keysight IO Libraries Suite or NI-VISA must be installed separately for real VISA/GPIB/USBTMC access.

## Unified quick start

`Connect DMM` is the preferred vendor-independent connection keyword. `AUTO` selects serial for `COM*` or `/dev/tty*` resources and VISA otherwise.

```robotframework
*** Settings ***
Library           rf_hp34401a.Hp34401ALibrary
Suite Teardown    Close All DMMs

*** Variables ***
${DMM_RESOURCE}    GPIB0::22::INSTR

*** Test Cases ***
Measure A 12 V Rail
    Connect DMM    ${DMM_RESOURCE}    transport=AUTO    alias=dmm
    ${metadata}=    Get Driver Metadata    alias=dmm
    Log    ${metadata}
    ${voltage}=    Measure DC Voltage    range_value=100    nplc=10    alias=dmm
    DMM Reading Should Be Between    11.5    12.5    alias=dmm
```

The stable transport-specific keywords remain supported:

- `Open DMM Via VISA`
- `Open DMM Via Serial`
- `Open Simulated DMM`

Run a hardware-independent example:

```powershell
robot --outputdir results examples/02_dc_voltage_limits.robot
```

## Unified project API

Release 26.03 adds the project-standard API while retaining all 26.01 keyword names:

- `Connect DMM`
- `Disconnect DMM`
- `Get Driver Metadata`
- `Get Driver Capabilities`

A Python compatibility method named `connect_to_dmm()` is intentionally available for existing orchestration libraries such as `MatrixVerificationLibrary.py`. It delegates to the public connection implementation and is not exposed as an extra Robot keyword.

## AI planning contract

The canonical single-driver contract is:

```text
ai/ai_contract.yaml
ai/ai_contract.lock
```

It describes all 69 public Robot keywords with exact signatures, states, resources, error recovery, safety constraints, timing, verification oracles, setup/teardown, measurement ownership, and planning metadata.

Validate the contract and its SHA-256 public-interface lock:

```powershell
python scripts/validate_ai_contract.py
```

RFDS-018 is bench-specific. The driver therefore includes a safe template rather than fabricated wiring data:

```text
examples/bench/system_ai_contract.template.yaml
```

Copy it to the test-bench repository as `system_ai_contract.yaml` and replace every `UNKNOWN` with verified topology, resource, safety, and qualification information. See `guide/ai_contract_and_bench_setup.md`.

## RFDS-019 call and protocol conformance

Release 26.03 includes a complete 69-keyword inventory, one primary callability vector per exported keyword, exact SCPI/transport oracles for all device-facing calls, raw-response capture, and four protocol-error/recovery vectors. Run:

```powershell
python scripts/validate_call_protocol_conformance.py
.\scripts\run_call_protocol_conformance.ps1
```

The full runner creates timestamped Robot reports and machine-readable evidence under `results/call_protocol_conformance/hp34401a/`. The unattended profile uses the approved deterministic `FakeTransport` at the production SCPI boundary. Real VISA/GPIB and RS-232 confirmation remains an opt-in HIL activity governed by a completed RFDS-018 bench contract.

## Main keyword areas

- unified, VISA, serial, simulation, aliases, and cleanup;
- metadata, capabilities, identity, self-test, health, error queue, terminal checks, and recovery;
- DC/AC voltage and current;
- 2-wire and 4-wire resistance;
- frequency, period, continuity, and diode;
- immediate and BUS-triggered acquisition;
- stable-resistance acquisition;
- scalar and metadata access;
- production assertions;
- guarded raw SCPI access.

Generate complete keyword documentation with:

```powershell
python -m robot.libdoc rf_hp34401a.Hp34401ALibrary generated/libdoc/Hp34401ALibrary.html
```

## Tests

```powershell
python scripts/validate_ai_contract.py
python scripts/validate_call_protocol_conformance.py
python scripts/run_call_protocol_conformance.py
pytest
robot --outputdir results tests/robot
robot --exclude hardware --outputdir results/examples examples
mkdocs build --strict
```

The HIL suites are opt-in and require explicit connection variables. See `guide/hardware_test_setup.md`.

## Project layout

The installable packages are directly in the repository root. No `src/` layout is used.

- `rf_hp34401a/` — Robot adapter;
- `hp34401a_dmm/` — reviewed core driver;
- `ai/` — canonical RFDS-017 contract and interface lock;
- `examples/` — 12 Robot examples plus RFDS-018 bench template;
- `scripts/` — environment, validation, test, example, documentation, and release scripts;
- `history/` — release history;
- `review/` — readiness, code review, risks, and traceability;
- `guide/` — PyCharm, Robot Framework, VISA, serial, HIL, and AI-contract setup;
- `docs/` — GitHub Pages sources.

## Safety notes

- Select the correct front/rear terminal before energizing the test setup.
- Never exceed the 34401A input ratings or current-terminal fuse rating.
- Resistance, continuity, and diode tests require a verified de-energized DUT.
- Self-test and reset can disturb an active production setup; use them deliberately.
- Simulation is never selected automatically after a hardware failure.
- Raw SCPI can alter state and should be limited to reviewed test cases.
- A driver contract cannot replace a verified RFDS-018 bench contract, independent interlocks, or laboratory procedures.

## License

MIT. The incorporated `hp34401a_dmm` core retains its original MIT license and attribution.

## Qualification status

The v26.02 software baseline previously passed 103 Python tests, 33 Robot acceptance tests, 11 offline example cases, RFDS-017 validation, Libdoc, strict MkDocs, packaging, and clean-install checks. For v26.03, 106 Python tests pass with 2 explicit HIL tests skipped; RFDS-019 static validation covers all 69 keywords, and all 73 simulator protocol vectors pass transport-boundary pre-validation. The official Robot RFDS-019 runner is included and is a mandatory release-site gate. Physical VISA/GPIB and RS-232 HIL qualification, long-duration stability, and site-specific RFDS-018 bench approval remain pending and are not claimed.
