"""Robot-layer exceptions."""


class Hp34401ARobotError(RuntimeError):
    """Failure raised by the Robot Framework adapter with session context."""
