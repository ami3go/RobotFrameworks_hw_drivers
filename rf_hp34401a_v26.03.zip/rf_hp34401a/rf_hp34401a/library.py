"""Explicit Robot Framework keyword library for the HP 34401A."""

from __future__ import annotations

import math
import platform
from dataclasses import asdict, is_dataclass
from datetime import datetime
from importlib.metadata import version as package_version
from typing import Any, Callable, Literal, cast

from robot.api import logger
from robot.api.deco import keyword, library

from hp34401a_dmm import (
    __version__ as CORE_VERSION,
    DriverConfig,
    FakeTransport,
    Hp34401A,
    MeasurementNotStableError,
    MeasurementReading,
    OverloadError,
    SerialRs232Config,
    StabilityProfile,
    VisaGpibConfig,
)

from .converters import (
    as_ac_filter,
    as_aperture,
    as_autozero,
    as_bool,
    as_float,
    as_int,
    as_nplc,
    as_optional_float,
    as_range,
    as_seconds,
    as_terminal,
    as_trigger_source,
)
from .exceptions import Hp34401ARobotError
from .sessions import DmmSession, SessionManager
from .version import __version__

ROBOT_FRAMEWORK_VERSION = package_version("robotframework")


@library(scope="SUITE", auto_keywords=False, version=__version__)
class Hp34401ALibrary:
    """Production-safe Robot Framework adapter for the HP/Agilent/Keysight 34401A.

    The library delegates all SCPI operations to ``hp34401a_dmm.Hp34401A``.
    Measurement keywords reject overload, invalid, missing, or unstable readings
    rather than returning a fabricated scalar.
    """

    ROBOT_LIBRARY_SCOPE = "SUITE"
    ROBOT_AUTO_KEYWORDS = False
    ROBOT_LIBRARY_VERSION = __version__

    def __init__(self) -> None:
        self._sessions = SessionManager()
        self.ROBOT_LIBRARY_LISTENER = self

    # ------------------------------- internal helpers
    def _execute(self, operation: str, call: Callable[[], Any], alias: object | None = None) -> Any:
        try:
            return call()
        except Hp34401ARobotError:
            raise
        except Exception as exc:
            active = (
                str(alias).strip()
                if alias is not None and str(alias).strip()
                else self._sessions.active_alias
            )
            suffix = f" [alias={active}]" if active else ""
            raise Hp34401ARobotError(f"{operation} failed{suffix}: {exc}") from exc

    def _session(self, alias: object | None = None) -> DmmSession:
        return self._execute("Get DMM session", lambda: self._sessions.get(alias), alias)

    @staticmethod
    def _driver_config(
        *,
        timeout: object = 10.0,
        reset_on_connect: object = False,
        verify_identity: object = True,
        drain_error_queue: object = True,
        clear_status: object = True,
        retry_queries: object = True,
        max_query_retries: object = 1,
        allow_calibration_commands: object = False,
        raw_traffic_log: object = False,
    ) -> DriverConfig:
        return DriverConfig(
            reset_on_connect=as_bool(reset_on_connect, name="reset_on_connect"),
            clear_status_on_connect=as_bool(clear_status, name="clear_status"),
            verify_identity_on_connect=as_bool(verify_identity, name="verify_identity"),
            drain_error_queue_on_connect=as_bool(drain_error_queue, name="drain_error_queue"),
            default_timeout_s=as_seconds(timeout, name="timeout"),
            retry_queries=as_bool(retry_queries, name="retry_queries"),
            max_query_retries=as_int(max_query_retries, name="max_query_retries"),
            allow_calibration_commands=as_bool(
                allow_calibration_commands, name="allow_calibration_commands"
            ),
            raw_traffic_log=as_bool(raw_traffic_log, name="raw_traffic_log"),
        )

    def _register_connected(
        self, alias: object, driver: Hp34401A, *, replace: object = False
    ) -> str:
        try:
            driver.connect()
            self._sessions.add(alias, driver, replace=as_bool(replace, name="replace"))
        except Exception:
            try:
                driver.close()
            except Exception:
                pass
            raise
        identity = driver.identity_cached
        if identity:
            logger.info(
                f"Opened HP34401A session {alias!r}: {identity.manufacturer} "
                f"{identity.model}, serial={identity.serial or 'unknown'}"
            )
        return str(alias)

    @staticmethod
    def _reading_to_dict(reading: MeasurementReading, session: DmmSession) -> dict[str, Any]:
        result = {
            "timestamp_utc": reading.timestamp_utc.isoformat(),
            "function": reading.function.value,
            "value": reading.value,
            "unit": reading.unit,
            "raw": reading.raw,
            "range_value": reading.range_value,
            "nplc": reading.nplc,
            "aperture_s": reading.aperture_s,
            "is_overload": reading.is_overload,
            "is_valid": reading.is_valid,
            "was_retried": reading.was_retried,
            "retry_count": reading.retry_count,
            "reconnect_count": reading.reconnect_count,
            "recovery_actions": list(reading.recovery_actions),
            "terminal": reading.terminal.value if reading.terminal else None,
            "transport": reading.transport.value if reading.transport else None,
            "alias": session.alias,
            "library_version": __version__,
            "driver_version": CORE_VERSION,
        }
        return result

    @staticmethod
    def _model_to_dict(value: Any) -> Any:
        if is_dataclass(value) and not isinstance(value, type):
            raw = asdict(value)
            return Hp34401ALibrary._model_to_dict(raw)
        if isinstance(value, dict):
            return {str(k): Hp34401ALibrary._model_to_dict(v) for k, v in value.items()}
        if isinstance(value, (list, tuple)):
            return [Hp34401ALibrary._model_to_dict(v) for v in value]
        if hasattr(value, "value") and not isinstance(value, (str, int, float, bool)):
            return value.value
        if isinstance(value, datetime):
            return value.isoformat()
        return value

    def _accept_reading(self, session: DmmSession, reading: MeasurementReading) -> float:
        session.last_reading = reading
        if reading.is_overload:
            raise OverloadError(
                f"DMM overload in {reading.function.value}; raw response={reading.raw!r}"
            )
        if not reading.is_valid or reading.value is None:
            raise Hp34401ARobotError(
                f"DMM returned an invalid {reading.function.value} reading; raw={reading.raw!r}"
            )
        logger.info(f"{session.alias}: {reading.value:.12g} {reading.unit}")
        return float(reading.value)

    def _measure(
        self,
        operation: str,
        producer: Callable[[Hp34401A], MeasurementReading],
        alias: object | None,
    ) -> float:
        session = self._session(alias)
        return self._execute(
            operation,
            lambda: self._accept_reading(session, producer(session.driver)),
            session.alias,
        )

    # ------------------------------- connection/session
    @keyword("Connect DMM")
    def connect_dmm(
        self,
        resource: str,
        transport: str = "AUTO",
        alias: str = "default",
        timeout: object = "10 s",
        visa_library: str | None = None,
        baud_rate: object = 9600,
        parity: str = "none",
        data_bits: object = 8,
        stop_bits: object = 2,
        dtr_dsr: object = True,
        remote_on_connect: object = True,
        local_on_close: object = False,
        reset_on_connect: object = False,
        verify_identity: object = True,
        drain_error_queue: object = True,
        retry_queries: object = True,
        max_query_retries: object = 1,
        allow_calibration_commands: object = False,
        replace: object = False,
        raw_traffic_log: object = False,
    ) -> str:
        """Open a DMM session using AUTO, VISA, or SERIAL transport selection.

        ``AUTO`` selects SERIAL for COM and ``/dev/tty*`` resources and VISA
        otherwise. The keyword exists as the transport-neutral project API; the
        explicit VISA and serial keywords remain stable for existing suites.
        """
        resource_text = str(resource).strip()
        if not resource_text:
            raise Hp34401ARobotError("Connect DMM requires a non-empty resource")
        selected = str(transport).strip().upper() or "AUTO"
        if selected == "AUTO":
            upper = resource_text.upper()
            selected = (
                "SERIAL"
                if upper.startswith("COM") or resource_text.startswith("/dev/tty")
                else "VISA"
            )
        if selected in {"VISA", "GPIB", "USB", "LAN"}:
            return self.open_dmm_via_visa(
                resource_text,
                alias=alias,
                timeout=timeout,
                visa_library=visa_library,
                reset_on_connect=reset_on_connect,
                verify_identity=verify_identity,
                drain_error_queue=drain_error_queue,
                retry_queries=retry_queries,
                max_query_retries=max_query_retries,
                allow_calibration_commands=allow_calibration_commands,
                replace=replace,
                raw_traffic_log=raw_traffic_log,
            )
        if selected in {"SERIAL", "RS232", "RS-232"}:
            return self.open_dmm_via_serial(
                resource_text,
                alias=alias,
                baud_rate=baud_rate,
                parity=parity,
                data_bits=data_bits,
                stop_bits=stop_bits,
                timeout=timeout,
                dtr_dsr=dtr_dsr,
                remote_on_connect=remote_on_connect,
                local_on_close=local_on_close,
                verify_identity=verify_identity,
                retry_queries=retry_queries,
                max_query_retries=max_query_retries,
                allow_calibration_commands=allow_calibration_commands,
                replace=replace,
                raw_traffic_log=raw_traffic_log,
            )
        raise Hp34401ARobotError(
            f"Unsupported DMM transport {transport!r}; use AUTO, VISA, or SERIAL"
        )

    # Python compatibility for orchestration libraries written before v26.03.
    # These methods are intentionally not Robot keywords.
    def connect_to_dmm(self, resource: str, *args: Any, **kwargs: Any) -> str:
        if args and "timeout" not in kwargs:
            kwargs["timeout"] = args[0]
        return self.connect_dmm(resource, **kwargs)

    @keyword("Open DMM Via VISA")
    def open_dmm_via_visa(
        self,
        resource: str,
        alias: str = "default",
        timeout: object = "10 s",
        visa_library: str | None = None,
        reset_on_connect: object = False,
        verify_identity: object = True,
        drain_error_queue: object = True,
        retry_queries: object = True,
        max_query_retries: object = 1,
        allow_calibration_commands: object = False,
        replace: object = False,
        raw_traffic_log: object = False,
    ) -> str:
        """Open a VISA/GPIB session and make ``alias`` active."""

        def action() -> str:
            dc = self._driver_config(
                timeout=timeout,
                reset_on_connect=reset_on_connect,
                verify_identity=verify_identity,
                drain_error_queue=drain_error_queue,
                retry_queries=retry_queries,
                max_query_retries=max_query_retries,
                allow_calibration_commands=allow_calibration_commands,
                raw_traffic_log=raw_traffic_log,
            )
            cfg = VisaGpibConfig(
                resource=str(resource).strip(),
                timeout_s=as_seconds(timeout, name="timeout"),
                visa_library=(str(visa_library).strip() if visa_library else None),
            )
            return self._register_connected(
                alias, Hp34401A.from_visa_gpib(cfg, dc), replace=replace
            )

        return self._execute("Open DMM via VISA", action, alias)

    @keyword("Open DMM Via Serial")
    def open_dmm_via_serial(
        self,
        port: str,
        alias: str = "default",
        baud_rate: object = 9600,
        parity: str = "none",
        data_bits: object = 8,
        stop_bits: object = 2,
        timeout: object = "10 s",
        dtr_dsr: object = True,
        remote_on_connect: object = True,
        local_on_close: object = False,
        verify_identity: object = True,
        retry_queries: object = True,
        max_query_retries: object = 1,
        allow_calibration_commands: object = False,
        replace: object = False,
        raw_traffic_log: object = False,
    ) -> str:
        """Open an RS-232 session using the instrument's supported serial settings."""

        def action() -> str:
            dc = self._driver_config(
                timeout=timeout,
                verify_identity=verify_identity,
                retry_queries=retry_queries,
                max_query_retries=max_query_retries,
                allow_calibration_commands=allow_calibration_commands,
                raw_traffic_log=raw_traffic_log,
            )
            cfg = SerialRs232Config(
                port=str(port).strip(),
                baudrate=as_int(baud_rate, name="baud_rate"),
                parity=cast(Literal["none", "even", "odd"], str(parity).strip().lower()),
                data_bits=as_int(data_bits, name="data_bits"),
                stop_bits=as_int(stop_bits, name="stop_bits"),
                timeout_s=as_seconds(timeout, name="timeout"),
                use_dtr_dsr=as_bool(dtr_dsr, name="dtr_dsr"),
                require_remote_on_connect=as_bool(remote_on_connect, name="remote_on_connect"),
                send_local_on_close=as_bool(local_on_close, name="local_on_close"),
            )
            return self._register_connected(alias, Hp34401A.from_serial(cfg, dc), replace=replace)

        return self._execute("Open DMM via serial", action, alias)

    @keyword("Open Simulated DMM")
    def open_simulated_dmm(
        self,
        alias: str = "default",
        reading: object = 12.0,
        identity: str = "HEWLETT-PACKARD,34401A,SIM0001,11-05-01",
        terminal: str = "FRONT",
        replace: object = False,
    ) -> str:
        """Open deterministic simulation. This keyword never runs automatically as fallback."""

        def action() -> str:
            value = as_float(reading, name="reading")
            responses = {
                "READ?": repr(value),
                "FETCh?": repr(value),
                "ROUTe:TERMinals?": str(terminal).strip().upper(),
                "*TST?": "0",
                "SYSTem:VERSion?": "1991.0",
            }
            transport = FakeTransport(responses=responses, idn=str(identity))
            driver = Hp34401A(transport, DriverConfig())
            return self._register_connected(alias, driver, replace=replace)

        return self._execute("Open simulated DMM", action, alias)

    @keyword("List VISA Resources")
    def list_visa_resources(self, visa_library: str | None = None) -> list[str]:
        def action() -> list[str]:
            try:
                import pyvisa
            except ImportError as exc:
                raise RuntimeError("PyVISA is not installed; install rf-hp34401a[visa]") from exc
            manager = pyvisa.ResourceManager(visa_library or "")
            try:
                return list(manager.list_resources())
            finally:
                manager.close()

        return self._execute("List VISA resources", action)

    @keyword("Select DMM")
    def select_dmm(self, alias: str) -> str:
        return self._execute("Select DMM", lambda: self._sessions.select(alias).alias, alias)

    @keyword("Get Active DMM Alias")
    def get_active_dmm_alias(self) -> str | None:
        return self._sessions.active_alias

    @keyword("Get Open DMM Aliases")
    def get_open_dmm_aliases(self) -> list[str]:
        return self._sessions.aliases()

    @keyword("DMM Should Be Connected")
    def dmm_should_be_connected(self, alias: object | None = None) -> None:
        session = self._session(alias)
        if not session.driver.is_connected():
            raise Hp34401ARobotError(f"DMM is not connected [alias={session.alias}]")

    @keyword("Close DMM")
    def close_dmm(self, alias: object | None = None) -> None:
        self._execute("Close DMM", lambda: self._sessions.close(alias), alias)

    @keyword("Disconnect DMM")
    def disconnect_dmm(self, alias: object | None = None) -> None:
        """Transport-neutral alias for ``Close DMM``."""
        self.close_dmm(alias)

    def disconnect(self, alias: object | None = None) -> None:
        """Python compatibility alias; not exposed as a Robot keyword."""
        self.close_dmm(alias)

    def close_connection(self, alias: object | None = None) -> None:
        """Python compatibility alias; not exposed as a Robot keyword."""
        self.close_dmm(alias)

    @keyword("Close All DMMs")
    def close_all_dmms(self) -> None:
        errors = self._sessions.close_all()
        if errors:
            raise Hp34401ARobotError(
                "One or more DMM sessions failed to close: " + "; ".join(errors)
            )

    # Robot Framework listener callback; auto-keywords are disabled, so it is not exposed.
    def close(self) -> None:
        self._sessions.close_all()

    # ------------------------------- identity/health
    @keyword("Identify DMM")
    def identify_dmm(self, alias: object | None = None) -> dict[str, Any]:
        session = self._session(alias)
        return self._execute(
            "Identify DMM", lambda: self._model_to_dict(session.driver.identify()), session.alias
        )

    @keyword("DMM Model Should Be 34401A")
    def dmm_model_should_be_34401a(self, alias: object | None = None) -> None:
        identity = self.identify_dmm(alias)
        if "34401A" not in str(identity["model"]).upper():
            raise AssertionError(f"Expected model 34401A but received {identity['model']!r}")

    @keyword("Run DMM Self Test")
    def run_dmm_self_test(self, alias: object | None = None) -> dict[str, Any]:
        session = self._session(alias)
        return self._execute(
            "Run DMM self-test",
            lambda: self._model_to_dict(session.driver.self_test()),
            session.alias,
        )

    @keyword("DMM Self Test Should Pass")
    def dmm_self_test_should_pass(self, alias: object | None = None) -> None:
        result = self.run_dmm_self_test(alias)
        if not result["passed"]:
            raise AssertionError(
                f"DMM self-test failed: code={result['code']}, raw={result['raw']!r}"
            )

    @keyword("Get DMM Health")
    def get_dmm_health(self, alias: object | None = None) -> dict[str, Any]:
        session = self._session(alias)
        return self._execute(
            "Get DMM health", lambda: self._model_to_dict(session.driver.heartbeat()), session.alias
        )

    @keyword("Recover DMM")
    def recover_dmm(self, alias: object | None = None) -> dict[str, Any]:
        session = self._session(alias)
        return self._execute(
            "Recover DMM", lambda: self._model_to_dict(session.driver.recover()), session.alias
        )

    @keyword("Clear DMM Status")
    def clear_dmm_status(self, alias: object | None = None) -> None:
        session = self._session(alias)
        self._execute("Clear DMM status", session.driver.clear_status, session.alias)

    @keyword("Read DMM Error")
    def read_dmm_error(self, alias: object | None = None) -> dict[str, Any]:
        session = self._session(alias)
        return self._execute(
            "Read DMM error",
            lambda: self._model_to_dict(session.driver.read_error()),
            session.alias,
        )

    @keyword("Get DMM Error Queue")
    def get_dmm_error_queue(
        self, max_errors: object = 25, alias: object | None = None
    ) -> list[dict[str, Any]]:
        session = self._session(alias)
        return self._execute(
            "Get DMM error queue",
            lambda: self._model_to_dict(
                session.driver.drain_error_queue(as_int(max_errors, name="max_errors"))
            ),
            session.alias,
        )

    @keyword("DMM Error Queue Should Be Empty")
    def dmm_error_queue_should_be_empty(self, alias: object | None = None) -> None:
        errors = [item for item in self.get_dmm_error_queue(alias=alias) if item["code"] != 0]
        if errors:
            raise AssertionError(f"DMM error queue is not empty: {errors}")

    @keyword("Get DMM Input Terminal")
    def get_dmm_input_terminal(self, alias: object | None = None) -> str:
        session = self._session(alias)
        return self._execute(
            "Get DMM input terminal", lambda: session.driver.query_terminal().value, session.alias
        )

    @keyword("Require DMM Input Terminal")
    def require_dmm_input_terminal(self, expected: object, alias: object | None = None) -> None:
        session = self._session(alias)
        terminal = as_terminal(expected)
        self._execute(
            "Require DMM input terminal",
            lambda: session.driver.require_terminal(terminal),
            session.alias,
        )

    @keyword("Get DMM State")
    def get_dmm_state(self, alias: object | None = None) -> str:
        return self._session(alias).driver.state.value

    @keyword("Get DMM Driver Version")
    def get_dmm_driver_version(self) -> str:
        return CORE_VERSION

    @keyword("Get Robot DMM Library Version")
    def get_robot_dmm_library_version(self) -> str:
        return __version__

    @keyword("Get Driver Capabilities")
    def get_driver_capabilities(self) -> dict[str, Any]:
        """Return the stable project capability model for planning tools."""
        return {
            "instrument_class": "DMM",
            "supported_models": ["34401A"],
            "transports": ["VISA_GPIB", "SERIAL_RS232", "FAKE"],
            "capabilities": [
                "SCPI",
                "MEASUREMENT",
                "TRIGGER",
                "STABLE_RESISTANCE",
                "ERROR_QUEUE",
                "SELF_TEST",
                "MULTI_SESSION",
                "SIMULATION",
                "RAW_SCPI_GUARDED",
            ],
            "measurement_functions": [
                "VOLT_DC",
                "VOLT_AC",
                "CURR_DC",
                "CURR_AC",
                "RES_2W",
                "RES_4W",
                "FREQ",
                "PERIOD",
                "CONTINUITY",
                "DIODE",
            ],
            "ai_contract": "ai/ai_contract.yaml",
            "rfds017_version": "3.0",
        }

    @keyword("Get Driver Metadata")
    def get_driver_metadata(self, alias: object | None = None) -> dict[str, Any]:
        """Return driver, runtime, transport, and connected-instrument metadata."""
        metadata: dict[str, Any] = {
            "driver_name": "rf_hp34401a.Hp34401ALibrary",
            "driver_version": __version__,
            "core_driver_version": CORE_VERSION,
            "driver_status": "RELEASE_CANDIDATE",
            "supported_models": ["34401A"],
            "supported_transports": ["VISA_GPIB", "SERIAL_RS232", "FAKE"],
            "manufacturer": ["HP", "HEWLETT-PACKARD", "AGILENT", "KEYSIGHT"],
            "python_version": platform.python_version(),
            "robot_framework_version": ROBOT_FRAMEWORK_VERSION,
            "library_build_date": "2026-07-24",
            "git_commit": "UNKNOWN",
            "alias": None,
            "instrument_id": "UNKNOWN",
            "model": "UNKNOWN",
            "serial_number": "UNKNOWN",
            "firmware_version": "UNKNOWN",
            "transport": "UNKNOWN",
            "state": "DISCONNECTED",
        }
        if alias is not None or self._sessions.active_alias is not None:
            session = self._session(alias)
            identity = self.identify_dmm(session.alias)
            metadata.update(
                {
                    "alias": session.alias,
                    "instrument_id": identity.get("raw", "UNKNOWN"),
                    "model": identity.get("model", "UNKNOWN"),
                    "serial_number": identity.get("serial", "UNKNOWN") or "UNKNOWN",
                    "firmware_version": identity.get("firmware", "UNKNOWN") or "UNKNOWN",
                    "transport": session.driver._t.transport_type.value,
                    "state": self.get_dmm_state(session.alias),
                }
            )
        return metadata

    # ------------------------------- configuration
    @keyword("Configure DC Voltage")
    def configure_dc_voltage(
        self,
        range_value: object = "DEF",
        nplc: object = 10,
        autozero: object = "ON",
        alias: object | None = None,
    ) -> None:
        s = self._session(alias)
        self._execute(
            "Configure DC voltage",
            lambda: s.driver.configure_dc_voltage(
                as_range(range_value), as_nplc(nplc), as_autozero(autozero)
            ),
            s.alias,
        )

    @keyword("Configure AC Voltage")
    def configure_ac_voltage(
        self, range_value: object = "DEF", ac_filter_hz: object = 20, alias: object | None = None
    ) -> None:
        s = self._session(alias)
        self._execute(
            "Configure AC voltage",
            lambda: s.driver.configure_ac_voltage(
                as_range(range_value), as_ac_filter(ac_filter_hz)
            ),
            s.alias,
        )

    @keyword("Configure DC Current")
    def configure_dc_current(
        self,
        range_value: object = "DEF",
        nplc: object = 10,
        autozero: object = "ON",
        alias: object | None = None,
    ) -> None:
        s = self._session(alias)
        self._execute(
            "Configure DC current",
            lambda: s.driver.configure_dc_current(
                as_range(range_value), as_nplc(nplc), as_autozero(autozero)
            ),
            s.alias,
        )

    @keyword("Configure AC Current")
    def configure_ac_current(
        self, range_value: object = "DEF", ac_filter_hz: object = 20, alias: object | None = None
    ) -> None:
        s = self._session(alias)
        self._execute(
            "Configure AC current",
            lambda: s.driver.configure_ac_current(
                as_range(range_value), as_ac_filter(ac_filter_hz)
            ),
            s.alias,
        )

    @keyword("Configure 2 Wire Resistance")
    def configure_2wire_resistance(
        self,
        range_value: object = "DEF",
        nplc: object = 10,
        autozero: object = "ON",
        alias: object | None = None,
    ) -> None:
        s = self._session(alias)
        self._execute(
            "Configure 2-wire resistance",
            lambda: s.driver.configure_2wire_resistance(
                as_range(range_value), as_nplc(nplc), as_autozero(autozero)
            ),
            s.alias,
        )

    @keyword("Configure 4 Wire Resistance")
    def configure_4wire_resistance(
        self,
        range_value: object = "DEF",
        nplc: object = 10,
        autozero: object = "ON",
        alias: object | None = None,
    ) -> None:
        s = self._session(alias)
        self._execute(
            "Configure 4-wire resistance",
            lambda: s.driver.configure_4wire_resistance(
                as_range(range_value), as_nplc(nplc), as_autozero(autozero)
            ),
            s.alias,
        )

    @keyword("Configure Frequency")
    def configure_frequency(
        self, voltage_range: object = "DEF", aperture: object = 0.1, alias: object | None = None
    ) -> None:
        s = self._session(alias)
        self._execute(
            "Configure frequency",
            lambda: s.driver.configure_frequency(as_range(voltage_range), as_aperture(aperture)),
            s.alias,
        )

    @keyword("Configure Period")
    def configure_period(
        self, voltage_range: object = "DEF", aperture: object = 0.1, alias: object | None = None
    ) -> None:
        s = self._session(alias)
        self._execute(
            "Configure period",
            lambda: s.driver.configure_period(as_range(voltage_range), as_aperture(aperture)),
            s.alias,
        )

    @keyword("Configure Continuity")
    def configure_continuity(self, alias: object | None = None) -> None:
        s = self._session(alias)
        self._execute("Configure continuity", s.driver.configure_continuity, s.alias)

    @keyword("Configure Diode")
    def configure_diode(self, alias: object | None = None) -> None:
        s = self._session(alias)
        self._execute("Configure diode", s.driver.configure_diode, s.alias)

    # ------------------------------- measurement
    @keyword("Read DMM")
    def read_dmm(self, alias: object | None = None) -> float:
        return self._measure("Read DMM", lambda d: d.read_once(), alias)

    @keyword("Measure DC Voltage")
    def measure_dc_voltage(
        self, range_value: object = "DEF", nplc: object = 10, alias: object | None = None
    ) -> float:
        return self._measure(
            "Measure DC voltage",
            lambda d: d.measure_dc_voltage(as_range(range_value), as_nplc(nplc)),
            alias,
        )

    @keyword("Measure AC Voltage")
    def measure_ac_voltage(
        self, range_value: object = "DEF", ac_filter_hz: object = 20, alias: object | None = None
    ) -> float:
        return self._measure(
            "Measure AC voltage",
            lambda d: d.measure_ac_voltage(as_range(range_value), as_ac_filter(ac_filter_hz)),
            alias,
        )

    @keyword("Measure DC Current")
    def measure_dc_current(
        self, range_value: object = "DEF", nplc: object = 10, alias: object | None = None
    ) -> float:
        return self._measure(
            "Measure DC current",
            lambda d: d.measure_dc_current(as_range(range_value), as_nplc(nplc)),
            alias,
        )

    @keyword("Measure AC Current")
    def measure_ac_current(
        self, range_value: object = "DEF", ac_filter_hz: object = 20, alias: object | None = None
    ) -> float:
        def producer(d: Hp34401A) -> MeasurementReading:
            d.configure_ac_current(as_range(range_value), as_ac_filter(ac_filter_hz))
            return d.read_once()

        return self._measure("Measure AC current", producer, alias)

    @keyword("Measure 2 Wire Resistance")
    def measure_2wire_resistance(
        self, range_value: object = "DEF", nplc: object = 10, alias: object | None = None
    ) -> float:
        return self._measure(
            "Measure 2-wire resistance",
            lambda d: d.measure_2wire_resistance(as_range(range_value), as_nplc(nplc)),
            alias,
        )

    @keyword("Measure 4 Wire Resistance")
    def measure_4wire_resistance(
        self, range_value: object = "DEF", nplc: object = 10, alias: object | None = None
    ) -> float:
        return self._measure(
            "Measure 4-wire resistance",
            lambda d: d.measure_4wire_resistance(as_range(range_value), as_nplc(nplc)),
            alias,
        )

    @keyword("Measure Frequency")
    def measure_frequency(
        self, voltage_range: object = "DEF", aperture: object = 0.1, alias: object | None = None
    ) -> float:
        def producer(d: Hp34401A) -> MeasurementReading:
            d.configure_frequency(as_range(voltage_range), as_aperture(aperture))
            return d.read_once()

        return self._measure("Measure frequency", producer, alias)

    @keyword("Measure Period")
    def measure_period(
        self, voltage_range: object = "DEF", aperture: object = 0.1, alias: object | None = None
    ) -> float:
        def producer(d: Hp34401A) -> MeasurementReading:
            d.configure_period(as_range(voltage_range), as_aperture(aperture))
            return d.read_once()

        return self._measure("Measure period", producer, alias)

    @keyword("Measure Continuity")
    def measure_continuity(self, alias: object | None = None) -> float:
        def producer(d: Hp34401A) -> MeasurementReading:
            d.configure_continuity()
            return d.read_once()

        return self._measure("Measure continuity", producer, alias)

    @keyword("Measure Diode")
    def measure_diode(self, alias: object | None = None) -> float:
        def producer(d: Hp34401A) -> MeasurementReading:
            d.configure_diode()
            return d.read_once()

        return self._measure("Measure diode", producer, alias)

    def _stable_profile(
        self,
        expected_ohm: object | None,
        range_value: object,
        nplc: object,
        final_nplc: object | None,
        min_settle: object,
        max_wait: object,
        sample_interval: object,
        window_size: object,
        max_stdev_ohm: object | None,
        max_relative_stdev: object | None,
        max_slope_relative_per_s: object | None,
        four_wire: object,
    ) -> StabilityProfile:
        final = (
            None
            if final_nplc is None or str(final_nplc).strip().lower() in {"", "none", "${none}"}
            else as_nplc(final_nplc)
        )
        return StabilityProfile(
            expected_ohm=as_optional_float(expected_ohm, name="expected_ohm"),
            range_ohm=as_range(range_value),
            nplc=as_nplc(nplc),
            final_nplc=final,
            min_settle_s=as_seconds(min_settle, name="min_settle"),
            max_wait_s=as_seconds(max_wait, name="max_wait"),
            sample_interval_s=as_seconds(sample_interval, name="sample_interval"),
            window_size=as_int(window_size, name="window_size"),
            max_stdev_ohm=as_optional_float(max_stdev_ohm, name="max_stdev_ohm"),
            max_relative_stdev=as_optional_float(max_relative_stdev, name="max_relative_stdev"),
            max_slope_relative_per_s=as_optional_float(
                max_slope_relative_per_s, name="max_slope_relative_per_s"
            ),
            four_wire=as_bool(four_wire, name="four_wire"),
        )

    @keyword("Try Read Stable Resistance")
    def try_read_stable_resistance(
        self,
        expected_ohm: object | None = None,
        range_value: object = "AUTO",
        nplc: object = 10,
        final_nplc: object | None = 100,
        min_settle: object = "500 ms",
        max_wait: object = "20 s",
        sample_interval: object = "200 ms",
        window_size: object = 5,
        max_stdev_ohm: object | None = None,
        max_relative_stdev: object | None = 0.0005,
        max_slope_relative_per_s: object | None = 0.0005,
        four_wire: object = False,
        alias: object | None = None,
    ) -> dict[str, Any]:
        session = self._session(alias)
        profile = self._stable_profile(
            expected_ohm,
            range_value,
            nplc,
            final_nplc,
            min_settle,
            max_wait,
            sample_interval,
            window_size,
            max_stdev_ohm,
            max_relative_stdev,
            max_slope_relative_per_s,
            four_wire,
        )
        result = self._execute(
            "Try read stable resistance",
            lambda: session.driver.read_stable_resistance(profile),
            session.alias,
        )
        if result.reading is not None:
            session.last_reading = result.reading
        data = self._model_to_dict(result)
        data["alias"] = session.alias
        data["library_version"] = __version__
        data["driver_version"] = CORE_VERSION
        return data

    @keyword("Read Stable Resistance")
    def read_stable_resistance(
        self,
        expected_ohm: object | None = None,
        range_value: object = "AUTO",
        nplc: object = 10,
        final_nplc: object | None = 100,
        min_settle: object = "500 ms",
        max_wait: object = "20 s",
        sample_interval: object = "200 ms",
        window_size: object = 5,
        max_stdev_ohm: object | None = None,
        max_relative_stdev: object | None = 0.0005,
        max_slope_relative_per_s: object | None = 0.0005,
        four_wire: object = False,
        alias: object | None = None,
    ) -> float:
        """Return a stable resistance or fail without fabricating a reading."""
        result = self.try_read_stable_resistance(
            expected_ohm=expected_ohm,
            range_value=range_value,
            nplc=nplc,
            final_nplc=final_nplc,
            min_settle=min_settle,
            max_wait=max_wait,
            sample_interval=sample_interval,
            window_size=window_size,
            max_stdev_ohm=max_stdev_ohm,
            max_relative_stdev=max_relative_stdev,
            max_slope_relative_per_s=max_slope_relative_per_s,
            four_wire=four_wire,
            alias=alias,
        )
        if not result["stable"] or result["value"] is None:
            raise MeasurementNotStableError(result["reason"])
        return float(result["value"])

    @keyword("Get Last DMM Reading")
    def get_last_dmm_reading(self, alias: object | None = None) -> dict[str, Any]:
        session = self._session(alias)
        if session.last_reading is None:
            raise Hp34401ARobotError(f"No DMM reading is available [alias={session.alias}]")
        return self._reading_to_dict(session.last_reading, session)

    @keyword("Get Last DMM Reading Value")
    def get_last_dmm_reading_value(self, alias: object | None = None) -> float:
        data = self.get_last_dmm_reading(alias)
        if not data["is_valid"] or data["is_overload"] or data["value"] is None:
            raise Hp34401ARobotError("Last DMM reading is not a valid scalar")
        return float(data["value"])

    # ------------------------------- triggers
    @keyword("Set DMM Trigger Source")
    def set_dmm_trigger_source(self, source: object, alias: object | None = None) -> None:
        s = self._session(alias)
        self._execute(
            "Set DMM trigger source",
            lambda: s.driver.set_trigger_source(as_trigger_source(source)),
            s.alias,
        )

    @keyword("Initiate DMM Measurement")
    def initiate_dmm_measurement(self, alias: object | None = None) -> None:
        s = self._session(alias)
        self._execute("Initiate DMM measurement", s.driver.initiate, s.alias)

    @keyword("Send DMM Bus Trigger")
    def send_dmm_bus_trigger(self, alias: object | None = None) -> None:
        s = self._session(alias)
        self._execute("Send DMM bus trigger", s.driver.trigger_bus, s.alias)

    @keyword("Fetch DMM Readings")
    def fetch_dmm_readings(self, alias: object | None = None) -> list[dict[str, Any]]:
        s = self._session(alias)
        readings = self._execute("Fetch DMM readings", s.driver.fetch, s.alias)
        if readings:
            s.last_reading = readings[-1]
        return [self._reading_to_dict(r, s) for r in readings]

    @keyword("Read DMM Once With Bus Trigger")
    def read_dmm_once_with_bus_trigger(self, alias: object | None = None) -> float:
        return self._measure("Read DMM once with bus trigger", lambda d: d.read_once_bus(), alias)

    # ------------------------------- assertions
    @keyword("DMM Reading Should Be Valid")
    def dmm_reading_should_be_valid(self, alias: object | None = None) -> None:
        data = self.get_last_dmm_reading(alias)
        if not data["is_valid"] or data["value"] is None:
            raise AssertionError(f"Invalid DMM reading: {data}")

    @keyword("DMM Reading Should Not Be Overload")
    def dmm_reading_should_not_be_overload(self, alias: object | None = None) -> None:
        data = self.get_last_dmm_reading(alias)
        if data["is_overload"]:
            raise AssertionError(f"DMM reading is overload: {data}")

    def _value_for_assertion(self, alias: object | None) -> tuple[float, dict[str, Any]]:
        data = self.get_last_dmm_reading(alias)
        if not data["is_valid"] or data["is_overload"] or data["value"] is None:
            raise AssertionError(f"Cannot assert limits for invalid reading: {data}")
        return float(data["value"]), data

    @keyword("DMM Reading Should Be Between")
    def dmm_reading_should_be_between(
        self, minimum: object, maximum: object, alias: object | None = None
    ) -> None:
        value, data = self._value_for_assertion(alias)
        low, high = as_float(minimum, name="minimum"), as_float(maximum, name="maximum")
        if low > high:
            raise ValueError("minimum must be <= maximum")
        if not low <= value <= high:
            raise AssertionError(
                f"{data['alias']} {data['function']} reading {value} {data['unit']} is outside [{low}, {high}]"
            )

    @keyword("DMM Reading Should Be Close To")
    def dmm_reading_should_be_close_to(
        self,
        expected: object,
        absolute_tolerance: object = 0.0,
        relative_tolerance: object = 0.0,
        alias: object | None = None,
    ) -> None:
        value, data = self._value_for_assertion(alias)
        exp = as_float(expected, name="expected")
        abs_tol = as_float(absolute_tolerance, name="absolute_tolerance")
        rel_tol = as_float(relative_tolerance, name="relative_tolerance")
        if abs_tol < 0 or rel_tol < 0:
            raise ValueError("tolerances must be >= 0")
        if not math.isclose(value, exp, rel_tol=rel_tol, abs_tol=abs_tol):
            raise AssertionError(
                f"{data['alias']} {data['function']} reading {value} {data['unit']} is not close to {exp}; abs_tol={abs_tol}, rel_tol={rel_tol}"
            )

    @keyword("DMM Reading Should Be Greater Than")
    def dmm_reading_should_be_greater_than(
        self, minimum: object, alias: object | None = None
    ) -> None:
        value, data = self._value_for_assertion(alias)
        limit = as_float(minimum, name="minimum")
        if not value > limit:
            raise AssertionError(
                f"{data['alias']} reading {value} {data['unit']} is not greater than {limit}"
            )

    @keyword("DMM Reading Should Be Less Than")
    def dmm_reading_should_be_less_than(self, maximum: object, alias: object | None = None) -> None:
        value, data = self._value_for_assertion(alias)
        limit = as_float(maximum, name="maximum")
        if not value < limit:
            raise AssertionError(
                f"{data['alias']} reading {value} {data['unit']} is not less than {limit}"
            )

    @keyword("Stable Resistance Should Be Between")
    def stable_resistance_should_be_between(
        self, result: dict[str, Any], minimum: object, maximum: object
    ) -> None:
        if not result.get("stable") or result.get("value") is None:
            raise AssertionError(f"Resistance was not stable: {result.get('reason')}")
        value = float(result["value"])
        low, high = as_float(minimum, name="minimum"), as_float(maximum, name="maximum")
        if not low <= value <= high:
            raise AssertionError(f"Stable resistance {value} Ohm is outside [{low}, {high}]")

    @keyword("DMM Should Have No Errors")
    def dmm_should_have_no_errors(self, context: str = "", alias: object | None = None) -> None:
        s = self._session(alias)
        self._execute(
            "Assert DMM has no errors", lambda: s.driver.assert_no_error(str(context)), s.alias
        )

    # ------------------------------- controlled raw SCPI
    @keyword("Write DMM Command")
    def write_dmm_command(self, command: str, alias: object | None = None) -> None:
        s = self._session(alias)
        logger.debug(f"{s.alias}: raw SCPI write {command!r}")
        self._execute("Write DMM command", lambda: s.driver.write(str(command)), s.alias)

    @keyword("Query DMM Command")
    def query_dmm_command(self, command: str, alias: object | None = None) -> str:
        s = self._session(alias)
        logger.debug(f"{s.alias}: raw SCPI query {command!r}")
        return self._execute("Query DMM command", lambda: s.driver.query(str(command)), s.alias)
