"""Named DMM session registry."""

from __future__ import annotations

from dataclasses import dataclass

from hp34401a_dmm import Hp34401A, MeasurementReading


@dataclass(slots=True)
class DmmSession:
    alias: str
    driver: Hp34401A
    last_reading: MeasurementReading | None = None


class SessionManager:
    def __init__(self) -> None:
        self._sessions: dict[str, DmmSession] = {}
        self._active_alias: str | None = None

    @staticmethod
    def normalize_alias(alias: object) -> str:
        text = str(alias).strip()
        if not text:
            raise ValueError("DMM alias must not be empty")
        return text

    def add(self, alias: object, driver: Hp34401A, *, replace: bool = False) -> DmmSession:
        key = self.normalize_alias(alias)
        if key in self._sessions and not replace:
            raise ValueError(f"DMM alias {key!r} is already open")
        if key in self._sessions:
            self._sessions[key].driver.close()
        session = DmmSession(key, driver)
        self._sessions[key] = session
        self._active_alias = key
        return session

    def select(self, alias: object) -> DmmSession:
        key = self.normalize_alias(alias)
        try:
            session = self._sessions[key]
        except KeyError as exc:
            raise ValueError(f"DMM alias {key!r} is not open") from exc
        self._active_alias = key
        return session

    def get(self, alias: object | None = None) -> DmmSession:
        if alias is not None and str(alias).strip():
            return self.select(alias)
        if self._active_alias is None:
            raise ValueError("No DMM session is open")
        return self._sessions[self._active_alias]

    @property
    def active_alias(self) -> str | None:
        return self._active_alias

    def aliases(self) -> list[str]:
        return list(self._sessions)

    def close(self, alias: object | None = None) -> None:
        session = self.get(alias)
        key = session.alias
        try:
            session.driver.close()
        finally:
            self._sessions.pop(key, None)
            if self._active_alias == key:
                self._active_alias = next(iter(self._sessions), None)

    def close_all(self) -> list[str]:
        errors: list[str] = []
        for key, session in list(self._sessions.items()):
            try:
                session.driver.close()
            except Exception as exc:  # cleanup must continue
                errors.append(f"{key}: {exc}")
            finally:
                self._sessions.pop(key, None)
        self._active_alias = None
        return errors
