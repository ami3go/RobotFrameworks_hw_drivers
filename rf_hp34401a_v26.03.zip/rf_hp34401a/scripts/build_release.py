#!/usr/bin/env python3
"""Validate and build rf_hp34401a_v26.03.zip with a fixed internal root."""

from __future__ import annotations

import argparse
import hashlib
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import zipfile

RELEASE = "26.03"
ZIP_NAME = f"rf_hp34401a_v{RELEASE}.zip"
ROOT_NAME = "rf_hp34401a"
EXCLUDED_PARTS = {
    ".git",
    ".venv",
    "__pycache__",
    ".pytest_cache",
    "build",
    "dist",
    "results",
    "htmlcov",
    ".mypy_cache",
    ".ruff_cache",
    "site",
}
EXCLUDED_SUFFIXES = {".pyc", ".pyo", ".ttf", ".otf", ".woff", ".woff2"}


def run(command: list[str], cwd: Path) -> None:
    print("+", " ".join(command), flush=True)
    subprocess.run(command, cwd=cwd, check=True)


def include(path: Path, root: Path) -> bool:
    rel = path.relative_to(root)
    if any(part in EXCLUDED_PARTS or part.endswith(".egg-info") for part in rel.parts):
        return False
    if path.suffix.lower() in EXCLUDED_SUFFIXES:
        return False
    if path.name in {".coverage"}:
        return False
    return True


def validate_layout(root: Path) -> None:
    required = [
        "rf_hp34401a",
        "hp34401a_dmm",
        "ai",
        "history",
        "review",
        "examples",
        "scripts",
        "guide",
        "docs",
        "README.md",
        "pyproject.toml",
        "tests/conformance/driver_call_protocol_conformance.robot",
        "tests/conformance/data/keyword_inventory.yaml",
        "tests/conformance/data/protocol_vectors.yaml",
        "tests/conformance/data/exclusions.yaml",
    ]
    missing = [item for item in required if not (root / item).exists()]
    if missing:
        raise SystemExit(f"Missing required release content: {missing}")
    for required_ai in ("ai_contract.yaml", "ai_contract.lock"):
        if not (root / "ai" / required_ai).is_file():
            raise SystemExit(f"Missing required RFDS-017 file: ai/{required_ai}")
    if not (root / "examples" / "bench" / "system_ai_contract.template.yaml").is_file():
        raise SystemExit("Missing RFDS-018 bench contract template")
    if any(path.name == "src" and path.is_dir() for path in root.rglob("src")):
        raise SystemExit("A src/ directory is not permitted")
    examples = list((root / "examples").glob("*.robot"))
    if len(examples) < 10:
        raise SystemExit(f"At least 10 Robot examples are required; found {len(examples)}")


def validate_zip(output: Path) -> None:
    with zipfile.ZipFile(output) as archive:
        names = archive.namelist()
        roots = {name.split("/", 1)[0] for name in names if name}
        if roots != {ROOT_NAME}:
            raise SystemExit(f"Invalid ZIP roots: {sorted(roots)}")
        if any("/src/" in f"/{name}" for name in names):
            raise SystemExit("ZIP contains prohibited src/ directory")
        prohibited = {".ttf", ".otf", ".woff", ".woff2"}
        font_files = [name for name in names if Path(name).suffix.lower() in prohibited]
        if font_files:
            raise SystemExit(f"ZIP contains prohibited font files: {font_files[:5]}")
        required = {
            f"{ROOT_NAME}/ai/ai_contract.yaml",
            f"{ROOT_NAME}/ai/ai_contract.lock",
            f"{ROOT_NAME}/examples/bench/system_ai_contract.template.yaml",
            f"{ROOT_NAME}/tests/conformance/driver_call_protocol_conformance.robot",
            f"{ROOT_NAME}/tests/conformance/data/keyword_inventory.yaml",
            f"{ROOT_NAME}/tests/conformance/data/protocol_vectors.yaml",
            f"{ROOT_NAME}/tests/conformance/data/exclusions.yaml",
            f"{ROOT_NAME}/review/v26.03_rfds019_conformance_review.md",
        }
        missing = sorted(required - set(names))
        if missing:
            raise SystemExit(f"ZIP is missing contract files: {missing}")


def build_zip(root: Path, output: Path) -> Path:
    with tempfile.TemporaryDirectory(prefix="rf_hp34401a_release_") as temp:
        staged = Path(temp) / ROOT_NAME
        shutil.copytree(
            root,
            staged,
            ignore=lambda directory, names: {
                name for name in names if not include(Path(directory) / name, root)
            },
        )
        with zipfile.ZipFile(
            output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9
        ) as archive:
            for path in sorted(staged.rglob("*")):
                if path.is_file():
                    archive.write(path, path.relative_to(staged.parent).as_posix())
    validate_zip(output)
    return output


def clean_install_smoke(root: Path) -> None:
    wheels = sorted((root / "dist").glob("rf_hp34401a-26.3.0-*.whl"))
    if not wheels:
        raise SystemExit("No v26.03 wheel was produced")
    wheel = wheels[-1]
    with tempfile.TemporaryDirectory(prefix="rf_hp34401a_clean_install_") as temp:
        venv_dir = Path(temp) / "venv"
        run([sys.executable, "-m", "venv", str(venv_dir)], root)
        python_exe = venv_dir / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
        run(
            [
                str(python_exe),
                "-m",
                "pip",
                "install",
                "--force-reinstall",
                str(wheel),
            ],
            root,
        )
        smoke = (
            "from pathlib import Path; import sys; "
            "from rf_hp34401a import Hp34401ALibrary; "
            "lib=Hp34401ALibrary(); lib.open_simulated_dmm(alias='smoke'); "
            "assert lib.measure_dc_voltage(alias='smoke') == 12.0; "
            "assert lib.get_driver_metadata(alias='smoke')['driver_version'] == '26.03'; "
            "lib.close_all_dmms(); "
            "base=Path(sys.prefix)/'share'/'rf_hp34401a'; "
            "assert (base/'ai'/'ai_contract.yaml').is_file(); "
            "assert (base/'ai'/'ai_contract.lock').is_file(); "
            "assert (base/'bench'/'system_ai_contract.template.yaml').is_file()"
        )
        run([str(python_exe), "-c", smoke], root)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--skip-tests", action="store_true")
    parser.add_argument("--output-dir", type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    output_dir = (args.output_dir or root.parent).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    validate_layout(root)

    env = os.environ.copy()
    env["PYTHONPATH"] = str(root) + os.pathsep + env.get("PYTHONPATH", "")
    run([sys.executable, "scripts/validate_ai_contract.py"], root)
    run([sys.executable, "scripts/validate_call_protocol_conformance.py"], root)
    if not args.skip_tests:
        run([sys.executable, "-m", "ruff", "check", "rf_hp34401a", "tests/unit", "scripts"], root)
        run([sys.executable, "-m", "mypy", "rf_hp34401a", "scripts/validate_ai_contract.py"], root)
        run(
            [
                sys.executable,
                "-m",
                "pytest",
                "--cov=rf_hp34401a",
                "--cov-fail-under=95",
                "--cov-report=term",
            ],
            root,
        )
        conformance_root = root / "results" / "call_protocol_conformance" / "hp34401a"
        run(
            [
                sys.executable,
                "scripts/run_call_protocol_conformance.py",
                "--output-root",
                str(conformance_root),
            ],
            root,
        )
        latest_conformance = max(
            (path for path in conformance_root.iterdir() if path.is_dir()),
            key=lambda path: path.name,
        )
        reviewed_evidence = root / "review" / "evidence" / "v26.03" / "rfds019"
        shutil.rmtree(reviewed_evidence, ignore_errors=True)
        shutil.copytree(latest_conformance, reviewed_evidence)
        run(
            [
                sys.executable,
                "-m",
                "robot",
                "--outputdir",
                str(root / "results" / "release"),
                "tests/robot",
            ],
            root,
        )
        run(
            [
                sys.executable,
                "-m",
                "robot",
                "--exclude",
                "hardware",
                "--outputdir",
                str(root / "results" / "examples"),
                "examples",
            ],
            root,
        )
    generated = root / "generated" / "libdoc"
    generated.mkdir(parents=True, exist_ok=True)
    run(
        [
            sys.executable,
            "-m",
            "robot.libdoc",
            "rf_hp34401a.Hp34401ALibrary",
            str(generated / "Hp34401ALibrary.html"),
        ],
        root,
    )
    run(
        [
            sys.executable,
            "-m",
            "robot.libdoc",
            "rf_hp34401a.Hp34401ALibrary",
            str(generated / "Hp34401ALibrary.xml"),
        ],
        root,
    )
    run([sys.executable, "-m", "mkdocs", "build", "--strict"], root)
    run([sys.executable, "-m", "build"], root)
    clean_install_smoke(root)

    output = output_dir / ZIP_NAME
    output.unlink(missing_ok=True)
    build_zip(root, output)
    digest = hashlib.sha256(output.read_bytes()).hexdigest()
    checksum = output.with_suffix(output.suffix + ".sha256")
    checksum.write_text(f"{digest}  {output.name}\n", encoding="utf-8")
    print(f"Built {output}")
    print(f"SHA-256 {digest}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
