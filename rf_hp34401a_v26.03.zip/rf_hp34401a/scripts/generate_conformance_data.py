#!/usr/bin/env python3
"""Generate the reviewed RFDS-019 keyword inventory and protocol vectors."""

from __future__ import annotations

import ast
from pathlib import Path
from typing import Any

import yaml

ROOT = Path(__file__).resolve().parents[1]
LIBRARY = ROOT / "rf_hp34401a" / "library.py"
DATA = ROOT / "tests" / "conformance" / "data"


def source_surface() -> list[dict[str, Any]]:
    module = ast.parse(LIBRARY.read_text(encoding="utf-8"))
    output: list[dict[str, Any]] = []
    for node in module.body:
        if not isinstance(node, ast.ClassDef) or node.name != "Hp34401ALibrary":
            continue
        for method in node.body:
            if not isinstance(method, ast.FunctionDef):
                continue
            robot_name = None
            for decorator in method.decorator_list:
                if (
                    isinstance(decorator, ast.Call)
                    and isinstance(decorator.func, ast.Name)
                    and decorator.func.id == "keyword"
                    and decorator.args
                ):
                    robot_name = ast.literal_eval(decorator.args[0])
            if robot_name is None:
                continue
            arguments = [arg.arg for arg in method.args.args[1:]]
            defaults = [None] * (len(arguments) - len(method.args.defaults)) + [
                ast.unparse(value) for value in method.args.defaults
            ]
            output.append(
                {
                    "keyword": robot_name,
                    "driver_method": method.name,
                    "arguments": [
                        {"name": name, "required": default is None, "default": default}
                        for name, default in zip(arguments, defaults)
                    ],
                }
            )
    return sorted(output, key=lambda item: item["keyword"])


RETURN_TYPES = {
    "Connect DMM": "string",
    "Open DMM Via VISA": "string",
    "Open DMM Via Serial": "string",
    "Open Simulated DMM": "string",
    "List VISA Resources": "list",
    "Select DMM": "string",
    "Get Active DMM Alias": "string",
    "Get Open DMM Aliases": "list",
    "Identify DMM": "dictionary",
    "Run DMM Self Test": "dictionary",
    "Get DMM Health": "dictionary",
    "Recover DMM": "dictionary",
    "Read DMM Error": "dictionary",
    "Get DMM Error Queue": "list",
    "Get DMM Input Terminal": "string",
    "Get DMM State": "string",
    "Get DMM Driver Version": "string",
    "Get Robot DMM Library Version": "string",
    "Get Driver Capabilities": "dictionary",
    "Get Driver Metadata": "dictionary",
    "Read DMM": "float",
    "Measure DC Voltage": "float",
    "Measure AC Voltage": "float",
    "Measure DC Current": "float",
    "Measure AC Current": "float",
    "Measure 2 Wire Resistance": "float",
    "Measure 4 Wire Resistance": "float",
    "Measure Frequency": "float",
    "Measure Period": "float",
    "Measure Continuity": "float",
    "Measure Diode": "float",
    "Try Read Stable Resistance": "dictionary",
    "Read Stable Resistance": "float",
    "Get Last DMM Reading": "dictionary",
    "Get Last DMM Reading Value": "float",
    "Fetch DMM Readings": "list",
    "Read DMM Once With Bus Trigger": "float",
    "Query DMM Command": "string",
}

NON_DEVICE = {
    "List VISA Resources",
    "Select DMM",
    "Get Active DMM Alias",
    "Get Open DMM Aliases",
    "DMM Should Be Connected",
    "Get DMM State",
    "Get DMM Driver Version",
    "Get Robot DMM Library Version",
    "Get Driver Capabilities",
    "Get Driver Metadata",
    "Get Last DMM Reading",
    "Get Last DMM Reading Value",
    "DMM Reading Should Be Valid",
    "DMM Reading Should Not Be Overload",
    "DMM Reading Should Be Between",
    "DMM Reading Should Be Close To",
    "DMM Reading Should Be Greater Than",
    "DMM Reading Should Be Less Than",
    "Stable Resistance Should Be Between",
}

ALIAS_OF = {
    "Disconnect DMM": "Close DMM",
}

OPEN = [{"keyword": "Open Simulated DMM", "arguments": ["alias=dut", "reading=12.0"]}]
MEASURED = OPEN + [{"keyword": "Measure DC Voltage", "arguments": [10, 10, "alias=dut"]}]
CONFIGURED = OPEN + [{"keyword": "Configure DC Voltage", "arguments": [10, 10, "ON", "alias=dut"]}]
BUS_WAITING = CONFIGURED + [
    {"keyword": "Set DMM Trigger Source", "arguments": ["BUS", "alias=dut"]},
    {"keyword": "Initiate DMM Measurement", "arguments": ["alias=dut"]},
]
BUS_TRIGGERED = BUS_WAITING + [
    {"keyword": "Send DMM Bus Trigger", "arguments": ["alias=dut"]},
]


def vector_for(item: dict[str, Any], index: int) -> dict[str, Any]:
    name = item["keyword"]
    vector: dict[str, Any] = {
        "id": f"HP34401A-KW-{index:03d}",
        "keyword": name,
        "canonical_keyword": ALIAS_OF.get(name, name),
        "driver_method": item["driver_method"],
        "device_facing": name not in NON_DEVICE,
        "risk_class": "R1" if name not in NON_DEVICE else "R0",
        "arguments": [],
        "expected_outbound": {"none": True} if name in NON_DEVICE else {},
        "expected_inbound": {"no_response": True},
        "expected_return": {"type": RETURN_TYPES.get(name, "null")},
    }
    if name in {
        "Connect DMM",
        "Open DMM Via VISA",
        "Open DMM Via Serial",
        "Open Simulated DMM",
        "List VISA Resources",
        "Get Active DMM Alias",
        "Get Open DMM Aliases",
        "Close All DMMs",
        "Get DMM Driver Version",
        "Get Robot DMM Library Version",
        "Get Driver Capabilities",
        "Get Driver Metadata",
    }:
        pass
    elif name == "Select DMM":
        vector["setup_calls"] = OPEN + [
            {"keyword": "Open Simulated DMM", "arguments": ["alias=second", "reading=13.0"]}
        ]
        vector["arguments"] = ["dut"]
        vector["expected_return"]["exact"] = "dut"
    elif name == "DMM Should Be Connected":
        vector["setup_calls"] = OPEN
        vector["arguments"] = ["dut"]
    elif name in {"Close DMM", "Disconnect DMM"}:
        vector["factory"] = "serial"
        vector["setup_calls"] = [
            {
                "keyword": "Open DMM Via Serial",
                "arguments": ["COM1", "alias=dut", "local_on_close=True"],
            }
        ]
        vector["arguments"] = ["dut"]
        vector["expected_outbound"] = {"contains": ["SYSTem:LOCal"]}
        vector["expected_inbound"] = {"no_response": True}
    elif name in {
        "Identify DMM",
        "DMM Model Should Be 34401A",
        "Run DMM Self Test",
        "DMM Self Test Should Pass",
        "Get DMM Health",
        "Recover DMM",
        "Clear DMM Status",
        "Read DMM Error",
        "Get DMM Error Queue",
        "DMM Error Queue Should Be Empty",
        "Get DMM Input Terminal",
        "Require DMM Input Terminal",
        "Get DMM State",
        "Get Driver Metadata",
        "Configure DC Voltage",
        "Configure AC Voltage",
        "Configure DC Current",
        "Configure AC Current",
        "Configure 2 Wire Resistance",
        "Configure 4 Wire Resistance",
        "Configure Frequency",
        "Configure Period",
        "Configure Continuity",
        "Configure Diode",
        "Read DMM",
        "Measure DC Voltage",
        "Measure AC Voltage",
        "Measure DC Current",
        "Measure AC Current",
        "Measure 2 Wire Resistance",
        "Measure 4 Wire Resistance",
        "Measure Frequency",
        "Measure Period",
        "Measure Continuity",
        "Measure Diode",
        "Try Read Stable Resistance",
        "Read Stable Resistance",
        "Get Last DMM Reading",
        "Get Last DMM Reading Value",
        "Set DMM Trigger Source",
        "Initiate DMM Measurement",
        "Send DMM Bus Trigger",
        "Fetch DMM Readings",
        "Read DMM Once With Bus Trigger",
        "DMM Reading Should Be Valid",
        "DMM Reading Should Not Be Overload",
        "DMM Reading Should Be Between",
        "DMM Reading Should Be Close To",
        "DMM Reading Should Be Greater Than",
        "DMM Reading Should Be Less Than",
        "DMM Should Have No Errors",
        "Write DMM Command",
        "Query DMM Command",
    }:
        vector["setup_calls"] = OPEN

    if name == "Connect DMM":
        vector["factory"] = "visa"
        vector["arguments"] = ["GPIB0::22::INSTR", "VISA", "dut"]
        vector["expected_outbound"] = {
            "contains_in_order": ["*IDN?", "SYSTem:VERSion?", "SYSTem:ERRor?", "*CLS"]
        }
        vector["expected_inbound"] = {"response_required": True, "raw_contains": ["1991.0"]}
        vector["expected_return"]["exact"] = "dut"
    elif name == "Open DMM Via VISA":
        vector["factory"] = "visa"
        vector["arguments"] = ["GPIB0::22::INSTR", "alias=dut"]
        vector["expected_outbound"] = {
            "contains_in_order": ["*IDN?", "SYSTem:VERSion?", "SYSTem:ERRor?", "*CLS"]
        }
        vector["expected_inbound"] = {"response_required": True, "raw_contains": ["1991.0"]}
        vector["expected_return"]["exact"] = "dut"
    elif name == "Open DMM Via Serial":
        vector["factory"] = "serial"
        vector["arguments"] = ["COM1", "alias=dut", "local_on_close=True"]
        vector["expected_outbound"] = {
            "contains_in_order": [
                "SYSTem:REMote",
                "*IDN?",
                "*IDN?",
                "SYSTem:VERSion?",
                "*CLS",
            ]
        }
        vector["expected_inbound"] = {"response_required": True, "raw_contains": ["1991.0"]}
        vector["expected_return"]["exact"] = "dut"
    elif name == "Open Simulated DMM":
        vector["arguments"] = ["alias=dut", "reading=12.0"]
        vector["expected_outbound"] = {
            "contains_in_order": ["*IDN?", "SYSTem:VERSion?", "SYSTem:ERRor?", "*CLS"]
        }
        vector["expected_inbound"] = {"response_required": True, "raw_contains": ["1991.0"]}
        vector["expected_return"]["exact"] = "dut"
    elif name == "List VISA Resources":
        vector["pyvisa_stub"] = True
        vector["expected_return"]["minimum_length"] = 2
    elif name == "Get Active DMM Alias":
        vector["setup_calls"] = OPEN
        vector["expected_return"]["exact"] = "dut"
    elif name == "Get Open DMM Aliases":
        vector["setup_calls"] = OPEN
        vector["expected_return"]["minimum_length"] = 1
    elif name == "Close All DMMs":
        vector["factory"] = "serial"
        vector["setup_calls"] = [
            {
                "keyword": "Open DMM Via Serial",
                "arguments": ["COM1", "alias=dut", "local_on_close=True"],
            }
        ]
        vector["expected_outbound"] = {"contains": ["SYSTem:LOCal"]}
    elif name == "Identify DMM":
        vector["arguments"] = ["dut"]
        vector["expected_outbound"] = {"contains": ["*IDN?"]}
        vector["expected_inbound"] = {"response_required": True}
        vector["expected_return"]["required_keys"] = ["manufacturer", "model", "serial", "firmware", "raw"]
    elif name == "DMM Model Should Be 34401A":
        vector["arguments"] = ["dut"]
        vector["expected_outbound"] = {"contains": ["*IDN?"]}
        vector["expected_inbound"] = {"response_required": True}
    elif name in {"Run DMM Self Test", "DMM Self Test Should Pass"}:
        vector["arguments"] = ["dut"]
        vector["expected_outbound"] = {"contains": ["*TST?"]}
        vector["expected_inbound"] = {"response_required": True, "raw_contains": ["0"]}
        if name == "Run DMM Self Test":
            vector["expected_return"]["required_keys"] = ["passed", "code", "raw", "message"]
    elif name == "Get DMM Health":
        vector["arguments"] = ["dut"]
        vector["expected_outbound"] = {"contains": ["SYSTem:ERRor?"]}
        vector["expected_inbound"] = {"response_required": True}
        vector["expected_return"]["required_keys"] = ["connected", "error_queue_clean", "state"]
    elif name == "Recover DMM":
        vector["arguments"] = ["dut"]
        vector["expected_outbound"] = {"contains": ["SYSTem:ERRor?"], "clear_count_min": 1}
        vector["expected_inbound"] = {"response_required": True}
        vector["expected_return"]["required_keys"] = ["succeeded", "actions", "state"]
    elif name == "Clear DMM Status":
        vector["arguments"] = ["dut"]
        vector["expected_outbound"] = {"contains": ["*CLS"]}
    elif name == "Read DMM Error":
        vector["arguments"] = ["dut"]
        vector["expected_outbound"] = {"contains": ["SYSTem:ERRor?"]}
        vector["expected_inbound"] = {"response_required": True}
        vector["expected_return"]["required_keys"] = ["code", "message", "raw"]
    elif name == "Get DMM Error Queue":
        vector["arguments"] = [5, "dut"]
        vector["expected_outbound"] = {"contains": ["SYSTem:ERRor?"]}
        vector["expected_inbound"] = {"response_required": True}
        vector["expected_return"]["minimum_length"] = 1
    elif name in {"DMM Error Queue Should Be Empty", "DMM Should Have No Errors"}:
        vector["arguments"] = ["dut"] if name.startswith("DMM Error") else ["conformance", "dut"]
        vector["expected_outbound"] = {"contains": ["SYSTem:ERRor?"]}
        vector["expected_inbound"] = {"response_required": True}
    elif name in {"Get DMM Input Terminal", "Require DMM Input Terminal"}:
        vector["arguments"] = ["dut"] if name.startswith("Get") else ["FRONT", "dut"]
        vector["expected_outbound"] = {"contains": ["ROUTe:TERMinals?"]}
        vector["expected_inbound"] = {"response_required": True, "raw_contains": ["FRONT"]}
        if name.startswith("Get"):
            vector["expected_return"]["exact"] = "FRONT"
    elif name == "Get DMM State":
        vector["arguments"] = ["dut"]
    elif name == "Get DMM Driver Version":
        vector["expected_return"]["exact"] = "1.2.8"
    elif name == "Get Robot DMM Library Version":
        vector["expected_return"]["exact"] = "26.03"
    elif name == "Get Driver Capabilities":
        vector["expected_return"]["required_keys"] = ["driver", "instrument_class", "transports", "measurement_functions"]
    elif name == "Get Driver Metadata":
        vector["arguments"] = ["dut"]
        vector["expected_return"]["required_keys"] = ["driver_version", "core_driver_version", "state"]
    else:
        configure = {
            "Configure DC Voltage": ([10, 10, "ON", "dut"], ["CONFigure:VOLTage:DC 10,DEF", "SENSe:VOLTage:DC:NPLCycles 10"]),
            "Configure AC Voltage": ([10, 20, "dut"], ["CONFigure:VOLTage:AC 10,DEF", "SENSe:DETector:BANDwidth 20"]),
            "Configure DC Current": ([1, 10, "ON", "dut"], ["CONFigure:CURRent:DC 1,DEF", "SENSe:CURRent:DC:NPLCycles 10"]),
            "Configure AC Current": ([1, 20, "dut"], ["CONFigure:CURRent:AC 1,DEF", "SENSe:DETector:BANDwidth 20"]),
            "Configure 2 Wire Resistance": ([1000, 10, "ON", "dut"], ["CONFigure:RESistance 1000,DEF", "SENSe:RESistance:NPLCycles 10"]),
            "Configure 4 Wire Resistance": ([1000, 10, "ON", "dut"], ["CONFigure:FRESistance 1000,DEF", "SENSe:FRESistance:NPLCycles 10"]),
            "Configure Frequency": ([10, 0.1, "dut"], ["CONFigure:FREQuency 10,DEF", "SENSe:FREQuency:APERture 0.1"]),
            "Configure Period": ([10, 0.1, "dut"], ["CONFigure:PERiod 10,DEF", "SENSe:PERiod:APERture 0.1"]),
            "Configure Continuity": (["dut"], ["CONFigure:CONTinuity"]),
            "Configure Diode": (["dut"], ["CONFigure:DIODe"]),
        }
        measurements = {
            "Measure DC Voltage": ([10, 10, "dut"], "CONFigure:VOLTage:DC 10,DEF"),
            "Measure AC Voltage": ([10, 20, "dut"], "CONFigure:VOLTage:AC 10,DEF"),
            "Measure DC Current": ([1, 10, "dut"], "CONFigure:CURRent:DC 1,DEF"),
            "Measure AC Current": ([1, 20, "dut"], "CONFigure:CURRent:AC 1,DEF"),
            "Measure 2 Wire Resistance": ([1000, 10, "dut"], "CONFigure:RESistance 1000,DEF"),
            "Measure 4 Wire Resistance": ([1000, 10, "dut"], "CONFigure:FRESistance 1000,DEF"),
            "Measure Frequency": ([10, 0.1, "dut"], "CONFigure:FREQuency 10,DEF"),
            "Measure Period": ([10, 0.1, "dut"], "CONFigure:PERiod 10,DEF"),
            "Measure Continuity": (["dut"], "CONFigure:CONTinuity"),
            "Measure Diode": (["dut"], "CONFigure:DIODe"),
        }
        if name in configure:
            vector["arguments"], operations = configure[name]
            vector["expected_outbound"] = {"contains_in_order": operations}
        elif name == "Read DMM":
            vector["setup_calls"] = CONFIGURED
            vector["arguments"] = ["dut"]
            vector["expected_outbound"] = {"contains_in_order": ["TRIGger:SOURce IMMediate", "TRIGger:COUNt 1", "SAMPle:COUNt 1", "READ?"]}
            vector["expected_inbound"] = {"response_required": True, "raw_contains": ["12.0"]}
        elif name in measurements:
            vector["arguments"], operation = measurements[name]
            vector["expected_outbound"] = {"contains_in_order": [operation, "READ?"]}
            vector["expected_inbound"] = {"response_required": True, "raw_contains": ["12.0"]}
        elif name in {"Try Read Stable Resistance", "Read Stable Resistance"}:
            vector["arguments"] = [
                "expected_ohm=12",
                "range_value=100",
                "nplc=0.02",
                "final_nplc=None",
                "min_settle=0 s",
                "max_wait=300 ms",
                "sample_interval=1 ms",
                "window_size=3",
                "alias=dut",
            ]
            vector["expected_outbound"] = {"contains": ["CONFigure:RESistance 100,DEF", "READ?"]}
            vector["expected_inbound"] = {"response_required": True, "raw_contains": ["12.0"]}
            if name.startswith("Try"):
                vector["expected_return"]["required_keys"] = ["stable", "value", "samples", "elapsed_s"]
        elif name in {"Get Last DMM Reading", "Get Last DMM Reading Value", "DMM Reading Should Be Valid", "DMM Reading Should Not Be Overload", "DMM Reading Should Be Between", "DMM Reading Should Be Close To", "DMM Reading Should Be Greater Than", "DMM Reading Should Be Less Than"}:
            vector["setup_calls"] = MEASURED
            if name == "Get Last DMM Reading":
                vector["arguments"] = ["dut"]
                vector["expected_return"]["required_keys"] = ["function", "value", "unit", "is_valid", "alias"]
            elif name == "Get Last DMM Reading Value":
                vector["arguments"] = ["dut"]
                vector["expected_return"]["exact"] = 12.0
            elif name in {"DMM Reading Should Be Valid", "DMM Reading Should Not Be Overload"}:
                vector["arguments"] = ["dut"]
            elif name == "DMM Reading Should Be Between":
                vector["arguments"] = [11, 13, "dut"]
            elif name == "DMM Reading Should Be Close To":
                vector["arguments"] = [12, 0.1, 0, "dut"]
            elif name == "DMM Reading Should Be Greater Than":
                vector["arguments"] = [11, "dut"]
            elif name == "DMM Reading Should Be Less Than":
                vector["arguments"] = [13, "dut"]
        elif name == "Stable Resistance Should Be Between":
            vector["arguments"] = ["$STABLE_RESULT", 900, 1100]
        elif name == "Set DMM Trigger Source":
            vector["arguments"] = ["BUS", "dut"]
            vector["expected_outbound"] = {"contains": ["TRIGger:SOURce BUS"]}
        elif name == "Initiate DMM Measurement":
            vector["setup_calls"] = CONFIGURED
            vector["arguments"] = ["dut"]
            vector["expected_outbound"] = {"contains_in_order": ['DATA:FEED RDG_STORE,"CALC"', "INITiate"]}
        elif name == "Send DMM Bus Trigger":
            vector["setup_calls"] = CONFIGURED + [{"keyword": "Set DMM Trigger Source", "arguments": ["BUS", "alias=dut"]}]
            vector["arguments"] = ["dut"]
            vector["expected_outbound"] = {"contains": ["*TRG"]}
        elif name == "Fetch DMM Readings":
            vector["setup_calls"] = BUS_TRIGGERED
            vector["arguments"] = ["dut"]
            vector["expected_outbound"] = {"contains": ["FETCh?"]}
            vector["expected_inbound"] = {"response_required": True, "raw_contains": ["12.0"]}
            vector["expected_return"]["minimum_length"] = 1
        elif name == "Read DMM Once With Bus Trigger":
            vector["setup_calls"] = CONFIGURED
            vector["arguments"] = ["dut"]
            vector["expected_outbound"] = {"contains_in_order": ["TRIGger:SOURce BUS", "TRIGger:COUNt 1", "SAMPle:COUNt 1", 'DATA:FEED RDG_STORE,"CALC"', "INITiate", "*TRG", "FETCh?"], "forbidden": ["READ?"]}
            vector["expected_inbound"] = {"response_required": True, "raw_contains": ["12.0"]}
        elif name == "Write DMM Command":
            vector["arguments"] = ["*CLS", "dut"]
            vector["expected_outbound"] = {"contains": ["*CLS"]}
        elif name == "Query DMM Command":
            vector["arguments"] = ["*IDN?", "dut"]
            vector["expected_outbound"] = {"contains": ["*IDN?"]}
            vector["expected_inbound"] = {"response_required": True}
            vector["expected_return"]["contains"] = "34401A"
    return vector


def main() -> None:
    surface = source_surface()
    vectors = [vector_for(item, index) for index, item in enumerate(surface, 1)]
    inventory = {
        "rfds019_version": "1.1",
        "driver": "rf_hp34401a.Hp34401ALibrary",
        "driver_version": "26.03",
        "keywords": [
            {
                "keyword": item["keyword"],
                "canonical_keyword": ALIAS_OF.get(item["keyword"], item["keyword"]),
                "aliases": [],
                "driver_method": item["driver_method"],
                "arguments": item["arguments"],
                "return_type": RETURN_TYPES.get(item["keyword"], "null"),
                "device_facing": item["keyword"] not in NON_DEVICE,
                "protocol_vector": vector["id"],
                "execution_status": "NOT RUN",
            }
            for item, vector in zip(surface, vectors)
        ],
    }
    errors = {
        "protocol_error_vectors": [
            {
                "id": "HP34401A-ERR-001",
                "keyword": "Query DMM Command",
                "setup_calls": OPEN,
                "transport_mutation": {"alias": "dut", "timeout_on": ["*IDN?"]},
                "arguments": ["*IDN?", "dut"],
                "expected_error_pattern": "*timeout*",
                "remove_timeout_on": ["*IDN?"],
                "recovery": {
                    "keyword": "Identify DMM",
                    "arguments": ["dut"],
                    "expected_return": {"type": "dictionary", "required_keys": ["model"]},
                },
            },
            {
                "id": "HP34401A-ERR-002",
                "keyword": "Measure DC Voltage",
                "setup_calls": OPEN,
                "transport_mutation": {"alias": "dut", "responses": {"READ?": "MALFORMED"}},
                "arguments": [10, 10, "dut"],
                "expected_error_pattern": "*parse*",
                "recovery_responses": {"READ?": "12.0"},
                "recovery": {
                    "keyword": "Measure DC Voltage",
                    "arguments": [10, 10, "dut"],
                    "expected_return": {"type": "float", "exact": 12.0},
                },
            },
            {
                "id": "HP34401A-ERR-003",
                "keyword": "DMM Error Queue Should Be Empty",
                "setup_calls": OPEN,
                "transport_mutation": {"alias": "dut", "error_queue": ['-100,"Command error"']},
                "arguments": ["dut"],
                "expected_error_pattern": "*DMM error queue is not empty*",
                "recovery": {
                    "keyword": "Identify DMM",
                    "arguments": ["dut"],
                    "expected_return": {"type": "dictionary", "required_keys": ["model"]},
                },
            },
            {
                "id": "HP34401A-ERR-004",
                "keyword": "Write DMM Command",
                "setup_calls": OPEN,
                "arguments": ["CALibration:SECure:STATe OFF", "dut"],
                "expected_error_pattern": "*Calibration commands are blocked*",
                "recovery": {
                    "keyword": "Identify DMM",
                    "arguments": ["dut"],
                    "expected_return": {"type": "dictionary", "required_keys": ["model"]},
                },
            },
        ]
    }
    doc = {"rfds019_version": "1.1", "vectors": vectors, **errors}
    DATA.mkdir(parents=True, exist_ok=True)
    (DATA / "keyword_inventory.yaml").write_text(
        yaml.safe_dump(inventory, sort_keys=False, width=120), encoding="utf-8"
    )
    (DATA / "protocol_vectors.yaml").write_text(
        yaml.safe_dump(doc, sort_keys=False, width=120), encoding="utf-8"
    )
    print(f"Generated {len(surface)} keyword entries and {len(vectors)} vectors")


if __name__ == "__main__":
    main()
