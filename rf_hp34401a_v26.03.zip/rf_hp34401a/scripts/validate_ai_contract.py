#!/usr/bin/env python3
"""Validate the RFDS-017 AI contract against the live Robot keyword surface."""

from __future__ import annotations

import argparse
import hashlib
import inspect
from pathlib import Path
import sys
from typing import Any

import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from rf_hp34401a.library import Hp34401ALibrary  # noqa: E402

MANDATORY_TOP_LEVEL = {
    "rfds017_version",
    "identity",
    "mental_model",
    "state_machine",
    "resources",
    "dependencies",
    "capabilities",
    "errors",
    "safety",
    "verification_objectives",
    "setup_teardown",
    "limitations",
    "planning_hints",
    "unknown_handling",
    "conformance",
    "open_questions",
}
RISK_LEVELS = {"NONE", "LOW", "MEDIUM", "HIGH", "DESTRUCTIVE"}
BLOCKING = {"BLOCKING", "NON_BLOCKING", "ASYNC_WITH_POLL"}
IDEMPOTENCY = {"IDEMPOTENT", "NON_IDEMPOTENT", "CONDITIONALLY_IDEMPOTENT"}
RETRY = {"SAFE_TO_RETRY", "RETRY_AFTER_RESET", "NEVER_RETRY"}
ERROR_CLASSES = {
    "TRANSIENT",
    "CONFIGURATION",
    "HARDWARE_FAULT",
    "SAFETY_TRIP",
    "COMMUNICATION",
    "STATE_VIOLATION",
}
POST_ERROR_STATES = {"STATE_UNCHANGED", "STATE_UNDEFINED", "SAFE_STATE", "REQUIRES_REINIT"}
ORACLE_TYPES = {
    "TOLERANCE_ABS",
    "TOLERANCE_REL",
    "EXACT_MATCH",
    "RANGE",
    "STATE_QUERY",
    "EXTERNAL_REFERENCE",
}


def _format_default(value: Any) -> str:
    if value is None:
        return "${NONE}"
    if value is True:
        return "${TRUE}"
    if value is False:
        return "${FALSE}"
    return str(value)


def public_keyword_surface() -> list[str]:
    """Return normalized, sorted Robot keyword signatures."""
    lines: list[str] = []
    for value in Hp34401ALibrary.__dict__.values():
        robot_name = getattr(value, "robot_name", None)
        if not robot_name:
            continue
        parts: list[str] = []
        parameters = list(inspect.signature(value).parameters.values())[1:]
        for parameter in parameters:
            if parameter.kind is inspect.Parameter.VAR_POSITIONAL:
                parts.append(f"*{parameter.name}")
            elif parameter.kind is inspect.Parameter.VAR_KEYWORD:
                parts.append(f"**{parameter.name}")
            elif parameter.default is inspect.Parameter.empty:
                parts.append(parameter.name)
            else:
                parts.append(f"{parameter.name}={_format_default(parameter.default)}")
        lines.append(f"{robot_name}({', '.join(parts)})")
    return sorted(lines, key=lambda line: line.split("(", 1)[0])


def surface_hash(lines: list[str] | None = None) -> str:
    payload = "\n".join(lines or public_keyword_surface()).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _load(path: Path) -> Any:
    with path.open(encoding="utf-8") as handle:
        return yaml.safe_load(handle)


def validate(contract_path: Path, lock_path: Path) -> list[str]:
    errors: list[str] = []
    contract = _load(contract_path)
    lock = _load(lock_path)
    if not isinstance(contract, dict):
        return ["ai_contract.yaml must contain a mapping"]
    missing = sorted(MANDATORY_TOP_LEVEL - set(contract))
    if missing:
        errors.append(f"Missing mandatory top-level sections: {missing}")

    capabilities = contract.get("capabilities", [])
    if not isinstance(capabilities, list):
        errors.append("capabilities must be a list")
        capabilities = []
    names = [item.get("keyword") for item in capabilities if isinstance(item, dict)]
    duplicates = sorted({name for name in names if name and names.count(name) > 1})
    if duplicates:
        errors.append(f"Duplicate capability keywords: {duplicates}")

    live_surface = public_keyword_surface()
    live_by_name = {line.split("(", 1)[0]: line for line in live_surface}
    contract_by_name = {
        str(item.get("keyword")): str(item.get("signature"))
        for item in capabilities
        if isinstance(item, dict) and item.get("keyword")
    }
    missing_keywords = sorted(set(live_by_name) - set(contract_by_name))
    extra_keywords = sorted(set(contract_by_name) - set(live_by_name))
    if missing_keywords:
        errors.append(f"Public Robot keywords missing from contract: {missing_keywords}")
    if extra_keywords:
        errors.append(f"Contract capabilities not present in library: {extra_keywords}")
    for name in sorted(set(live_by_name) & set(contract_by_name)):
        if live_by_name[name] != contract_by_name[name]:
            errors.append(
                f"Signature mismatch for {name}: contract={contract_by_name[name]!r}, "
                f"live={live_by_name[name]!r}"
            )

    states = set(contract.get("state_machine", {}).get("states", []))
    error_names = {
        item.get("name") for item in contract.get("errors", []) if isinstance(item, dict)
    }
    for item in capabilities:
        if not isinstance(item, dict):
            errors.append("Each capability must be a mapping")
            continue
        keyword = item.get("keyword", "<unknown>")
        if item.get("risk_level") not in RISK_LEVELS:
            errors.append(f"{keyword}: invalid risk_level {item.get('risk_level')!r}")
        if item.get("blocking") not in BLOCKING:
            errors.append(f"{keyword}: invalid blocking {item.get('blocking')!r}")
        if item.get("idempotency") not in IDEMPOTENCY:
            errors.append(f"{keyword}: invalid idempotency {item.get('idempotency')!r}")
        if item.get("retry") not in RETRY:
            errors.append(f"{keyword}: invalid retry {item.get('retry')!r}")
        for state in item.get("valid_in_states", []):
            if state not in states:
                errors.append(f"{keyword}: unknown valid state {state!r}")
        resulting = item.get("resulting_state")
        if resulting not in states and resulting != "SAME":
            errors.append(f"{keyword}: unknown resulting state {resulting!r}")
        for raised in item.get("raises", []):
            if raised not in error_names:
                errors.append(f"{keyword}: unknown error reference {raised!r}")
        for coupling in item.get("coupling", []):
            if not str(coupling).startswith(("REQUIRES:", "FORBIDS:", "ORDER:", "MUTEX:")):
                errors.append(f"{keyword}: coupling has no normative prefix: {coupling!r}")

    for item in contract.get("errors", []):
        if item.get("class") not in ERROR_CLASSES:
            errors.append(f"Error {item.get('name')}: invalid class {item.get('class')!r}")
        if item.get("post_error_state") not in POST_ERROR_STATES:
            errors.append(
                f"Error {item.get('name')}: invalid post_error_state "
                f"{item.get('post_error_state')!r}"
            )
        if item.get("retry") not in RETRY:
            errors.append(f"Error {item.get('name')}: invalid retry {item.get('retry')!r}")

    objectives = contract.get("verification_objectives", [])
    for item in objectives:
        oracle = item.get("oracle") if isinstance(item, dict) else None
        if not isinstance(oracle, dict):
            errors.append(f"Verification objective {item!r} has no oracle mapping")
        elif oracle.get("type") not in ORACLE_TYPES:
            errors.append(
                f"Verification objective {item.get('id')}: invalid oracle type "
                f"{oracle.get('type')!r}"
            )

    for transition in contract.get("state_machine", {}).get("transitions", []):
        for field in ("from", "to"):
            if transition.get(field) not in states:
                errors.append(f"State transition has unknown {field}: {transition.get(field)!r}")
        capability = transition.get("via_capability")
        if capability not in contract_by_name and capability != "INTERNAL_TRANSITION":
            errors.append(f"State transition references unknown capability {capability!r}")

    expected_hash = surface_hash(live_surface)
    if not isinstance(lock, dict):
        errors.append("ai_contract.lock must contain a mapping")
    else:
        if lock.get("algorithm") != "SHA-256":
            errors.append("ai_contract.lock algorithm must be SHA-256")
        if lock.get("sha256") != expected_hash:
            errors.append(
                f"ai_contract.lock hash mismatch: lock={lock.get('sha256')}, live={expected_hash}"
            )
        if lock.get("keyword_count") != len(live_surface):
            errors.append(
                f"ai_contract.lock keyword_count mismatch: lock={lock.get('keyword_count')}, "
                f"live={len(live_surface)}"
            )
        if lock.get("surface") != live_surface:
            errors.append("ai_contract.lock normalized surface does not match live keyword surface")

    identity = contract.get("identity", {})
    if str(identity.get("driver_version")) != "26.3.0":
        errors.append("identity.driver_version must match release 26.3.0")
    if str(contract.get("rfds017_version")) != "3.0":
        errors.append("rfds017_version must be 3.0")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--contract", type=Path, default=ROOT / "ai" / "ai_contract.yaml")
    parser.add_argument("--lock", type=Path, default=ROOT / "ai" / "ai_contract.lock")
    args = parser.parse_args()
    errors = validate(args.contract, args.lock)
    if errors:
        print("RFDS-017 AI contract validation FAILED:")
        for error in errors:
            print(f"- {error}")
        return 1
    print(
        "RFDS-017 AI contract validation PASSED: "
        f"{len(public_keyword_surface())} keywords, SHA-256 {surface_hash()}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
