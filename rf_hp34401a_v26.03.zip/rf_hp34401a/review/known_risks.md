# Known risks

- Vendor VISA implementations differ in clear, timeout, lock, and USBTMC behavior.
- Serial flow control and cable topology must match the instrument configuration.
- Self-test and reset can interrupt a live production setup.
- Resistance settling depends on fixture capacitance, DUT impedance, relay path, range, and NPLC.
- The included simulation is deterministic and cannot represent all physical failure modes.
- Current measurement can open the DMM fuse or disturb the DUT when wired incorrectly.
- Resistance, continuity, and diode modes can produce invalid or unsafe interactions with an energized DUT.
- The incorporated core baseline had 73% measured line coverage before adapter work; HIL behavior cannot be established by coverage alone.
- RFDS-017 and RFDS-018 are project draft standards and may evolve; contract versioning and CI validation must be maintained.
- `examples/bench/system_ai_contract.template.yaml` is not a validated bench description. Every UNKNOWN safety, topology, and resource value must be resolved before autonomous multi-driver execution.
- The RFDS-019 simulator profile proves deterministic SCPI construction and parsing but does not reproduce vendor VISA, GPIB controller, USBTMC, cable, or RS-232 timing behavior.
- The official RFDS-019 Robot execution must be run in the release-site uv environment before the package is promoted from release-candidate status.
- Direct pre-validation of the conformance harness is diagnostic evidence only; it does not replace Robot `output.xml`, `log.html`, and `report.html`.
