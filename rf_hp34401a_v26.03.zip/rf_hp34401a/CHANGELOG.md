# Changelog

## 26.03 — 2026-07-24

- Added RFDS-019 v1.1 public-call and protocol-conformance structure.
- Added complete 69-keyword inventory and one primary vector per exported keyword.
- Added exact SCPI/transport oracles for 50 device-facing keywords and raw inbound-response capture.
- Added timeout, malformed-response, SCPI-error, calibration-blocking, and recovery vectors.
- Added timestamped Robot runners and machine-readable conformance evidence generation.
- Added conformance documentation, lifecycle gate reviews, tests, traceability, and release-candidate status.
- Preserved the 69-keyword public Robot interface and RFDS-017 interface hash.

## 26.02 — 2026-07-21

- Added the transport-neutral `Connect DMM` and `Disconnect DMM` project-standard keywords while preserving every v26.01 public keyword.
- Added `Get Driver Metadata` and `Get Driver Capabilities` for runtime discovery and multi-driver planning.
- Integrated non-keyword Python compatibility methods used by legacy orchestration libraries, including `connect_to_dmm`, `disconnect`, and `close_connection`.
- Replaced the variadic strict stable-resistance signature with an explicit Robot signature.
- Added the canonical RFDS-017 v3.0 `ai/ai_contract.yaml` covering all public keywords exactly once.
- Added `ai/ai_contract.lock`, a SHA-256 lock over the normalized public keyword surface.
- Added contract validation and CI enforcement for signatures, states, error references, enums, verification oracles, and lock staleness.
- Added an RFDS-018 `system_ai_contract.yaml` bench template with conservative `UNKNOWN` values for site-specific topology and limits.
- Added AI-contract and bench-integration documentation, tests, release records, and traceability.
- Updated versioning, Libdoc, MkDocs, packaging, and release scripts for v26.02.

## 26.01 — 2026-07-18

- Added explicit SUITE-scoped Robot Framework library.
- Added named VISA, serial, and deterministic simulated sessions.
- Added all principal 34401A measurement modes and BUS-trigger support.
- Added strict overload and invalid-reading rejection.
- Added stable-resistance strict and non-strict keywords.
- Added metadata dictionaries, assertions, health, recovery, terminal, and error keywords.
- Added 12 examples, scripts, guides, tests, Libdoc generation, CI, and GitHub Pages sources.
- Incorporated reviewed core driver version 1.2.8 without duplicating SCPI logic.
