# Release notes 26.03

Release 26.03 adds RFDS-019 v1.1 call and protocol conformance while preserving the complete v26.02 public API.

Highlights:

- complete inventory of all 69 exported Robot keywords;
- one primary callability vector per keyword;
- protocol-boundary oracles for 50 device-facing keywords;
- raw inbound-response capture before parsing;
- timeout, malformed-response, device-error, calibration-blocking, and recovery vectors;
- timestamped Robot runner and mandatory machine-readable evidence;
- RFDS Driver Implementation Lifecycle Gate 1–5 reviews;
- updated RFDS-017 metadata, README, GitHub Pages, guide, history, review, and traceability.

No public keyword was added, removed, renamed, or reordered. The RFDS-017 interface hash remains unchanged.

The package is a controlled release candidate until the official Robot RFDS-019 suite and representative real-device HIL confirmation are completed. See `history/v26.03.md`, `review/v26.03_code_review.md`, `review/v26.03_rfds019_conformance_review.md`, and `review/v26.03_validation_report.md`.
