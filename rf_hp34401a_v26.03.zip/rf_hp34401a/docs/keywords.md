# Keywords

Generate the complete HTML reference:

```powershell
python -m robot.libdoc rf_hp34401a.Hp34401ALibrary generated/libdoc/Hp34401ALibrary.html
```

## Unified platform keywords

- `Connect DMM` — select `AUTO`, `VISA`, or `SERIAL` without exposing transport internals to the test workflow.
- `Disconnect DMM` — close one alias safely.
- `Get Driver Metadata` — return package, core-driver, runtime, transport, identity, and state information.
- `Get Driver Capabilities` — return machine-readable feature flags and supported measurement functions.

The transport-specific v26.01 keywords remain stable for backward compatibility.

## Functional groups

- connection and named-session lifecycle;
- identity, model, self-test, health, status, error queue, and recovery;
- voltage, current, resistance, frequency, period, continuity, and diode configuration;
- immediate and BUS-triggered acquisition;
- strict and non-strict stable resistance;
- complete last-reading metadata;
- inclusive limits and absolute/relative tolerance assertions;
- guarded raw SCPI.

Every public keyword and exact signature appears once in `ai/ai_contract.yaml`. CI rejects interface/contract drift.
