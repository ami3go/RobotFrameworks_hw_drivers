# RF HP34401A 26.03

Production-oriented Robot Framework control for the HP/Agilent/Keysight 34401A DMM.

The library keeps the reviewed SCPI implementation in the core Python driver and adds explicit Robot keywords, named sessions, deterministic simulation, assertions, measurement metadata, unified metadata/capability discovery, and RFDS-017 AI planning data.

Start with [Installation](installation.md), then [Quick start](quick_start.md). For AI-generated multi-instrument plans, read [AI driver and bench contracts](ai_contract.md).

## Qualification

Software-only validation and simulator validation are complete. Real-hardware VISA/GPIB, RS-232, long-duration, and site-specific RFDS-018 bench qualification remain pending.

## Protocol conformance

Release 26.03 provides RFDS-019 v1.1 inventory, vectors, transport traces, error/recovery checks, and timestamped evidence. See [RFDS-019 conformance](conformance.md).
