# Release notes 26.04

Release 26.04 expands the driver from the RFDS-017/RFDS-019 baseline to the current project API, capability, configuration, plugin, error, evidence, and package requirements.

## Added

- RFDS-002 canonical universal and multi-session keyword groups;
- RFDS-013 static/effective capability model and discovery APIs;
- RFDS-014 JSON schema, defaults, profiles, import/export, validation, explicit persistence, and fingerprinting;
- RFDS-015 side-effect-free plugin provider, manifest, and entry point;
- RFDS-007 structured error codes and Robot-facing diagnostics;
- guarded raw I/O requiring explicit authorization;
- 108-keyword RFDS-002 inventory, RFDS-017 contract, and RFDS-019 vector synchronization;
- `tests/hil/verify_all_public_api_real_hardware.robot` and cross-platform runners;
- per-keyword real-hardware PASS/FAIL/EXCLUDED/NOT RUN evidence;
- release manifest, SBOM, compatibility, traceability, and validation records;
- example 13 demonstrating canonical lifecycle, discovery, and configuration.

## Compatibility

All v26.03 DMM-specific Robot keywords remain present. Python `connect_to_dmm()` compatibility remains available for existing matrix orchestration code. `Get Driver Capabilities` now follows RFDS-002 and returns a sorted list of capability identifiers; the detailed RFDS-013 object is returned by `Get Driver Capability Model`.

## Release status

D0 development candidate. Real VISA/GPIB and RS-232 all-API verification is included but not represented as executed. Shared `rfds-core` adoption and full RFDS-004 v2.0 byte-transport migration remain controlled deviations for a later architectural release.
