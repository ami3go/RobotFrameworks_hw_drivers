# RF HP34401A 26.04

RFDS Robot Framework driver for the HP/Agilent/Keysight 34401A DMM.

Release 26.04 adds the canonical RFDS-002 lifecycle, RFDS-013 capability discovery, RFDS-014 JSON configuration, RFDS-015 plugin metadata, structured RFDS-007 errors, and a real-hardware Robot suite that accounts for all 108 public keywords.

**Qualification:** D0 development candidate. Real-device qualification is pending execution of the packaged HIL profile.

Start with [Installation](installation.md), [Quick start](quick_start.md), and [Real-hardware all-API verification](real_hardware_api_verification.md).
