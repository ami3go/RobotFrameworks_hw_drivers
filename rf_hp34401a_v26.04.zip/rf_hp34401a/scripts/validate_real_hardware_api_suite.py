#!/usr/bin/env python3
"""Verify that the real-hardware Robot suite accounts for every public keyword."""

from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
API = ROOT / "api" / "public_api.yaml"
SUITE = ROOT / "tests" / "hil" / "verify_all_public_api_real_hardware.robot"


def validate() -> list[str]:
    errors: list[str] = []
    api = json.loads(API.read_text(encoding="utf-8"))
    names = [str(item["name"]) for item in api["keywords"]]
    text = SUITE.read_text(encoding="utf-8")
    missing = [name for name in names if name not in text]
    if missing:
        errors.append(f"Public keywords missing from real-HIL suite: {missing}")
    required_controls = [
        "${HIL_ENABLED}", "${FAIL_ON_EXCLUSIONS}", "${VISA_RESOURCE}",
        "Exclude Real Hardware API Keywords", "Finalize Real Hardware API Coverage",
        "Suite Teardown", "RUN_DC_VOLTAGE_PROFILE", "RUN_RAW_IO_PROFILE",
        "RUN_RESET_PROFILE", "RUN_SERIAL_PROFILE",
    ]
    for control in required_controls:
        if control not in text:
            errors.append(f"Missing required HIL control {control!r}")
    if "Open Simulated DMM" not in text:
        errors.append("The simulator-only public API must remain explicitly accounted for")
    return errors


def main() -> int:
    errors = validate()
    if errors:
        print("Real-hardware all-API suite validation FAILED")
        for error in errors:
            print(f"- {error}")
        return 1
    count = len(json.loads(API.read_text(encoding="utf-8"))["keywords"])
    print(f"Real-hardware all-API suite validation PASSED: {count}/{count} keyword names accounted for")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
