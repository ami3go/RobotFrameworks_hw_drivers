# Troubleshooting

- **Identity mismatch:** confirm that the resource points to a 34401A and not another instrument.
- **Timeout:** verify termination, serial flow control, GPIB address, and vendor connection utility operation.
- **Overload:** select a suitable range and inspect DUT wiring; the library intentionally does not return a scalar.
- **Unstable resistance:** increase settling time, NPLC, window size, or stability thresholds based on fixture behavior.
- **Calibration command blocked:** use reviewed calibration tooling and explicitly enable calibration commands only for authorized procedures.
- **BUS trigger failure:** configure a measurement before triggering and use the complete safe sequence.
