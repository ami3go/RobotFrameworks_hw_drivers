# Release notes 26.05

Release 26.05 is a backward-compatible HIL orchestration hotfix over v26.04.

## Fixed

- Robot command-line variables such as `HIL_ENABLED:true` are now normalized before Boolean assertions or `IF` expressions.
- All `RUN_*_PROFILE` and `FAIL_ON_EXCLUSIONS` values accept case-insensitive `true/false`, `yes/no`, `on/off`, and `1/0`.
- Invalid Boolean values fail closed before hardware access.
- PowerShell and Linux HIL launchers now emit canonical `True`/`False`.
- Suite teardown no longer reports every API as `NOT RUN` when mandatory preflight fails before coverage starts.

## Compatibility

The 108-keyword public Robot API is unchanged from v26.04. SCPI behavior, measurement logic, configuration schemas, capability identifiers, and legacy E-Resistor compatibility methods are unchanged.

## Release status

D0 development candidate. The corrected real-hardware suite must be executed in the user's Robot/uv environment. Real VISA/GPIB and RS-232 qualification are not claimed by the source package.
