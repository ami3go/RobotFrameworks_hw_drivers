# RF HP34401A 26.05

RFDS Robot Framework driver for the HP/Agilent/Keysight 34401A DMM.

Release 26.05 corrects Boolean command-line variable handling in the all-public-API real-hardware verification suite. It preserves the complete 108-keyword v26.04 API and all existing driver behavior.

**Qualification:** D0 development candidate. Real-device qualification is pending execution of the corrected packaged HIL profile.

Start with [Installation](installation.md), [Quick start](quick_start.md), and [Real-hardware all-API verification](real_hardware_api_verification.md).
