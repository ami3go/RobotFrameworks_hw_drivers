param(
    [Parameter(Mandatory=$true)][string]$VisaResource,
    [string]$OutputRoot = "results/real_hardware_all_api",
    [string]$SerialPort = "",
    [switch]$FailOnExclusions,
    [string[]]$ExtraRobotArgs = @()
)
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$stamp = (Get-Date).ToUniversalTime().ToString("yyyyMMddTHHmmssZ")
$out = Join-Path $root "$OutputRoot/rf_hp34401a/$stamp"
New-Item -ItemType Directory -Force $out | Out-Null
$args = @(
    "--outputdir", $out,
    "--variable", "HIL_ENABLED:True",
    "--variable", "VISA_RESOURCE:$VisaResource",
    "--variable", "SERIAL_PORT:$SerialPort",
    "--variable", "FAIL_ON_EXCLUSIONS:$($FailOnExclusions.IsPresent.ToString())"
) + $ExtraRobotArgs + @("$root/tests/hil/verify_all_public_api_real_hardware.robot")
& robot @args
exit $LASTEXITCODE
